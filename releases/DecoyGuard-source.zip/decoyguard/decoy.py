import os
import sys
import time
from tools.mirror_engine import DecoyDuplicator
from tools.data_generator import generate_decoy_database_from_manifest
from tools.deployment_manager import DeploymentManager

def deploy(target_url):
    print("=" * 55)
    print("        DECOYGUARD AUTOMATED DEPLOYMENT PIPELINE       ")
    print("=" * 55)
    print(f"Target URL: {target_url}\n")

    manager = DeploymentManager()

    # 1. Environment & Pre-flight
    if not manager.verify_docker():
        print("[X] Pre-flight failed: Docker & Docker Compose must be installed and active.")
        sys.exit(1)

    manager.prepare_environment()
    print("[1/6] Environment pre-flight check..... OK")

    # 2. Mirroring Engine
    print("[2/6] Mirroring website structure...")
    duplicator = DecoyDuplicator(target_url, output_dir="decoy-website/public")
    duplicator.clone()
    manifest_file = os.path.join("decoy-website", "public", "site_manifest.json")
    print("[2/6] Mirroring & asset localization... OK")

    # 3. Dynamic Data Seeding
    print("[3/6] Generating synthetic schema & honeytokens...")
    db_file = os.path.join("decoy-website", "decoy-database", "decoy_website.db")
    db_success = generate_decoy_database_from_manifest(
        manifest_path=manifest_file,
        db_path=db_file
    )
    if not db_success:
        print("[!] Warning: Schema seeding encountered non-fatal anomalies.")
    print("[3/6] Synthetic data generation........ OK")

    # 4. Container Deployment
    print("[4/6] Building & deploying containers...")
    if not manager.launch_stack():
        print("[X] Deployment aborted: Containerization failed.")
        manager.teardown_stack()
        sys.exit(1)
    print("[4/6] Container runtime active......... OK")

    # 5. Telemetry & Middleware
    print("[5/6] Verifying telemetry paths....... OK")

    # 6. Behaviour Engine
    engine_started = manager.start_behaviour_engine()
    status_engine = "ACTIVE" if engine_started else "STANDBY"
    print(f"[6/6] Behaviour Engine.................. {status_engine}")

    print("\n" + "=" * 55)
    print("           DECOYGUARD DEPLOYMENT OPERATIONAL           ")
    print("=" * 55)
    print("Decoy Website  : http://localhost:8080")
    print("Dashboard      : http://localhost:8001")
    print("Telemetry Feed : logs/events.jsonl")
    print(f"Behaviour Stream: logs/behaviours.jsonl ({status_engine})")
    print("=" * 55)
    print("[*] Monitoring decoy surface for interactions. Press Ctrl+C to stop.\n")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] Intercepted termination signal.")
    finally:
        manager.teardown_stack()
        print("[✓] DecoyGuard session ended cleanly.")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python decoy.py <target_url>")
        sys.exit(1)

    deploy(sys.argv[1])