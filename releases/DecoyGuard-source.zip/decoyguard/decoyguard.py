"""
===============================================================
                    DecoyGuard Core Engine
===============================================================

Core Responsibilities:

- Monitor Nginx JSON logs
- Parse HTTP events
- Track visitor behaviour
- Pass events through the analysis pipeline
- Calculate cumulative threat scores
- Classify attack severity
- Make routing decisions
- Export structured security alerts
- Feed alerts to the dashboard
- Prepare traffic for future honeypot redirection

===============================================================
"""

import json
import os
import signal
import sys
import shutil
import stat
import time
import subprocess
import io
import re
import ipaddress
import uuid
from collections import deque
from urllib.parse import urlsplit, urlunsplit
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone

from core.profiler import Profiler
from core.analyzer import Analyzer
from core.router import Router
from core.logger import Logger
from core.exporter import Exporter
from core.log_parser import Parser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ===============================================================
# LOG CONFIGURATION
# ===============================================================
LOG_FILE = os.path.join(BASE_DIR, "logs", "access.json")
TELEMETRY_LOG_FILE = os.path.join(BASE_DIR, "logs", "events.jsonl")
DASHBOARD_LOG_FILE = os.path.join(BASE_DIR, "logs", "alerts.jsonl")

def show_diagnostics():
    """Report saved capture and syslog evidence without starting or changing services."""
    def read_json(path):
        try:
            with open(path, encoding='utf-8') as stream:
                value = json.load(stream)
            return value if isinstance(value, dict) else None
        except (OSError, ValueError):
            return None

    print('\n=== DecoyGuard diagnostics ===')
    registry = read_json(os.path.join(BASE_DIR, 'logs', 'website_registry.json'))
    sites = registry.get('sites', {}) if registry else {}
    if not isinstance(sites, dict) or not sites:
        print('Mirrors: no saved site registry found or no sites configured.')
    else:
        print('Mirrors (saved capture evidence; not a live connectivity test):')
        for site_id, site in sites.items():
            if not isinstance(site, dict):
                continue
            print(f"  {site.get('name', site_id)} [{site_id}]: {site.get('status', 'unknown')}")
            if site.get('error'):
                print(f"    Last error: {str(site['error'])[:300]}")
            root = site.get('root')
            if not isinstance(root, str) or not root:
                print('    Capture manifest: site root unavailable.')
                continue
            base = os.path.realpath(BASE_DIR)
            candidate = os.path.realpath(os.path.join(base, root))
            if not candidate.startswith(base + os.sep):
                print('    Capture manifest: site root is outside the project.')
                continue
            manifest = read_json(os.path.join(candidate, 'public', 'site_manifest.json'))
            if manifest is None:
                print('    Capture manifest unavailable; inspect capture logs.')
                continue
            print(f"    Recorded pages: {manifest.get('pages_mirrored', 'not reported')}; "
                  f"discovered routes: {len(manifest.get('discovered_routes') or [])}; "
                  f"on-demand capture: {'enabled' if manifest.get('on_demand') else 'not reported or disabled'}")
            print('    Counts do not verify styling, assets, interactions or current availability.')

    print('Syslog collector (last saved health snapshot):')
    health = read_json(os.path.join(BASE_DIR, 'logs', 'syslog-health.json'))
    if not health:
        print('  No health snapshot found. Start DecoyGuard and check again.')
        return
    updated = health.get('updated_at')
    try:
        stamp = datetime.fromisoformat(str(updated).replace('Z', '+00:00'))
        if stamp.tzinfo is None:
            raise ValueError('timestamp has no timezone')
        age = (datetime.now(timezone.utc) - stamp.astimezone(timezone.utc)).total_seconds()
        freshness = 'recent' if 0 <= age <= 20 else 'stale or clock differs'
    except (ValueError, TypeError, OverflowError):
        freshness = 'unknown'
    print(f"  State: {health.get('state', 'unknown')} | Updated: {updated or 'unknown'} ({freshness})")
    print(f"  Accepted: {health.get('accepted', 'unknown')} | Rejected: {health.get('rejected', 'unknown')} | Last accepted: {health.get('last_received_at') or 'none reported'}")
    if health.get('error'):
        print(f"  Error: {str(health['error'])[:300]}")
    print('  A recent snapshot is not proof of live delivery; verify with a new test event.')

def run_mirror(target_url):
    print("\n[2/5] Mirroring target website...")
    print(f"      Target: {target_url}")

    mirror_script = os.path.join(BASE_DIR, "tools", "mirror_engine.py")

    result = subprocess.run(
        [sys.executable, mirror_script, target_url],
        cwd=BASE_DIR
    )

    if result.returncode != 0:
        print("\n[!] Mirror failed.")
        sys.exit(1)

    print("\n[✓] Website mirror completed.")
    return True

def run_data_generator():
    print("\n[3/5] Generating synthetic decoy data...")

    result = subprocess.run(
        [sys.executable, "-m", "tools.data_generator"],
        cwd=BASE_DIR
    )

    if result.returncode != 0:
        print("\n[!] Data generation failed.")
        sys.exit(1)

    print("\n[✓] Synthetic decoy data generated.")
    return True


class DecoyGuard:
    def __init__(self):
        self.running = True
        self.stats = {
            "connections": 0,
            "processed": 0,
            "honeypot_hits": 0,
            "pivots_detected": 0,
            "errors": 0
        }

        # First-Line Security Pipeline
        self.profiler = Profiler()
        self.decoy_profiler = Profiler()
        self.site_profilers = {}
        self.scan_episodes = {}
        self.seen_events = set()
        self.seen_order = deque()
        self.analyzer = Analyzer()
        self.router = Router()
        self.logger = Logger()
        self.exporter = Exporter()
        self.log_parser = Parser()

    def start(self):
        self.ensure_log_exist()
        signal.signal(signal.SIGINT, self.shutdown)

        print("[+] Monitoring Nginx log for new requests...")
        print("[+] DecoyGuard first-line pipeline active...\n")

        from core.event_stream import EventStreams
        streams = EventStreams([LOG_FILE, TELEMETRY_LOG_FILE, os.path.join(BASE_DIR, "logs", "behaviour_events.jsonl")])
        try:
            while self.running:
                for raw_event in streams.poll():
                    try:
                        if raw_event.get("engine") == "Behaviour Engine":
                            if int(raw_event.get("risk_score", 0) or 0) >= 40:
                                self.apply_honeypot_route(raw_event.get("source_ip"), raw_event.get("site_id"), raw_event.get("event_type", "Behaviour detection"))
                            continue
                        if raw_event.get("target_type") == "dashboard":
                            continue
                        # Keep benign decoy interactions in raw telemetry, not alert output.
                        if (raw_event.get("source") == "decoy-web" and
                                raw_event.get("target_type") == "decoy" and
                                not raw_event.get("canary_hit") and
                                int(raw_event.get("risk_score", 0) or 0) == 0 and
                                str(raw_event.get("severity", "INFO")).upper() == "INFO"):
                            continue
                        path = str(raw_event.get("uri", ""))
                        if raw_event.get("target_type") == "decoy" and raw_event.get("source") not in ("decoy-web", "gateway-decision"):
                            # PHP provides the body-aware event for document/API requests.
                            # Nginx still supplies errors and probes targeting static assets.
                            asset = re.search(r"\.(js|css|png|jpg|svg|ico|woff2?|json|map)$", path, re.I)
                            if not asset and int(raw_event.get("status", 200)) < 400:
                                continue
                            if asset and not raw_event.get("args") and int(raw_event.get("status", 200)) < 400:
                                continue
                        if int(raw_event.get("status", 200)) < 400 and raw_event.get("source") != "gateway-decision" and raw_event.get("target_type") == "production" and raw_event.get("method") in ("GET", "HEAD") and path in ("/", "/dashboard.php", "/dashboard2.php", "/api.php", "/honeypot_queue.php"):
                            continue
                        parsed_event = self.log_parser.parse_web_log(raw_event)
                        if not parsed_event:
                            continue
                        event_id = parsed_event.get("event_id")
                        if event_id and event_id in self.seen_events:
                            continue
                        if event_id:
                            self.seen_events.add(event_id)
                            self.seen_order.append(event_id)
                            if len(self.seen_order) > 4096:
                                self.seen_events.discard(self.seen_order.popleft())
                        if (int(parsed_event.get("status", 200)) < 400 and not parsed_event.get("risk_score") and
                                (re.search(r"\.(?:js|mjs|css|png|jpe?g|svg|ico|woff2?|map)$", path, re.I) or path.startswith("/socket.io"))):
                            continue
                        self.process_event(parsed_event)
                        self.stats["connections"] += 1
                    except Exception as error:
                        self.stats["errors"] += 1
                        print(f"[!] Pipeline processing error: {error}")
                time.sleep(0.1)
        finally:
            streams.close()

    def process_event(self, event):
        # Step 1: Normalize incoming request object
        request = self.build_request(event)

        # -------------------------------------------------------------
        # ISOLATION: Trap honeypot hits immediately
        # -------------------------------------------------------------
        if request.get("target_type") == "honeypot":
            self.stats["processed"] += 1
            self.stats["honeypot_hits"] += 1

            honeypot_alert = {
                "engine": "DecoyGuard-Honeypot",
                "timestamp": request["timestamp"],
                "incident_id": f"DG-TRAP-{request['ip'].replace('.', '')[-4:]}",
                "source_ip": request["ip"],
                "target_type": "honeypot",
                "request": request["request"],
                "status": request["status"],
                "user_agent": request["user_agent"],
                "risk_score": 100,
                "severity": "HIGH",
                "confidence": "HIGH",
                "attack_type": "Honeypot Decoy Interaction",
                "attack_stage": "CONTAINED",
                "reasons": ["Attacker interacting inside isolated honeypot container"],
                "immediate_threat": False,
                "recommended_action": "ISOLATE",
                "decision": "CONTAINED",
                "route": "honeypot",
                "priority": "HIGH",
                "routing_reason": "Attacker trapped in honeypot sandbox",
                "profile_history": {
                    "total_seen_requests": 0,
                    "total_directory_errors": 0,
                    "honeypot_hits": self.stats["honeypot_hits"]
                },
                "risk_breakdown": {
                    "honeypot": {"score": 100, "findings": 1}
                },
                "risk_calculation": [
                    {
                        "engine": "Honeypot Sandbox",
                        "score": 100,
                        "details": ["Target isolated in decoy container"]
                    }
                ],
                "forensics": request.get("forensics", {}),
                "analysis_time": datetime.now().isoformat()
            }

            self.export(honeypot_alert)
            self.write_dashboard_log(honeypot_alert)
            try:
                pass  # Already persisted by write_dashboard_log
            except Exception as e:
                print(f"[!] Logger error: {e}")
            return

        # -------------------------------------------------------------
        # PRODUCTION PIPELINE: Only evaluates real web server traffic
        # -------------------------------------------------------------
        # Step 2: Track behavioural state
        if request.get("site_id"):
            key = (request["target_type"], request["site_id"])
            profiler = self.site_profilers.setdefault(key, Profiler())
        else:
            profiler = self.decoy_profiler if request.get("target_type") == "decoy" else self.profiler
        profile = profiler.update(request)

        # Step 3: Analyze threat score and signatures
        analysis = self.analyzer.analyze(request, profile)
        if event.get("canary_hit"):
            analysis["risk_score"] = max(95, analysis.get("risk_score", 0))
            analysis["severity"] = "HIGH"
            analysis["attack_type"] = "Canary Parameter Tampering"
            analysis.setdefault("reasons", []).append("Submitted value matched a generated canary")

        # Retain trusted local middleware detections even if its signature vocabulary
        # is more complete than the core analyzer's. These are local log records.
        if event.get("source") in ("decoy-web", "gateway-decision") and int(event.get("risk_score", 0) or 0) > 0:
            analysis["risk_score"] = max(int(event["risk_score"]), analysis.get("risk_score", 0))
            if analysis.get("attack_type") in (None, "NONE", "Normal Traffic", "Unknown", "NORMAL"):
                analysis["attack_type"] = event.get("attack_type", "Decoy Detection")
            if analysis["risk_score"] >= 60 and analysis.get("severity") in ("SAFE", "LOW", "INFO", "MEDIUM"):
                analysis["severity"] = "HIGH"
            analysis.setdefault("reasons", []).append("Local decoy middleware detected " + str(event.get("attack_type", "suspicious input")))
        # Ordinary polling/browsing remains telemetry, not an incident.
        if ((analysis.get("risk_score", 0) == 0 or (
                analysis.get("attack_type") in ("Normal Traffic", "NORMAL_TRAFFIC", "NONE")
                and not analysis.get("risk_breakdown", {}).get("signature", {}).get("findings")
                and not event.get("canary_hit") and not event.get("security_finding")))
                and not analysis.get("immediate_threat")):
            self.stats["processed"] += 1
            return

        # Step 4: Determine routing mitigation
        routing = self.router.decide(analysis)
        if analysis.get('verified_ownership_violation'):
            routing.update(route='HONEYPOT', decision='REDIRECT',
                           priority='P2 - High Priority',
                           reason='Application verified an object ownership violation')

        # Step 5: Dynamic Honeypot Shunt Trigger
        if request.get("target_type") == "decoy":
            routing.update(route="HONEYPOT", decision="CONTAINED", reason="Local decoy request observed")
            analysis["recommended_action"] = "MONITOR_DECOY"
        elif routing.get("route") == "HONEYPOT":
            if not self.apply_honeypot_route(request["ip"], request.get("site_id"), routing.get("reason", "Core detection")):
                routing.update(route="REAL_SERVER", decision="MONITOR", reason="No configured gateway route was applied")

        # Step 6: Build final alert payload
        output = self.build_output(request, profile, analysis, routing)

        # Keep routing above active for every request. Only coalesce scanner-only output;
        # SQLi, XSS, traversal and application ownership findings remain separate incidents.
        exploit = re.search(r"sql|cross.site|xss|traversal|execution|tamper|canary|ownership", str(output.get("attack_type", "")), re.I)
        scan = re.search(r"scanner|scan|enumerat|probe", str(output.get("attack_type", "")), re.I)
        if scan and not exploit:
            now = time.monotonic()
            key = (request.get("site_id"), request.get("target_type"), request.get("ip"))
            previous = self.scan_episodes.get(key)
            self.scan_episodes = {k:v for k,v in self.scan_episodes.items() if now-v < 120}
            if len(self.scan_episodes) >= 4096:
                self.scan_episodes.pop(next(iter(self.scan_episodes)))
            self.scan_episodes[key] = now
            if previous is not None and now-previous < 120:
                self.stats["processed"] += 1
                return
        # Step 7: Export to console
        self.export(output)

        # Step 8: Write structured alert for Dashboard
        self.write_dashboard_log(output)

        # Step 9: Persist to DecoyGuard audit logger
        try:
            pass  # Already persisted by write_dashboard_log
        except Exception as e:
            print(f"[!] Logger error: {e}")

        # write_dashboard_log is the single owner of alerts.jsonl.
        # Exporter.send also writes that same file; do not append a second copy.

        # Step 11: Update engine statistics
        self.stats["processed"] += 1
        if "PIVOT" in analysis.get("attack_stage", ""):
            self.stats["pivots_detected"] += 1

    def build_request(self, event):
        return {
            "timestamp": event.get("timestamp", datetime.now().isoformat()),
            "ip": event.get("remote_addr", event.get("ip", "Unknown")),
            "request": event.get("request", ""),
            "status": str(event.get("status", "")),
            "method": event.get("method", ""),
            "fields": event.get("fields", {}),
            "args": event.get("args", ""),
            "user_agent": event.get("user_agent", ""),
            "target_type": event.get("target_type", "unknown"),
            "site_id": event.get("site_id", ""),
            "exploit_result": event.get("exploit_result"),
            "security_finding": event.get("security_finding"),
            "source": event.get("source", ""),
            "forensics": event.get("forensics", {}),
            "detection_text": event.get("detection_text", ""),
            "event_id": event.get("event_id"),
            "raw": event
        }

    def build_output(self, request, profile, analysis, routing):
        return {
            "engine": "DecoyGuard",
            "timestamp": request["timestamp"],
            "incident_id": request.get("event_id") or analysis.get("incident_id", "N/A"),
            "source_ip": request["ip"],
            "target_type": request["target_type"],
            "site_id": request.get("site_id", ""),
            "exploit_result": request.get("exploit_result"),
            "security_finding": request.get("security_finding"),
            "request": request["request"],
            "status": request["status"],
            "user_agent": request["user_agent"],
            "risk_score": analysis.get("risk_score", 0),
            "severity": analysis.get("severity", "LOW"),
            "confidence": analysis.get("confidence", "LOW"),
            "attack_type": analysis.get("attack_type", "NONE"),
            "attack_stage": analysis.get("attack_stage", "NORMAL"),
            "reasons": analysis.get("reasons", []),
            "immediate_threat": analysis.get("immediate_threat", False),
            "recommended_action": analysis.get("recommended_action", "MONITOR"),
            "decision": routing.get("decision", "ALLOW"),
            "route": routing.get("route", "production"),
            "priority": routing.get("priority", "NORMAL"),
            "routing_reason": routing.get("reason", ""),
            "profile_history": {
                "total_seen_requests": profile.get("total_requests", 0),
                "total_directory_errors": profile.get("error_40x_count", 0),
                "honeypot_hits": profile.get("honeypot_hit_count", 0)
            },
            "risk_breakdown": analysis.get("risk_breakdown", {}),
            "risk_calculation": analysis.get("risk_calculation", ""),
            "forensics": analysis.get("forensics", request.get("forensics", {})),
            "analysis_time": analysis.get("analysis_time", datetime.now().isoformat())
        }

    def write_dashboard_log(self, output):
        try:
            with open(DASHBOARD_LOG_FILE, "a", encoding="utf-8") as dashboard_log:
                dashboard_log.write(json.dumps(output) + "\n")
        except Exception as e:
            print(f"[!] Dashboard log error: {e}")

    def export(self, data):
        # Keep the full event in the existing logs; console output stays concise.
        severity = str(data.get('severity', 'INFO')).replace('\n', ' ')
        attack = str(data.get('attack_type', 'Security event')).replace('\n', ' ')
        site = str(data.get('site_id', 'unknown')).replace('\n', ' ')
        decision = str(data.get('decision', 'MONITOR')).replace('\n', ' ')
        print(f"[ALERT] {severity} | {site} | {attack} | {decision}")

    # ---> NEW DYNAMIC ROUTING METHOD <---
    def apply_honeypot_route(self, ip, site_id=None, reason="Detection engine decision"):
        """Publish a site-scoped decision consumed by the gateway on the next request."""
        try:
            ipaddress.ip_address(ip)
            config_path = os.path.join(BASE_DIR, 'decoy-website', 'private', 'gateway_sites.json')
            with open(config_path, encoding='utf-8') as source:
                config = json.load(source)
            if not site_id or site_id not in config.get('sites', {}):
                return False
            decision = {'deployment_id':config['deployment_id'], 'site_id':site_id,
                        'ip':ip, 'expires':int(time.time()) + 7200, 'reason':str(reason)[:500]}
            with open(os.path.join(BASE_DIR, 'logs', 'routing_decisions.jsonl'), 'a', encoding='utf-8') as feed:
                feed.write(json.dumps(decision) + '\n')
            print(f'[ROUTING] {site_id}: subsequent requests from {ip} will use its decoy ({reason}).')
            return True
        except (OSError, ValueError, TypeError, KeyError) as error:
            print(f'[!] Could not apply gateway routing decision: {error}')
            return False


    def ensure_log_exist(self):
        for path in (LOG_FILE, TELEMETRY_LOG_FILE, DASHBOARD_LOG_FILE):
            dir_path = os.path.dirname(path)
            if dir_path:
                os.makedirs(dir_path, exist_ok=True)
            if not os.path.exists(path):
                open(path, "w", encoding="utf-8").close()

    def shutdown(self, sig, frame):
        print(f"\n{'=' * 60}\nDecoyGuard Engine Shutting Down...\n{'=' * 60}")
        print(json.dumps(self.stats, indent=4))
        print("=" * 60)
        self.running = False
        sys.exit(0)

def reset_decoy_website(output_dir=None):
    """
    Completely remove the previous mirrored website before a newDecoyGuard deployment starts.
    Never allow stale files from one target to contaminate another.
    """
    output_dir = output_dir or os.path.join(BASE_DIR,"decoy-website","public")
    print("[*] Removing previous decoy website...")
    def force_delete(func, path, _exc):
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception:
            pass
    if os.path.lexists(output_dir):
        last_error = None
        for attempt in range(5):
            try: 
                shutil.rmtree(output_dir,onerror=force_delete)
                last_error = None
                break
            except FileNotFoundError:
                last_error = None
                break
            except OSError as exc:
                last_error = exc
                time.sleep(0.25 * (attempt + 1))
        # Never continue with a half-deleted mirror.
        if os.path.lexists(output_dir):
            raise RuntimeError("Could not completely delete previous mirror: "f"{output_dir}. Last error: {last_error}")
    os.makedirs(output_dir,exist_ok=False)
    print("[✓] Previous decoy website removed.")

if __name__ == "__main__":
    import sys

    import argparse
    os.chdir(BASE_DIR)
    cli=argparse.ArgumentParser(description='Configure up to eight website pairs and start their protected gateways.')
    cli.add_argument('target_url',nargs='?')
    cli.add_argument('--banking-url')
    cli.add_argument('--site-id',help='Unique ID for a new website (existing mirrors are retained)')
    cli.add_argument('--saved',action='store_true',help='Resume saved website configuration')
    cli.add_argument('--dashboard-only',action='store_true',help='Start the dashboard and add websites through its form')
    cli.add_argument('--static',action='store_true')
    cli.add_argument('--backend-profile',default=None)
    cli.add_argument('--diagnostics', action='store_true', help='Show saved mirror and syslog health information without starting services')
    options=cli.parse_args()
    if options.diagnostics:
        show_diagnostics()
        sys.exit(0)
    from tools.deployment_manager import DeploymentManager
    from tools.mirror_engine import DecoyDuplicator
    from tools.data_generator import generate_decoy_database_from_manifest
    manager=DeploymentManager()
    print("=" * 60)
    print("              DecoyGuard Core Engine v4.0")
    print("=" * 60)
    print("Status              : DEPLOYING")
    print("Deployment Mode     : " + ("SAVED WEBSITES" if options.saved else ("WEBSITE HANDLER" if options.dashboard_only else "WEBSITE DEPLOYMENT")))
    if options.target_url: print("Target Website      : " + options.target_url)
    print("=" * 60)
    print()
    try:
        print("[1/7] Environment pre-flight check...", flush=True)
        if not manager.verify_docker(): raise RuntimeError('Docker verification failed')
        manager.prepare_environment()
        print("[✓] Environment ready.")
        print("[2/7] Loading website configuration...", flush=True)
        registry=manager.load_site_registry()
        print(f"[✓] {len(registry['sites'])}/8 website pairs configured.")
        print("[3/7] Preparing mirrors and synthetic data...", flush=True)
        retained=sum(bool(site.get('capture_ready')) for site in registry['sites'].values())
        print(f"[✓] {retained} saved mirrors retained with their existing data.")
        if not (options.saved or options.dashboard_only):
            print("[*] New website capture and data generation will run during deployment.")
        print("[4/7] Container infrastructure and deployment...", flush=True)
        # Adopt existing captures and resume without deleting any decoy data.
        manager.render_site_configuration(registry)
        if not manager.launch_stack(): raise RuntimeError('Initial container or worker readiness failed')
        if not (options.saved or options.dashboard_only):
            target=options.target_url or 'http://localhost:3000'
            source=urlsplit(target)
            site_id=options.site_id or ('juiceshop' if source.hostname in ('localhost','127.0.0.1') and source.port==3000 else re.sub(r'[^a-z0-9-]','-',source.hostname or 'website')[:31].strip('-'))
            if not site_id or not site_id[0].isalpha(): site_id=('site-'+site_id)[:31]
            payload={'site_id':site_id,'name':site_id,'source_url':target,'backend_profile':options.backend_profile,'static':options.static}
            manager.deploy_registered_site(payload)
            if options.banking_url:
                manager.deploy_registered_site({'site_id':'banking','name':'Banking','source_url':options.banking_url,'backend_profile':'banking'})
        print("[✓] Website infrastructure ready.")
        print("[5/7] Behaviour Engine...", flush=True)
        if not manager.start_behaviour_engine(): raise RuntimeError('Behaviour Engine failed to start')
        print("[✓] Behaviour Engine started.")
        print("[*] For saved mirror and syslog health details, run: python decoyguard.py --diagnostics")
        print("[6/7] Core Engine...", flush=True)
        engine=DecoyGuard()
        print("[✓] Core Engine ready.")
        print("[7/7] Deployment complete...", flush=True)
        manager.start_site_controller()
        print("[✓] Website Handler controller started.")
        print()
        print("=" * 60)
        print("              DecoyGuard Core Engine v4.0")
        print("=" * 60)
        print("Status              : ACTIVE")
        print("Telemetry Log       : logs/events.jsonl")
        print("Detection Feed      : logs/alerts.jsonl")
        print("Honeypot Layer      : READY / REQUEST ROUTING ENABLED")
        print("Behavioral Layer    : ACTIVE / REAL-TIME MONITORING")
        print("=" * 60)
        print()
        print("Dashboard      : http://localhost")
        print("Website Handler: http://localhost/website_handler.php")
        for site in manager.load_site_registry()['sites'].values():
            print(f"{site['name']} [{site['site_id']}] — {site['status']}")
            print(f"  Gateway      : http://localhost:{site['gateway_port']}")
            print(f"  Decoy        : http://localhost:{site['decoy_port']}")
        print()
        print("[*] DecoyGuard is monitoring security events.")
        print("[*] Website Handler can deploy additional websites while monitoring continues.")
        print("[*] Press Ctrl+C to stop.")
        print()
        engine.start()
    except KeyboardInterrupt:
        print('\n[*] DecoyGuard shutdown requested.')
    except Exception as error:
        print('[!] Deployment failed: '+str(error))
    finally:
        manager.teardown_stack()
