<?php
if (!defined('DG_DASHBOARD_PAGE')) define('DG_DASHBOARD_PAGE', true);
require_once __DIR__ . '/api.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DecoyGuard — Honeypot Queue & Deception Forensics</title>

    <link rel="stylesheet" href="soc_theme.css?v=<?= filemtime(__DIR__.'/soc_theme.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --cyan: #20d9ff;
            --purple: #9b6cff;
            --pink: #ff3b9d;
            --green: #35e887;
            --lime: #c7ff32;
            --bg: #050811;
            --panel: #080d1e;
            --panel-inner: #040712;
            --line: rgba(71, 85, 105, 0.22);
            --muted: #64748b;
            --text: #e2e8f0;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            background-color: var(--bg);
            color: var(--text);
            font-family: 'Plus Jakarta Sans', sans-serif;
            overflow-x: hidden;
        }
        .mono { font-family: 'JetBrains Mono', monospace; }

        .panel-box {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
        }

        .kpi-card {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 14px 16px;
        }

        /* Standard 5-Color System Indicators & Badges */
        .badge-pink { background: rgba(255, 59, 157, 0.1); border: 1px solid rgba(255, 59, 157, 0.35); color: var(--pink); }
        .badge-cyan { background: rgba(32, 217, 255, 0.1); border: 1px solid rgba(32, 217, 255, 0.35); color: var(--cyan); }
        .badge-purple { background: rgba(155, 108, 255, 0.1); border: 1px solid rgba(155, 108, 255, 0.35); color: var(--purple); }
        .badge-green { background: rgba(53, 232, 135, 0.1); border: 1px solid rgba(53, 232, 135, 0.35); color: var(--green); }
        .badge-lime { background: rgba(199, 255, 50, 0.1); border: 1px solid rgba(199, 255, 50, 0.35); color: var(--lime); }

        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: rgba(8, 13, 30, 0.4); }
        .custom-scroll::-webkit-scrollbar-thumb { background: #1e293b; border-radius: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #334155; }
    </style>
</head>
<body class="flex min-h-screen">

    <!-- UNIVERSAL SIDEBAR -->
    <?php include 'sidebar.php'; ?>

    <!-- MAIN CONSOLE -->
    <main class="flex-1 px-6 py-5 overflow-y-auto min-w-0 transition-all duration-200 flex flex-col justify-start gap-4">

        <!-- TOP BAR -->
        <header class="flex items-center justify-between pb-3.5 border-b border-[#1e293b]/80">
            <div>
                <div class="flex items-center gap-3">
                    <h1 class="text-lg font-extrabold tracking-tight text-white m-0">Honeypot Queue & Deception Layer</h1>
                    <span class="px-2.5 py-0.5 rounded text-[10px] mono font-bold badge-pink">
                        ● DECEPTION ACTIVE
                    </span>
                </div>
                <p class="text-[11px] mono text-[#64748b] mt-0.5">DECOYGUARD // CONTAINER ISOLATION & TRAP FORENSICS</p>
            </div>

            <div class="flex items-center gap-2.5">
                <div class="px-3 py-1.5 rounded flex items-center gap-2 border text-[10px] mono font-bold" style="background: rgba(32,217,255,0.06); border-color: rgba(32,217,255,0.25); color: var(--cyan);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                    <span class="text-[#64748b] uppercase text-[9px]">LAST TELEMETRY</span>
                    <span id="lastTelemetryTime" class="text-slate-200 font-extrabold">--:--:--</span>
                </div>
                <div class="px-3 py-1.5 rounded flex items-center gap-2 border text-[10px] mono font-extrabold badge-pink">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--pink); box-shadow: 0 0 6px var(--pink);"></span>
                    <span id="hpQueueCount">0</span>
                    <span class="tracking-wide">QUEUED FOR ISOLATION</span>
                </div>
            </div>
        </header>

        <!-- ROW 1: 4 STANDARDIZED KPI CARDS -->
        <section class="grid grid-cols-4 gap-4">
            <div class="kpi-card">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Total Trapped Entities</span>
                    <i class="fa-solid fa-jar text-sm" style="color: var(--pink);"></i>
                </div>
                <div id="statTrapped" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-1.5 flex items-center gap-1.5" style="color: var(--pink);">
                    <span>●</span> Deception Subsystem
                </div>
            </div>

            <div class="kpi-card">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Active Sessions</span>
                    <i class="fa-solid fa-network-wired text-sm" style="color: var(--cyan);"></i>
                </div>
                <div id="statSessions" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-1.5 flex items-center gap-1.5" style="color: var(--cyan);">
                    <span>●</span> Deception Nodes Active
                </div>
            </div>

            <div class="kpi-card">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Captured Commands</span>
                    <i class="fa-solid fa-terminal text-sm" style="color: var(--purple);"></i>
                </div>
                <div id="statCommands" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-1.5 flex items-center gap-1.5" style="color: var(--purple);">
                    <span>●</span> Commands Logged
                </div>
            </div>

            <div class="kpi-card">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Credential Attempts</span>
                    <i class="fa-solid fa-key text-sm" style="color: var(--lime);"></i>
                </div>
                <div id="statCredentials" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-1.5 flex items-center gap-1.5" style="color: var(--lime);">
                    <span>●</span> Auth Probing
                </div>
            </div>
        </section>

        <!-- MAIN 3-COLUMN WORKSPACE -->
        <div class="grid grid-cols-12 gap-4 flex-1">

            <!-- TOP LEFT: Dynamic Isolation Queue (35%) -->
            <div class="col-span-12 lg:col-span-4 panel-box p-4 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2.5 pb-1 border-b border-[#1e293b]/60">
                        <div class="flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full" style="background: var(--pink); box-shadow: 0 0 6px var(--pink);"></span>
                            <h3 class="text-xs font-bold text-white m-0">Dynamic Isolation Queue</h3>
                        </div>
                        <span class="text-[9px] mono text-[#64748b]">Router Telemetry</span>
                    </div>

                    <div class="overflow-y-auto max-h-[250px] custom-scroll pr-1">
                        <table class="w-full text-left border-collapse">
                            <thead class="sticky top-0 bg-[#080d1e] z-10">
                                <tr class="text-[8px] mono text-[#64748b] border-b border-[#1e293b]">
                                    <th class="py-2 px-1">INCIDENT</th>
                                    <th class="py-2 px-1">IP</th>
                                    <th class="py-2 px-1">PROBE REQUEST</th>
                                    <th class="py-2 px-1">RISK</th>
                                    <th class="py-2 px-1 text-right">ACTION</th>
                                </tr>
                            </thead>
                            <tbody id="queueTableBody" class="text-[9px] mono divide-y divide-[#1e293b]/50">
                                <tr>
                                    <td colspan="5" class="py-4 text-center text-[#64748b]">Reading queue...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="pt-2.5 mt-2 border-t border-[#1e293b]/70 flex items-center justify-between text-[10px] mono text-[#64748b]">
                    <span>Target Socket: <span class="text-slate-300 font-bold">172.18.0.1:2222</span></span>
                    <span style="color: var(--pink);">Policy: Auto-Reroute Active</span>
                </div>
            </div>

            <!-- TOP CENTER: Interactive Honeypot Shell Stream (35%) -->
            <div class="col-span-12 lg:col-span-4 panel-box p-4 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between px-2.5 py-1.5 mb-2.5 rounded border border-[#1e293b] bg-[#040712] text-[10px] mono">
                        <div class="flex items-center gap-2">
                            <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                            <span class="text-slate-400">ACTIVE SESSION:</span>
                            <span id="sessionTargetIp" class="font-bold" style="color: var(--cyan);">--</span>
                        </div>
                        <div class="flex items-center gap-3 text-[9px]">
                            <span class="text-slate-400">PORT: <span class="text-slate-200 font-semibold">2222/SSH</span></span>
                            <span class="text-slate-400">COMMANDS: <span id="sessionCmdCount" class="font-bold" style="color: var(--purple);">0</span></span>
                            <span class="px-2 py-0.5 rounded font-bold badge-pink">CAPTURED</span>
                        </div>
                    </div>

                    <div class="flex items-center justify-between mb-2">
                        <h3 class="text-xs font-bold text-white m-0">Interactive Honeypot Shell Stream</h3>
                        <span class="px-2 py-0.5 rounded text-[8px] mono font-bold border border-slate-800 text-slate-400 bg-slate-900/60">
                            RAW EMULATION
                        </span>
                    </div>

                    <div id="terminalStream" class="h-[200px] p-3 rounded bg-[#03060d] border border-slate-800 font-mono text-[9.5px] overflow-y-auto custom-scroll flex flex-col gap-2">
                        <div class="text-[#64748b]">// Awaiting interactive session execution on port 2222...</div>
                    </div>
                </div>

                <div class="pt-2.5 mt-2 border-t border-[#1e293b]/70 flex items-center justify-between text-[10px] mono text-[#64748b]">
                    <span>Parser: <span class="text-slate-300 font-bold">MITRE T1059 / T1082</span></span>
                    <span style="color: var(--cyan);">Stream: Beelzebub Telemetry</span>
                </div>
            </div>

            <!-- COLUMN 3: DECOY SANDBOX ACTIVITY (30% Width, 2 Rows High) -->
            <div class="col-span-12 lg:col-span-4 row-span-2 panel-box p-4 flex flex-col justify-between border-l-2 border-l-[var(--cyan)]/40">
                <div class="h-full flex flex-col">
                    <div class="flex items-center justify-between mb-2.5 pb-1 border-b border-[#1e293b]/60">
                        <div class="flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                            <h3 class="text-xs font-bold text-white m-0 tracking-wide uppercase">Fake Website Activity</h3>
                        </div>
                        <span class="px-2 py-0.5 rounded text-[8px] mono font-bold badge-cyan">
                            SANDBOX TRAP
                        </span>
                    </div>

                    <div class="flex items-center justify-between px-2.5 py-1.5 mb-2.5 rounded border border-[#1e293b] bg-[#040712] text-[10px] mono">
                        <span class="text-slate-400">Target Node: <strong class="text-slate-200">Northstar Bank Sandbox</strong></span>
                        <span class="text-[9px] text-[var(--cyan)] font-bold">PORT 8080</span>
                    </div>

                    <!-- Continuous Live Web Sandbox Feed -->
                    <div id="decoyActivityStream" class="flex-1 overflow-y-auto max-h-[500px] custom-scroll pr-1 flex flex-col gap-2">
                        <div class="text-[#64748b] text-[10px] mono py-4 text-center">Reading decoy website telemetry...</div>
                    </div>
                </div>

                <div class="pt-2.5 mt-2 border-t border-[#1e293b]/70 flex items-center justify-between text-[10px] mono text-[#64748b]">
                    <span>Engine: <span class="text-slate-300 font-bold">Decoy Banking Core</span></span>
                    <span style="color: var(--cyan);">Status: Live Sandbox</span>
                </div>
            </div>

            <!-- BOTTOM LEFT: Harvested Authentication Attempts (35%) -->
            <div class="col-span-12 lg:col-span-4 panel-box p-4 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2.5 pb-1 border-b border-[#1e293b]/60">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-user-lock text-xs" style="color: var(--lime);"></i>
                            <h3 class="text-xs font-bold text-white m-0">Harvested Authentication Attempts</h3>
                        </div>
                        <span class="text-[9px] mono text-[#64748b]">Auth Probing</span>
                    </div>

                    <div class="overflow-y-auto max-h-[160px] custom-scroll pr-1">
                        <table class="w-full text-left border-collapse">
                            <thead class="sticky top-0 bg-[#080d1e] z-10">
                                <tr class="text-[8px] mono text-[#64748b] border-b border-[#1e293b]">
                                    <th class="py-1.5 px-1">TIME</th>
                                    <th class="py-1.5 px-1">SOURCE IP</th>
                                    <th class="py-1.5 px-1">USER</th>
                                    <th class="py-1.5 px-1">PASSWORD</th>
                                    <th class="py-1.5 px-1 text-right">STATUS</th>
                                </tr>
                            </thead>
                            <tbody id="credentialTableBody" class="text-[9px] mono divide-y divide-[#1e293b]/50">
                                <tr>
                                    <td colspan="5" class="py-4 text-center text-[#64748b]">No auth traps captured yet.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- BOTTOM CENTER: Trapped Exploit Payloads & Artifacts (35%) -->
            <div class="col-span-12 lg:col-span-4 panel-box p-4 flex flex-col justify-between">
                <div>
                    <div class="flex items-center justify-between mb-2.5 pb-1 border-b border-[#1e293b]/60">
                        <div class="flex items-center gap-2">
                            <i class="fa-solid fa-file-shield text-xs" style="color: var(--purple);"></i>
                            <h3 class="text-xs font-bold text-white m-0">Trapped Exploit Payloads & Artifacts</h3>
                        </div>
                        <span class="text-[9px] mono text-[#64748b]">Payload Quarantine</span>
                    </div>

                    <div class="overflow-y-auto max-h-[160px] custom-scroll pr-1">
                        <table class="w-full text-left border-collapse">
                            <thead class="sticky top-0 bg-[#080d1e] z-10">
                                <tr class="text-[8px] mono text-[#64748b] border-b border-[#1e293b]">
                                    <th class="py-1.5 px-1">PAYLOAD NAME</th>
                                    <th class="py-1.5 px-1">INCIDENT</th>
                                    <th class="py-1.5 px-1">ARTIFACT IDENTIFIER (SHA-256)</th>
                                    <th class="py-1.5 px-1 text-right">STATUS</th>
                                </tr>
                            </thead>
                            <tbody id="artifactTableBody" class="text-[9px] mono divide-y divide-[#1e293b]/50">
                                <tr>
                                    <td colspan="4" class="py-4 text-center text-[#64748b]">No artifacts dropped.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    <div style="clear:both;width:100%;margin-top:12px"><p style="padding:12px 20px;font-size:11px">Recent grouped feed only (up to 100 records). KPIs can cover a wider retained tail. Decisions do not verify forwarding; artifact status is supplied metadata.</p></div>
</main>

    <!-- LIVE TELEMETRY ENGINE SCRIPT -->
    <script>
function escapeHTML(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }

function dgEventDate(e){const t=Date.parse(e.timestamp||e.time||'');return Number.isFinite(t)?t:null;}
function dgEnvironment(e){const target=String(e.target_type||'').toLowerCase(),channel=String(e.channel||'').toLowerCase();if(target==='production'||channel==='production')return 'production';if(['decoy','honeypot','honeypot_sandbox'].includes(target)||['ssh','web'].includes(channel))return 'honeypot';return 'unknown';}
function dgLastRecorded(rows){const dates=rows.map(dgEventDate).filter(t=>t!==null);return dates.length?new Date(Math.max(...dates)).toLocaleString():'No dated evidence';}

        function maskPassword(pw) {
            return '[REDACTED]';
        }

        let hpPollBusy=false;
        async function fetchHoneypotData() {
            if(hpPollBusy)return;hpPollBusy=true;
            try {
                const res = await fetch('api.php', {cache:'no-store'});
                if (res.status === 401) { location.reload(); return; }
                if (!res.ok) throw new Error(`API HTTP ${res.status}`);
                const data = await res.json();

                const allRecent = (Array.isArray(data.recent)?data.recent:[]).map(e=>({...e,incident_id:e.incident_id||e.event_id||'Not supplied',source_ip:e.source_ip||e.remote_addr||'Not supplied',attack:String(e.attack||e.attack_type||e.event_type||'Unclassified'),risk:e.risk??e.risk_score??'Not supplied',time:e.timestamp?new Date(e.timestamp).toLocaleString():e.time||'Not supplied'}));

                // Separate SSH Probes vs Web Sandbox events
                const sshEvents = allRecent.filter(e => e.channel === 'ssh');
                const webEvents = allRecent.filter(e => e.channel === 'web');

                // Update KPIs
                document.getElementById('statTrapped').innerText = data.stats?.hp_trapped || 0;
                document.getElementById('statSessions').innerText = data.stats?.hp_sessions || 0;
                document.getElementById('statCommands').innerText = data.stats?.hp_commands || 0;
                document.getElementById('hpQueueCount').innerText = sshEvents.length;

                // Update Active Session Strip
                const firstSession = sshEvents.find(e => e.source_ip && e.source_ip !== '-');
                document.getElementById('sessionTargetIp').innerText='No SSH source in recent feed';
                document.getElementById('sessionCmdCount').innerText='—';
                if (firstSession) {
                    document.getElementById('sessionTargetIp').innerText = firstSession.source_ip;
                    document.getElementById('sessionCmdCount').innerText = sshEvents.filter(e=>e.source_ip===firstSession.source_ip).reduce((n,e)=>n+(Array.isArray(e.forensics?.session_log)?e.forensics.session_log.length:0),0);
                }

                // 1. Dynamic Isolation Queue (Exclusively Redirected Ingress Probes)
                const queueTbody = document.getElementById('queueTableBody');
                if (queueTbody) {
                    if (sshEvents.length > 0) {
                        queueTbody.innerHTML = sshEvents.slice(0, 10).map(e => `
                            <tr>
                                <td class="py-2 px-1 mono font-bold" style="color: var(--pink);">${escapeHTML(e.incident_id)}</td>
                                <td class="py-2 px-1 text-slate-300 font-semibold">${escapeHTML(e.source_ip)}</td>
                                <td class="py-2 px-1 font-sans text-slate-300 truncate max-w-[140px]">${escapeHTML(e.attack || 'SSH Connection')}</td>
                                <td class="py-2 px-1 font-bold ${e.risk >= 70 ? 'text-[#c7ff32]' : 'text-slate-400'}">${e.risk}</td>
                                <td class="py-2 px-1 text-right">
                                    <span class="px-2 py-0.5 rounded text-[8px] mono font-bold badge-pink">${escapeHTML(e.decision||'Not supplied')}</span>
                                </td>
                            </tr>
                        `).join('');
                    } else {
                        queueTbody.innerHTML = `<tr><td colspan="5" class="py-4 text-center text-[#64748b]">No SSH detections in the recent feed.</td></tr>`;
                    }
                }

                // 2. Interactive Honeypot Shell Stream (SSH Telemetry Only)
                const termBox = document.getElementById('terminalStream');
                if (termBox) {
                    let cmdLines = [];
                    sshEvents.forEach(e => {
                        const forensics = e.forensics;
                        if (forensics && Array.isArray(forensics.session_log)) {
                            forensics.session_log.forEach(log => {
                                if (log.text) {
                                    cmdLines.push({
                                        time: log.time || e.time,
                                        ip: e.source_ip,
                                        text: log.text,
                                        output: log.output
                                    });
                                }
                            });
                        }
                    });

                    if (cmdLines.length > 0) {
                        termBox.innerHTML = cmdLines.slice(0, 15).map(c => `
                            <div class="border-b border-slate-900/80 pb-1 mb-1">
                                <span class="text-[#64748b]">[${escapeHTML(c.time)}]</span>
                                <span class="font-bold" style="color: var(--cyan);">${escapeHTML(c.ip)}</span>
                                <span class="font-mono" style="color: var(--pink);">$ ${escapeHTML(c.text)}</span>
                                ${c.output ? `<div class="text-slate-400 pl-3 text-[9px]">> ${escapeHTML(c.output)}</div>` : ''}
                            </div>
                        `).join('');
                    } else {
                        termBox.innerHTML = `
                            <div class="text-[#64748b] font-mono text-[9.5px]">
                                // No SSH command evidence in the recent feed.<br>
                                // Listener readiness is not checked by this page.
                            </div>
                        `;
                    }
                }

                // 3. Dedicated Fake Website Activity Stream (Cyan / Purple scheme)
                const decoyStreamBox = document.getElementById('decoyActivityStream');
                if (decoyStreamBox) {
                    if (webEvents.length > 0) {
                        decoyStreamBox.innerHTML = webEvents.map(w => `
                            <div class="p-2.5 rounded bg-[#040712] border border-[#1e293b] flex flex-col gap-1">
                                <div class="flex items-center justify-between text-[9px] mono">
                                    <span class="font-bold" style="color: var(--cyan);">${escapeHTML(w.incident_id)}</span>
                                    <span class="text-[#64748b]">${escapeHTML(w.time)}</span>
                                </div>
                                <div class="text-[11px] font-semibold text-slate-200 leading-tight">
                                    ${escapeHTML(w.attack.replace('[WEB] ', ''))}
                                </div>
                                <div class="flex items-center justify-between text-[9px] mono mt-1 pt-1 border-t border-slate-900">
                                    <span class="text-slate-400">Actor: <strong class="text-slate-300">${escapeHTML(w.source_ip)}</strong></span>
                                    <span class="px-1.5 py-0.5 rounded font-bold text-[8px] ${w.severity === 'CRITICAL' ? 'badge-pink' : 'badge-purple'}">${escapeHTML(w.severity)}</span>
                                </div>
                            </div>
                        `).join('');
                    } else {
                        decoyStreamBox.innerHTML = `
                            <div class="text-[#64748b] text-[10px] mono py-6 text-center">
                                No sandbox exploit traffic captured yet.<br>
                                Website activity appears here after a detected decoy attack.
                            </div>
                        `;
                    }
                }

                // 4. Harvested Credentials & Quarantined Artifacts
                let credRows = [];
                let artRows = [];

                allRecent.forEach(e => {
                    if (e.auth_attempt) {
                        credRows.push(`
                            <tr>
                                <td class="py-1.5 px-1 text-[#64748b]">${escapeHTML(e.time)}</td>
                                <td class="py-1.5 px-1 text-slate-300 font-semibold">${escapeHTML(e.source_ip)}</td>
                                <td class="py-1.5 px-1 font-bold" style="color: var(--cyan);">${escapeHTML(e.auth_attempt.user)}</td>
                                <td class="py-1.5 px-1 font-mono" style="color: var(--pink);">${escapeHTML(maskPassword(e.auth_attempt.password))}</td>
                                <td class="py-1.5 px-1 text-right">
                                    <span class="px-1.5 py-0.5 rounded text-[7.5px] badge-lime">CAPTURED</span>
                                </td>
                            </tr>
                        `);
                    }

                    const forensics = e.forensics;
                    if (forensics && Array.isArray(forensics.artifacts)) {
                        forensics.artifacts.forEach(art => {
                            const hashVal = art.sha256 || art.hash || '';
                            artRows.push(`
                                <tr>
                                    <td class="py-1.5 px-1 font-bold" style="color: var(--pink);">${escapeHTML(art.name)}</td>
                                    <td class="py-1.5 px-1 text-[#64748b]">${escapeHTML(e.incident_id)}</td>
                                    <td class="py-1.5 px-1 text-slate-400 font-mono text-[8px]">${escapeHTML(hashVal ? hashVal.substring(0, 16) + '...' : 'N/A')}</td>
                                    <td class="py-1.5 px-1 text-right">
                                        <span class="px-1.5 py-0.5 rounded text-[7.5px] mono font-bold badge-lime">${escapeHTML(art.status||'Not supplied')}</span>
                                    </td>
                                </tr>
                            `);
                        });
                    }
                });

                document.getElementById('statCredentials').innerText = credRows.length;

                const credTbody = document.getElementById('credentialTableBody');
                if (credTbody) {
                    credTbody.innerHTML = credRows.length > 0 
                        ? credRows.join('') 
                        : `<tr><td colspan="5" class="py-4 text-center text-[#64748b]">No auth traps captured yet.</td></tr>`;
                }

                const artTbody = document.getElementById('artifactTableBody');
                if (artTbody) {
                    artTbody.innerHTML = artRows.length > 0 
                        ? artRows.join('') 
                        : `<tr><td colspan="4" class="py-4 text-center text-[#64748b]">No artifacts dropped.</td></tr>`;
                }

                document.getElementById('lastTelemetryTime').innerText = dgLastRecorded(allRecent);
                document.getElementById('lastTelemetryTime').title='Last successful refresh: '+new Date().toLocaleString();

            } catch (err) {
                console.error("Honeypot telemetry poll failed:", err);
        const status = document.getElementById("lastTelemetryTime") || document.getElementById("lastTelemetry"); if (status) status.textContent = "API unavailable: " + err.message;
            } finally { hpPollBusy=false; }
        }

        setInterval(fetchHoneypotData, 2000);
        fetchHoneypotData();
    </script>
</body>
</html>