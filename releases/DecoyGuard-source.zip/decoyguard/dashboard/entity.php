<?php
if (!defined('DG_DASHBOARD_PAGE')) define('DG_DASHBOARD_PAGE', true);
require_once __DIR__ . '/api.php';
?>
   
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DecoyGuard — Entity Investigation</title>

    <link rel="stylesheet" href="soc_theme.css?v=<?= filemtime(__DIR__.'/soc_theme.css') ?>">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        :root {
            --cyan: #20d9ff;
            --purple: #9b6cff;
            --pink: #ff3b9d;
            --green: #35e887;
            --lime: #c7ff32;
            --bg: #050811;
            --panel: #080d1e;
            --panel-2: #0a1021;
            --line: rgba(71, 85, 105, 0.22);
            --muted: #64748b;
            --text: #e2e8f0;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            background-color: var(--bg);
            color: var(--text);
            font-family: 'Plus Jakarta Sans', sans-serif;
            overflow-x: hidden;
        }
        .mono { font-family: 'JetBrains Mono', monospace; }

        .panel-box {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
        }

        /* Badges */
        .badge-safe { background: rgba(53, 232, 135, 0.12); border: 1px solid rgba(53, 232, 135, 0.3); color: var(--green); }
        .badge-critical { background: rgba(199, 255, 50, 0.12); border: 1px solid rgba(199, 255, 50, 0.3); color: var(--lime); }
        .badge-honeypot { background: rgba(255, 59, 157, 0.12); border: 1px solid rgba(255, 59, 157, 0.3); color: var(--pink); }
        .badge-purple { background: rgba(155, 108, 255, 0.12); border: 1px solid rgba(155, 108, 255, 0.3); color: var(--purple); }
        .badge-cyan { background: rgba(32, 217, 255, 0.12); border: 1px solid rgba(32, 217, 255, 0.3); color: var(--cyan); }

        /* Custom Scrollbars */
        .custom-scroll::-webkit-scrollbar { width: 4px; height: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.5); }
        .custom-scroll::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #64748b; }

        #incidentHistoryTable tr:hover {
            background: rgba(32, 217, 255, 0.04);
        }
    </style>
</head>

<body class="min-h-screen flex text-base antialiased">



    <!-- UNIVERSAL SIDEBAR INCLUDE -->
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-4 overflow-y-auto min-w-0 transition-all duration-200">

        <!-- TOP BAR -->
        <header class="flex items-center justify-between pb-3 mb-3 border-b border-[#1e293b]">
            <div>
                <div class="flex items-center gap-3">
                    <h1 class="text-base font-extrabold tracking-tight text-white m-0">Threat Monitoring Console</h1>
                    <span class="px-2 py-0.5 rounded text-[9px] mono font-bold" style="background: rgba(255,59,157,0.1); border: 1px solid rgba(255,59,157,0.3); color: var(--pink);">
                        ● STREAM ACTIVE
                    </span>
                </div>
                <p class="text-[10px] mono text-[#64748b] mt-0.5">DECOYGUARD // BEHAVIOURAL THREAT PROFILES & INCIDENT DOSSIER</p>
            </div>

            <div class="flex items-center gap-2.5">
                <div class="px-3 py-1.5 rounded-lg flex items-center gap-2 border text-[10px] mono font-bold" style="background: rgba(32,217,255,0.08); border-color: rgba(32,217,255,0.25); color: var(--cyan);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                    <span class="text-[#64748b] uppercase tracking-wider text-[8px]">LAST TELEMETRY</span>
                    <span id="lastTelemetry" class="text-slate-200 font-extrabold">--:--:--</span>
                </div>
                <div class="px-3 py-1.5 rounded-lg flex items-center gap-2 border text-[10px] mono font-extrabold" style="background: rgba(32,217,255,0.08); border-color: rgba(32,217,255,0.25); color: var(--cyan);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                    <span id="activeCaseCount">0</span>
                    <span class="tracking-wide">ENTITIES</span>
                </div>
            </div>
        </header>

        <!-- MAIN LAYOUT: items-stretch to align sidebar with the end of the vault -->
        <div class="grid grid-cols-12 gap-3.5 items-stretch">

            <!-- LEFT COL: THREAT PROFILES (Span 2) - Exactly aligned to end of right stack -->
            <aside class="col-span-2 panel-box p-3 flex flex-col justify-between min-w-0">
                <div class="flex flex-col flex-1 min-h-0">
                    <div class="flex items-center justify-between mb-2">
                        <div>
                            <span class="text-[7px] mono text-[#64748b] uppercase block">Entity Index</span>
                            <h2 class="text-xs font-bold text-white m-0">Profiles</h2>
                        </div>
                        <i class="fa-solid fa-layer-group text-xs" style="color: var(--purple);"></i>
                    </div>

                    <div class="flex gap-1 mb-2">
                        <button onclick="filterEntities('ALL')" class="filter-btn flex-1 py-1 rounded text-[8px] mono font-bold bg-slate-800 text-white hover:bg-slate-700 transition">ALL</button>
                        <button onclick="filterEntities('CRITICAL')" class="filter-btn flex-1 py-1 rounded text-[8px] mono font-bold bg-slate-900 text-slate-400 hover:bg-slate-800 transition">CRIT</button>
                        <button onclick="filterEntities('HIGH')" class="filter-btn flex-1 py-1 rounded text-[8px] mono font-bold bg-slate-900 text-slate-400 hover:bg-slate-800 transition">HIGH</button>
                    </div>

                    <div id="caseFileList" class="space-y-1.5 overflow-y-auto custom-scroll flex-1 pr-1">
                        <p class="text-[9px] mono text-slate-500 text-center py-4">Loading profiles...</p>
                    </div>
                </div>
            </aside>

            <!-- RIGHT COL: DOSSIER & FORENSIC VAULT (Span 10) -->
            <div class="col-span-10 space-y-3 min-w-0 flex flex-col justify-between">

                <!-- TOP ROW: TARGET ENTITY & ACTIVITY STREAM (Paired 50/50) -->
                <div class="grid grid-cols-2 gap-3.5 items-stretch">

                    <!-- Target Entity Summary Box -->
                    <section class="panel-box p-3.5 flex flex-col justify-between min-w-0 overflow-hidden">
                        <div class="min-w-0">
                            <div class="flex justify-between items-start gap-2 mb-2.5">
                                <div class="min-w-0 flex-1">
                                    <span class="text-[8px] mono uppercase font-bold" style="color: var(--cyan);">Target Entity</span>
                                    <h2 id="entityIP" class="text-xl font-extrabold mono text-white mt-0.5 truncate">--</h2>
                                    <p id="entityAlias" class="text-[9px] text-slate-400 truncate mt-0.5 block" title="">--</p>
                                </div>
                                
                                <div class="flex gap-1 shrink-0">
                                    <button title="Local analyst annotation only; does not change routing" onclick="setEntityStatus('MONITOR')" class="px-2 py-0.5 rounded text-[8px] mono font-bold badge-cyan hover:opacity-80 transition whitespace-nowrap">
                                        MONITOR
                                    </button>
                                    <button title="Local analyst annotation only; does not change routing" onclick="setEntityStatus('HONEYPOT')" class="px-2 py-0.5 rounded text-[8px] mono font-bold badge-honeypot hover:opacity-80 transition whitespace-nowrap">
                                        HONEYPOT
                                    </button>
                                    <button title="Local analyst annotation only; does not change routing" onclick="setEntityStatus('ISOLATE')" class="px-2 py-0.5 rounded text-[8px] mono font-bold badge-critical hover:opacity-80 transition whitespace-nowrap">
                                        ISOLATE
                                    </button>
                                </div>
                            </div>

                            <div class="grid grid-cols-3 gap-2 p-2 rounded bg-slate-950/50 border border-[#1e293b] mb-2.5">
                                <div class="min-w-0">
                                    <span class="text-[7px] mono text-[#64748b] uppercase block">Latest Incident</span>
                                    <p id="entityLatestID" class="text-[9px] mono font-bold text-slate-200 truncate mt-0.5">--</p>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-[7px] mono text-[#64748b] uppercase block">First Observed</span>
                                    <p id="entityFirstSeen" class="text-[9px] mono font-bold text-slate-300 truncate mt-0.5">--</p>
                                </div>
                                <div class="min-w-0">
                                    <span class="text-[7px] mono text-[#64748b] uppercase block">Primary Vectors</span>
                                    <p id="entityClassification" class="text-[9px] mono font-bold truncate mt-0.5" style="color: var(--purple);">--</p>
                                </div>
                            </div>
                        </div>

                        <div class="flex justify-between items-center text-[9px] mono pt-2 border-t border-[#1e293b]">
                            <span class="text-slate-400">Recorded Response: <b id="entityStatus" style="color: var(--cyan);" class="uppercase">MONITOR</b></span>
                            <span class="text-slate-400">Total Incidents: <b id="entityIncidents" class="text-white">0</b></span>
                        </div>
                    </section>

                    <!-- Activity Stream: Non-scrollable, strictly 4 latest items -->
                    <section class="panel-box p-3.5 flex flex-col justify-between min-w-0 overflow-hidden">
                        <div>
                            <div class="flex items-center justify-between mb-2">
                                <div class="flex items-center gap-2">
                                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--pink);"></span>
                                    <h3 class="text-xs font-bold text-white m-0">DecoyGuard Activity Stream</h3>
                                </div>
                                <span class="text-[8px] mono text-[#64748b]">Telemetry for selected entity</span>
                            </div>

                            <table class="w-full text-left border-collapse" id="incidentHistoryTable">
                                <thead>
                                    <tr class="text-[7px] mono text-[#64748b] border-b border-[#1e293b]">
                                        <th class="py-1 px-1">INCIDENT</th>
                                        <th class="py-1 px-1">TIME</th>
                                        <th class="py-1 px-1">ATTACK</th>
                                        <th class="py-1 px-1">RISK</th>
                                        <th class="py-1 px-1 text-center">SEV</th>
                                        <th class="py-1 px-1 text-right">ACTION</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-[#1e293b]/50 text-[9px] mono">
                                    <tr><td colspan="6" class="py-3 text-center text-slate-500">Select an entity to view history</td></tr>
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>

                <!-- FORENSIC EVIDENCE VAULT (Dual-Layer 2-Data Breakdown per System) -->
                <section class="panel-box p-3.5 border border-[#1e293b] relative overflow-hidden flex-1 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center justify-between mb-3">
                            <div class="flex items-center gap-2.5">
                                <div class="w-7 h-7 rounded-lg flex items-center justify-center text-xs" style="background: rgba(155,108,255,0.12); border: 1px solid rgba(155,108,255,0.3); color: var(--purple);">
                                    <i class="fa-solid fa-fingerprint"></i>
                                </div>
                                <div>
                                    <h3 class="text-xs font-extrabold text-white tracking-wide m-0">Forensic Evidence Vault</h3>
                                    <p class="text-[8px] mono text-[#64748b] mt-0.5 uppercase tracking-wider">Session Playback & Dual-Layer Extraction</p>
                                </div>
                            </div>
                            <div class="px-2 py-0.5 rounded flex items-center gap-1.5 border text-[8px] mono font-bold" style="background: rgba(53,232,135,0.08); border-color: rgba(53,232,135,0.25); color: var(--green);">
                                <span class="w-1.5 h-1.5 rounded-full" style="background: var(--green); box-shadow: 0 0 6px var(--green);"></span>
                                <span>EVIDENCE PRESERVED</span>
                            </div>
                        </div>

                        <div class="grid grid-cols-12 gap-3.5 items-start">
                            
                            <!-- LEFT COLUMN: Specs & Kill Chain (Span 5) -->
                            <div class="col-span-5 space-y-2.5">
                                
                              <!-- 1. Network Fingerprint (Clean Neutral) -->
                            <div>
                                <div class="flex items-center justify-between mb-1.5">
                                    <span class="text-[9px] mono font-bold uppercase tracking-wider text-slate-400">Network Fingerprint</span>
                                    <span class="text-[7px] mono text-slate-600">DUAL-LAYER TELEMETRY</span>
                                </div>
                                <div class="grid grid-cols-2 gap-1.5">
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Bait Port (HP)</span>
                                        <span id="vaultHpPort" class="text-[11px] mono font-bold text-slate-200 mt-0.5 block">2222 / SSH</span>
                                    </div>
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">App Port (BE)</span>
                                        <span id="vaultBePort" class="text-[11px] mono font-bold text-slate-200 mt-0.5 block">80 / HTTP</span>
                                    </div>
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Decoy Target</span>
                                        <span id="vaultHpTarget" class="text-[11px] mono font-bold text-slate-300 truncate mt-0.5 block">Beelzebub / Bait</span>
                                    </div>
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Client Tool</span>
                                        <span id="vaultClientTool" class="text-[11px] mono font-bold text-slate-300 truncate mt-0.5 block">Automated Script</span>
                                    </div>
                                </div>
                            </div>

                            <!-- 2. Session Metadata (Clean Neutral) -->
                            <div>
                                <div class="flex items-center justify-between mb-1.5">
                                    <span class="text-[9px] mono font-bold uppercase tracking-wider text-slate-400">Session Metadata</span>
                                    <span class="text-[7px] mono text-slate-600">ACTIVITY METRICS</span>
                                </div>
                                <div class="grid grid-cols-2 gap-1.5">
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Trapped Hits</span>
                                        <span id="vaultHpTrapped" class="text-[11px] mono font-bold text-slate-200 mt-0.5 block">0</span>
                                    </div>
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Requests Observed</span>
                                        <span id="vaultBeRequests" class="text-[11px] mono font-bold text-slate-200 mt-0.5 block">0</span>
                                    </div>
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Deception Route</span>
                                        <span id="vaultHpRoute" class="text-[10px] mono font-bold text-slate-300 mt-0.5 block">MONITOR</span>
                                    </div>
                                    <div class="p-2 rounded bg-slate-950/60 border border-[#1e293b]">
                                        <span class="text-[7px] mono text-slate-500 block uppercase font-medium">Detection State</span>
                                        <span id="vaultBeState" class="text-[10px] mono font-bold text-slate-300 mt-0.5 block">ANALYSIS</span>
                                    </div>
                                </div>
                            </div>

                                <!-- 3. Kill Chain Progression Card -->
                                <div>
                                    <div class="flex items-center gap-1.5 mb-1 text-[9px] mono font-bold uppercase" style="color: var(--pink);">
                                        <i class="fa-solid fa-timeline text-[10px]"></i>
                                        <span>Kill Chain Progression</span>
                                    </div>
                                    <div class="p-3 rounded bg-slate-950/70 border border-[#1e293b]">
                                        <div id="vaultKillChain" class="w-full relative py-1"></div>
                                    </div>
                                </div>

                            </div>

                            <!-- RIGHT COLUMN: Session Playback & IOCs (Span 7) -->
                            <div class="col-span-7 flex flex-col gap-3">
                                
                                <div>
                                    <div class="flex items-center gap-1.5 text-[10px] mono font-extrabold uppercase text-slate-200">
                                        <i class="fa-solid fa-video text-[10px]" style="color: var(--pink);"></i>
                                        <span>Session Playback</span>
                                    </div>
                                    <p class="text-[8px] mono text-[#64748b] mt-0.5">Chronological reconstruction of captured activity</p>
                                </div>

                                <!-- Terminal Window -->
                                <div class="rounded-xl overflow-hidden border border-[#1e293b] bg-[#020409] flex flex-col shadow-xl">
                                    <div class="bg-slate-900/60 border-b border-[#1e293b] px-3 py-2 flex items-center justify-between">
                                        <div class="flex items-center gap-2">
                                            <div class="flex items-center gap-1">
                                                <span class="w-2 h-2 rounded-full bg-slate-700"></span>
                                                <span class="w-2 h-2 rounded-full bg-slate-700"></span>
                                                <span class="w-2 h-2 rounded-full bg-slate-700"></span>
                                            </div>
                                            <span class="h-2.5 w-px bg-slate-700 mx-1"></span>
                                            <div class="flex items-center gap-1.5">
                                                <span class="w-1.5 h-1.5 rounded-full" style="background: var(--pink); box-shadow: 0 0 4px var(--pink);"></span>
                                                <span class="text-[9px] mono text-slate-300">dg_reconstruction_<span class="entity-ip-insert">--</span>.log</span>
                                            </div>
                                        </div>
                                        <span class="text-[8px] mono font-extrabold text-[#64748b]">EVIDENCE</span>
                                    </div>

                                    <div id="terminal-output" class="h-[210px] p-3 font-mono text-[11px] leading-relaxed overflow-y-auto custom-scroll">
                                        <div id="terminal-content">
                                            <p class="text-slate-600 text-[9px] mono">INITIALIZING RECONSTRUCTION OF CAPTURED EVENTS...</p>
                                        </div>
                                        <div id="lines-container" class="space-y-1.5 mt-1.5"></div>
                                    </div>

                                    <!-- Controls Bar -->
                                    <div class="bg-slate-900/60 border-t border-[#1e293b] px-3 py-2 flex items-center gap-2.5">
                                        <button id="btnRestartTerminal" class="text-slate-500 hover:text-white transition text-xs"><i class="fa-solid fa-rotate-left"></i></button>
                                        <button id="btnSpeedToggle" class="text-[8px] mono font-extrabold text-slate-300 bg-slate-800 border border-slate-700 px-1.5 py-0.5 rounded">0.5x</button>

                                        <div class="flex-1 flex items-center gap-2">
                                            <span id="playback-time" class="text-[8px] mono text-slate-400 w-6 text-right">00:00</span>
                                            
                                            <div class="flex-1 h-1.5 bg-slate-950 rounded-full relative cursor-pointer border border-slate-800" id="progress-container">
                                                <div id="playback-progress" class="absolute top-0 left-0 h-full w-0 rounded-full transition-all duration-75" style="background: var(--cyan);"></div>
                                                <div id="timeline-markers" class="absolute top-0 left-0 w-full h-full pointer-events-none"></div>
                                            </div>
                                            
                                            <span id="playback-total" class="text-[8px] mono text-slate-500 w-6">00:00</span>
                                        </div>

                                        <div class="flex items-center gap-2.5 text-slate-400 text-xs">
                                            <button id="btnPrevEvent" class="hover:text-white transition"><i class="fa-solid fa-backward-step"></i></button>
                                            <button id="btnPlayPause" class="text-white hover:text-cyan-400 text-xs transition w-3.5 flex justify-center"><i class="fa-solid fa-play"></i></button>
                                            <button id="btnNextEvent" class="hover:text-white transition"><i class="fa-solid fa-forward-step"></i></button>
                                        </div>
                                    </div>
                                </div>

                                <!-- IOC Extraction Sub-panel -->
                                <div>
                                    <div class="flex items-center gap-1.5 mb-1 text-[9px] mono font-bold uppercase" style="color: var(--pink);">
                                        <i class="fa-solid fa-crosshairs text-[10px]"></i>
                                        <span>IOC Extraction</span>
                                    </div>
                                    <div id="vaultIOCs" class="space-y-1.5"></div>
                                </div>

                            </div>

                        </div>
                    </div>
                </section>

            </div>
        </div>
    <div style="clear:both;width:100%;margin-top:12px"><p style="padding:12px 20px;font-size:11px;color:var(--muted)">Recent grouped feed only (up to 100 records). Sources are address groups, not verified sessions. Buttons add local analyst notes only. Annotation: <span id="entityAnnotation">None</span></p></div>
</main>

    
<script>
let liveEntities = {};
let activeIP = null;
let activeSeverityFilter = "ALL";

let sessionEvents = [];
const speeds = [0.25, 0.5, 1, 2];
let speedIndex = 1;
let playbackState = { isPlaying: false, speed: speeds[speedIndex], elapsedMs: 0, totalMs: 0, lastTick: 0, animationFrame: null, currentIndex: -1 };
let currentLoadedIncidentID = null;

function escapeHTML(value) { 
    return String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;"); 
}

function formatMs(ms) {
    const totalSeconds = Math.floor(Math.max(0, ms) / 1000);
    const mins = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
    const secs = (totalSeconds % 60).toString().padStart(2, "0");
    return `${mins}:${secs}`;
}

// -------------------------------------------------------------
// DUAL-LAYER PLAYBACK ENGINE
// -------------------------------------------------------------
function initPlaybackEngine(rawScript) {
    cancelAnimationFrame(playbackState.animationFrame);
    sessionEvents = [];
    playbackState.animationFrame = null;
    playbackState.isPlaying = false;
    playbackState.elapsedMs = 0;
    playbackState.totalMs = 0;
    playbackState.lastTick = 0;
    playbackState.currentIndex = -1;

    const linesContainer = document.getElementById("lines-container");
    const totalDisplay = document.getElementById("playback-total");
    const btnPlayPause = document.querySelector("#btnPlayPause i");

    if (linesContainer) linesContainer.innerHTML = "";
    if (!Array.isArray(rawScript) || rawScript.length === 0) {
        const terminalContent = document.getElementById("terminal-content");
        if (terminalContent) terminalContent.innerHTML = `<p class="text-slate-600 text-[9px] mono">NO ACTIVITY RECORDED FOR THIS ENTITY.</p>`;
        if (totalDisplay) totalDisplay.innerText = "00:00";
        if (btnPlayPause) btnPlayPause.className = "fa-solid fa-play";
        syncPlaybackUI();
        return;
    }

    const terminalContent = document.getElementById("terminal-content");
    if (terminalContent) terminalContent.innerHTML = `<p class="text-[#64748b] text-[8px] mono uppercase font-bold">INITIALIZING RECONSTRUCTION OF ${rawScript.length} EVENTS...</p>`;

    let cumulativeTime = 0;
    rawScript.forEach((log, index) => {
        const delay = Math.max(150, parseInt(log.delay, 10) || 800);
        cumulativeTime += delay;
        sessionEvents.push({ ...log, index: index, startTime: cumulativeTime });
    });

    playbackState.totalMs = cumulativeTime + 400;
    if (totalDisplay) totalDisplay.innerText = formatMs(playbackState.totalMs);
    if (btnPlayPause) btnPlayPause.className = "fa-solid fa-play";
    renderTimelineMarkers();
    syncPlaybackUI();
}

function renderTimelineMarkers() {
    const container = document.getElementById("timeline-markers");
    if (!container) return;
    container.innerHTML = "";
    if (!playbackState.totalMs) return;

    sessionEvents.forEach(ev => {
        const percentage = (ev.startTime / playbackState.totalMs) * 100;
        const marker = document.createElement("div");
        marker.className = "absolute top-1/2 -translate-y-1/2 w-0.5 h-1.5 bg-slate-600 rounded-full";
        marker.style.left = `${percentage}%`;
        container.appendChild(marker);
    });
}

function playbackLoop(timestamp) {
    if (!playbackState.isPlaying) return;
    if (!playbackState.lastTick) playbackState.lastTick = timestamp;

    const delta = timestamp - playbackState.lastTick;
    playbackState.lastTick = timestamp;
    playbackState.elapsedMs += delta * playbackState.speed;

    if (playbackState.elapsedMs >= playbackState.totalMs) {
        playbackState.elapsedMs = playbackState.totalMs;
        playbackState.isPlaying = false;
        playbackState.currentIndex = sessionEvents.length - 1;
        renderEventsUpTo(sessionEvents.length - 1);
        const btn = document.querySelector("#btnPlayPause i");
        if (btn) btn.className = "fa-solid fa-rotate-right";
        syncPlaybackUI();
        return;
    }

    let targetIndex = -1;
    for (let i = sessionEvents.length - 1; i >= 0; i--) {
        if (playbackState.elapsedMs >= sessionEvents[i].startTime) {
            targetIndex = i;
            break;
        }
    }

    if (targetIndex > playbackState.currentIndex) {
        renderEventsUpTo(targetIndex);
        playbackState.currentIndex = targetIndex;
    }

    syncPlaybackUI();
    playbackState.animationFrame = requestAnimationFrame(playbackLoop);
}

function renderEventsUpTo(index) {
    const linesContainer = document.getElementById("lines-container");
    const terminalOutput = document.getElementById("terminal-output");
    if (!linesContainer) return;
    if (index < -1) index = -1;

    linesContainer.innerHTML = "";
    const startIndex = Math.max(0, index - 3);
    for (let i = startIndex; i <= index; i++) {
        appendPlaybackEvent(sessionEvents[i], linesContainer);
    }

    if (terminalOutput) {
        terminalOutput.scrollTop = terminalOutput.scrollHeight;
    }
}

function appendPlaybackEvent(ev, container) {
    if (!ev || !container) return;
    const isHoneypot = ev.layer === "honeypot";
    
    const layerTag = isHoneypot 
        ? `<span class="font-bold" style="color: var(--pink);">[HP-LAYER: HONEYPOT]</span>`
        : `<span class="font-bold" style="color: var(--purple);">[BE-LAYER: PRODUCTION]</span>`;

    const commandText = ev.command || ev.text || "GET /";
    const descText = ev.description || ev.output || "Activity observed";

    const block = document.createElement("div");
    block.className = "p-2 rounded bg-slate-950/80 border border-slate-900 mono text-[9px]";
    block.innerHTML = `
        <div class="flex items-center justify-between text-[#64748b] text-[8px] mb-0.5">
            <span>${layerTag} ${escapeHTML(ev.time || "--")}</span>
            <span class="text-slate-500 font-bold">${isHoneypot ? 'DECEPTIVE CAPTURE' : 'EXPLOIT TELEMETRY'}</span>
        </div>
        <div class="flex items-center gap-1.5 text-slate-100 font-extrabold mb-0.5">
            <span style="color: var(--cyan);">&gt;</span>
            <span class="truncate">${escapeHTML(commandText)}</span>
        </div>
        <p class="text-[8px] text-[#94a3b8]">${escapeHTML(descText)}</p>
    `;
    container.appendChild(block);
}

function syncPlaybackUI() {
    const timeDisplay = document.getElementById("playback-time");
    const progressBar = document.getElementById("playback-progress");

    if (timeDisplay) timeDisplay.innerText = formatMs(playbackState.elapsedMs);
    if (progressBar) {
        const percentage = playbackState.totalMs > 0 ? (playbackState.elapsedMs / playbackState.totalMs) * 100 : 0;
        progressBar.style.width = `${Math.min(100, Math.max(0, percentage))}%`;
    }
}

// -------------------------------------------------------------
// KILL CHAIN & IOC GENERATORS
// -------------------------------------------------------------
function renderKillChain(forensics = {}, incident = {}) {
 return '<div class="p-3 border rounded" style="border-color:var(--line)"><span class="text-[9px]">RECORDED STAGE</span><strong class="block mt-2">'+escapeHTML(incident.attack_stage||'Not supplied')+'</strong><p class="text-[10px] mt-2">Recorded response: '+escapeHTML(incident.decision||'Not supplied')+'</p><p class="text-[9px] mt-2">This evidence does not establish every preceding attack stage.</p></div>';
}

function renderIOCs(forensics = {}, incident = {}) {
    const container = document.getElementById("vaultIOCs");
    if (!container) return;

    const sourceIP = incident.source_ip || incident.ip || activeIP || "Not supplied";
    const clientTool = forensics.client_tool || "Not supplied";

    container.innerHTML = `
        <div class="p-2 rounded bg-slate-950/70 border border-[#1e293b] flex items-center gap-2.5">
            <div class="w-7 h-7 rounded flex items-center justify-center text-[10px]" style="background: rgba(32,217,255,0.1); border: 1px solid rgba(32,217,255,0.3); color: var(--cyan);">
                <i class="fa-solid fa-network-wired"></i>
            </div>
            <div>
                <span class="text-[7px] mono text-[#64748b] uppercase font-bold block">SOURCE IP</span>
                <span class="text-[11px] mono font-extrabold text-white">${escapeHTML(sourceIP)}</span>
            </div>
        </div>
        <div class="p-2 rounded bg-slate-950/70 border border-[#1e293b] flex items-center gap-2.5">
            <div class="w-7 h-7 rounded flex items-center justify-center text-[10px]" style="background: rgba(155,108,255,0.1); border: 1px solid rgba(155,108,255,0.3); color: var(--purple);">
                <i class="fa-solid fa-terminal"></i>
            </div>
            <div>
                <span class="text-[7px] mono text-[#64748b] uppercase font-bold block">CLIENT TOOL</span>
                <span class="text-[11px] mono font-extrabold text-white">${escapeHTML(clientTool)}</span>
            </div>
        </div>
    `;
}

// -------------------------------------------------------------
// TELEMETRY SYNC
// -------------------------------------------------------------

function dgEventDate(e){const t=Date.parse(e.timestamp||e.time||'');return Number.isFinite(t)?t:null;}
function dgEnvironment(e){const target=String(e.target_type||'').toLowerCase(),channel=String(e.channel||'').toLowerCase();if(target==='production'||channel==='production')return 'production';if(['decoy','honeypot','honeypot_sandbox'].includes(target)||['ssh','web'].includes(channel))return 'honeypot';return 'unknown';}
function dgLastRecorded(rows){const dates=rows.map(dgEventDate).filter(t=>t!==null);return dates.length?new Date(Math.max(...dates)).toLocaleString():'No dated evidence';}

const analystAnnotations={};
let entityPollBusy=false;
async function syncTelemetryFromAPI() {
    if(entityPollBusy)return;entityPollBusy=true;
    try {
        const response = await fetch("api.php", { cache: "no-store" });
        if (response.status === 401) { location.reload(); return; }
        if (!response.ok) throw new Error(`API HTTP ${response.status}`);
        const data = await response.json();
        if (!data.recent || !Array.isArray(data.recent)) return;

        const entities = {};
        [...data.recent].sort((a,b)=>(dgEventDate(a)??-Infinity)-(dgEventDate(b)??-Infinity)).forEach(item => {
            const ip = item.source_ip || item.remote_addr || item.ip || "UNKNOWN";
            const incidentID = item.incident_id || item.event_id || "Not supplied";
            const attackType = item.attack || item.attack_type || "Suspicious Activity";
            const severity = String(item.severity || "INFO").toUpperCase();
            const risk = parseInt(item.risk ?? item.risk_score ?? 0, 10) || 0;
            const timestamp = item.timestamp || item.time || "N/A";

            if (!entities[ip]) {
                entities[ip] = {
                    ip: ip,
                    latestID: incidentID,
                    firstSeen: timestamp,
                    attackTypes: new Set(),
                    highestSeverity: severity,
                    maxRisk: risk,
                    status: item.decision || "MONITOR",
                    incidents: [],
                    honeypotHits: 0,
                    unknownTargets: 0,
                    behRequests: 0
                };
            }

            const entity = entities[ip];
            entity.latestID = incidentID;
            entity.status = item.decision || "Not supplied";
            entity.attackTypes.add(attackType);

            if (dgEnvironment(item) === "production") {
                entity.behRequests++;
            } else if(dgEnvironment(item)==="honeypot") {
                entity.honeypotHits++;
            }

            if(entity.firstSeen==="N/A"||(Number.isFinite(Date.parse(timestamp))&&Date.parse(timestamp)<Date.parse(entity.firstSeen)))entity.firstSeen=timestamp;
            if (severityRank(severity) > severityRank(entity.highestSeverity)) entity.highestSeverity = severity;
            if (risk > entity.maxRisk) entity.maxRisk = risk;

            let sessionLog = (Array.isArray(item.forensics?.session_log)?item.forensics.session_log:[]).map(log => ({...log, command: log.command || log.text || "", description: log.description || log.output || "", layer: dgEnvironment(item)==="production"?"behaviour":dgEnvironment(item)}));
            if (!sessionLog || sessionLog.length === 0) {
                const isBeh = incidentID.startsWith("BE-");
                const rawCommand = item.request || "No request details recorded";
                const actionDesc = item.details || `${attackType} observed on ${item.source_ip}`;

                sessionLog = [{
                    time: timestamp,
                    command: rawCommand,
                    description: actionDesc,
                    layer: dgEnvironment(item)==="production"?"behaviour":dgEnvironment(item),
                    delay: 600
                }];
            }

            entity.incidents.push({
                ...item,
                id: incidentID,
                time: timestamp,
                attack: attackType,
                risk: risk,
                severity: severity,
                decision: item.decision || "MONITOR",
                site_id: item.site_id,
                channel: item.channel,
                forensics: {
                    ...(item.forensics||{}),
                    target_port: item.forensics?.target_port || item.target_port || "Not supplied",
                    client_tool: item.forensics?.client_tool || item.client_tool || "Not recorded",
                    duration: item.forensics?.duration || "Not recorded",
                    transferred: item.forensics?.transferred || "Not recorded",
                    session_log: sessionLog
                }
            });
        });

        liveEntities = entities;
        document.getElementById("activeCaseCount").innerText = Object.keys(liveEntities).length;
        document.getElementById("lastTelemetry").innerText = dgLastRecorded(data.recent);
        document.getElementById("lastTelemetry").title="Last successful refresh: "+new Date().toLocaleString();

        renderCabinetSidebar();
        const visibleEntities = getVisibleEntities();
        if (visibleEntities.length === 0) {activeIP=null;for(const id of ['entityLatestID','entityFirstSeen','entityClassification','entityStatus','vaultHpPort','vaultHpTarget','vaultClientTool','vaultBeState']){const el=document.getElementById(id);if(el)el.textContent='No matching evidence';}for(const id of ['vaultKillChain','vaultIOCs','lines-container']){const el=document.getElementById(id);if(el)el.replaceChildren();}return;}

        const currentStillExists = visibleEntities.some(entity => entity.ip === activeIP);
        if (activeIP && currentStillExists) loadEntity(activeIP);
        else loadEntity(visibleEntities[0].ip);

    } catch (error) {
        console.error("Telemetry sync error:", error);
        const status = document.getElementById("lastTelemetryTime") || document.getElementById("lastTelemetry"); if (status) status.textContent = "API unavailable: " + error.message;
    } finally {entityPollBusy=false;}
}

function severityRank(severity) {
    const ranks = {INFO:0,SAFE:0,LOW:1,MEDIUM:2,HIGH:3,"VERY HIGH":4,CRITICAL:5};
    return ranks[String(severity || "INFO").toUpperCase()] ?? 0;
}

function getVisibleEntities() {
    return Object.values(liveEntities).filter(entity => 
        activeSeverityFilter === "ALL" || entity.highestSeverity === activeSeverityFilter
    ).sort((a, b) => severityRank(b.highestSeverity) - severityRank(a.highestSeverity) || b.maxRisk - a.maxRisk);
}

function filterEntities(sev) {
    activeSeverityFilter = sev;
    renderCabinetSidebar();
    const list = getVisibleEntities();
    if (list.length > 0) loadEntity(list[0].ip);
}

function renderCabinetSidebar() {
    const container = document.getElementById("caseFileList");
    if (!container) return;
    container.innerHTML = "";
    const list = getVisibleEntities();

    if (list.length === 0) {
        container.innerHTML = `<p class="text-[9px] mono text-slate-500 text-center py-4">No entities found.</p>`;
        return;
    }

    list.forEach(ent => {
        const isSelected = ent.ip === activeIP;
        const btn = document.createElement("button");
        btn.className = `w-full text-left p-1.5 rounded border transition-all mb-1 ${
            isSelected 
                ? 'border-cyan-500/50 bg-cyan-500/10' 
                : 'border-[#1e293b] bg-slate-950/40 hover:bg-slate-900/50'
        }`;
        btn.onclick = () => loadEntity(ent.ip);

        const isCrit = ent.maxRisk > 75;
        btn.innerHTML = `
            <div class="flex items-center justify-between mb-0.5">
                <span class="mono text-[10px] font-bold truncate ${isSelected ? 'text-white' : 'text-slate-300'}">${escapeHTML(ent.ip)}</span>
                <span class="px-1 py-0.2 rounded text-[6px] mono font-bold ${isCrit ? 'badge-critical' : 'badge-safe'}">${escapeHTML(ent.highestSeverity)}</span>
            </div>
            <div class="flex justify-between items-center text-[7px] mono text-slate-500">
                <span>${ent.incidents.length} Alert(s)</span>
                <span>Peak: <b class="${isCrit ? 'text-lime-300' : 'text-slate-400'}">${ent.maxRisk}</b></span>
            </div>
        `;
        container.appendChild(btn);
    });
}

function loadEntity(ip) {
    activeIP = ip;
    const entity = liveEntities[ip];
    if (!entity) return;

    renderCabinetSidebar();
    document.querySelectorAll(".entity-ip-insert").forEach(el => el.innerText = entity.ip);

    const vectorsList = Array.from(entity.attackTypes).join(", ");

    document.getElementById("entityIP").innerText = entity.ip;
    
    const aliasEl = document.getElementById("entityAlias");
    aliasEl.innerText = "Vectors: " + vectorsList;
    aliasEl.title = vectorsList;

    document.getElementById("entityLatestID").innerText = entity.latestID;
    document.getElementById("entityFirstSeen").innerText = entity.firstSeen;
    
    const classEl = document.getElementById("entityClassification");
    classEl.innerText = vectorsList;
    classEl.title = vectorsList;

    document.getElementById("entityStatus").innerText = entity.status;
    document.getElementById("entityAnnotation").textContent=(analystAnnotations[entity.ip]||"None")+" (local note only; routing unchanged)";
    document.getElementById("entityIncidents").innerText = entity.incidents.length;

    const latest = entity.incidents[entity.incidents.length - 1];

   // Dual-Layer Network Fingerprint
    document.getElementById("vaultHpPort").innerText = latest.forensics.target_port;
    document.getElementById("vaultBePort").innerText = latest.target_type === "production" ? latest.forensics.target_port : "Not supplied";
    document.getElementById("vaultHpTarget").innerText = latest.site_id || (latest.channel === "ssh" ? "SSH honeypot" : "Website");
    document.getElementById("vaultClientTool").innerText = latest.forensics.client_tool;

    // Dual-Layer Session Metadata
    document.getElementById("vaultHpTrapped").innerText = entity.honeypotHits;
    document.getElementById("vaultBeRequests").innerText = entity.behRequests;

    // Clean text without glowing colors
    document.getElementById("vaultHpRoute").innerText = latest.decision;
    document.getElementById("vaultBeState").innerText = latest.attack_stage || "Not supplied";

    // Progression Kill Chain
    const killChainEl = document.getElementById("vaultKillChain");
    if (killChainEl) {
        killChainEl.innerHTML = renderKillChain(latest.forensics, latest);
    }

    // Indicators of Compromise (IOCs)
    renderIOCs(latest.forensics, latest);

    // Playback Terminal
    let combinedLogs = [];
    entity.incidents.forEach(inc => {
        if (inc.forensics && Array.isArray(inc.forensics.session_log)) {
            combinedLogs = combinedLogs.concat(inc.forensics.session_log);
        }
    });

    const sessionKey = entity.ip + "_" + combinedLogs.length;
    if (currentLoadedIncidentID !== sessionKey) {
        currentLoadedIncidentID = sessionKey;
        initPlaybackEngine(combinedLogs);
    }

    // Activity Stream Table (Strictly 4 rows)
    renderIncidentTable(entity.incidents);
}

function renderIncidentTable(incidents) {
    const tbody = document.querySelector("#incidentHistoryTable tbody");
    if (!tbody) return;
    tbody.innerHTML = "";

    if (!incidents || incidents.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="py-2.5 text-center text-slate-500">No events found.</td></tr>`;
        return;
    }

    // Strictly slice the latest 4 events chronologically reversed
    incidents.slice().reverse().slice(0, 4).forEach(inc => {
        const isCrit = inc.risk > 70;
        const rawId = inc.id || 'DG-000';
        let coloredId = `<span class="text-slate-400">${escapeHTML(rawId)}</span>`;
        if (rawId.includes('-')) {
            const parts = rawId.split('-');
            const prefix = parts[0] + '-';
            const code = parts.slice(1).join('-');
            coloredId = prefix === 'BE-' 
                ? `<span class="font-bold" style="color:var(--purple);">${escapeHTML(prefix)}</span><span>${escapeHTML(code)}</span>` 
                : `<span class="font-bold" style="color:var(--cyan);">${escapeHTML(prefix)}</span><span>${escapeHTML(code)}</span>`;
        }

        const row = document.createElement("tr");
        row.innerHTML = `
            <td class="py-1 px-1">${coloredId}</td>
            <td class="py-1 px-1 text-slate-400">${escapeHTML(inc.time)}</td>
            <td class="py-1 px-1 text-slate-200 truncate max-w-[110px]">${escapeHTML(inc.attack)}</td>
            <td class="py-1 px-1 font-bold ${isCrit ? 'text-lime-300' : 'text-slate-400'}">${inc.risk}</td>
            <td class="py-1 px-1 text-center"><span class="px-1 py-0.2 rounded text-[6px] ${isCrit ? 'badge-critical' : 'badge-safe'}">${escapeHTML(inc.severity)}</span></td>
            <td class="py-1 px-1 text-right font-bold text-slate-300">${escapeHTML(inc.decision)}</td>
        `;
        tbody.appendChild(row);
    });
}

function setEntityStatus(status) {
 if(!activeIP)return;
 analystAnnotations[activeIP]=status;
 const el=document.getElementById('entityAnnotation');if(el)el.textContent=status+' (local note only; routing unchanged)';
}


// -------------------------------------------------------------
// CONTROLS & INIT
// -------------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
    const btnPlayPause = document.getElementById("btnPlayPause");
    const btnSpeed = document.getElementById("btnSpeedToggle");
    const btnRestart = document.getElementById("btnRestartTerminal");
    const btnPrev = document.getElementById("btnPrevEvent");
    const btnNext = document.getElementById("btnNextEvent");
    const progressContainer = document.getElementById("progress-container");

    if (btnPlayPause) {
        btnPlayPause.onclick = () => {
            if (playbackState.totalMs === 0) return;
            const icon = btnPlayPause.querySelector("i");
            if (playbackState.isPlaying) {
                playbackState.isPlaying = false;
                cancelAnimationFrame(playbackState.animationFrame);
                if (icon) icon.className = "fa-solid fa-play";
                return;
            }
            if (playbackState.elapsedMs >= playbackState.totalMs) {
                playbackState.elapsedMs = 0;
                playbackState.currentIndex = -1;
                document.getElementById("lines-container").innerHTML = "";
            }
            playbackState.isPlaying = true;
            playbackState.lastTick = performance.now();
            if (icon) icon.className = "fa-solid fa-pause";
            cancelAnimationFrame(playbackState.animationFrame);
            playbackState.animationFrame = requestAnimationFrame(playbackLoop);
        };
    }

    if (btnSpeed) {
        btnSpeed.onclick = () => {
            speedIndex = (speedIndex + 1) % speeds.length;
            playbackState.speed = speeds[speedIndex];
            btnSpeed.innerText = `${playbackState.speed}x`;
        };
    }

    if (btnRestart) {
        btnRestart.onclick = () => {
            playbackState.isPlaying = false;
            cancelAnimationFrame(playbackState.animationFrame);
            playbackState.elapsedMs = 0;
            playbackState.currentIndex = -1;
            document.getElementById("lines-container").innerHTML = "";
            const icon = document.querySelector("#btnPlayPause i");
            if (icon) icon.className = "fa-solid fa-play";
            syncPlaybackUI();
        };
    }

    if (btnPrev) {
        btnPrev.onclick = () => {
            if (playbackState.currentIndex > 0) {
                const prev = sessionEvents[playbackState.currentIndex - 1];
                playbackState.elapsedMs = prev.startTime;
                renderEventsUpTo(playbackState.currentIndex - 1);
                playbackState.currentIndex--;
                syncPlaybackUI();
            } else if (playbackState.currentIndex === 0) {
                btnRestart.click();
            }
        };
    }

    if (btnNext) {
        btnNext.onclick = () => {
            if (playbackState.currentIndex < sessionEvents.length - 1) {
                const next = sessionEvents[playbackState.currentIndex + 1];
                playbackState.elapsedMs = next.startTime;
                renderEventsUpTo(playbackState.currentIndex + 1);
                playbackState.currentIndex++;
                syncPlaybackUI();
            }
        };
    }

    if (progressContainer) {
        progressContainer.onclick = (e) => {
            if (playbackState.totalMs === 0) return;
            const rect = progressContainer.getBoundingClientRect();
            const pct = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
            playbackState.elapsedMs = pct * playbackState.totalMs;

            let targetIndex = -1;
            for (let i = sessionEvents.length - 1; i >= 0; i--) {
                if (playbackState.elapsedMs >= sessionEvents[i].startTime) {
                    targetIndex = i;
                    break;
                }
            }
            renderEventsUpTo(targetIndex);
            playbackState.currentIndex = targetIndex;
            syncPlaybackUI();
        };
    }

    syncTelemetryFromAPI();
    setInterval(syncTelemetryFromAPI, 3000);
});
</script>

</body>
</html>