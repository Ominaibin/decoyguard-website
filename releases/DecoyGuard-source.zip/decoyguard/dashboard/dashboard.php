<?php
if (!defined('DG_DASHBOARD_PAGE')) define('DG_DASHBOARD_PAGE', true);
require_once __DIR__ . '/api.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DecoyGuard — SOC Monitoring Console</title>

    <link rel="stylesheet" href="soc_theme.css?v=<?= filemtime(__DIR__.'/soc_theme.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script async src="https://cdn.jsdelivr.net/npm/echarts@6.0.0/dist/echarts.min.js" onload="window.dispatchEvent(new Event('dg:echarts-ready'))"></script>

    <style>
        :root {
            --cyan: #20d9ff;
            --purple: #9b6cff;
            --pink: #ff3b9d;
            --green: #35e887;
            --lime: #c7ff32;
            --bg: #050811;
            --panel: #080d1e;
            --panel-2: #0a1021;
            --line: rgba(71, 85, 105, 0.22);
            --muted: #64748b;
            --text: #e2e8f0;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            background-color: var(--bg);
            color: var(--text);
            font-family: 'Plus Jakarta Sans', sans-serif;
            overflow-x: hidden;
        }
        .mono { font-family: 'Segoe UI', monospace; }

        .panel-box {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 10px;
        }

        .kpi-card {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 12px 14px;
            position: relative;
        }
        [hidden] { display: none !important; }

        .dashboard-stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%, 190px), 1fr));
        }

        .soc-panel-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%, 340px), 1fr));
        }

        .settings-backdrop {
            position: fixed;
            inset: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
            background: rgba(2, 6, 18, 0.82);
            backdrop-filter: blur(6px);
        }

        .settings-window {
            width: min(100%, 980px);
            max-height: min(90vh, 720px);
            overflow-y: auto;
            background: #080d1e;
            border: 1px solid rgba(71, 85, 105, 0.28);
            border-radius: 10px;
            box-shadow: 0 24px 80px rgba(0, 0, 0, 0.55);
        }

        .settings-option {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            min-height: 38px;
            padding: 9px 12px;
            border: 1px solid rgba(71, 85, 105, 0.24);
            border-radius: 8px;
            background: rgba(15, 23, 42, 0.4);
            cursor: pointer;
        }

        .settings-option input {
            width: 16px;
            height: 16px;
            accent-color: var(--cyan);
        }

        .settings-action {
            border: 1px solid rgba(71, 85, 105, 0.35);
            border-radius: 8px;
            background: rgba(15, 23, 42, 0.5);
            color: #cbd5e1;
            padding: 7px 11px;
            cursor: pointer;
        }

        .settings-action:hover {
            border-color: rgba(32, 217, 255, 0.45);
            color: var(--cyan);
        }

        /* Circular Gauges - Squarish Cut Ends */
        .gauge-wrap {
            position: relative;
            width: 120px;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .gauge-svg {
            transform: rotate(-90deg);
            width: 120px;
            height: 120px;
        }
        .gauge-track {
            fill: none;
            stroke: #162033;
            stroke-width: 12.5;
        }
        .gauge-value {
            fill: none;
            stroke-width: 12.5;
            stroke-linecap: butt; /* Flat, squarish ends */
            transition: stroke-dashoffset 0.6s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.4s ease;
        }

        /* Pill Badges */
        .badge-safe { background: rgba(53, 232, 135, 0.12); border: 1px solid rgba(53, 232, 135, 0.3); color: var(--green); }
        .badge-critical { background: rgba(199, 255, 50, 0.12); border: 1px solid rgba(199, 255, 50, 0.3); color: var(--lime); }
        .badge-honeypot { background: rgba(255, 59, 157, 0.12); border: 1px solid rgba(255, 59, 157, 0.3); color: var(--pink); }
        .badge-purple { background: rgba(155, 108, 255, 0.12); border: 1px solid rgba(155, 108, 255, 0.3); color: var(--purple); }

        /* Custom Scrollbar */
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.5); }
        .custom-scroll::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #64748b; }

        /* Reading preferences: presentation only, never changes telemetry or routing. */
        body.dg-reading { --dg-reading-scale: 1; --dg-reading-leading: 1.5; }
        body.dg-reading main { font-size: calc(13px * var(--dg-reading-scale)); line-height: var(--dg-reading-leading); }
        body.dg-reading main .text-\[8px\] { font-size: calc(8px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-\[9px\] { font-size: calc(9px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-\[10px\] { font-size: calc(10px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-\[11px\] { font-size: calc(11px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-xs { font-size: calc(12px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-sm { font-size: calc(14px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-lg { font-size: calc(18px * var(--dg-reading-scale)) !important; }
        body.dg-reading main .text-2xl { font-size: calc(24px * var(--dg-reading-scale)) !important; }
        body.dg-reading.dg-spacious .panel-box, body.dg-reading.dg-spacious .kpi-card { padding: 20px !important; }
        body.dg-reading.dg-spacious main td, body.dg-reading.dg-spacious main th { padding-top: 12px !important; padding-bottom: 12px !important; }
        body.dg-reading.dg-compact .panel-box, body.dg-reading.dg-compact .kpi-card { padding: 8px !important; }
        body.dg-reading.dg-compact main td, body.dg-reading.dg-compact main th { padding-top: 4px !important; padding-bottom: 4px !important; }
        body.dg-reading.dg-focus [data-dashboard-panel]:not([data-dashboard-panel="activityStream"]):not([data-dashboard-panel="threatCore"]) { display: none !important; }
        body.dg-reading.dg-no-charts canvas { visibility: hidden !important; }
        body.dg-reading.dg-contrast { --bg:#000; --panel:#080808; --panel-2:#101010; --line:rgba(255,255,255,.65); --muted:#cbd5e1; --text:#fff; }
        body.dg-reading.dg-contrast .text-\[\#64748b\], body.dg-reading.dg-contrast .text-slate-500, body.dg-reading.dg-contrast .text-slate-400 { color:#e2e8f0 !important; }
        .dg-reading-controls { margin-top:16px; border-top:1px solid var(--line); padding-top:16px; }
        .dg-reading-controls select, .dg-reading-controls input[type=range] { accent-color:var(--cyan); }
        .dg-reading-controls select { background:#0b1428; color:#e2e8f0; border:1px solid #334155; border-radius:7px; padding:8px; width:100%; }
        .dg-reading-controls label { display:block; font-size:11px; color:#cbd5e1; margin-bottom:6px; }
        .dg-reading-controls .dg-control-grid { display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:12px; }
        .dg-reading-controls .dg-check { display:flex; align-items:center; gap:8px; }
        .dg-reading-controls .dg-check input { accent-color:#20d9ff; }
        @media(max-width:560px){ .dg-reading-controls .dg-control-grid { grid-template-columns:1fr; } }

        /* Stage 1: structural redesign inspired by the SOC reading-mode concept */
        .dg-main { max-width:none; padding:24px 26px; }
        .dg-main header { gap:16px; flex-wrap:wrap; border-bottom-color:#162640; }
        .dg-main header h1 { font-size:clamp(20px,2vw,27px); letter-spacing:-.035em; }
        .dg-workspace-bar {display:flex; align-items:center; justify-content:space-between; gap:12px; padding:13px 16px; margin:0 0 18px; border:1px solid #19314b; background:linear-gradient(110deg,#0c1a30,#080e1c);border-radius:10px;font-size:12px;}
        .dg-live-dot {display:inline-block;width:7px;height:7px;background:#35e887;border-radius:50%;margin-right:7px;box-shadow:0 0 9px #35e88766}
        .dg-muted {color:#8394af;font-size:11px}
        .dg-workspace-actions {display:flex;gap:8px;flex-wrap:wrap}
        .dg-workspace-actions a,.dg-workspace-actions button {padding:8px 11px;border:1px solid #24405b;border-radius:7px;color:#a9d9ee;background:#0b1729;font-size:11px;text-decoration:none}
        .dg-workspace-actions a:hover,.dg-workspace-actions button:hover {border-color:var(--cyan);color:var(--cyan)}
        .dashboard-stat-grid {grid-template-columns:repeat(5,minmax(0,1fr));gap:12px}
        .kpi-card {padding:17px 15px;min-height:108px;border-color:#1a2d49;background:linear-gradient(160deg,#0b1730,#090f20)}
        .kpi-card [id^="stat"] {font-size:26px}
        .panel-box {border-color:#1a2d49;background:#091225;border-radius:11px}
        #overviewTopPanels {grid-template-columns:minmax(0,1.05fr) minmax(0,1fr);gap:16px}
        #overviewBottomPanels {grid-template-columns:minmax(0,1.65fr) minmax(270px,.8fr);gap:16px}
        #overviewBottomPanels [data-dashboard-panel="activityStream"] .max-h-\[220px\] {max-height:360px}
        #overviewBottomPanels th {font-size:10px}
        #overviewBottomPanels td {font-size:11px}
        .dg-reading-drawer {position:fixed;z-index:85;right:0;top:0;bottom:0;width:min(360px,100vw);overflow-y:auto;padding:22px;background:#0a1428;border-left:1px solid #24405b;box-shadow:-20px 0 65px #0009}
        .dg-drawer-heading {display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding-bottom:16px;border-bottom:1px solid #23324b}
        .dg-drawer-heading strong {font-size:14px;color:white}
        .dg-drawer-heading strong i {color:var(--cyan);margin-right:8px}
        .dg-drawer-heading p {font-size:11px;color:#94a3b8;margin-top:7px}
        .dg-drawer-heading button {color:#cbd5e1;padding:5px 8px}
        .dg-reading-drawer .dg-reading-controls {border:0;margin:0;padding-top:15px}
        .dg-reading-drawer .dg-control-grid {grid-template-columns:1fr;gap:16px}
        .dg-reading-drawer label {font-size:12px}
        body.dg-drawer-open .dg-main {margin-right:360px}
        body.dg-reading.dg-focus .dg-workspace-bar,body.dg-reading.dg-focus .dg-global-charts {display:none}
        body.dg-reading.dg-focus #overviewTopPanels {grid-template-columns:1fr}
        body.dg-reading.dg-focus #overviewBottomPanels {grid-template-columns:1fr}
        body.dg-reading.dg-contrast .panel-box,body.dg-reading.dg-contrast .kpi-card {background:#080808;border-color:#fff}
        @media(max-width:1450px) {.dashboard-stat-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
        @media(max-width:1150px) {#overviewTopPanels,#overviewBottomPanels{grid-template-columns:1fr}body.dg-drawer-open .dg-main{margin-right:0}}
        @media(max-width:700px) {.dg-main{padding:14px}.dashboard-stat-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dg-workspace-bar{align-items:flex-start;flex-direction:column}.dg-muted{display:none}.dg-main header>div:last-child{flex-wrap:wrap}}


        /* Stage 2 global overview */
        .dg-workspace-bar {padding:11px 16px;margin-bottom:15px}
        .dg-global-charts {display:grid;grid-template-columns:1fr 1.2fr 1fr;gap:14px;margin:0 0 16px}
        .dg-summary-card {min-height:246px;padding:16px;min-width:0}
        .dg-card-heading {display:flex;justify-content:space-between;gap:8px;align-items:center;margin-bottom:15px}
        .dg-card-heading h3 {font-size:13px;font-weight:700;color:#f8fafc}
        .dg-card-heading span {font-size:10px;color:#758aa7}
        .dg-summary-body {display:flex;flex-direction:column;gap:13px}
        .dg-empty {color:#8797b0;font-size:12px;padding:25px 0}
        .dg-bar-row {display:flex;flex-direction:column;gap:5px}
        .dg-bar-label {display:flex;justify-content:space-between;gap:8px;font-size:11px;color:#cbd5e1}
        .dg-bar-label span {overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .dg-bar-label strong {color:#e2e8f0}
        .dg-bar-track {height:7px;border-radius:4px;background:#172841;overflow:hidden}
        .dg-bar-fill {height:100%;border-radius:4px;background:linear-gradient(90deg,#20d9ff,#ac78f9)}
        #dgAttackTypes .dg-bar-fill {background:linear-gradient(90deg,#ff3b9d,#b881ff)}
        .dg-mini-chart {height:184px;position:relative}
        .dg-engine-details {margin:0 0 16px;border:1px solid #1b2e49;border-radius:11px;background:#081426}
        .dg-engine-details>summary {list-style:none;cursor:pointer;padding:14px 16px;color:#e5edf8;font-weight:700;font-size:12px}
        .dg-engine-details>summary::-webkit-details-marker {display:none}
        .dg-engine-details>summary i {color:#20d9ff;margin-right:9px}
        .dg-engine-details>summary span {font-size:10px;color:#8091ab;font-weight:400;margin-left:10px}
        .dg-engine-details[open]>summary {border-bottom:1px solid #1b2e49;margin-bottom:14px}
        .dg-engine-details #overviewTopPanels {padding:0 14px 14px;margin-bottom:0}
        @media(max-width:1250px){.dg-global-charts{grid-template-columns:1fr 1fr}.dg-global-charts article:last-child{grid-column:1/-1}}
        @media(max-width:800px){.dg-global-charts{grid-template-columns:1fr}.dg-global-charts article:last-child{grid-column:auto}}


        .dg-top-select {background:#0b182c;border:1px solid #284361;color:#d9e8f7;border-radius:7px;padding:8px 9px;font-size:11px;max-width:190px}
        .dg-control-label {font-size:10px;color:#8498b5}
        .dg-header-actions {flex-wrap:wrap;justify-content:flex-end}
        .dg-workspace-switch {display:flex;gap:4px;padding:3px;border:1px solid #263c56;border-radius:9px;background:#060e1d}
        .dg-workspace-switch button {padding:7px 12px;font-size:11px;color:#9db0c9;border-radius:6px}
        .dg-workspace-switch .dg-view-active {background:#0e3650;color:#23ddff}
        .dg-scope-notice {margin-bottom:14px;border:1px solid #26516b;background:#0b2032;padding:12px 15px;border-radius:8px;font-size:11px;color:#b9d9ed}
        .dg-directory {border:1px solid #1a2d49;background:#091225;border-radius:11px;padding:18px;margin-bottom:17px}
        .dg-site-cards {display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
        .dg-site-card {padding:18px;border:1px solid #243952;background:linear-gradient(145deg,#0b1b30,#081020);border-radius:10px;min-height:166px}
        .dg-site-card h3 {font-size:15px;font-weight:700;color:white;margin-bottom:9px}
        .dg-site-status {font-size:10px;color:#32e9b5;border:1px solid #1b665a;padding:3px 8px;border-radius:12px}
        .dg-site-card p {font-size:11px;color:#a0b3ce;margin:14px 0}
        .dg-site-card button {border:1px solid #287390;border-radius:7px;padding:8px 11px;color:#2cddff;font-size:11px}
        .dg-incident-filters {display:flex;gap:12px;flex-wrap:wrap;margin:0 0 15px;padding:15px;border:1px solid #1a2d49;border-radius:10px;background:#091225}
        .dg-incident-filters label {font-size:11px;color:#a9bbd0;display:flex;flex-direction:column;gap:6px;min-width:170px;flex:1}
        .dg-incident-filters input,.dg-incident-filters select {background:#0b182c;border:1px solid #284361;color:#f1f5f9;padding:9px;border-radius:7px;min-width:0}
        .dg-directory[hidden],.dg-incident-filters[hidden],.dg-global-charts[hidden],.dg-engine-details[hidden],.dashboard-stat-grid[hidden],#overviewBottomPanels[hidden],.dg-scope-notice[hidden] {display:none!important}
        @media(max-width:1000px){.dg-site-cards{grid-template-columns:repeat(2,minmax(0,1fr))}.dg-header-actions{justify-content:flex-start}}
        @media(max-width:620px){.dg-site-cards{grid-template-columns:1fr}.dg-workspace-bar{flex-wrap:wrap}.dg-top-select{max-width:145px}}

    
        /* Sketch-matched visualization cards */
        .dg-global-charts{grid-template-columns:minmax(0,1.05fr) minmax(0,1.18fr) minmax(0,.92fr);gap:14px}
        .dg-summary-card{min-height:278px;padding:17px 18px;background:linear-gradient(145deg,#0b1830,#081124)}
        .dg-card-heading{margin-bottom:19px}
        .dg-card-heading h3{font-size:13px;letter-spacing:-.01em}
        .dg-card-heading span{font-size:10px}
        .dg-site-visual{display:grid;grid-template-columns:minmax(115px,.95fr) minmax(120px,1fr);gap:15px;align-items:center;min-height:193px}
        .dg-site-donut{aspect-ratio:1;width:min(100%,186px);border-radius:50%;background:#192b48;display:grid;place-items:center;margin:auto}
        .dg-donut-core{width:66%;aspect-ratio:1;border-radius:50%;background:#091428;display:flex;flex-direction:column;justify-content:center;align-items:center;box-shadow:inset 0 0 0 1px #1a2b46}
        .dg-donut-core strong{font-size:27px;font-weight:800;color:white}
        .dg-donut-core span{font-size:10px;color:#a0b3ce;margin-top:4px}
        .dg-site-legend{display:flex;flex-direction:column;gap:12px;min-width:0}
        .dg-site-legend-row{display:flex;align-items:center;gap:8px;color:#cbd9eb;font-size:11px}
        .dg-site-legend-row i{width:10px;height:10px;flex:none;border-radius:50%}
        .dg-site-legend-row span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
        .dg-site-legend-row strong{font-size:10px;white-space:nowrap;font-weight:600;color:#d9e7f7}
        .dg-trend-legend{display:flex;justify-content:flex-end;margin:-6px 0 9px;color:#a4b6d2;font-size:10px}
        .dg-trend-legend i{display:inline-block;width:8px;height:8px;border-radius:50%;background:#20d9ff;margin-right:5px}
        .dg-mini-chart{height:189px}
        #dgAttackTypes .dg-summary-body{gap:13px}
        #dgAttackTypes .dg-bar-row{gap:6px}
        #dgAttackTypes .dg-bar-track{height:9px}
        @media(max-width:1300px){.dg-global-charts{grid-template-columns:1fr 1fr}.dg-global-charts article:last-child{grid-column:1/-1}}
        @media(max-width:780px){.dg-global-charts{grid-template-columns:1fr}.dg-global-charts article:last-child{grid-column:auto}}
</style>
    <link rel="stylesheet" href="soc_theme.css?v=trend-7">
<?php if(is_readable(__DIR__.'/dashboard_workspace.css')){echo '<style id="dgWorkspaceStyles">';readfile(__DIR__.'/dashboard_workspace.css');echo '</style>';} ?>
</head>
<body class="flex min-h-screen">

    <!-- UNIVERSAL SIDEBAR INCLUDE -->
    <?php include 'sidebar.php'; ?>

    <!-- MAIN CONSOLE -->
    <main class="dg-main flex-1 p-5 overflow-y-auto min-w-0 transition-all duration-200">
        <!-- TOP BAR -->
        <header class="flex items-center justify-between pb-4 mb-4 border-b border-[#1e293b]">
            <div>
                <div class="flex items-center gap-3">
                    <h1 class="text-lg font-extrabold tracking-tight text-white m-0">Global Overview</h1>
                    <span class="px-2.5 py-0.5 rounded text-[10px] mono font-bold" style="background: rgba(255,59,157,0.1); border: 1px solid rgba(255,59,157,0.3); color: var(--pink);">
                        ● STREAM ACTIVE
                    </span>
                </div>
                <p class="text-[11px] mono text-[#64748b] mt-0.5">LIVE SECURITY TELEMETRY ACROSS PROTECTED WEBSITES</p>
            </div>

            <div class="flex items-center gap-2.5 dg-header-actions">
                <button type="button" id="dgEditLayout" class="settings-action" aria-pressed="false" aria-controls="dgCustomGrid">Edit layout</button>
                
                <label class="dg-control-label" for="dgSiteSelect">Website</label>
                <select id="dgSiteSelect" class="dg-top-select" aria-label="Filter dashboard by website"><option value="">All websites</option></select>
                <label class="dg-global-only dg-control-label" for="dgGlobalPeriod">Time</label><select id="dgGlobalPeriod" class="dg-global-only dg-top-select" aria-label="Global overview history period"><option value="retained">Retained history</option><option value="30">Last 30 minutes</option><option value="60">Last hour</option><option value="1440">Last 24 hours</option></select><label class="dg-global-only dg-control-label" for="dgFeedMode">Feed</label><select id="dgFeedMode" class="dg-global-only dg-top-select"><option value="live">Live stream</option><option value="paused">Paused</option></select><label class="dg-control-label" for="dgWindowSelect">Rows</label>
                <select id="dgWindowSelect" class="dg-top-select" aria-label="Recent event limit"><option value="25">Latest 25 events</option><option value="50">Latest 50 events</option><option value="100" selected>Latest 100 events</option></select>
                
                <div class="px-3 py-1.5 rounded-lg flex items-center gap-2 border text-[10px] mono font-bold" style="background: rgba(32,217,255,0.08); border-color: rgba(32,217,255,0.25); color: var(--cyan);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                    <span class="text-[#64748b] uppercase tracking-wider text-[8px]">LAST TELEMETRY</span>
                    <span id="lastTelemetryTime" class="text-slate-200 font-extrabold">--:--:--</span>
                </div>
                <div class="px-3 py-1.5 rounded-lg flex items-center gap-2 border text-[10px] mono font-extrabold" style="background: rgba(53,232,135,0.08); border-color: rgba(53,232,135,0.25); color: var(--green);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--green); box-shadow: 0 0 6px var(--green);"></span>
                    <span class="tracking-wide" id="dgConnectionStatus">CONNECTING</span>
                </div>
            </div>
        </header>

        <div class="dg-workspace-bar">
            <div><span class="dg-live-dot"></span> <strong id="dgWorkspaceName">Security Operations</strong><span class="dg-muted" id="dgWorkspaceCaption"> / Global monitoring workspace</span></div>
            <div class="dg-workspace-switch" role="group" aria-label="Workspace view"><button type="button" class="dg-view-active" data-dg-view="overview">Overview</button><button type="button" data-dg-view="websites">Websites</button><button type="button" data-dg-view="incidents">Incidents</button><button type="button" data-dg-view="reports">Reports</button></div>
</div>
        <div id="dgScopeNotice" class="dg-scope-notice" hidden></div>
        <section id="dgWebsiteDirectory" class="dg-directory" hidden aria-label="Protected website directory"><div class="dg-card-heading"><h3>Protected Websites</h3><span>Registered sites · live deployment state from Website Handler</span></div><div id="dgSiteCards" class="dg-site-cards"><p class="dg-empty">Loading configured websites…</p></div></section>
        <section id="dgIncidentFilters" class="dg-incident-filters" hidden aria-label="Incident filters"><label>Attack search <input id="dgAttackSearch" type="search" placeholder="Search attack, source IP, incident ID…"></label><label>Severity <select id="dgSeverityFilter"><option value="">All severities</option><option>CRITICAL</option><option>VERY HIGH</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option><option>SAFE</option><option>INFO</option></select></label><label>Environment <select id="dgEnvironmentFilter"><option value="">All environments</option><option value="production">Production</option><option value="decoy">Decoy</option><option value="honeypot">Honeypot</option></select></label></section>
        <!-- ROW 1: 5 METRIC CARDS -->
        <section class="dashboard-stat-grid gap-3 mb-5">
            <div class="kpi-card" data-dashboard-panel="total">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Detections in Period</span>
                    <i class="fa-solid fa-globe text-sm" style="color: var(--cyan);"></i>
                </div>
                <div id="statTotal" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--cyan);">
                    <span>●</span> Selected history period
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="critical">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Critical Threats</span>
                    <i class="fa-solid fa-triangle-exclamation text-sm" style="color: var(--lime);"></i>
                </div>
                <div id="statCritical" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--lime);">
                    <span id="statCriticalPercent">0%</span> of detections
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="high">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>High Risk</span>
                    <i class="fa-solid fa-shield-heart text-sm" style="color: var(--green);"></i>
                </div>
                <div id="statHigh" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--green);">
                    <span id="statHighPercent">0%</span> of detections
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="honeypotHits">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Decoy-Targeted Detections</span>
                    <i class="fa-solid fa-jar text-sm" style="color: var(--pink);"></i>
                </div>
                <div id="statHoneypot" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--pink);">
                    <span>●</span> Recorded decoy target
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="blocked">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Blocked Detections</span>
                    <i class="fa-solid fa-ban text-sm" style="color: var(--purple);"></i>
                </div>
                <div id="statBlocked" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--purple);">
                    <span>●</span> Recorded block decision
                </div>
            </div>
        </section>

        <!-- TOP TIER: THREAT INTELLIGENCE & DETECTION ENGINES (50/50) -->
        <section class="dg-global-charts" data-dashboard-layout aria-label="Global threat visualizations">
            <article class="panel-box dg-summary-card" data-dashboard-panel="siteChart">
                <div class="dg-card-heading"><h3>Threats by Website</h3><span>Retained events</span></div>
                <div class="dg-site-visual">
                    <div class="dg-site-donut" id="dgSiteDonut"><div class="dg-donut-core"><strong id="dgDonutTotal">—</strong><span>Total events</span></div></div>
                    <div id="dgSiteThreats" class="dg-site-legend"><p class="dg-empty">Loading website activity…</p></div>
                </div>

            </article>
            <article class="panel-box dg-summary-card" data-dashboard-panel="attackTrendChart">
                <div class="dg-card-heading"><h3>Attack Trend</h3><span id="dgAttackTrendScope">All Websites · retained events</span></div>
                <div class="dg-trend-controls"><label for="dgTrendWindow">History period</label><select id="dgTrendWindow"><option value="retained">Retained history</option><option value="30">Last 30 minutes</option><option value="60">Last hour</option><option value="1440">Last 24 hours</option></select><label for="dgTrendFit">Display</label><select id="dgTrendFit"><option value="1">Fit to activity</option><option value="0">Full period</option></select></div><div id="dgTrendTotals" class="dg-trend-totals" aria-live="polite"></div><div class="dg-trend-body"><div class="dg-trend-plot"><div class="dg-mini-chart"><canvas id="dgAttackTrend" role="img" aria-label="Retained detection counts by severity and time"></canvas></div></div><aside class="dg-trend-sites"><h4>Detections by website</h4><div id="dgTrendSites"></div><p id="dgTrendSitesNote" class="dg-trend-sites-note"></p></aside></div><p id="dgTrendCoverage" class="dg-trend-coverage"></p><details class="dg-history-diagnostics"><summary>History source diagnostics</summary><div id="dgHistorySources"></div></details>
            </article>
            <article class="panel-box dg-summary-card" data-dashboard-panel="attackTypesChart">
                <div class="dg-card-heading"><h3>Top Attack Types</h3><span>Same history period as Attack Trend</span></div>
                <div id="dgAttackTypes" class="dg-summary-body"><p class="dg-empty">Loading attack types…</p></div>
            </article>
        </section>
        <article class="panel-box dg-summary-card dg-severity-widget" data-dashboard-panel="severitySplit" aria-label="Severity Split">
            <div id="dgSeveritySplit" class="dg-severity-content"><p class="dg-empty">Waiting for selected severity history…</p></div>
        </article>
        <details class="dg-engine-details" id="dgEngineDetails" data-dashboard-panel="engineDetails">
            <summary><i class="fa-solid fa-shield-halved"></i> Detection Engine Details <span>Global assessments and selected-feed behavioural patterns</span></summary>
        <section id="overviewTopPanels" class="soc-panel-grid gap-4 mb-4" data-dashboard-layout>

            <!-- LEFT COLUMN: Gauges & Timeline -->
            <div class="flex flex-col gap-4" data-dashboard-group>
                <div class="panel-box p-4 flex-1 flex flex-col justify-between" data-dashboard-panel="threatCore">
                    <div class="flex items-center justify-between mb-2">
                        <div>
                            <h3 class="text-xs font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-crosshairs text-xs" style="color: var(--pink);"></i> Latest Global Assessment
                            </h3>
                            <p class="text-[10px] text-[#64748b] m-0">Latest global assessment · independent of website filter</p>
                        </div>
                        <span class="px-2 py-0.5 rounded text-[9px] mono font-bold" style="background: rgba(255,59,157,0.1); color: var(--pink);">LIVE</span>
                    </div>

                    <!-- Centered Gauges with Smaller Numbers -->
                    <div class="grid grid-cols-2 gap-4 py-4 flex-1 items-center border-b border-[#1e293b]">
                        <div class="flex flex-col items-center justify-center">
                            <div class="gauge-wrap">
                                <svg class="gauge-svg" viewBox="0 0 140 140">
                                    <circle class="gauge-track" cx="70" cy="70" r="54"></circle>
                                    <circle id="riskGaugeCircle" class="gauge-value" cx="70" cy="70" r="54" stroke="#ff3b9d"
                                            stroke-linecap="butt"
                                            stroke-dasharray="339.29" stroke-dashoffset="339.29"></circle>
                                </svg>
                                <div class="absolute text-center">
                                    <span id="gaugeRiskVal" class="text-xl font-extrabold mono text-white">0</span>
                                </div>
                            </div>
                            <span class="text-xs font-bold text-slate-300 mt-2">Risk Score</span>
                            <span id="gaugeRiskBadge" class="px-2.5 py-0.5 rounded-full text-[9px] mono font-bold badge-safe mt-1">SAFE</span>
                        </div>

                        <div class="flex flex-col items-center justify-center">
                            <div class="gauge-wrap">
                                <svg class="gauge-svg" viewBox="0 0 140 140">
                                    <circle class="gauge-track" cx="70" cy="70" r="54"></circle>
                                    <circle id="confGaugeCircle" class="gauge-value" cx="70" cy="70" r="54" stroke="#20d9ff"
                                            stroke-linecap="butt"
                                            stroke-dasharray="339.29" stroke-dashoffset="339.29"></circle>
                                </svg>
                                <div class="absolute text-center">
                                    <span id="gaugeConfVal" class="text-xl font-extrabold mono text-white">0%</span>
                                </div>
                            </div>
                            <span class="text-xs font-bold text-slate-300 mt-2">Confidence</span>
                        </div>
                    </div>

                    <!-- Response Strip -->
                    <div class="grid grid-cols-3 text-center pt-3">
                        <div>
                            <span class="text-[9px] mono text-[#64748b] block uppercase">Current Response</span>
                            <span id="stripResponse" class="text-xs font-extrabold text-white mt-1 block" style="color: var(--cyan);">ALLOW</span>
                        </div>
                        <div class="border-x border-[#1e293b]">
                            <span class="text-[9px] mono text-[#64748b] block uppercase">Attack Stage</span>
                            <span id="stripStage" class="text-xs font-extrabold text-white mt-1 block" style="color: var(--purple);">NORMAL</span>
                        </div>
                        <div>
                            <span class="text-[9px] mono text-[#64748b] block uppercase">Threat Level</span>
                            <span id="stripSeverity" class="text-xs font-extrabold text-white mt-1 block" style="color: var(--green);">SAFE</span>
                        </div>
                    </div>
                </div>

                <!-- Latest Stage Indicator -->
                <div class="panel-box p-3" data-dashboard-panel="attackTimeline">
                    <span class="text-[8px] mono text-[#64748b] uppercase block">INCIDENT PATH</span>
                    <h3 class="text-xs font-bold text-white mb-2">Latest Stage Indicator</h3>
                    
                    <div class="dg-path-nodes relative flex items-center justify-between px-3 py-1">
                        <div class="absolute left-6 right-6 top-[15px] h-[2px] bg-white/20 z-0"></div>

                        <!-- Nodes -->
                        <div id="tlNodeNormal" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Normal</span>
                        </div>
                        <div id="tlNodeSuspicious" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Suspicious</span>
                        </div>
                        <div id="tlNodeDetected" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Detected</span>
                        </div>
                        <div id="tlNodeEscalated" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Escalated</span>
                        </div>
                        <div id="tlNodeHoneypot" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Honeypot</span>
                        </div>
                    </div>
                    <div class="dg-path-context"><div><span>Reported stage</span><strong id="dgPathStage">Awaiting telemetry</strong></div><div><span>Recorded response</span><strong id="dgPathResponse">Awaiting telemetry</strong></div></div>
                    <p class="dg-path-note">Latest global assessment. Highlighted stage does not prove every preceding step occurred.</p>
                </div>
            </div>

            <!-- RIGHT COLUMN: Behaviour, Honeypot & Latest Assessment Contributions -->
            <div class="flex flex-col gap-4" data-dashboard-group>
                <div class="grid grid-cols-2 gap-3" data-dashboard-group>
                    <!-- Behaviour Engine -->
                    <div class="panel-box dg-behaviour-card" data-dashboard-panel="behaviour">
                        <div class="dg-widget-heading"><h3><i class="fa-solid fa-wave-square" aria-hidden="true"></i> Behaviour</h3><span class="badge-purple">RECORDED</span></div>
                        <div class="dg-behaviour-total"><strong id="behRiskScore">0</strong><div><span>Pattern records</span><small>Selected feed · recorded detections</small></div></div>
                        <div class="dg-pattern-visual"><div id="dgBehaviourRose" class="dg-pattern-rose"></div><div class="dg-pattern-key"><span id="behRiskBadge" class="badge-safe">NO PATTERNS</span><ul id="dgBehaviourPatterns"><li>Waiting for recorded pattern evidence…</li></ul></div></div>
                    </div>

                    <!-- Honeypot -->
                    <div class="panel-box p-4 border-l-4 flex flex-col justify-between" data-dashboard-panel="honeypot" style="border-left-color: var(--pink);">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-xs font-bold text-white flex items-center gap-2">
                                    <i class="fa-solid fa-jar text-xs" style="color: var(--pink);"></i> Honeypot · global
                                </span>
                                <span class="text-[9px] mono font-bold px-2 py-0.5 rounded badge-honeypot">RECORDED</span>
                            </div>
                            <div class="dg-honeypot-metrics">
                                <div class="p-2 rounded bg-slate-900/60 border border-slate-800">
                                    <i class="fa-solid fa-jar" aria-hidden="true"></i><span id="hpTrapped" class="text-sm font-bold mono text-white block" style="color: var(--pink);">0</span>
                                    <span class="text-[8px] font-bold text-[#64748b] block uppercase mt-0.5">Trapped</span>
                                </div>
                                <div class="p-2 rounded bg-slate-900/60 border border-slate-800">
                                    <i class="fa-solid fa-users" aria-hidden="true"></i><span id="hpSessions" class="text-sm font-bold mono text-white block">0</span>
                                    <span class="text-[8px] font-bold text-[#64748b] block uppercase mt-0.5">Sessions</span>
                                </div>
                                <div class="p-2 rounded bg-slate-900/60 border border-slate-800">
                                    <i class="fa-solid fa-terminal" aria-hidden="true"></i><span id="hpCommands" class="text-sm font-bold mono text-white block">0</span>
                                    <span class="text-[8px] font-bold text-[#64748b] block uppercase mt-0.5">Commands</span>
                                </div>
                            </div>
                        </div>
                        <div class="dg-honeypot-source">
                            Last source: <span id="hpLatestIp" class="text-slate-300 font-semibold">Awaiting telemetry</span>
                        </div>
                    </div>
                </div>

                <!-- Latest Assessment Contributions (Thicker, Less Roundish Bars) -->
                <div class="panel-box p-4 flex-1 flex flex-col justify-between" data-dashboard-panel="riskLayers">
                    <div class="flex items-center justify-between mb-2">
                        <div>
                            <h3 class="text-xs font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-layer-group text-xs" style="color: var(--purple);"></i> Latest Assessment Contributions
                            </h3>
                            <p class="text-[10px] text-[#64748b] m-0">Score contribution · latest global assessment</p>
                        </div>
                        <span class="px-2 py-1 rounded text-[9px] mono font-bold border border-slate-800 text-slate-400 bg-slate-900/60">
                            4 ENGINE MODEL
                        </span>
                    </div>
                    <div class="relative w-full" style="height: 180px;">
                        <canvas id="riskLayerChart"></canvas>
                    </div>
                </div>
            </div>
        </section>

        </details>

        <!-- BOTTOM TIER: ACTIVITY STREAM & THREAT HISTORY (50/50) -->
        <section id="overviewBottomPanels" class="soc-panel-grid gap-4" data-dashboard-layout>

            <!-- Activity Stream Table (Max 8 Visible, Scrollable) -->
            <div class="panel-box p-4 flex flex-col justify-between" data-dashboard-panel="activityStream"><div class="dg-scan-controls"><span class="dg-auto-group-label">Repeated scanner probes are grouped automatically</span><span id="dgScanGroupNote" class="dg-note"></span></div>
                <div class="dg-activity-body">
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-[#ff3b9d] shadow-[0_0_6px_#ff3b9d]"></span>
                            <h3 class="text-xs font-bold text-white m-0">DecoyGuard Activity Stream</h3>
                        </div>
                        <span class="text-[9px] mono text-[#64748b]">Live telemetry & responses</span>
                    </div>

                    <div class="dg-activity-scroll overflow-y-auto overflow-x-auto max-h-[220px] custom-scroll pr-1">
                        <table class="w-full text-left border-collapse">
                            <thead class="sticky top-0 bg-[#080d1e] z-10">
                                <tr class="text-[8px] mono text-[#64748b] border-b border-[#1e293b]">
                                    <th class="py-2 px-1">INCIDENT</th>
                                    <th class="py-2 px-1">TIME</th>
                                    <th class="py-2 px-1">WEBSITE</th>
                                    <th class="py-2 px-1">SOURCE IP</th>
                                    <th class="py-2 px-1">ATTACK</th>
                                    <th class="py-2 px-1">RISK</th>
                                    <th class="py-2 px-1 text-center">SEVERITY</th>
                                    <th class="py-2 px-1 text-right">DECISION</th>
                                </tr>
                            </thead>
                            <tbody id="activityStreamBody" class="text-[9px] mono divide-y divide-[#1e293b]/50">
                                <tr>
                                    <td colspan="8" class="py-4 text-center text-[#64748b]">Polling logs...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Risk Over Time Chart -->
            <div class="panel-box p-4 flex flex-col justify-between" data-dashboard-panel="threatHistory"><p class="dg-note dg-latest-risk-note">Recorded risk scores · scanner groups use peak score · up to 60 points</p><div id="dgGlobalRiskStats" class="dg-global-only dg-risk-stats"></div>
                <div class="flex items-center justify-between mb-1">
                    <h3 class="text-xs font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-chart-line text-xs" style="color: var(--cyan);"></i> Risk Over Time
                    </h3>
                    <span class="text-[9px] mono text-[#64748b]">LIVE TELEMETRY</span>
                </div>
                <div class="w-full relative" style="height: 190px;">
                    <canvas id="threatHistoryChart"></canvas>
                </div>
            </div>

        </section>
<section class="panel-box p-5 mb-4 report-builder" id="securityReports" >
            <div class="brief-header"><div><p class="brief-kicker">EVIDENCE &amp; REPORTING</p><h2>Generate a security report</h2></div><span class="report-tag">From retained logs</span></div>
            <p class="report-help">Security Evidence includes detector findings. Behavioural Patterns includes only request-pattern anomalies; signatures remain separate. Log Activity includes retained request and log records.</p>
            <form id="securityReportForm" action="api.php" method="post" target="_blank" class="report-form">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="report"><input type="hidden" name="team" id="reportTeam" value="Security Operations">
                <label>Report type<select name="scope"><option value="security">Security Evidence · all detector findings</option><option value="behaviour">Behavioural Patterns · excludes signatures</option><option value="activity">Log Activity Report</option></select></label>
                <label>Website<select name="site" id="reportSite"><option value="">All websites</option></select></label>
                <input type="hidden" name="period" value="retained"><input type="hidden" name="timezone" id="reportTimezone" value="UTC">
                
                <label>Format<select name="format"><option value="pdf">Professional A4 PDF</option><option value="bundle">Evidence bundle (PDF, CSV, JSON + hashes)</option><option value="html">Print preview / HTML report</option><option value="txt">ASCII text report (.txt)</option><option value="csv">CSV evidence export</option><option value="json">JSON report &amp; metadata</option></select></label>
                <details class="report-help" style="grid-column:1 / -1"><summary>Optional reviewer statement</summary>
                <label>Reviewer name<input name="reviewer" maxlength="120" placeholder="Enter your name"></label>
                <label>Role<input name="review_role" maxlength="120" placeholder="e.g. Security analyst"></label>
                <p>Document date and time are recorded automatically when the report is generated, using this device's time zone.</p>
                <label>Ticket / case reference<input name="ticket_id" maxlength="120" placeholder="Optional case reference"></label><label>Review state<select name="sign_off_status"><option value="draft">Draft / not yet reviewed</option><option value="reviewed">Reviewed (your statement)</option></select></label>
                <label>Review conclusion<input name="review_conclusion" maxlength="1200" placeholder="State only what you reviewed and verified"></label>
                <p>This records your statement; it does not create a digital signature or independently verify containment.</p></details>
                <div class="report-submit"><button class="settings-action" type="submit">Generate report ↗</button><span id="reportFormStatus" role="status">The evidence period is derived automatically from retained records.</span></div>
            </form>
            <p class="report-help">Reports list source coverage and read limits. JSON telemetry is supported now; local <code>syslog.log</code> / <code>syslog.jsonl</code> can be included if a collector supplies them. This interface does not install a network syslog receiver.</p>
        </section>
    </main>

    <div id="dashboardSettingsBackdrop" class="settings-backdrop" hidden>
        <section class="settings-window p-4 sm:p-5" role="dialog" aria-modal="true" aria-labelledby="dashboardSettingsTitle">
            <div class="flex items-start justify-between gap-4 mb-4">
                <div>
                    <h2 id="dashboardSettingsTitle" class="text-sm font-extrabold text-white m-0">Dashboard Settings</h2>
                    <p class="text-[10px] text-slate-500 mt-1 mb-0">Choose which cards and panels appear in your live overview. Your choices are saved in this browser.</p>
                </div>
                <div class="flex items-center gap-2 shrink-0">
                    <button id="showAllDashboardPanels" class="settings-action text-[9px] mono font-bold" type="button">Show all</button>
                    <button id="hideAllDashboardPanels" class="settings-action text-[9px] mono font-bold" type="button">Hide all</button>
                    <button id="closeDashboardSettings" class="settings-action text-xs" type="button" aria-label="Close dashboard settings">
                        <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
<section class="dg-settings-appearance" aria-label="Layout and display settings"><h3>Layout &amp; appearance</h3><p>Choose a dashboard layout, saved workspace, or reading preferences.</p><div class="dg-settings-appearance-actions"><button type="button" class="dg-layout-launch" data-open-layouts><i class="fa-solid fa-border-all"></i> Layout</button><button id="readingOptionsButton" type="button" class="px-3 py-1.5 rounded-lg border text-[10px] mono font-bold" style="border-color:rgba(32,217,255,.4);color:var(--cyan);background:rgba(32,217,255,.07)" aria-label="Open reading options"><i class="fa-solid fa-book-open" aria-hidden="true"></i> Reading Mode</button></div></section><h3 class="dg-settings-panels-title">Visible dashboard panels</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2"><label class="settings-option text-[10px] font-semibold text-slate-300"><span>Threats by Website</span><input type="checkbox" data-dashboard-toggle="siteChart" checked></label><label class="settings-option text-[10px] font-semibold text-slate-300"><span>Attack Trend</span><input type="checkbox" data-dashboard-toggle="attackTrendChart" checked></label><label class="settings-option text-[10px] font-semibold text-slate-300"><span>Top Attack Types</span><input type="checkbox" data-dashboard-toggle="attackTypesChart" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Detections in Period</span><input type="checkbox" data-dashboard-toggle="total" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Critical Threats</span><input type="checkbox" data-dashboard-toggle="critical" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>High Risk</span><input type="checkbox" data-dashboard-toggle="high" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Decoy-Targeted Detections</span><input type="checkbox" data-dashboard-toggle="honeypotHits" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Blocked Detections</span><input type="checkbox" data-dashboard-toggle="blocked" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Latest Global Assessment</span><input type="checkbox" data-dashboard-toggle="threatCore" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Latest Stage Indicator</span><input type="checkbox" data-dashboard-toggle="attackTimeline"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Behaviour</span><input type="checkbox" data-dashboard-toggle="behaviour"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Honeypot</span><input type="checkbox" data-dashboard-toggle="honeypot"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Latest Assessment Contributions</span><input type="checkbox" data-dashboard-toggle="riskLayers"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Activity Stream</span><input type="checkbox" data-dashboard-toggle="activityStream" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Risk Over Time</span><input type="checkbox" data-dashboard-toggle="threatHistory"></label>
            </div>
            <p class="text-[9px] mono text-slate-600 mt-4 mb-0">Changes apply immediately to the live overview.</p>


        </section>
    </div>


    <aside id="dgReadingDrawer" class="dg-reading-drawer" hidden aria-label="Display and reading options">
        <div class="dg-drawer-heading">
            <div><strong><i class="fa-solid fa-book-open"></i> Display &amp; Reading Options</strong>
            <p>Personalize your monitoring workspace.</p></div>
            <button id="dgCloseReading" type="button" aria-label="Close reading options"><i class="fa-solid fa-xmark"></i></button>
        </div>
            <div class="dg-reading-controls" aria-labelledby="readingControlsTitle">
                <h3 id="readingControlsTitle" class="text-sm font-bold text-white mb-2">Display &amp; Reading Options</h3>
                <p class="text-[10px] text-slate-400 mb-3">Adjust readability without changing security events or detection rules.</p>
                <div class="dg-reading-cards"><button type="button" class="dg-reading-card" data-dg-reading-card="compact" aria-pressed="false"><i class="fa-solid fa-list" aria-hidden="true"></i><span><strong>Compact</strong><small>More information, smaller spacing</small></span></button><button type="button" class="dg-reading-card" data-dg-reading-card="standard" aria-pressed="false"><i class="fa-solid fa-book-open" aria-hidden="true"></i><span><strong>Standard (Default)</strong><small>Balanced monitoring view</small></span></button><button type="button" class="dg-reading-card" data-dg-reading-card="comfortable" aria-pressed="false"><i class="fa-solid fa-text-height" aria-hidden="true"></i><span><strong>Comfortable</strong><small>Larger text and spacing</small></span></button><button type="button" class="dg-reading-card" data-dg-reading-card="focus" aria-pressed="false"><i class="fa-solid fa-crosshairs" aria-hidden="true"></i><span><strong>Focus Mode</strong><small>Focus on investigation</small></span></button><button type="button" class="dg-reading-card" data-dg-reading-card="contrast" aria-pressed="false"><i class="fa-solid fa-circle-half-stroke" aria-hidden="true"></i><span><strong>High Contrast</strong><small>Maximum readability</small></span></button></div><div class="dg-control-grid">
                    <div><label for="dgReadingMode">Reading mode</label><select id="dgReadingMode"><option value="standard">Standard</option><option value="compact">Compact</option><option value="comfortable">Comfortable</option><option value="focus">Focus (investigation)</option><option value="contrast">High Contrast</option></select></div>
                    <div><label for="dgTextSize">Text size: <output id="dgTextSizeValue">100%</output></label><input id="dgTextSize" type="range" min="90" max="150" step="5" value="100" style="width:100%"></div>
                    <div><label for="dgLineSpacing">Line spacing</label><select id="dgLineSpacing"><option value="1.3">Tight</option><option value="1.5">Normal</option><option value="1.85">Spacious</option></select></div>
                    <div><label for="dgCardDensity">Card density</label><select id="dgCardDensity"><option value="normal">Normal</option><option value="compact">Compact</option><option value="spacious">Spacious</option></select></div>
                    <label class="dg-check"><input type="checkbox" id="dgShowCharts" checked> Show charts</label>
                    <div><label for="dgFontStyle">Font style</label><select id="dgFontStyle"><option value="jakarta">Plus Jakarta Sans</option><option value="system">System sans serif</option><option value="mono">Monospace</option></select></div><label class="dg-check"><input id="dgShowIcons" type="checkbox" checked> Show icons</label><label class="dg-check"><input id="dgShowDescriptions" type="checkbox" checked> Show descriptions</label><label class="dg-check"><input id="dgColorFriendly" type="checkbox"> Color-blind-friendly presentation</label><label class="dg-check"><input type="checkbox" id="dgReduceMotion"> Reduce motion</label>
                </div>
                <button type="button" id="dgResetReading" class="settings-action text-[10px] mono font-bold mt-3">Reset reading options</button>
                <p id="dgReadingStatus" class="text-[10px] text-slate-400 mt-2" role="status" aria-live="polite">Preferences saved in this browser.</p>
            </div>
    </aside>

    <!-- LIVE TELEMETRY LOGIC -->

    <script>
        // Stage 2 visualizations use only the retained events supplied by api.php.
        // Events without site_id remain Unassigned rather than being attributed to a site.
        if(typeof Chart!=='undefined' && Chart.defaults?.font){Chart.defaults.font.family="'Segoe UI Variable','Segoe UI',Arial,sans-serif";Chart.defaults.font.size=11;}
        function dgColor(role){return window.dgThemePalette?.[role]||({danger:'#eb79a0',warning:'#d5b36f',success:'#7bc7a3',info:'#70b8d9',purple:'#b49bdd',muted:'#a0b3c9',text:'#e8f2ff',line:'#28415d',card:'#08192d',raised:'#10243a'})[role];}
        function dgSeries(){return window.dgThemePalette?.series||['#70b8d9','#c08bc9','#b49bdd','#d5b36f','#7bc7a3','#a0b3c9'];}
        let dgAttackTrendChart = null;
        function dgScannerRecord(e){const attack=String(e.attack||e.attack_type||'');return /scanner[ _]prob|reconnaissance|\bnmap\b|scanner detected/i.test(attack)&&!/sql|injection|scripting|\bxss\b|tamper|traversal/i.test(attack);}
        function dgGroupedRecords(events){
            const output=[],active=new Map();
            const sorted=events.map((e,index)=>({e,index,ms:Date.parse(e.timestamp||'')})).sort((a,b)=>(Number.isFinite(a.ms)?a.ms:Infinity)-(Number.isFinite(b.ms)?b.ms:Infinity));
            for(const {e,index,ms}of sorted){if(!dgScannerRecord(e)||!Number.isFinite(ms)){output.push({...e,_order:index});continue;}
                const key=JSON.stringify([e.site_id||'Unassigned',e.source_ip||'Unknown',e.engine||'Unknown',e.target_type||'',e.decision||'',e.route||'',Math.floor(ms/600000)]);
                let group=active.get(key);
                if(!group||ms-group._lastMs>120000){group={...e,_order:index,_firstMs:Date.parse(e.first_seen)||ms,_lastMs:ms,_count:0,_requests:[],_statusCounts:{},_groupKey:key+'|'+ms};active.set(key,group);output.push(group);}
                group._count+=Math.max(1,Number(e.probe_count)||1);group._lastMs=ms;group._order=Math.min(group._order,index);group.risk=Math.max(Number(group.risk??group.risk_score)||0,Number(e.risk??e.risk_score)||0);
                if(e.severity&&['INFO','SAFE','LOW','MEDIUM','HIGH','VERY HIGH','CRITICAL'].indexOf(e.severity)>['INFO','SAFE','LOW','MEDIUM','HIGH','VERY HIGH','CRITICAL'].indexOf(group.severity))group.severity=e.severity;
                for(const value of (e.sample_requests||[e.request||e.uri||'Endpoint not supplied'])){const request=String(value);if(!group._requests.includes(request)&&group._requests.length<8)group._requests.push(request);}
                if(e.status!==undefined&&e.status!==null&&!e.probe_count)group._statusCounts[e.status]=(group._statusCounts[e.status]||0)+1;
            }
            return output.sort((a,b)=>(a._order??0)-(b._order??0));
        }
        const dgOpenScanGroups=new Set();
        function dgScanDetails(event){if(!event._count||event._count<2)return '';const key=escapeHTML(event._groupKey);const statuses=Object.entries(event._statusCounts).map(([status,n])=>'HTTP '+status+': '+n).join(' · ');return `<details data-scan-group="${key}"><summary>${event._count} detection records · view evidence</summary><div class="dg-scan-evidence">${escapeHTML(dgTrendDate(event._firstMs)+' → '+dgTrendDate(event._lastMs))}<br>${escapeHTML(statuses)}<br>${event._requests.map(escapeHTML).join('<br>')}<br>Sampled endpoints; raw records are retained.</div></details>`;}
        document.addEventListener('toggle',e=>{const key=e.target?.dataset?.scanGroup;if(!key)return;if(e.target.open)dgOpenScanGroups.add(key);else dgOpenScanGroups.delete(key);},true);
        function dgIsDetection(event){const label=String(event.attack||event.attack_type||'');const severity=String(event.severity||'').toUpperCase();return severity!=='SAFE'&&!/normal[ _]traffic|decoy[ _]interaction|^activity$/i.test(label)&&(Number(event.risk??event.risk_score)>0||['LOW','MEDIUM','HIGH','VERY HIGH','CRITICAL'].includes(severity));}
        function dgRenderGlobalSummary(events, data) {
            if(trendChart){const historic=document.body.dataset.dgPreset==='global';const rows=historic?(dgHistoryResult?.buckets||[]).map((b,i)=>({time:new Date(dgHistoryResult.start+i*dgHistoryResult.interval),risk:b.risk_max})):dgGroupedRecords(events).map(e=>({time:new Date(e._lastMs||e.timestamp||e.time),risk:e.risk??e.risk_score})).filter(e=>!isNaN(e.time)&&e.risk!==null&&e.risk!==''&&Number.isFinite(Number(e.risk))).sort((a,b)=>a.time-b.time).slice(-60);trendChart.data.labels=rows.map(e=>e.time.toLocaleString());trendChart.data.datasets[0].data=rows.map(e=>historic&&e.risk===null?null:Number(e.risk));trendChart.data.datasets[0].label=historic?'Peak recorded risk per interval':'Recorded risk score';trendChart.options.spanGaps=false;const riskStats=document.getElementById('dgGlobalRiskStats');if(riskStats){const summary=dgHistoryResult?.risk_summary;riskStats.textContent=summary?'Peak score: '+(summary.max_score??'—')+' · Recorded source addresses: '+summary.recorded_source_addresses:'Waiting for historical risk evidence…';}trendChart.data.datasets[0].tension=0;trendChart.update('none');}
            const bySite = new Map(), byType = new Map();
            const buckets = [];
            events.forEach((event, index) => {
                const site = String(event.site_id || 'Unassigned').trim() || 'Unassigned';
                const rawAttack = String(event.attack || 'Unclassified').trim();
                const attack = /sql.injection/i.test(rawAttack) ? 'SQL Injection'
                    : /cross.site.scripting|\bxss\b/i.test(rawAttack) ? 'Cross-Site Scripting'
                    : /traversal/i.test(rawAttack) ? 'Directory Traversal'
                    : /brute.force|credential.stuff/i.test(rawAttack) ? 'Brute Force'
                    : /scanner|nmap|enumeration|recon/i.test(rawAttack) ? 'Reconnaissance'
                    : /normal.traffic/i.test(rawAttack) ? 'Normal Traffic'
                    : (rawAttack.split(':')[0] || 'Unclassified').replace(/^\[WEB\]\s*/,'');
                bySite.set(site, (bySite.get(site) || 0) + 1);
                if(dgIsDetection(event))byType.set(attack, (byType.get(attack) || 0) + 1);
                buckets.push(Number(event.risk || 0));
            });
            const siteEl = document.getElementById('dgSiteThreats');
            const typesEl = document.getElementById('dgAttackTypes');
            const renderBars = (target, values) => {
                if (!target) return;
                target.replaceChildren();
                const sorted = [...values].sort((a,b) => b[1]-a[1]).slice(0,6);
                if (!sorted.length) { const msg=document.createElement('p');msg.className='dg-empty';msg.textContent='No retained events available';target.append(msg);return; }
                const max = sorted[0][1],typeTotal=[...values].reduce((sum,item)=>sum+Number(item[1]),0);
                for (const [rank,[name,count]] of sorted.entries()) {
                    const row=document.createElement('div');row.className='dg-bar-row';if(target.id==='dgAttackTypes'){const lower=String(name).toLowerCase();const family=lower.includes('sql')?'sql':lower.includes('script')||lower.includes('xss')?'xss':lower.includes('travers')?'path':lower.includes('scan')||lower.includes('recon')?'scan':'other';row.dataset.attackFamily=family;const icon=document.createElement('i');icon.className='fa-solid '+({sql:'fa-database',xss:'fa-code',path:'fa-folder-open',scan:'fa-magnifying-glass',other:'fa-shield-halved'}[family]);icon.setAttribute('aria-hidden','true');icon.classList.add('dg-attack-tile-icon');row.append(icon);const position=document.createElement('span');position.className='dg-attack-rank';position.textContent=String(rank+1).padStart(2,'0');row.append(position);row.style.setProperty('--rank-color',dgSeries()[rank%dgSeries().length]);}
                    const heading=document.createElement('div');heading.className='dg-bar-label';
                    const label=document.createElement('span');label.textContent=name;label.title=name;
                    const amount=document.createElement('strong');amount.textContent=String(count);
                    heading.append(label,amount);if(target.id==='dgAttackTypes'){const share=document.createElement('small');share.className='dg-attack-share';share.textContent=(typeTotal?Math.round(count/typeTotal*100):0)+'% of detections';heading.append(share);}
                    const track=document.createElement('div');track.className='dg-bar-track';
                    const bar=document.createElement('div');bar.className='dg-bar-fill';bar.style.width=`${100*count/max}%`;
                    track.append(bar);row.append(heading,track);target.append(row);
                }
            };
            if(dgHistoryResult){renderBars(typesEl,new Map(Object.entries(dgHistoryResult.attack_types||{})));}else if(!dgHistoryKey){typesEl.replaceChildren();}
            if (siteEl) {
                siteEl.replaceChildren();
                const sites=[...bySite].sort((a,b)=>b[1]-a[1]).slice(0,6);
                const palette=dgSeries();
                const total=[...bySite.values()].reduce((a,b)=>a+b,0);
                const donut=document.getElementById('dgSiteDonut');
                const totalEl=document.getElementById('dgDonutTotal');
                if(totalEl)totalEl.textContent=String(total);
                if(donut) {
                    let angle=0;
                    const stops=sites.map(([,count],i)=>{const start=angle;angle+=count/Math.max(total,1)*100;return `${palette[i]} ${start}% ${angle}%`;});
                    if(angle<100)stops.push(`#1a2c48 ${angle}% 100%`);
                    donut.style.background=stops.length?`conic-gradient(${stops.join(',')})`:'#1a2c48';
                }
                for(const [i,[name,count]] of sites.entries()){
                    const row=document.createElement('div');row.className='dg-site-legend-row';
                    const dot=document.createElement('i');dot.style.background=palette[i];
                    const label=document.createElement('span');label.textContent=name;label.title=name;
                    const value=document.createElement('strong');value.textContent=`${count} (${Math.round(count/Math.max(total,1)*100)}%)`;
                    row.append(dot,label,value);siteEl.append(row);
                }
                if(!sites.length){const empty=document.createElement('p');empty.className='dg-empty';empty.textContent='No retained website events';siteEl.append(empty);}
            }
            dgFetchHistoricalTrend();
        }

        function dgTrendDate(ms,withTime=true){const date=new Date(ms);return date.toLocaleDateString('en-GB',{month:'short',day:'numeric',year:'numeric'})+(withTime?' · '+date.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false}):'');}
        function dgBuildAttackTrend(events,data){
            const source=events.filter(dgIsDetection);
            const timed=source.map(e=>({...e,ms:e.timestamp?Date.parse(e.timestamp):Number.isFinite(e.epoch)?e.epoch*1000:NaN})).filter(e=>Number.isFinite(e.ms)).sort((a,b)=>a.ms-b.ms);
            const period=document.getElementById('dgTrendWindow').value,now=Date.now();
            const windowed=timed.filter(e=>e.ms<=now&&(period==='retained'||e.ms>=now-Number(period)*60000));
            const first=period==='retained'?(windowed[0]?.ms??now):now-Number(period)*60000,last=period==='retained'?(windowed.at(-1)?.ms??now):now;
            const span=Math.max(60000,last-first+1),interval=Math.max(60000,Math.ceil(span/24/60000)*60000),start=Math.floor(first/interval)*interval;
            const size=windowed.length?Math.min(26,Math.floor((last-start)/interval)+1):0;
            const buckets=Array.from({length:size},()=>({high:0,medium:0,low:0,info:0,sites:Object.create(null)})),totals={total:0,high:0,medium:0,low:0,info:0},sites=new Map();
            for(const e of windowed){const severity=String(e.severity||'').toUpperCase(),risk=Number(e.risk??e.risk_score)||0,tier=['HIGH','VERY HIGH','CRITICAL'].includes(severity)?'high':severity==='MEDIUM'?'medium':severity==='INFO'?'info':severity==='LOW'?'low':risk>=150?'high':risk>=85?'medium':'low';const index=Math.min(size-1,Math.floor((e.ms-start)/interval)),bucket=buckets[index],site=String(e.site_id||'Unassigned');bucket[tier]++;totals[tier]++;totals.total++;bucket.sites[site]=(bucket.sites[site]||0)+1;if(!sites.has(site))sites.set(site,{id:site,count:0,values:Array(size).fill(0)});sites.get(site).count++;sites.get(site).values[index]++;}
            const labels=buckets.map((_,i)=>dgTrendDate(start+i*interval,interval<86400000));
            const missing=source.length-timed.length,occupied=buckets.filter(b=>b.high+b.medium+b.low+b.info>0).length;
            return {buckets,totals,labels,interval,start,sites:[...sites.values()].sort((a,b)=>b.count-a.count),smooth:size>=6&&occupied===size,note:(windowed.length?'Each point counts retained records in a '+Math.round(interval/60000)+'-minute interval. ':'No timestamped detections match this selection. ')+(missing?missing+' undated record(s) omitted. ':'')+(occupied<3&&occupied>0?'Sparse data: only '+occupied+' populated interval(s). ':'')+'Zero bins mean no matching retained records, not verified collection coverage. Previous-period comparison is unavailable from this bounded feed.'};
        }
        function dgHistoryParams(){return new URLSearchParams({action:'attack-trend',fit:document.getElementById('dgTrendFit').value,period:document.getElementById('dgTrendWindow').value,site:dgSiteSelect.value,severity:dgSeverityFilter.value,environment:dgEnvironmentFilter.value,search:dgAttackSearch.value.trim()});}
        function dgClearHistoricalSummary(){if(dgSeverityChart){dgSeverityChart.dispose();dgSeverityChart=null;}if(dgSeverityObserver){dgSeverityObserver.disconnect();dgSeverityObserver=null;}const severityBox=document.getElementById('dgSeveritySplit');if(severityBox){severityBox.dataset.signature='';severityBox.textContent='Waiting for selected severity history…';}for(const id of ['statTotal','statCritical','statHigh','statHoneypot','statBlocked','statCriticalPercent','statHighPercent'])document.getElementById(id).textContent='—';document.getElementById('dgAttackTypes').replaceChildren();}
        function dgRenderSeverityFallback(result){
            const host=document.getElementById('dgSeveritySplit');if(!host)return;
            const summary=result.summary||{},totals=result.totals||{},palette=dgSeries();
            const rows=[['Critical / very high',Number(summary.critical)||0],['High',Number(summary.high)||0],['Medium',Number(totals.medium)||0],['Low',Number(totals.low)||0],['Info',Number(totals.info)||0]];
            const total=rows.reduce((sum,row)=>sum+row[1],0),signature=JSON.stringify([rows,palette]);
            if(host.dataset.signature===signature)return;
            let previous=[];try{previous=JSON.parse(host.dataset.shares||'[]');}catch(error){}
            host.dataset.signature=signature;const shares=rows.map(([,count])=>total?count/total*100:0);
            host.innerHTML=`<div class="dg-severity-heading"><h4>Severity split</h4><span>${total} detections</span></div><div class="dg-severity-bars" role="group" aria-label="Severity distribution of selected historical detections">${rows.map(([name,count],index)=>`<div class="dg-severity-bar-row" tabindex="0" role="img" aria-label="${escapeHTML(name)}: ${count} detections, ${shares[index].toFixed(1)} percent"><div class="dg-severity-bar-label"><span><i aria-hidden="true" style="background:${palette[index%palette.length]}"></i>${escapeHTML(name)}</span><b>${count}</b><small>${shares[index].toFixed(1)}%</small></div><div class="dg-severity-bar-track"><i class="dg-severity-bar-fill" style="width:${shares[index]}%;background:${palette[index%palette.length]}"></i></div></div>`).join('')}</div><p class="dg-note">${total?'Share of selected history.':'No detections in selected history.'} Bar lengths represent percentages; counts remain unchanged.</p>`;
            const reduced=document.body.classList.contains('dg-ws-motion')||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
            if(!reduced)for(const [index,fill]of [...host.querySelectorAll('.dg-severity-bar-fill')].entries())fill.animate?.([{width:(previous[index]||0)+'%'},{width:shares[index]+'%'}],{duration:550,easing:'ease-out'});
            host.dataset.shares=JSON.stringify(shares);
        }
        let dgSeverityChart=null,dgSeverityObserver=null,dgSeveritySnapshot=null;
        function dgResizeSeverityChart(){const surface=document.getElementById('dgSeverityChart');if(dgSeverityChart&&surface&&!surface.closest('[hidden]'))dgSeverityChart.resize();}
        function dgRenderSeveritySplit(result){
            dgSeveritySnapshot=result;
            if(!window.echarts){dgRenderSeverityFallback(result);return;}
            const host=document.getElementById('dgSeveritySplit');if(!host)return;
            const summary=result.summary||{},totals=result.totals||{},palette=dgSeries();
            const rows=[['Critical / very high',Number(summary.critical)||0,5],['High',Number(summary.high)||0,4],['Medium',Number(totals.medium)||0,3],['Low',Number(totals.low)||0,2],['Info',Number(totals.info)||0,1]];
            const total=rows.reduce((sum,row)=>sum+row[1],0),reduced=document.body.classList.contains('dg-ws-motion')||window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
            const signature=JSON.stringify(['echarts',rows,palette,reduced]);if(host.dataset.signature===signature)return;host.dataset.signature=signature;
            let surface=document.getElementById('dgSeverityChart');
            if(!surface){host.innerHTML='<div class="dg-severity-heading"><h4>Severity split</h4><span id="dgSeverityTotal"></span></div><div id="dgSeverityChart" class="dg-severity-echart"></div><p id="dgSeverityNote" class="dg-note"></p>';surface=document.getElementById('dgSeverityChart');}
            document.getElementById('dgSeverityTotal').textContent=total+' detections';
            document.getElementById('dgSeverityNote').textContent=(total?'Selected history.':'No detections in selected history.')+' Length = detection count; colour = severity category, not a calculated risk score.';
            if(!dgSeverityChart){dgSeverityChart=window.echarts.init(surface,null,{renderer:'svg'});if(window.ResizeObserver){let last='';dgSeverityObserver=new ResizeObserver(entries=>{const rect=entries[0]?.contentRect;if(!rect||rect.width<=0)return;const size=Math.round(rect.width)+'x'+Math.round(rect.height);if(size!==last){last=size;dgResizeSeverityChart();}});dgSeverityObserver.observe(surface);}}
            dgSeverityChart.setOption({
                backgroundColor:'transparent',animation:!reduced,animationDuration:550,animationDurationUpdate:450,
                textStyle:{fontFamily:'Segoe UI, Arial, sans-serif',color:dgColor('text')},
                aria:{enabled:true,description:rows.map(([name,count])=>name+': '+count+' detections').join('; ')},
                dataset:{source:[['severityLevel','count','severity'],...rows.map(([name,count,level])=>[level,count,name])]},
                grid:{containLabel:true,left:4,right:34,top:10,bottom:73},
                tooltip:{trigger:'item',confine:true,backgroundColor:dgColor('raised'),borderColor:dgColor('line'),textStyle:{color:dgColor('text')},formatter:params=>{const value=params.value;return escapeHTML(value[2])+': '+value[1]+' detections ('+(value[1]/(total||1)*100).toFixed(1)+'%)';}},
                xAxis:{type:'value',name:'Detections',min:0,minInterval:1,splitNumber:3,nameLocation:'middle',nameGap:26,axisLabel:{color:dgColor('muted'),fontSize:10},nameTextStyle:{color:dgColor('muted'),fontSize:10},splitLine:{lineStyle:{color:dgColor('line'),opacity:.55}}},
                yAxis:{type:'category',inverse:true,axisTick:{show:false},axisLine:{show:false},axisLabel:{color:dgColor('text'),fontSize:10,lineHeight:14,formatter:value=>value==='Critical / very high'?'Critical /\nvery high':value}},
                visualMap:{type:'continuous',orient:'horizontal',left:'center',bottom:4,min:1,max:5,dimension:0,calculable:false,precision:0,text:['Critical','Info'],itemWidth:10,itemHeight:110,textGap:8,textStyle:{color:dgColor('muted'),fontSize:10},inRange:{color:[...palette.slice(0,5)].reverse()}},
                series:[{type:'bar',encode:{x:'count',y:'severity'},barMaxWidth:21,itemStyle:{borderRadius:[0,4,4,0]},label:{show:true,position:'right',color:dgColor('text'),fontSize:11,formatter:params=>String(params.value[1])},emphasis:{focus:'self'}}]
            },{notMerge:true,lazyUpdate:false});dgResizeSeverityChart();
        }
        window.addEventListener('dg:echarts-ready',()=>{if(dgSeveritySnapshot)dgRenderSeveritySplit(dgSeveritySnapshot);});
        window.addEventListener('resize',dgResizeSeverityChart);
        window.addEventListener('dg:grid-resized',dgResizeSeverityChart);
        window.addEventListener('dg:layout-changed',()=>{if(dgSeveritySnapshot)dgRenderSeveritySplit(dgSeveritySnapshot);requestAnimationFrame(dgResizeSeverityChart);});
        function dgApplyHistoricalSummary(result){const period=document.getElementById('dgGlobalPeriod');if(period)period.value=document.getElementById('dgTrendWindow').value;dgRenderSeveritySplit(result);const values=result.summary;if(!values){dgClearHistoricalSummary();return;}const map={statTotal:'total',statCritical:'critical',statHigh:'high',statHoneypot:'decoy',statBlocked:'blocked'};for(const [id,key]of Object.entries(map))document.getElementById(id).textContent=String(values[key]??0);document.getElementById('statCriticalPercent').textContent=values.total?Math.round(100*values.critical/values.total)+'%':'0%';document.getElementById('statHighPercent').textContent=values.total?Math.round(100*values.high/values.total)+'%':'0%';for(const id of Object.keys(map))document.getElementById(id).title='Same historical detection set as Attack Trend. Decoy-targeted does not prove successful delivery.';}
        let dgHistoryKey='',dgHistoryAt=0,dgHistoryRequest=0,dgHistoryResult=null;
        async function dgFetchHistoricalTrend(){
            const params=dgHistoryParams();const key=params.toString();
            if(key===dgHistoryKey&&Date.now()-dgHistoryAt<15000){if(dgHistoryResult)dgApplyHistoricalSummary(dgHistoryResult);return;}
            const sameSelection=key===dgHistoryKey;dgHistoryKey=key;dgHistoryAt=Date.now();const request=++dgHistoryRequest;if(!sameSelection){dgHistoryResult=null;dgClearHistoricalSummary();window.dispatchEvent(new CustomEvent('dg:history-data',{detail:null}));}
            if(!sameSelection||!dgHistoryResult)document.getElementById('dgTrendCoverage').textContent='Loading stored detection history…';
            try{const response=await fetch('api.php?'+key,{cache:'no-store'});if(!response.ok)throw new Error('HTTP '+response.status);const result=await response.json();if(!Array.isArray(result.buckets)||!result.totals||!Array.isArray(result.sites))throw new Error('Invalid historical response');if(request!==dgHistoryRequest)return;
                result.labels=result.buckets.map((_,i)=>dgTrendDate(result.start+i*result.interval,result.interval<86400000));dgHistoryResult=result;dgRenderAttackTrend(result);if(dgLastData)dgRenderGlobalSummary(dgFilteredEvents(dgLastData),dgLastData);window.dispatchEvent(new CustomEvent('dg:history-data',{detail:result}));
            }catch(error){if(request!==dgHistoryRequest)return;document.getElementById('dgTrendCoverage').textContent='History unavailable: '+error.message+'. No latest-feed fallback is shown.';dgClearHistoricalSummary();document.getElementById('dgTrendTotals').replaceChildren();document.getElementById('dgTrendSites').replaceChildren();if(dgAttackTrendChart){dgAttackTrendChart.data.labels=[];dgAttackTrendChart.data.datasets=[];dgAttackTrendChart.update('none');}}
        }
        function dgTrendTick(result,index){const date=new Date(result.start+index*result.interval);const day=date.toLocaleDateString('en-GB',{day:'numeric',month:'short'});return result.interval<86400000?[day,date.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false})]:day;}
        function dgRenderAttackTrend(result){
            dgApplyHistoricalSummary(result);
            const scope=dgSiteSelect.value,scopeName=dgSites.find(s=>String(s.site_id)===scope)?.display_name||dgSites.find(s=>String(s.site_id)===scope)?.name||scope||'All Websites';
            document.getElementById('dgAttackTrendScope').textContent=scopeName+' · stored detection history';
            const totals=document.getElementById('dgTrendTotals');totals.replaceChildren();
            for(const [label,key,color,symbol]of [['Stored detections','total','info','◈'],['High / Critical','high','danger','!'],['Medium risk','medium','warning','◇'],['Low / Info','low','purple','●']]){const box=document.createElement('div');box.className='dg-trend-stat';box.style.setProperty('--trend-accent',dgColor(color));const icon=document.createElement('span');icon.className='dg-trend-symbol';icon.textContent=symbol;icon.setAttribute('aria-hidden','true');const body=document.createElement('div'),name=document.createElement('span'),count=document.createElement('strong');name.textContent=label;count.textContent=String(result.totals[key]+(key==='low'?result.totals.info:0));body.append(name,count);box.append(icon,body);totals.append(box);}
            document.getElementById('dgTrendCoverage').textContent=(result.partial?'PARTIAL history · ':'')+(document.getElementById('dgTrendFit').value==='1'?'Fit to activity · '+dgTrendDate(result.start)+' → '+dgTrendDate(result.end)+' · ':'')+result.totals.total+' detection records · '+Math.round(result.interval/60000)+'-minute bins'+((result.malformed||result.invalid_dates)?' · '+((result.malformed||0)+(result.invalid_dates||0))+' parsing issues (see diagnostics)':'')+'. Counts are records, not unique attacks.';const diagnostics=document.getElementById('dgHistorySources');if(diagnostics){diagnostics.replaceChildren();const explanation=document.createElement('p');explanation.textContent=result.note;diagnostics.append(explanation);for(const source of result.sources||[]){const row=document.createElement('div');row.className='dg-source-row';const title=document.createElement('strong');title.textContent=source.file;const counts=document.createElement('p');counts.textContent=(source.format||'')+' '+(source.encoding||'')+' · selected '+(source.selected??'—')+' · malformed '+(source.malformed||0)+' · unusable dates '+(source.invalid_dates||0);row.append(title,counts);if(source.error||source.errors?.length){row.classList.add('has-errors');const detail=document.createElement('details'),summary=document.createElement('summary'),message=document.createElement('p');summary.textContent='View parsing errors';message.textContent=[source.error,...(source.errors||[])].filter(Boolean).join('; ');detail.append(summary,message);row.append(detail);}diagnostics.append(row);}}
            const list=document.getElementById('dgTrendSites');const siteSignature=JSON.stringify([result.sites,dgSites.map(s=>[s.site_id,s.display_name||s.name]),dgSeries()]);if(list.dataset.signature!==siteSignature){list.dataset.signature=siteSignature;list.replaceChildren();
            for(const [i,site]of result.sites.slice(0,5).entries()){const row=document.createElement('button');row.type='button';row.className='dg-trend-site';row.title='Show retained detections for '+site.id;const color=dgSeries()[i%dgSeries().length];row.style.setProperty('--site-accent',color);const name=document.createElement('span');name.className='dg-trend-site-name';name.textContent=dgSites.find(s=>String(s.site_id)===site.id)?.display_name||dgSites.find(s=>String(s.site_id)===site.id)?.name||site.id;const count=document.createElement('strong');count.textContent=String(site.count);
                const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 100 30');svg.setAttribute('preserveAspectRatio','none');svg.setAttribute('role','img');svg.setAttribute('aria-label',site.id+': '+site.count+' retained detections');const line=document.createElementNS('http://www.w3.org/2000/svg','polyline');const max=Math.max(1,...site.values);line.setAttribute('points',site.values.map((v,j)=>(site.values.length===1?50:j/(site.values.length-1)*96+2)+','+(27-v/max*23)).join(' '));line.setAttribute('fill','none');line.setAttribute('stroke',color);line.setAttribute('stroke-width','2');line.setAttribute('vector-effect','non-scaling-stroke');svg.append(line);if(site.values.length===1){const dot=document.createElementNS('http://www.w3.org/2000/svg','circle');dot.setAttribute('cx','50');dot.setAttribute('cy',String(27-site.values[0]/max*23));dot.setAttribute('r','3');dot.setAttribute('fill',color);svg.append(dot);}row.append(name,svg,count);row.disabled=site.id==='Unassigned';if(row.disabled)row.title='Unattributed records cannot be assigned to a website';row.addEventListener('click',()=>{if(site.id==='Unassigned')return;if(![...dgSiteSelect.querySelectorAll('option')].some(o=>o.value===site.id)){const option=document.createElement('option');option.value=site.id;option.textContent=site.id;dgSiteSelect.append(option);}dgSiteSelect.value=site.id;dgSiteSelect.dispatchEvent(new Event('change'));});list.append(row);}
            if(!result.sites.length){const p=document.createElement('p');p.className='dg-empty';p.textContent='No website detections in this selection.';list.append(p);}
            const more=document.getElementById('dgTrendSitesNote');more.textContent=result.sites.length>5?'Top 5 of '+result.sites.length+' website labels; main chart includes all selected records.':'Select a website row to filter the dashboard. Mini-trends use the same time intervals.';}
            const canvas=document.getElementById('dgAttackTrend');if(!canvas||typeof Chart==='undefined')return;
            const reduced=window.matchMedia?.('(prefers-reduced-motion: reduce)').matches||document.body.classList.contains('dg-ws-motion');
            const series=[['Info','info','info'],['Low','low','success'],['Medium','medium','warning'],['High / Critical','high','danger']];
            const datasets=series.map(([label,key,role],i)=>{const color=dgColor(role),edge=document.body.dataset.dgTheme==='daylight'?({info:'#087b91',success:'#17804b',warning:'#8a7300',danger:'#bc006b'})[role]:color;return {label,data:result.buckets.map(b=>b[key]),borderColor:edge,borderWidth:2,pointBackgroundColor:color,backgroundColor:ctx=>{const chart=ctx.chart,area=chart.chartArea;if(!area||!chart.ctx?.createLinearGradient)return color+'b8';const g=chart.ctx.createLinearGradient(0,area.top,0,area.bottom);g.addColorStop(0,color+'e0');g.addColorStop(0.55,color+'b8');g.addColorStop(1,color+'b0');return g;},fill:i===0?'origin':'-1',stack:'detections',tension:result.smooth ? 0.25 : 0,cubicInterpolationMode:'monotone',pointRadius:ctx=>{const b=result.buckets[ctx.dataIndex];return b&&b.high+b.medium+b.low+b.info>0?2.5:0},pointHoverRadius:5,pointHitRadius:12,spanGaps:false};});
            const callbacks={title:items=>{const index=items[0]?.dataIndex;if(index===undefined)return '';return [dgTrendDate(result.start+index*result.interval),'to '+dgTrendDate(Math.min(result.end??Infinity,result.start+(index+1)*result.interval))];},beforeBody:items=>{const b=result.buckets[items[0]?.dataIndex];return b?'Total: '+(b.high+b.medium+b.low+b.info)+' detection records':'';},afterBody:items=>{const b=result.buckets[items[0]?.dataIndex];return b?Object.entries(b.sites).sort((a,b)=>b[1]-a[1]).map(([site,n])=>site+': '+n):[];}};
            if(!dgAttackTrendChart){dgAttackTrendChart=new Chart(canvas,{type:result.buckets.length===1?'bar':'line',data:{labels:result.labels,datasets},options:{responsive:true,resizeDelay:180,maintainAspectRatio:false,animation:reduced?false:{duration:650,easing:'easeOutQuart'},interaction:{mode:'index',intersect:false},plugins:{legend:{position:'bottom',reverse:true,labels:{color:dgColor('muted'),usePointStyle:true,boxWidth:7,font:{size:11}}},tooltip:{callbacks,mode:'index',intersect:false,backgroundColor:dgColor('raised'),titleColor:dgColor('text'),bodyColor:dgColor('text'),borderColor:dgColor('line'),borderWidth:1,padding:12}},scales:{x:{grid:{color:dgColor('line')+'55'},ticks:{color:dgColor('muted'),maxTicksLimit:4,maxRotation:0,autoSkip:true,font:{size:10},callback:(_,index)=>dgTrendTick(result,index)},title:{display:true,text:'Local time',color:dgColor('muted')}},y:{beginAtZero:true,stacked:true,grace:'5%',grid:{color:dgColor('line')+'55'},ticks:{color:dgColor('muted'),precision:0,maxTicksLimit:5},title:{display:true,text:'Detections',color:dgColor('muted')}}}}});}
            else{dgAttackTrendChart.config.type=result.buckets.length===1?'bar':'line';for(const axis of Object.values(dgAttackTrendChart.options.scales||{})){if(axis.ticks)axis.ticks.color=dgColor('muted');if(axis.title)axis.title.color=dgColor('muted');if(axis.grid)axis.grid.color=dgColor('line')+'55';}dgAttackTrendChart.options.plugins.legend.labels.color=dgColor('muted');dgAttackTrendChart.data.labels=result.labels;dgAttackTrendChart.data.datasets=datasets;dgAttackTrendChart.options.scales.x.ticks.callback=(_,index)=>dgTrendTick(result,index);Object.assign(dgAttackTrendChart.options.plugins.tooltip,{callbacks,backgroundColor:dgColor('raised'),titleColor:dgColor('text'),bodyColor:dgColor('text'),borderColor:dgColor('line')});dgAttackTrendChart.options.animation=reduced?false:{duration:650,easing:'easeOutQuart'};const signature=JSON.stringify([result.labels,result.buckets,document.body.dataset.dgTheme]);dgAttackTrendChart.update(signature===dgAttackTrendChart.$feedSignature?'none':undefined);dgAttackTrendChart.$feedSignature=signature;}
        }

        let dgLastData=null;
        let dgSites=[];
        let dgView='overview';
        const dgSiteSelect=document.getElementById('dgSiteSelect');
        const dgWindowSelect=document.getElementById('dgWindowSelect');
        const dgSeverityFilter=document.getElementById('dgSeverityFilter');
        const dgEnvironmentFilter=document.getElementById('dgEnvironmentFilter');
        const dgAttackSearch=document.getElementById('dgAttackSearch');
        function dgFilteredEvents(data){
            const selected=dgSiteSelect.value;
            const severity=dgSeverityFilter.value;
            const environment=dgEnvironmentFilter.value;
            const search=dgAttackSearch.value.trim().toLowerCase();
            return (Array.isArray(data.recent)?data.recent:[]).filter(e=>{
                if(selected && String(e.site_id||'')!==selected)return false;
                if(severity && String(e.severity||'').toUpperCase()!==severity)return false;
                if(environment){const t=String(e.target_type||'').toLowerCase();if(t!==environment && !(environment==='honeypot' && String(e.channel||'').toLowerCase()==='ssh'))return false;}
                if(search && ![e.attack,e.source_ip,e.incident_id,e.request].some(x=>String(x||'').toLowerCase().includes(search)))return false;
                return true;
            }).slice(0,Number(dgWindowSelect.value)||100);
        }
        function dgSetView(view, updateURL=true){
            view=['overview','websites','incidents','reports'].includes(view)?view:'overview';dgView=view;
            document.querySelectorAll('[data-dg-view]').forEach(b=>{b.classList.toggle('dg-view-active',b.dataset.dgView===view);b.setAttribute('aria-pressed',String(b.dataset.dgView===view));});
            document.getElementById('dgWebsiteDirectory').hidden=view!=='websites';
            document.getElementById('dgIncidentFilters').hidden=view!=='incidents';
            document.querySelector('.dashboard-stat-grid').hidden=view==='websites'||view==='reports';
            document.querySelector('.dg-global-charts').hidden=view!=='overview';
            document.getElementById('dgEngineDetails').hidden=view!=='overview';
            document.getElementById('overviewBottomPanels').hidden=view==='websites'||view==='reports';
            document.getElementById('securityReports').hidden=view!=='reports';
            document.getElementById('dgWorkspaceName').textContent=({websites:'Protected Websites',incidents:'Incident Investigation',reports:'Security Reports'})[view]||'Security Operations';
            document.getElementById('dgWorkspaceCaption').textContent=({websites:' / Website inventory',incidents:' / Retained incident feed',reports:' / Evidence exports and review'})[view]||' / Global monitoring workspace';
            if(updateURL){const url=new URL(location.href);url.searchParams.set('view',view);history.pushState({view},'',url);}
            document.dispatchEvent(new CustomEvent('dg-view-changed',{detail:view}));
            if(dgLastData)dgRenderScope(dgLastData);
        }
        function dgRenderScope(data){
            const selected=dgSiteSelect.value;
            const events=dgFilteredEvents(data);for(const id of ['activityStream','threatHistory']){const panel=document.querySelector('[data-dashboard-panel="'+id+'"]');if(panel){let badge=panel.querySelector('.dg-feed-scope');if(!badge){badge=document.createElement('p');badge.className='dg-feed-scope dg-note';panel.append(badge);}badge.textContent='Latest-record scope: '+events.length+' matching records · independent of Attack Trend history';}}
            const note=document.getElementById('dgScopeNotice');
            const scopeName=dgSites.find(s=>String(s.site_id)===selected)?.display_name||selected;
            const scoped=Boolean(selected)||dgView==='incidents'||dgWindowSelect.value!=='100'||Boolean(dgSeverityFilter.value)||Boolean(dgEnvironmentFilter.value)||Boolean(dgAttackSearch.value);
            note.hidden=!scoped;
            note.textContent=scoped?`${scopeName||'All websites'} · ${events.length} matching retained event(s). Site-scoped counts are derived from the retained feed, not all-time totals. Unattributed events cannot be assigned to a website.`:'';
            if(dgHistoryResult&&dgHistoryKey===dgHistoryParams().toString())dgApplyHistoricalSummary(dgHistoryResult);else dgClearHistoricalSummary();
            const details=document.getElementById('dgEngineDetails');
            if(details && selected)details.title='Detection engine panels show global metrics; they are not scoped by website.';
        }
        function dgRenderSites(){
            const container=document.getElementById('dgSiteCards');container.replaceChildren();
            if(!dgSites.length){const p=document.createElement('p');p.className='dg-empty';p.textContent='No configured websites returned by the Website Handler.';container.append(p);return;}
            for(const site of dgSites){
                const id=String(site.site_id||'');if(!id)continue;
                const card=document.createElement('article');card.className='dg-site-card';
                const name=document.createElement('h3');name.textContent=String(site.display_name||site.name||id);
                const status=document.createElement('span');status.className='dg-site-status';status.textContent=String(site.status||'Configured');
                const meta=document.createElement('p');meta.textContent='Site ID: '+id;
                const select=document.createElement('button');select.type='button';select.textContent='Open site dashboard →';select.addEventListener('click',()=>{dgSiteSelect.value=id;dgSetView('overview');dgRefreshLocal();});
                card.append(name,status,meta,select);container.append(card);
            }
        }
        async function dgLoadSites(){
            try{
                const response=await fetch('api.php?action=sites',{cache:'no-store'});
                if(!response.ok)throw new Error('Website registry unavailable');
                const payload=await response.json();
                dgSites=Array.isArray(payload.sites)?payload.sites:[];
                const old=dgSiteSelect.value;
                dgSiteSelect.replaceChildren(new Option('All websites',''));
                for(const site of dgSites){const id=String(site.site_id||'');if(id)dgSiteSelect.add(new Option(String(site.display_name||site.name||id),id));}
                if([...dgSiteSelect.options].some(o=>o.value===old))dgSiteSelect.value=old;
                dgRenderSites();
            }catch(err){const p=document.getElementById('dgSiteCards');p.textContent='Website registry unavailable. Existing SOC telemetry remains accessible.';}
        }
        window.dgActivitySource='';
        window.addEventListener('dg:activity-source',event=>{
            window.dgActivitySource=typeof event.detail==='string'?event.detail:'';
            const panel=document.querySelector('[data-dashboard-panel="activityStream"]');
            if(panel){let note=document.getElementById('dgActivitySourceNotice');if(!note){note=document.createElement('div');note.id='dgActivitySourceNotice';note.className='dg-activity-source-notice';panel.prepend(note);}note.replaceChildren();note.hidden=!window.dgActivitySource;if(window.dgActivitySource){const text=document.createElement('span');text.textContent='Source filter: '+window.dgActivitySource;const clear=document.createElement('button');clear.type='button';clear.className='settings-action';clear.textContent='Clear source filter';clear.addEventListener('click',()=>window.dispatchEvent(new CustomEvent('dg:activity-source',{detail:''})));note.append(text,clear);}}
            if(dgLastData)fetchSOCData();
        });
        function dgRefreshLocal(){if(dgLastData)fetchSOCData();}
        [dgSiteSelect,dgWindowSelect,dgSeverityFilter,dgEnvironmentFilter,dgAttackSearch,document.getElementById('dgTrendWindow'),document.getElementById('dgTrendFit')].forEach(el=>el.addEventListener(el===dgAttackSearch?'input':'change',dgRefreshLocal));
        document.querySelectorAll('[data-dg-view]').forEach(b=>b.addEventListener('click',()=>{dgSetView(b.dataset.dgView);dgRefreshLocal();}));
        dgLoadSites();

function escapeHTML(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
        const CIRCUMFERENCE = 339.29;
        const dashboardSettingsKey = 'decoyguard-dashboard-panels';
        const dashboardSettingsButton = document.getElementById('dashboardSettingsButton');
        const dashboardSettingsBackdrop = document.getElementById('dashboardSettingsBackdrop');
        const dashboardToggles = Array.from(document.querySelectorAll('[data-dashboard-toggle]'));

        function updateDashboardPanels() {
            dashboardToggles.forEach((toggle) => {
                const panel = document.querySelector(`[data-dashboard-panel="${toggle.dataset.dashboardToggle}"]`);
                // Unified workspace owns visibility in Custom / Blank modes.
                if (document.body.dataset.dgWorkspaceManaged === 'true') return;
                panel.hidden = !toggle.checked;
            });

            document.querySelectorAll('[data-dashboard-group]').forEach((group) => {
                group.hidden = !group.querySelector('[data-dashboard-panel]:not([hidden])');
            });

            document.querySelectorAll('[data-dashboard-layout]').forEach((layout) => {
                layout.hidden = !layout.querySelector('[data-dashboard-panel]:not([hidden])');layout.dataset.visiblePanels=String(Array.from(layout.children).filter(child=>!child.hidden).length);
            });

            if (riskChart) riskChart.resize();
            if (trendChart) trendChart.resize();
        }

        function saveDashboardPreferences() {
            const preferences = Object.fromEntries(
                dashboardToggles.map((toggle) => [toggle.dataset.dashboardToggle, toggle.checked])
            );
            try {
                localStorage.setItem(dashboardSettingsKey, JSON.stringify(preferences));
            } catch (error) {
                console.warn('Could not save dashboard panel preferences:', error);
            }
        }

        try {
            const savedPreferences = JSON.parse(localStorage.getItem(dashboardSettingsKey) || '{}');
            if (savedPreferences && typeof savedPreferences === 'object' && !Array.isArray(savedPreferences)) {
                dashboardToggles.forEach((toggle) => {
                    const preference = savedPreferences[toggle.dataset.dashboardToggle];
                    if (typeof preference === 'boolean') toggle.checked = preference;
                });
            }
        } catch (error) {
            console.warn('Could not load dashboard panel preferences:', error);
        }

        dashboardToggles.forEach((toggle) => {
            toggle.addEventListener('change', () => {
                updateDashboardPanels();
                saveDashboardPreferences();
            });
        });

        function setDashboardSettingsOpen(isOpen) {
            dashboardSettingsBackdrop.hidden = !isOpen;
            if (isOpen) dashboardToggles[0]?.focus();
            else dashboardSettingsButton?.focus();
        }

// 1. Chart Initializations
const riskCtx = document.getElementById('riskLayerChart');
let riskChart = null;
if (riskCtx && typeof Chart !== "undefined") {
    riskChart = new Chart(riskCtx, {
        type: 'bar',
        data: {
            labels: ['Signature', 'Scanner', 'Behaviour', 'Correlation', 'Application'],
            datasets: [{
                data: [0, 0, 0, 0, 0],
                // Cyan (Signature), Purple (Scanner), Solar Amber (Behaviour), Neon Magenta (Correlation)
                backgroundColor: [dgColor('info'), dgColor('purple'), dgColor('warning'), dgColor('danger'), dgColor('success')],
                borderRadius: 3,
                borderSkipped: false,
                barThickness: 21
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            resizeDelay: 180,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    min: 0,
                    max: 200,
                    grid: { color: 'rgba(71, 85, 105, 0.15)', drawBorder: false },
                    ticks: { color: dgColor('muted'), font: { family: 'Segoe UI', size: 9 }, stepSize: 40 }
                },
                y: {
                    grid: { display: false, drawBorder: false },
                    ticks: { color: dgColor('text'), font: { family: 'Segoe UI', size: 10, weight: 'bold' } }
                }
            }
        }
    });
}

const trendCtx = document.getElementById('threatHistoryChart');
let trendChart = null;
if (trendCtx && typeof Chart !== "undefined") {
    trendChart = new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                data: [],
                borderColor: dgColor('success'),
                backgroundColor: dgColor('success')+'38',
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: dgColor('success'),
                fill: true,
                tension: 0.25
            }]
        },
        options: {
            responsive: true,
            resizeDelay: 180,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: dgColor('muted'), font: { size: 10 },maxTicksLimit:5,maxRotation:0,autoSkip:true,callback:function(value){const label=String(this.getLabelForValue(value));const date=new Date(label);return Number.isFinite(date.getTime())?date.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false}):label.slice(0,16);} }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(71, 85, 105, 0.1)' },
                    ticks: { color: dgColor('muted'), font: { size: 8 } }
                }
            }
        }
    });
}

updateDashboardPanels();

// 2. Timeline Dynamic Stage Lighting
function updateTimeline(stage, decision) {
    const stages = ['Normal', 'Suspicious', 'Detected', 'Escalated', 'Honeypot'];
    const colorMap = {
        'Normal': dgColor('info'),     // Ice Blue
        'Suspicious': dgColor('info'), // Electric Cyan
        'Detected': dgColor('purple'),   // Electric Purple
        'Escalated': dgColor('warning'),  // Golden Cheese Amber
        'Honeypot': dgColor('danger')    // Shadow Milk Neon Magenta
    };

    let activeIndex = 0;
    const s = String(stage || '').toUpperCase();
    const d = String(decision || '').toUpperCase();

    if (d === 'REDIRECT' || d === 'HONEYPOT' || s.includes('HONEYPOT') || s.includes('CONTAINED')) {
        activeIndex = 4;
    } else if (s.includes('ESCALAT') || s.includes('EXPLOIT')) {
        activeIndex = 3;
    } else if (s.includes('DETECT') || s.includes('ACCESS')) {
        activeIndex = 2;
    } else if (s.includes('SUSPICIOUS') || s.includes('RECON') || s.includes('ENUM')) {
        activeIndex = 1;
    }

    document.getElementById('dgPathStage').textContent=stage||'Not supplied';
    document.getElementById('dgPathResponse').textContent=decision||'Not supplied';
    stages.forEach((name, idx) => {
        const nodeEl = document.getElementById(`tlNode${name}`);
        if (!nodeEl) return;
        const dot = nodeEl.querySelector('.tl-dot');
        const text = nodeEl.querySelector('.tl-text');

        if (idx === activeIndex) {
            const color = colorMap[name];
            if (dot) {
                dot.style.borderColor = color;
                dot.style.color = color;
                dot.style.boxShadow = `0 0 8px ${color}`;
            }
            if (text) {
                text.style.color = color;
                text.classList.add('font-bold');
            }
        } else {
            if (dot) {
                dot.style.borderColor = '#334155';
                dot.style.color = '#334155';
                dot.style.boxShadow = 'none';
            }
            if (text) {
                text.style.color = '#64748b';
                text.classList.remove('font-bold');
            }
        }
    });
}

// 3. Main Data Fetcher

        // Browser-local reading preferences; separate from existing widget visibility preferences.
        const dgReadingKey = 'decoyguard-reading-v1';
        const dgReadingDefaults = { mode:'standard', size:100, line:'1.5', density:'normal', charts:true, motion:false, font:'jakarta',icons:true,descriptions:true,colorFriendly:false };
        const dgReadingEls = {
            mode: document.getElementById('dgReadingMode'), size:document.getElementById('dgTextSize'),
            line:document.getElementById('dgLineSpacing'), density:document.getElementById('dgCardDensity'),
            charts:document.getElementById('dgShowCharts'), motion:document.getElementById('dgReduceMotion'),font:document.getElementById('dgFontStyle'),icons:document.getElementById('dgShowIcons'),descriptions:document.getElementById('dgShowDescriptions'),colorFriendly:document.getElementById('dgColorFriendly')
        };
        function dgApplyReading(p) {
            const body = document.body;
            body.classList.add('dg-reading');document.dispatchEvent(new CustomEvent('dg-reading-updated',{detail:p}));document.querySelectorAll('[data-dg-reading-card]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.dgReadingCard===p.mode)));
            body.classList.toggle('dg-compact',p.mode==='compact'||p.density==='compact');
            body.classList.toggle('dg-spacious',p.mode==='comfortable'||p.density==='spacious');
            body.classList.toggle('dg-focus',p.mode==='focus');
            body.classList.toggle('dg-contrast',p.mode==='contrast');
            body.classList.toggle('dg-no-charts',!p.charts);
            body.style.setProperty('--dg-reading-scale',String(p.size/100));
            body.style.setProperty('--dg-reading-leading',p.line);
            document.getElementById('dgTextSizeValue').textContent=p.size+'%';
            document.documentElement.style.scrollBehavior=p.motion?'auto':'';
            let motionStyle=document.getElementById('dgReducedMotionStyle');
            if(!motionStyle){ motionStyle=document.createElement('style');motionStyle.id='dgReducedMotionStyle';document.head.appendChild(motionStyle); }
            motionStyle.textContent=p.motion?'*,*::before,*::after{animation-duration:0.01ms!important;transition-duration:0.01ms!important;scroll-behavior:auto!important;}':'';
            if(typeof riskChart!=='undefined' && riskChart) riskChart.resize();
            if(typeof trendChart!=='undefined' && trendChart) trendChart.resize();
        }
        function dgReadControls(){return {mode:dgReadingEls.mode.value,size:Number(dgReadingEls.size.value),line:dgReadingEls.line.value,density:dgReadingEls.density.value,charts:dgReadingEls.charts.checked,motion:dgReadingEls.motion.checked,font:dgReadingEls.font.value,icons:dgReadingEls.icons.checked,descriptions:dgReadingEls.descriptions.checked,colorFriendly:dgReadingEls.colorFriendly.checked};}
        function dgSetControls(p){dgReadingEls.mode.value=p.mode;dgReadingEls.size.value=p.size;dgReadingEls.line.value=p.line;dgReadingEls.density.value=p.density;dgReadingEls.charts.checked=p.charts;dgReadingEls.motion.checked=p.motion;dgReadingEls.font.value=p.font;dgReadingEls.icons.checked=p.icons;dgReadingEls.descriptions.checked=p.descriptions;dgReadingEls.colorFriendly.checked=p.colorFriendly;}
        let dgReading= {...dgReadingDefaults};
        try {
            const stored=JSON.parse(localStorage.getItem(dgReadingKey)||'null');
            if(stored && typeof stored==='object'){
                if(['standard','compact','comfortable','focus','contrast'].includes(stored.mode))dgReading.mode=stored.mode;
                if(Number.isFinite(stored.size))dgReading.size=Math.max(90,Math.min(150,stored.size));
                if(['1.3','1.5','1.85'].includes(stored.line))dgReading.line=stored.line;
                if(['normal','compact','spacious'].includes(stored.density))dgReading.density=stored.density;
                if(typeof stored.charts==='boolean')dgReading.charts=stored.charts;
                if(typeof stored.motion==='boolean')dgReading.motion=stored.motion;for(const key of ['icons','descriptions','colorFriendly'])if(typeof stored[key]==='boolean')dgReading[key]=stored[key];if(['jakarta','system','mono'].includes(stored.font))dgReading.font=stored.font;
            }
        } catch(e){console.warn('Reading settings unavailable',e);}
        dgSetControls(dgReading);
        dgApplyReading(dgReading);document.querySelectorAll('[data-dg-reading-card]').forEach(button=>button.addEventListener('click',()=>{dgReadingEls.mode.value=button.dataset.dgReadingCard;dgReadingEls.mode.dispatchEvent(new Event('input'));}));
        Object.values(dgReadingEls).forEach(el=>el.addEventListener('input',()=>{
            dgReading=dgReadControls();dgApplyReading(dgReading);
            try{localStorage.setItem(dgReadingKey,JSON.stringify(dgReading));}catch(e){document.getElementById('dgReadingStatus').textContent='Could not save preferences in this browser.';}
        }));
        document.getElementById('dgResetReading').addEventListener('click',()=>{
            dgReading={...dgReadingDefaults};dgSetControls(dgReading);dgApplyReading(dgReading);
            try{localStorage.setItem(dgReadingKey,JSON.stringify(dgReading));}catch(e){}
        });
        function dgSetDrawer(open){
            const drawer=document.getElementById('dgReadingDrawer');
            drawer.hidden=!open;
            document.body.classList.toggle('dg-drawer-open',open);
            document.getElementById('readingOptionsButton').setAttribute('aria-expanded',String(open));
            window.dispatchEvent(new Event('resize'));
        }
        document.getElementById('dgCloseReading').addEventListener('click',()=>{dgSetDrawer(false);setDashboardSettingsOpen(true);document.getElementById('readingOptionsButton').focus();});
        document.addEventListener('keydown',e=>{if(e.key==='Escape')dgSetDrawer(false);});
        document.getElementById('readingOptionsButton').addEventListener('click',()=>{
            setDashboardSettingsOpen(false);dgSetDrawer(true);document.querySelector('[data-dg-reading-card]')?.focus();
        });

let dgPollRunning=false;
async function fetchSOCData() {
    if(document.body.dataset.dgPreset==='global'&&document.getElementById('dgFeedMode')?.value==='paused')return;
    if(dgPollRunning)return;dgPollRunning=true;
    try {
        const res = await fetch('api.php', {cache:'no-store'});
        if (res.status === 401) { location.reload(); return; }
                if (!res.ok) throw new Error(`API HTTP ${res.status}`);
        const data = await res.json();

        // Historical summary exclusively owns the detection KPI cards.
        // Gauges & Metric Numbers
        const risk = Number(data.gauges?.risk || 0);
        const conf = Number(data.gauges?.confidence || 0);
        const gRisk = document.getElementById('gaugeRiskVal');
        const gConf = document.getElementById('gaugeConfVal');
        if (gRisk) gRisk.innerText = risk;
        if (gConf) gConf.innerText = `${conf}%`;

        // SVG Donut Geometry Computation
        const riskCircle = document.getElementById('riskGaugeCircle');
        const confCircle = document.getElementById('confGaugeCircle');
        let circleCircumference = CIRCUMFERENCE;

        if (riskCircle) {
            const radius = riskCircle.r?.baseVal?.value;
            if (radius && radius > 0) {
                circleCircumference = 2 * Math.PI * radius;
            }
            riskCircle.style.strokeDasharray = `${circleCircumference}`;
        }
        if (confCircle) {
            confCircle.style.strokeDasharray = `${circleCircumference}`;
        }

        const riskRatio = Math.min(Math.max(risk, 0), 200) / 200;
        const confRatio = Math.min(Math.max(conf, 0), 100) / 100;
        const riskOffset = circleCircumference - (riskRatio * circleCircumference);
        const confOffset = circleCircumference - (confRatio * circleCircumference);

        // Palette Mapping
        let activeRiskColor = dgColor('info');
        let activeRiskBadge = 'SAFE';
        let activeBadgeClass = 'text-[#38bdf8] bg-[#38bdf8]/10 border border-[#38bdf8]/30';

        if (risk >= 100) {
            activeRiskColor = dgColor('danger'); // Shadow Milk Magenta
            activeRiskBadge = 'CRITICAL';
            activeBadgeClass = 'text-[#ff2a85] bg-[#ff2a85]/10 border border-[#ff2a85]/40';
        } else if (risk >= 50) {
            activeRiskColor = dgColor('warning'); // Golden Cheese Solar Amber
            activeRiskBadge = 'ELEVATED';
            activeBadgeClass = 'text-[#facc15] bg-[#facc15]/10 border border-[#facc15]/40';
        } else if (risk >= 20) {
            activeRiskColor = dgColor('info'); // Electric Cyan
            activeRiskBadge = 'LOW';
            activeBadgeClass = 'text-[#22d3ee] bg-[#22d3ee]/10 border border-[#22d3ee]/30';
        }

        // Render Risk Donut Ring
        if (riskCircle) {
            riskCircle.style.transition = 'stroke-dashoffset 0.6s ease, stroke 0.4s ease';
            riskCircle.style.stroke = activeRiskColor;
            riskCircle.style.strokeDashoffset = `${riskOffset}`;
        }

        // Render Risk Badge
        const riskBadge = document.getElementById('gaugeRiskBadge');
        if (riskBadge) {
            riskBadge.innerText = activeRiskBadge;
            riskBadge.className = `px-2.5 py-0.5 rounded-full text-[9px] mono font-bold mt-1 ${activeBadgeClass}`;
        }

        // Render Confidence Donut Ring
        if (confCircle) {
            confCircle.style.transition = 'stroke-dashoffset 0.6s ease';
            confCircle.style.stroke = dgColor('info');
            confCircle.style.strokeDashoffset = `${confOffset}`;
        }

        // Response Strips
        const stripResp = document.getElementById('stripResponse');
        const stripStg = document.getElementById('stripStage');
        const stripSev = document.getElementById('stripSeverity');

        if (stripResp) stripResp.innerText = data.latest?.decision || 'ALLOW';
        if (stripStg) stripStg.innerText = data.latest?.attack_stage || 'NORMAL';
        
        if (stripSev) {
            const rawSev = String(data.latest?.severity || (risk >= 50 ? 'HIGH' : 'SAFE')).toUpperCase();
            stripSev.innerText = rawSev;
            
            // Explicit style color to overwrite old emerald classes
            if (rawSev === 'CRITICAL') {
                stripSev.style.color = dgColor('danger');
            } else if (rawSev === 'HIGH' || rawSev === 'ELEVATED') {
                stripSev.style.color = dgColor('warning');
            } else if (rawSev === 'MEDIUM') {
                stripSev.style.color = dgColor('info');
            } else {
                stripSev.style.color = dgColor('info');
            }
        }

        // Pattern counts are owned by the selected-feed analytics renderer.
        // Dynamic Honeypot Engine Counters
        const hpTrapped = document.getElementById('hpTrapped');
        const hpSessions = document.getElementById('hpSessions');
        const hpCommands = document.getElementById('hpCommands');
        const hpLatestIp = document.getElementById('hpLatestIp');

        if (hpTrapped) hpTrapped.innerText = data.stats?.hp_trapped || data.stats?.honeypot || 0;
        if (hpSessions) hpSessions.innerText = data.stats?.hp_sessions || 0;
        if (hpCommands) hpCommands.innerText = data.stats?.hp_commands || 0;

        if (hpLatestIp && data.latest?.source_ip && data.latest.source_ip !== '-') {
            hpLatestIp.innerText = `${data.latest.source_ip}`;
        }

        // Update Timeline
        updateTimeline(data.latest?.attack_stage, data.latest?.decision);

        // Update Charts
        if (data.risk && riskChart) {
            riskChart.data.datasets[0].data = data.risk;
            riskChart.update('none');
        }



        dgLastData=data;window.dispatchEvent(new CustomEvent('dg:soc-data',{detail:data}));
        dgRenderScope(data);
        const dgVisibleEvents=dgFilteredEvents(data).filter(e=>!window.dgActivitySource||String(e.source_ip||e.remote_addr||'')===window.dgActivitySource);
        dgRecolorCharts();
        // Populate Activity Stream Table (Capped to 8 rows)
        const tbody = document.getElementById('activityStreamBody');
        if (tbody) {
            if(!dgVisibleEvents.length){const note=document.getElementById('dgScanGroupNote');if(note)note.textContent='No matching records in the selected latest feed'+(window.dgActivitySource?' for source '+window.dgActivitySource:'')+'.';}
            if (dgVisibleEvents.length > 0) {
                const grouped=dgGroupedRecords(dgVisibleEvents);const groupNote=document.getElementById("dgScanGroupNote");if(groupNote)groupNote.textContent=grouped.length+" displayed row(s) in the selected latest feed. Historical counts and trends retain individual detections. The latest feed groups scanner records before its display limit; original request logs are retained.";
                const rows = grouped.slice(0, dgView==='incidents' ? 50 : 8).map(event => {
                    if (!event) return '';
                    const riskVal = Number(event.risk || 0);
                    const severityStr = String(event.severity || 'SAFE').toUpperCase().trim();
                    
                    let sevPillStyle = 'text-[#38bdf8] bg-[#38bdf8]/10 border border-[#38bdf8]/30';
                    let riskNumColor = 'text-slate-400';

                    if (severityStr === 'CRITICAL' || severityStr === 'VERY HIGH') {
                        sevPillStyle = 'text-[#ff2a85] bg-[#ff2a85]/10 border border-[#ff2a85]/40';
                        riskNumColor = 'text-[#ff2a85]';
                    } else if (severityStr === 'HIGH') {
                        sevPillStyle = 'text-[#facc15] bg-[#facc15]/10 border border-[#facc15]/40';
                        riskNumColor = 'text-[#facc15]';
                    } else if (severityStr === 'MEDIUM' || severityStr === 'LOW') {
                        sevPillStyle = 'text-[#22d3ee] bg-[#22d3ee]/10 border border-[#22d3ee]/30';
                        riskNumColor = 'text-[#22d3ee]';
                    }
                    
                    const rawId = String(event.incident_id || 'DG-00000000');
                    let coloredId = `<span class="text-slate-400">${escapeHTML(rawId)}</span>`;

                    if (rawId.includes('-')) {
                        const parts = rawId.split('-');
                        const prefix = parts[0] + '-';
                        const code = parts.slice(1).join('-');

                        if (prefix === 'BE-') {
                            coloredId = `<span class="font-bold text-[#c084fc]">${escapeHTML(prefix)}</span><span class="text-slate-400">${escapeHTML(code)}</span>`;
                        } else if (prefix === 'HP-') {
                            coloredId = `<span class="font-bold text-[#ff2a85]">${escapeHTML(prefix)}</span><span class="text-slate-400">${escapeHTML(code)}</span>`;
                        } else {
                            coloredId = `<span class="font-bold text-[#22d3ee]">${escapeHTML(prefix)}</span><span class="text-slate-400">${escapeHTML(code)}</span>`;
                        }
                    }

                    const decisionStr = String(event.decision || 'ALLOW').toUpperCase();
                    const decisionColor = (decisionStr === 'REDIRECT' || decisionStr === 'ISOLATE' || decisionStr === 'HONEYPOT') 
                        ? 'text-[#ff2a85]' 
                        : 'text-slate-400';

                    return `
                        <tr>
                            <td class="py-2 px-1 mono">${coloredId}</td>
                            <td class="py-2 px-1 text-[#64748b]">${escapeHTML(event.time || '--:--:--')}</td>
                            <td class="py-2 px-1 text-slate-300">${escapeHTML(event.site_id || 'Unassigned')}</td>
                            <td class="py-2 px-1 text-slate-300">${escapeHTML(event.source_ip || '-')}</td>
                            <td class="py-2 px-1 font-sans text-slate-200">${escapeHTML(event._count>1?'Scanner probing process':(event.attack || 'Normal Traffic'))}<small class="dg-global-only dg-global-request">${escapeHTML(event.request||'Endpoint not recorded')}</small>${dgScanDetails(event)}</td>
                            <td class="py-2 px-1 font-bold ${riskNumColor}">${riskVal}</td>
                            <td class="py-2 px-1 text-center">
                                <span class="px-2 py-0.5 rounded-full text-[8px] mono font-bold uppercase tracking-wider ${sevPillStyle}">
                                    ${escapeHTML(severityStr)}
                                </span>
                            </td>
                            <td class="py-2 px-1 text-right font-bold ${decisionColor}">${escapeHTML(decisionStr)}</td>
                        </tr>
                    `;
                }).join('');

                if(tbody.dataset.rows!==rows){tbody.innerHTML=rows;tbody.dataset.rows=rows;for(const details of tbody.querySelectorAll('[data-scan-group]'))details.open=dgOpenScanGroups.has(details.dataset.scanGroup);}
            } else {
                tbody.innerHTML = `<tr><td colspan="8" class="py-4 text-center text-[#64748b]">No active alerts recorded.</td></tr>`;tbody.dataset.rows="";const groupNote=document.getElementById("dgScanGroupNote");if(groupNote)groupNote.textContent="No matching records.";
            }
        }

        const connection=document.getElementById('dgConnectionStatus');if(connection)connection.textContent='FEED CONNECTED';
        const timeElem = document.getElementById('lastTelemetryTime');
        if (timeElem) {
            timeElem.innerText = new Date().toLocaleTimeString();
        }

    } catch (err) {
        console.error("Telemetry poll failed:", err);const connection=document.getElementById("dgConnectionStatus");if(connection)connection.textContent="FEED UNAVAILABLE";
        const status = document.getElementById("lastTelemetryTime") || document.getElementById("lastTelemetry"); if (status) status.textContent = "API unavailable: " + err.message;
    } finally {dgPollRunning=false;}
}

function dgRecolorCharts(){
 if(riskChart){const ds=riskChart.data.datasets[0];ds.backgroundColor=dgSeries().slice(0,5);ds.borderColor=document.body.dataset.dgTheme==='daylight'?[dgColor('info'),dgColor('danger'),dgColor('success'),dgColor('warning'),dgColor('text')]:ds.backgroundColor;ds.borderWidth=1;}
 if(trendChart){const d=trendChart.data.datasets[0];d.borderColor=document.body.dataset.dgTheme==='daylight'?'#17804b':dgColor('success');d.pointBackgroundColor=d.borderColor;d.backgroundColor=dgColor('success')+'38';}
 if(dgLastData)dgRenderGlobalSummary(dgFilteredEvents(dgLastData),dgLastData);
 for(const chart of [riskChart,trendChart]){if(!chart)continue;for(const axis of Object.values(chart.options.scales||{})){if(axis.ticks)axis.ticks.color=dgColor('muted');if(axis.title)axis.title.color=dgColor('muted');if(axis.grid)axis.grid.color=dgColor('line')+'70';}if(chart.options.plugins?.legend?.labels)chart.options.plugins.legend.labels.color=dgColor('muted');chart.update('none');}
 const risk=Number(dgLastData?.gauges?.risk||0);const circle=document.getElementById('riskGaugeCircle');if(circle)circle.style.stroke=dgColor(risk>=100?'danger':risk>=50?'warning':'info');const confidence=document.getElementById('confGaugeCircle');if(confidence)confidence.style.stroke=dgColor('info');
}
window.addEventListener('dg:theme-changed',dgRecolorCharts);

// Poll every 2 seconds
document.getElementById('dgGlobalPeriod').addEventListener('change',e=>{document.getElementById('dgTrendWindow').value=e.target.value;dgRefreshLocal();});
document.getElementById('dgFeedMode').addEventListener('change',e=>{document.getElementById('dgConnectionStatus').textContent=e.target.value==='paused'?'FEED PAUSED':'CONNECTING';if(e.target.value==='live')fetchSOCData();});
window.addEventListener('dg:layout-changed',()=>{if(dgLastData)dgRenderGlobalSummary(dgFilteredEvents(dgLastData),dgLastData);document.getElementById('dgGlobalPeriod').value=document.getElementById('dgTrendWindow').value;if(document.body.dataset.dgPreset!=='global')document.getElementById('dgFeedMode').value='live';});
setInterval(fetchSOCData, 2000);
fetchSOCData();
    </script>
<?php include __DIR__ . '/dashboard_layout.php'; ?>
<script>dgSetView(new URLSearchParams(location.search).get('view')||'overview',false);window.addEventListener('popstate',()=>dgSetView(new URLSearchParams(location.search).get('view')||'overview',false));</script>

<script>
(()=>{const form=document.getElementById('securityReportForm');
const draftFields=['reviewer','review_role','ticket_id','review_conclusion'];
const draftKey='dg-report-review-draft-v1:'+<?= json_encode($_SESSION['analyst_id'] ?? 'current', JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
try{const draft=JSON.parse(sessionStorage.getItem(draftKey)||'{}');for(const key of draftFields){const field=form.elements.namedItem(key);if(field&&typeof draft[key]==='string'&&!field.value)field.value=draft[key];}}catch(error){}
const saveDraft=()=>{try{const draft={};for(const key of draftFields)draft[key]=form.elements.namedItem(key)?.value||'';sessionStorage.setItem(draftKey,JSON.stringify(draft));}catch(error){}};
form.addEventListener('input',saveDraft);form.addEventListener('change',saveDraft);form.addEventListener('submit',saveDraft);
const syncZone=()=>{document.getElementById('reportTimezone').value=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';};syncZone();form.addEventListener('submit',e=>{syncZone();const status=document.getElementById('reportFormStatus');status.textContent='Report opens in a new tab. Print the HTML report to save as PDF.';});fetch('api.php?action=sites',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(data=>{if(!data)return;for(const site of data.sites||[]){const option=document.createElement('option');option.value=site.site_id;option.textContent=site.name||site.site_id;document.getElementById('reportSite').append(option);}}).catch(()=>{});})();

</script>
<script src="dashboard_analytics.js?v=<?= filemtime(__DIR__.'/dashboard_analytics.js') ?>" defer></script>
<script src="dashboard_customizer.js?v=<?= filemtime(__DIR__.'/dashboard_customizer.js') ?>" defer></script>
</body>
</html>