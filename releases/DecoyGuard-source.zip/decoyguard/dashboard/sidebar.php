<?php
if (!defined('DG_DASHBOARD_PAGE')) define('DG_DASHBOARD_PAGE', true);
require_once __DIR__ . '/api.php';
$currentPage = basename($_SERVER['SCRIPT_NAME'] ?? 'dashboard.php');
?>


<style>
    /* SIDEBAR BASE */
    #sidebar {
        width: 218px;
        transition: width 220ms ease, padding 220ms ease;
    }

    /* NAVIGATION LINK */
    .sidebar-link {
        position: relative;
        display: flex;
        align-items: center;
        gap: 12px;
        width: 100%;
        padding: 10px 12px;
        border-radius: 9px;
        color: #78869a;
        font-size: 11px;
        font-weight: 600;
        text-decoration: none;
        transition: background 180ms ease, color 180ms ease, transform 180ms ease;
    }

    #dashboardSettingsButton {
        border: 0;
        background: transparent;
        text-align: left;
        font-family: inherit;
        cursor: pointer;
    }

    .sidebar-link:hover {
        background: rgba(255,255,255,0.035);
        color: #f1f5f9;
        transform: translateX(2px);
    }

    /* ICON */
    .sidebar-icon {
        width: 20px;
        min-width: 20px;
        text-align: center;
        font-size: 14px;
        transition: transform 180ms ease, filter 180ms ease;
    }

    .sidebar-link:hover .sidebar-icon {
        transform: scale(1.08);
    }

    /* ACTIVE LINK */
    .sidebar-link.active {
        background: rgba(32,217,255,0.08);
        color: #dbeafe;
        border: 1px solid rgba(32,217,255,0.10);
    }

    .sidebar-link.active::before {
        content: "";
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 3px;
        height: 20px;
        border-radius: 0 4px 4px 0;
        background: #20d9ff;
        box-shadow: 0 0 10px rgba(32,217,255,0.55);
    }

    /* SIDEBAR TEXT */
    .sidebar-text {
        white-space: nowrap;
        overflow: hidden;
        opacity: 1;
        max-width: 180px;
        transition: opacity 150ms ease, max-width 220ms ease;
    }

    /* TOOLTIP */
    .sidebar-tooltip {
        display: none;
        position: absolute;
        left: calc(100% + 10px);
        top: 50%;
        transform: translateY(-50%);
        z-index: 999;
        white-space: nowrap;
        padding: 7px 10px;
        border-radius: 7px;
        background: #0d1322;
        border: 1px solid rgba(255,255,255,0.10);
        color: #f8fafc;
        font-size: 10px;
        font-weight: 600;
        box-shadow: 0 10px 25px rgba(0,0,0,0.4);
    }

    /* COLLAPSED SIDEBAR */
    #sidebar.sidebar-collapsed {
        width: 70px;
        padding-left: 9px;
        padding-right: 9px;
    }

    #sidebar.sidebar-collapsed .sidebar-text {
        max-width: 0;
        opacity: 0;
        pointer-events: none;
    }

    #sidebar.sidebar-collapsed .sidebar-link {
        justify-content: center;
        padding-left: 0;
        padding-right: 0;
    }

    #sidebar.sidebar-collapsed .sidebar-icon {
        width: 22px;
    }

    #sidebar.sidebar-collapsed .sidebar-link:hover .sidebar-tooltip {
        display: block;
    }

    #sidebar.sidebar-collapsed .sidebar-link.active::before {
        left: -5px;
        height: 18px;
    }

    /* LOGO */
    .sidebar-logo {
        cursor: pointer;
        flex-shrink: 0;
    }

    .sidebar-logo > div {
        transition: transform 180ms ease, background 180ms ease, border-color 180ms ease, box-shadow 180ms ease;
    }

    .sidebar-logo:hover > div {
        background: rgba(32,217,255,0.14);
        border-color: rgba(32,217,255,0.55);
        transform: scale(1.04);
        box-shadow: 0 0 16px rgba(32,217,255,0.18);
    }

    #sidebar.sidebar-collapsed .sidebar-logo {
        margin-left: auto;
        margin-right: auto;
    }

    #sidebar.sidebar-collapsed .sidebar-logo > div {
        transform: scale(0.92);
    }

    #sidebar.sidebar-collapsed .sidebar-logo:hover > div {
        transform: scale(1.02);
    }

    /* SIDEBAR USER CARD */
    .sidebar-user {
        transition: padding 220ms ease;
    }

    #sidebar.sidebar-collapsed .sidebar-user {
        justify-content: center;
        padding: 7px;
    }

    #sidebar.sidebar-collapsed .sidebar-user > div {
        margin: 0;
    }

    /* NAVIGATION SPACING */
    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 3px;
    }

    .sidebar-section {
        margin-bottom: 7px;
    }

    .sidebar-section-label {
        padding: 3px 10px 6px;
        color: #465268;
        font-family: "JetBrains Mono", monospace;
        font-size: 7px;
        font-weight: 600;
        letter-spacing: 0.14em;
        text-transform: uppercase;
    }

    #sidebar.sidebar-collapsed .sidebar-section-label {
        height: 6px;
        padding: 0;
        opacity: 0;
    }

    /* MOBILE BREAKPOINT */
    @media (max-width: 1023px) {
        #sidebar {
            width: 70px !important;
            padding-left: 9px;
            padding-right: 9px;
        }
        #sidebar .sidebar-text {
            max-width: 0;
            opacity: 0;
        }
        #sidebar .sidebar-link {
            justify-content: center;
            padding-left: 0;
            padding-right: 0;
        }
        #sidebar .sidebar-section-label {
            opacity: 0;
            height: 6px;
            padding: 0;
        }
    }

body #sidebar .sidebar-link .dg-website-handler-icon{color:var(--dg-info,#6acafc)!important;}
body #sidebar .sidebar-link .dg-dashboard-settings-icon{color:var(--dg-success,#6ce6dd)!important;}
</style>

<!-- SIDEBAR HTML -->
<aside id="sidebar" class="group hidden lg:flex bg-[#080d1e]/95 backdrop-blur-xl border-r border-slate-800/80 flex-col justify-between px-[9px] py-4 shrink-0 min-h-screen transition-all duration-200 ease-in-out">
    <div>
        <!-- LOGO & BRAND -->
        <div class="flex items-center mb-5 px-1">
            <button id="sidebarToggle" type="button" class="sidebar-logo shrink-0 rounded-xl flex items-center justify-center transition-all duration-200" title="Expand sidebar">
                <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400 text-xl">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
            </button>

            <div class="sidebar-text ml-3 overflow-hidden">
                <h1 class="text-[15px] font-black text-cyan-400">DecoyGuard</h1>
                <p class="text-[8px] uppercase tracking-[0.18em] text-slate-500">SOC Platform</p>
            </div>
        </div>

        <!-- NAVIGATION -->
        <nav class="sidebar-nav">
            <!-- MONITORING -->
            <div class="sidebar-section">
                <div class="sidebar-section-label">Monitoring</div>
                <a href="dashboard.php" class="sidebar-link <?= ($currentPage == 'dashboard.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-chart-pie sidebar-icon text-cyan-400"></i>
                    <span class="sidebar-text">Live SOC Overview</span>
                    <span class="sidebar-tooltip">Live SOC Overview</span>
                </a>
                <?php if (in_array($currentPage, ['dashboard.php','dashboard_classic.php'], true)): ?>
                    <button id="dashboardSettingsButton" type="button" class="sidebar-link">
                        <i class="fa-solid fa-sliders sidebar-icon text-green-400 dg-dashboard-settings-icon"></i>
                        <span class="sidebar-text">Customize Dashboard</span>
                        <span class="sidebar-tooltip">Customize Dashboard</span>
                    </button>
                <?php endif; ?>
                <a href="entity.php" class="sidebar-link <?= ($currentPage == 'entity.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-user-shield sidebar-icon text-purple-400"></i>
                    <span class="sidebar-text">Entity Profiles</span>
                    <span class="sidebar-tooltip">Entity Profiles</span>
                </a>
            </div>

            <!-- RESPONSE -->
            <div class="sidebar-section">
                <div class="sidebar-section-label">Response</div>
                 <a href="honeypot_queue.php" class="sidebar-link <?= ($currentPage == 'honeypot_queue.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-jar sidebar-icon text-pink-400"></i>
                    <span class="sidebar-text">Honeypot Queue</span>
                    <span class="sidebar-tooltip">Honeypot Queue</span>
                </a>
                <a href="website_handler.php" class="sidebar-link <?= ($currentPage == 'website_handler.php') ? 'active' : '' ?>">
                    <i class="fa-solid fa-globe sidebar-icon dg-website-handler-icon"></i>
                    <span class="sidebar-text">Website Handler</span>
                    <span class="sidebar-tooltip">Website Handler</span>
                </a>
            </div>
        </nav>
    </div>

    <!-- USER CARD -->
    <div class="sidebar-user bg-white/[0.02] border border-white/[0.06] rounded-lg p-2 flex items-center justify-between">
        <div class="flex items-center gap-2 min-w-0">
            <div class="w-8 h-8 shrink-0 rounded-lg bg-cyan-500/10 border border-cyan-400/25 flex items-center justify-center font-black text-cyan-300 text-xs">
                A
            </div>
            <div class="sidebar-text overflow-hidden whitespace-nowrap">
                <p class="text-white font-bold text-[10px]">Lead Analyst</p>
                <p class="text-[8px] text-green-400 font-bold">● Engine Active</p>
            </div>
        </div>
        <form method="post"><input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="dg_action" value="logout"><button type="submit" class="sidebar-text text-slate-500 hover:text-pink-400 transition text-sm p-1.5" title="Logout">
            <i class="fa-solid fa-right-from-bracket"></i>
        </button></form><a href="api.php?action=account" class="sidebar-text text-slate-400 text-xs" title="Change password">Account</a>
    </div>
</aside>

<!-- SIDEBAR SCRIPT -->
<script>
// All dashboard pages share the viewing device's timezone; source evidence stays unchanged.
(()=>{try{const sync=()=>{const zone=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';document.cookie='dg_device_timezone='+encodeURIComponent(zone)+'; Path=/; SameSite=Strict'+(location.protocol==='https:'?'; Secure':'');document.documentElement.dataset.timezone=zone;};sync();window.addEventListener('focus',sync);}catch(error){console.warn('Device timezone unavailable; server timezone is used.');}})();

document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.getElementById("sidebar");
    const toggle = document.getElementById("sidebarToggle");

    if (!sidebar || !toggle) return;

    // Start collapsed by default
    sidebar.classList.add("sidebar-collapsed");
    toggle.title = "Expand sidebar";

    // Toggle open / collapse
    toggle.addEventListener("click", function (event) {
        event.preventDefault();
        sidebar.classList.toggle("sidebar-collapsed");
        const collapsed = sidebar.classList.contains("sidebar-collapsed");
        toggle.title = collapsed ? "Expand sidebar" : "Collapse sidebar";
    });

    // Ensure state stays collapsed upon page navigation
    sidebar.querySelectorAll(".sidebar-link[href]").forEach(function (link) {
        link.addEventListener("click", function () {
            sidebar.classList.add("sidebar-collapsed");
        });
    });
});
</script>
<?php if(!defined('DG_SHARED_THEME_LOADED')){define('DG_SHARED_THEME_LOADED',true);echo '<style id="dgSharedThemeStyles">';if(is_readable(__DIR__.'/soc_theme.css'))print(substr(file_get_contents(__DIR__.'/soc_theme.css'),strpos(file_get_contents(__DIR__.'/soc_theme.css'),'/* DG_CUSTOM_THEME_START */')));echo '</style>'; } ?>
<script>
(()=>{const palettes={
  original: {
    base: "#02080f", card: "#061722", raised: "#0c2332", text: "#e8f2ff", muted: "#a0b3c9", line: "#25465b",
    accent: "#00d9ff", danger: "#ff609a", warning: "#ffd452", success: "#35ec9c", info: "#00d9ff", purple: "#b895ff",
    series: ["#00d9ff", "#ff609a", "#b895ff", "#ffd452", "#35ec9c", "#72a9ff"]
  },
  midnight: {
    base: "#050b25", card: "#0d1740", raised: "#15234c", text: "#ecf4ff", muted: "#a3b6d0", line: "#34477e",
    accent: "#83a1ff", danger: "#ff7895", warning: "#ffd36c", success: "#4be0c3", info: "#69baff", purple: "#a89aff",
    series: ["#83a1ff", "#69baff", "#4be0c3", "#ffd36c", "#ff7895", "#a89aff"]
  },
  amethyst: {
    base: "#11001f", card: "#25063d", raised: "#330d4c", text: "#f3e8fc", muted: "#d4bfe5", line: "#683280",
    accent: "#8494ff", danger: "#ef7cbb", warning: "#efc47c", success: "#6ce6dd", info: "#6acafc", purple: "#8494ff", lime: "#dbf094",
    series: ["#8494ff", "#6acafc", "#6ce6dd", "#dbf094", "#ef7cbb", "#efc47c"]
  },
  daylight: {
    base: "#e5f4fb", card: "#ffffff", raised: "#f3f9fc", text: "#183747", muted: "#526978", line: "#c6dfe9",
    accent: "#167ca8", danger: "#FA26A0", warning: "#FFF591", success: "#A3F7BF", info: "#05DFD7", purple: "#6acafc", lime: "#C4FB6D",
    series: ["#05DFD7", "#FA26A0", "#C4FB6D", "#FFF591", "#A3F7BF", "#6acafc"]
  },
  dracula: {
    base: "#262630", card: "#30303d", raised: "#373745", text: "#f8f8f2", muted: "#b6b8d0", line: "#67627b",
    accent: "#bd93f9", danger: "#ff838c", warning: "#f1fa8c", success: "#50fa7b", info: "#8be9fd", purple: "#bd93f9",
    series: ["#bd93f9", "#ff79c6", "#8be9fd", "#f1fa8c", "#50fa7b", "#ffb86c"]
  },
  nord: {
    base: "#203139", card: "#2b4048", raised: "#324952", text: "#edf7f8", muted: "#b8ced2", line: "#607d85",
    accent: "#62e0e2", danger: "#ffa4b4", warning: "#ffdb8f", success: "#a5e6a0", info: "#8bd4ff", purple: "#d1b4f3",
    series: ["#62e0e2", "#8bd4ff", "#d1b4f3", "#ffdb8f", "#a5e6a0", "#ffa4b4"]
  }
};
window.dgApplySharedTheme=function(theme){const p=palettes[theme]||palettes.original;for(const node of [document.documentElement,document.body]){node.dataset.dgTheme=theme in palettes?theme:'original';for(const [k,v]of Object.entries(p))if(typeof v==='string')node.style.setProperty('--dg-'+k,v);node.style.setProperty('--dg-fg',p.text);for(const [k,v]of Object.entries({cyan:'info',pink:'danger',lime:(p.lime?'lime':'warning'),green:'success',purple:'purple',bg:'base',panel:'card','panel-2':'raised',text:'text',muted:'muted',line:'line'}))node.style.setProperty('--'+k,p[v]);node.style.colorScheme=theme==='daylight'?'light':'dark';}window.dgThemePalette=p;};
function applySaved(){try{window.dgApplySharedTheme(JSON.parse(localStorage.getItem('dg-unified-workspace-v1')||'{}').theme||'original');}catch(_){window.dgApplySharedTheme('original');}}applySaved();window.addEventListener('storage',e=>{if(e.key==='dg-unified-workspace-v1')applySaved();});
})();
</script>
