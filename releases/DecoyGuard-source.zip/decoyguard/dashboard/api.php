<?php
// Display timezone comes from the viewing device. Accept only known IANA identifiers.
$dgDeviceZone = $_COOKIE['dg_device_timezone'] ?? '';
if (!is_string($dgDeviceZone) || !in_array($dgDeviceZone, timezone_identifiers_list(DateTimeZone::ALL_WITH_BC), true))
    $dgDeviceZone = date_default_timezone_get();
date_default_timezone_set($dgDeviceZone);
// Shared dashboard authentication. No decoy authentication or SQL bypass is used here.
function dg_dashboard_auth(bool $json = false): void {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        session_name('DG_ADMIN');
        session_set_cookie_params(['lifetime'=>0, 'path'=>'/', 'httponly'=>true,
            'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'samesite'=>'Strict']);
        session_start();
    }
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: same-origin');
    $_SESSION['csrf'] ??= bin2hex(random_bytes(32));
    $dir = getenv('DECOYGUARD_AUTH_DIR') ?: (is_dir('/var/log/decoyguard')
        ? '/var/log/decoyguard/dashboard-auth' : sys_get_temp_dir().'/dg-admin-'.substr(hash('sha256', __DIR__),0,16));
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    $fp = @fopen($dir.'/credentials.json', 'c+');
    if (!$fp || !flock($fp, LOCK_EX)) {
        http_response_code(503); exit($json ? '{"error":"Authentication storage unavailable"}' : 'Authentication storage unavailable. Check PHP write permissions.');
    }
    @chmod($dir.'/credentials.json', 0600);
    $state = json_decode(stream_get_contents($fp), true);
    if (!is_array($state)) $state = ['user'=>getenv('DECOYGUARD_ADMIN_USER') ?: 'admin',
        'hash'=>getenv('DECOYGUARD_ADMIN_PASSWORD_HASH') ?: password_hash('decoyguard', PASSWORD_DEFAULT), 'failures'=>[]];
    $configuredHash = getenv('DECOYGUARD_ADMIN_PASSWORD_HASH');
    if ($configuredHash) {
        $state['hash'] = $configuredHash;
        $state['user'] = getenv('DECOYGUARD_ADMIN_USER') ?: 'admin';
    }
    $now = time();
    foreach ($state['failures'] as $key=>$value) if (($value['until'] ?? 0) < $now-900) unset($state['failures'][$key]);
    $authenticated = !empty($_SESSION['dg_admin']) && hash_equals(hash('sha256',$state['user']."\0".$state['hash']), $_SESSION['credential_version'] ?? '')
        && $now-($_SESSION['last_seen'] ?? 0) < 1800 && $now-($_SESSION['created'] ?? 0) < 28800;
    $error = '';
    $action = $_POST['dg_action'] ?? '';
    $csrfOK = is_string($_POST['csrf'] ?? null) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
    if ($action && !$csrfOK) { flock($fp,LOCK_UN); fclose($fp); http_response_code(403); header('Content-Type: application/json'); exit(json_encode(['error'=>'Invalid session token. Reload and try again.'])); }
    elseif ($action === 'logout') {
        $_SESSION=[]; session_regenerate_id(true); $_SESSION['csrf']=bin2hex(random_bytes(32)); $authenticated=false;
    } elseif ($action === 'login') {
        $key=hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '').'|'.$state['user']);
        $failure=$state['failures'][$key] ?? ['count'=>0,'until'=>0];
        if ($failure['until'] > $now && $failure['count'] >= 5) {
            http_response_code(429); header('Retry-After: '.($failure['until']-$now)); $error='Too many failed attempts. Try again in 15 minutes.';
        } elseif (is_string($_POST['username'] ?? null) && is_string($_POST['password'] ?? null)
            && hash_equals($state['user'], $_POST['username']) && password_verify($_POST['password'], $state['hash'])) {
            session_regenerate_id(true); $_SESSION=['dg_admin'=>true, 'created'=>$now, 'last_seen'=>$now,
                'credential_version'=>hash('sha256',$state['user']."\0".$state['hash']), 'csrf'=>bin2hex(random_bytes(32))];
            unset($state['failures'][$key]); $authenticated=true;
        } else {
            if ($failure['until'] <= $now) $failure=['count'=>0,'until'=>$now+900];
            $failure['count']++; $state['failures'][$key]=$failure; $error='Invalid username or password.';
        }
    } elseif ($action === 'password' && $authenticated) {
        $new=$_POST['new_password'] ?? '';
        if ($configuredHash) $error='The password is managed by DECOYGUARD_ADMIN_PASSWORD_HASH.';
        elseif (!is_string($new) || strlen($new)<12 || strlen($new)>72 || !password_verify((string)($_POST['password'] ?? ''),$state['hash']))
            $error='Enter your current password and a new password of 12 to 72 characters.';
        else {
            $state['hash']=password_hash($new,PASSWORD_DEFAULT); session_regenerate_id(true);
            $_SESSION['credential_version']=hash('sha256',$state['user']."\0".$state['hash']); $_SESSION['csrf']=bin2hex(random_bytes(32));
            $error='Password updated.';
        }
    }
    rewind($fp); ftruncate($fp,0); fwrite($fp,json_encode($state)); fflush($fp); flock($fp,LOCK_UN); fclose($fp);
    if ($csrfOK && (($action === 'login' && $authenticated) || $action === 'logout' || ($action === 'password' && $error === 'Password updated.'))) {
        $destination = basename($_SERVER['SCRIPT_NAME'] ?? 'dashboard.php');
        if ($destination === 'api.php') $destination = $action === 'password' ? 'api.php?action=account' : 'dashboard.php';
        session_write_close(); header('Location: '.$destination, true, 303); exit;
    }
    $account=$authenticated && ($_GET['action'] ?? '') === 'account';
    if ($authenticated) { $_SESSION['analyst_id']=$state['user']; $_SESSION['last_seen']=$now; $_SESSION['default_password']=password_verify('decoyguard',$state['hash']); }
    if ($authenticated && !$account) { session_write_close(); return; }
    if ($json && !$account) {
        http_response_code(401); header('Content-Type: application/json'); exit(json_encode(['error'=>'Authentication required','login_required'=>true]));
    }
    $esc=static fn($s)=>htmlspecialchars($s, ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DecoyGuard Login</title><style>body{margin:0;background:#050811;color:#e2e8f0;font:16px system-ui;min-height:100vh;display:grid;place-items:center}main{width:min(360px,85vw);padding:32px;background:#0a1021;border:1px solid #25334b;border-radius:16px}h1{color:#20d9ff}input,button{box-sizing:border-box;width:100%;padding:14px;margin:8px 0;border-radius:8px;border:1px solid #334155;background:#050811;color:#fff}button{background:#20d9ff;color:#050811;font-weight:bold}p,a{color:#94a3b8}label{display:block;margin-top:12px}.error{color:#ff9abc}</style><main><h1>DecoyGuard</h1><p>'.($account?'Account security':'Sign in to the security dashboard').'</p><p class="error">'.$esc($error).'</p><form method="post"><input type="hidden" name="csrf" value="'.$esc($_SESSION['csrf']).'"><input type="hidden" name="dg_action" value="'.($account?'password':'login').'">';
    if (!$account) echo '<label>Username<input name="username" autocomplete="username" required maxlength="128"></label>';
    echo '<label>'.($account?'Current password':'Password').'<input type="password" name="password" autocomplete="current-password" required maxlength="1024"></label>';
    if ($account) echo '<label>New password<input type="password" name="new_password" autocomplete="new-password" minlength="12" maxlength="72" required></label>';
    echo '<button>'.($account?'Update password':'Sign in').'</button></form>'.($account?'<a href="dashboard.php">Return to dashboard</a>':'').'</main></html>';
    exit;
}
dg_dashboard_auth(!defined('DG_DASHBOARD_PAGE'));
if (defined('DG_DASHBOARD_PAGE')) return;

header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');

// Authenticated site control is queued for the host Python controller.
$siteAction = $_GET['action'] ?? '';
if ($siteAction === 'sites') {
    $dir = getenv('DECOYGUARD_LOG_DIR') ?: '/var/log/decoyguard';
    if (!is_dir($dir)) $dir = dirname(__DIR__).'/logs';
    $registryPath = $dir.'/website_registry.json';
    $registry = is_file($registryPath) ? json_decode(file_get_contents($registryPath),true) : ['sites'=>[]];
    $controller = is_file($dir.'/site_controller.json') ? json_decode(file_get_contents($dir.'/site_controller.json'),true) : [];
    $online = ($controller['status'] ?? '') === 'ready' && time()-($controller['timestamp'] ?? 0)<15;
    $jobsDir=$dir.'/site_requests';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $body=file_get_contents('php://input',false,null,0,8193);
        if (strlen($body)>8192) { http_response_code(413); exit(json_encode(['error'=>'Website request is too large'])); }
        $input=json_decode($body,true);
        if (!is_array($input) || !is_string($input['csrf'] ?? null) || !hash_equals($_SESSION['csrf'] ?? '',$input['csrf'])) {
            http_response_code(403); exit(json_encode(['error'=>'Invalid session token. Reload the dashboard.']));
        }
        if (!$online) { http_response_code(503); exit(json_encode(['error'=>'Start DecoyGuard with --saved or --dashboard-only so the deployment controller is running.'])); }
        $action=$input['operation'] ?? '';
        if (!in_array($action,['add','retry','remove'],true)) { http_response_code(400); exit(json_encode(['error'=>'Invalid operation'])); }
        $site=$input['site'] ?? [];
        if (!is_array($site) || !preg_match('/^[a-z][a-z0-9-]{0,30}$/',(string)($site['site_id'] ?? ''))) {
            http_response_code(400); exit(json_encode(['error'=>'Use a website ID starting with a letter, with up to 31 letters, numbers or hyphens.']));
        }
        if (!empty($site['domain']) && !empty($_SESSION['default_password'])) {
            http_response_code(400); exit(json_encode(['error'=>'Change the initial admin password using Account before enabling public access.']));
        }
        if (!is_dir($jobsDir) || !is_writable($jobsDir)) { http_response_code(503); exit(json_encode(['error'=>'Deployment request directory is not writable. Restart DecoyGuard.'])); }
        $lock=fopen($jobsDir.'/.queue.lock','c+');
        if (!$lock || !flock($lock,LOCK_EX)) { http_response_code(503); exit(json_encode(['error'=>'Deployment queue is unavailable'])); }
        $current=is_file($registryPath) ? json_decode(file_get_contents($registryPath),true) : ['sites'=>[]];
        $reserved=array_fill_keys(array_keys($current['sites'] ?? []),true);
        foreach (array_merge(glob($jobsDir.'/*.json') ?: [],glob($jobsDir.'/*.running') ?: []) as $path) {
            $pending=json_decode(file_get_contents($path),true);
            if (($pending['action'] ?? '') === 'add') $reserved[$pending['site']['site_id'] ?? '']=true;
        }
        if ($action==='add' && (isset($reserved[$site['site_id']]) || count($reserved)>=8)) {
            flock($lock,LOCK_UN);fclose($lock);http_response_code(409);
            exit(json_encode(['error'=>isset($reserved[$site['site_id']])?'Website ID is already registered or queued.':'At most eight website pairs are supported.']));
        }
        if ($action==='retry') {
            $saved=$current['sites'][$site['site_id']] ?? null;
            if (!$saved || ($saved['status'] ?? '') !== 'failed') {
                flock($lock,LOCK_UN);fclose($lock);http_response_code(409);exit(json_encode(['error'=>'Only failed website deployments can be retried.']));
            }
            $site=$saved;
            if (!empty($site['domain']) && !empty($_SESSION['default_password'])) {
                flock($lock,LOCK_UN);fclose($lock);http_response_code(400);exit(json_encode(['error'=>'Change the initial admin password before enabling public access.']));
            }
        }
        if ($action==='remove' && !isset($current['sites'][$site['site_id']])) {
            flock($lock,LOCK_UN);fclose($lock);http_response_code(404);exit(json_encode(['error'=>'Unknown website ID']));
        }
        $jobId=bin2hex(random_bytes(16));
        $job=['job_id'=>$jobId,'action'=>$action,'site'=>$site,'status'=>'queued','created'=>time()];
        $temporary=$jobsDir.'/'.$jobId.'.tmp';
        $written=file_put_contents($temporary,json_encode($job),LOCK_EX);
        if ($written===false || !rename($temporary,$jobsDir.'/'.$jobId.'.json')) {
            @unlink($temporary);flock($lock,LOCK_UN);fclose($lock);http_response_code(503);exit(json_encode(['error'=>'Could not queue deployment']));
        }
        flock($lock,LOCK_UN);fclose($lock);http_response_code(202);exit(json_encode(['job_id'=>$jobId,'status'=>'queued']));
    }
    $jobs=[];
    foreach (array_merge(glob($jobsDir.'/*.json') ?: [],glob($jobsDir.'/*.running') ?: [],glob($jobsDir.'/*.done') ?: []) as $path) {
        $job=json_decode(file_get_contents($path),true);
        if (is_array($job)) $jobs[]=$job;
    }
    usort($jobs,static fn($a,$b)=>($b['created'] ?? 0)<=>($a['created'] ?? 0));
    exit(json_encode(['sites'=>array_values($registry['sites'] ?? []),'jobs'=>array_slice($jobs,0,20),
                     'limit'=>8,'controller_online'=>$online,'csrf'=>$_SESSION['csrf'] ?? ''],JSON_INVALID_UTF8_SUBSTITUTE));
}

// Read the same log files that DecoyGuard writes. Keep paths portable
// across Windows, Docker bind mounts and Linux deployments.
$baseDirs = [
    '/var/log/decoyguard',
    '/app/logs',
    '/workspace/logs',
    '/var/www/decoyguard/logs',
    '/var/www/html/logs',
    '/var/www/html/decoyguard/logs',
    dirname(__DIR__) . '/logs',
    dirname(__DIR__, 2) . '/logs',
    __DIR__ . '/logs',
    __DIR__ . '/../dashboard/logs',
    getcwd() . '/logs'
];
foreach (['DECOYGUARD_LOG_DIR', 'DECOYGUARD_LOGS_DIR'] as $envName) {
    $envPath = getenv($envName);
    if (is_string($envPath) && $envPath !== '') {
        array_unshift($baseDirs, $envPath);
    }
}
$baseDirs = array_unique(array_map(static function ($dir) {
    return rtrim(str_replace('\\', '/', $dir), '/');
}, $baseDirs));

// Decode Windows UTF-16 logs without requiring an optional PHP extension.
function dg_history_utf16(string $bytes,bool $little): ?string {
    if(strlen($bytes)%2)return null;$out='';$length=strlen($bytes);
    for($i=0;$i<$length;$i+=2){$u=$little?(ord($bytes[$i])|(ord($bytes[$i+1])<<8)):((ord($bytes[$i])<<8)|ord($bytes[$i+1]));
        if($u>=0xD800&&$u<=0xDBFF){if($i+3>=$length)return null;$v=$little?(ord($bytes[$i+2])|(ord($bytes[$i+3])<<8)):((ord($bytes[$i+2])<<8)|ord($bytes[$i+3]));if($v<0xDC00||$v>0xDFFF)return null;$u=0x10000+(($u-0xD800)<<10)+$v-0xDC00;$i+=2;}
        elseif($u>=0xDC00&&$u<=0xDFFF)return null;
        $out.=$u<0x80?chr($u):($u<0x800?chr(0xC0|($u>>6)).chr(0x80|($u&63)):($u<0x10000?chr(0xE0|($u>>12)).chr(0x80|(($u>>6)&63)).chr(0x80|($u&63)):chr(0xF0|($u>>18)).chr(0x80|(($u>>12)&63)).chr(0x80|(($u>>6)&63)).chr(0x80|($u&63))));
    }return $out;
}
// Historical chart aggregation is independent of the live activity tail.
if (($_GET['action'] ?? '') === 'attack-trend') {
    session_write_close();
    $period=(string)($_GET['period'] ?? 'retained');
    if (!in_array($period,['retained','30','60','1440'],true)) { http_response_code(400);exit(json_encode(['error'=>'Invalid trend period'])); }
    $now=time();$from=$period==='retained'?0:$now-(int)$period*60;
    $siteFilter=substr((string)($_GET['site'] ?? ''),0,128);$severityFilter=strtoupper(substr((string)($_GET['severity'] ?? ''),0,20));
    $environment=substr((string)($_GET['environment'] ?? ''),0,40);$search=strtolower(substr((string)($_GET['search'] ?? ''),0,256));
    $summary=['total'=>0,'critical'=>0,'high'=>0,'decoy'=>0,'blocked'=>0];$siteDetails=[];$attackTypes=[];$endpoints=[];$endpointOverflow=0;$endpointMissing=0;$fileLatest=null;
    $riskSources=[];$riskMax=null;$minutes=[];$seen=[];$sources=[];$invalid=0;$malformed=0;$future=0;$duplicates=0;$selected=0;$first=null;$last=null;$partial=false;$deadline=microtime(true)+15;
    $consume=function($event) use (&$riskSources,&$riskMax,&$endpoints,&$endpointOverflow,&$endpointMissing,&$fileLatest,&$summary,&$siteDetails,&$attackTypes,&$consume,&$minutes,&$seen,&$invalid,&$future,&$duplicates,&$selected,&$first,&$last,$now,$from,$siteFilter,$severityFilter,$environment,$search) {
        if (!is_array($event))return;
        if(isset($event['event'])&&is_array($event['event']))$event=$event['event'];
        if(array_is_list($event)){foreach($event as$child)$consume($child);return;}
        foreach(['events','alerts','records']as$wrapper)if(isset($event[$wrapper])&&is_array($event[$wrapper])&&array_is_list($event[$wrapper])){foreach($event[$wrapper]as$child)$consume($child);return;}
        $attack=(string)($event['attack']??$event['attack_type']??$event['event_type']??'');$severity=strtoupper((string)($event['severity']??''));$risk=(float)($event['risk_score']??$event['risk']??$event['score']??0);
        if($severity==='SAFE'||preg_match('/normal[ _]traffic|decoy[ _]interaction|^activity$/i',$attack)||($risk<=0&&!in_array($severity,['LOW','MEDIUM','HIGH','VERY HIGH','CRITICAL'],true)))return;
        $site=(string)($event['site_id']??$event['website_id']??$event['site']??'Unassigned');$target=strtolower((string)($event['target_type']??''));
        if($siteFilter!==''&&$site!==$siteFilter)return;if($severityFilter!==''&&$severity!==$severityFilter)return;
        if($environment!==''&&$target!==$environment&&!($environment==='honeypot'&&strtolower((string)($event['channel']??''))==='ssh'))return;
        if($search!==''&&!str_contains(strtolower(implode(' ',[$attack,(string)($event['source_ip']??''),(string)($event['incident_id']??$event['event_id']??''),(string)($event['request']??'')])),$search))return;
        $stamp=$event['timestamp']??$event['DateTime']??$event['@timestamp']??$event['time_iso8601']??$event['time_local']??$event['datetime']??$event['date']??$event['ts']??$event['epoch']??null;
        if($stamp===null||!is_scalar($stamp)){$invalid++;return;}
        $value=trim((string)$stamp);$ms=null;
        if(preg_match('/^\d{10}(?:\.\d+)?$|^\d{13}$/D',$value)){$ms=(float)$value;if($ms>100000000000)$ms/=1000;$ms=(int)$ms;}
        elseif(preg_match('/\d{4}|\d{1,2}\/[A-Za-z]{3}\//',$value)){$parsed=strtotime($value);if($parsed!==false)$ms=$parsed;}
        if($ms===null){$invalid++;return;}if($ms>$now){$future++;return;}if($ms<$from)return;
        $id=(string)($event['incident_id']??$event['event_id']??'');
        $identity=$id!==''?'id:'.$id:'content:'.hash('sha256',json_encode($event,JSON_INVALID_UTF8_SUBSTITUTE));
        if(isset($seen[$identity])){$duplicates++;return;}$seen[$identity]=true;
        $tier=in_array($severity,['HIGH','VERY HIGH','CRITICAL'],true)?'high':($severity==='MEDIUM'?'medium':($severity==='INFO'?'info':($severity==='LOW'?'low':($risk>=150?'high':($risk>=85?'medium':'low')))));
        $minute=(int)(floor($ms/60)*60);$minutes[$minute]??=['high'=>0,'medium'=>0,'low'=>0,'info'=>0,'sites'=>[],'risk_max'=>null];$minutes[$minute]['risk_max']=$minutes[$minute]['risk_max']===null?$risk:max($risk,$minutes[$minute]['risk_max']);$riskMax=$riskMax===null?$risk:max($riskMax,$risk);$sourceIp=(string)($event['source_ip']??$event['remote_addr']??'');if($sourceIp!=='')$riskSources[$sourceIp]=true;$minutes[$minute][$tier]++;$minutes[$minute]['sites'][$site]=($minutes[$minute]['sites'][$site]??0)+1;
        $summary['total']++;if($tier==='high'){if(in_array($severity,['CRITICAL','VERY HIGH'],true))$summary['critical']++;else$summary['high']++;}
        $decision=strtoupper((string)($event['decision']??''));$route=strtoupper((string)($event['route']??''));$isDecoy=in_array($target,['decoy','honeypot','honeypot_sandbox'],true)||in_array($route,['HONEYPOT','DECOY'],true)||in_array($decision,['CONTAINED','REDIRECT','REDIRECT_TO_HONEYPOT','HONEYPOT'],true);
        if($isDecoy)$summary['decoy']++;if(in_array($decision,['BLOCK','BLOCKED','DROP','ISOLATE','ISOLATED'],true))$summary['blocked']++;
        $siteDetails[$site]??=['high'=>0,'decoy'=>0];if($tier==='high')$siteDetails[$site]['high']++;if($isDecoy)$siteDetails[$site]['decoy']++;
        $type=preg_match('/sql.injection/i',$attack)?'SQL Injection':(preg_match('/cross.site.scripting|\bxss\b/i',$attack)?'Cross-Site Scripting':(preg_match('/traversal/i',$attack)?'Directory Traversal':(preg_match('/brute.force|credential.stuff/i',$attack)?'Brute Force':(preg_match('/scanner|nmap|enumeration|recon/i',$attack)?'Reconnaissance':trim(preg_replace('/^\[WEB\]\s*/','',explode(':',$attack)[0]))))));$type=$type!==''?$type:'Unclassified';$attackTypes[$type]=($attackTypes[$type]??0)+1;
        $fileLatest=$fileLatest===null?$ms:max($fileLatest,$ms);
        $rawPath=(string)($event['uri']??$event['request_uri']??$event['path']??'');
        if($rawPath===''&&preg_match('/^[A-Z]+\s+(\S+)/',(string)($event['request']??''),$match))$rawPath=$match[1];
        $endpoint=parse_url($rawPath,PHP_URL_PATH);
        if(is_string($endpoint)&&str_starts_with($endpoint,'/')){
            $endpoint=substr($endpoint,0,512);
            if(!isset($endpoints[$endpoint])&&count($endpoints)>=256)$endpointOverflow++;
            else{
                $endpoints[$endpoint]??=['path'=>$endpoint,'count'=>0,'sites'=>[],'types'=>[],'last_seen'=>0];
                $ep=&$endpoints[$endpoint];$ep['count']++;$ep['sites'][$site]=true;$ep['types'][$type]=true;$ep['last_seen']=max($ep['last_seen'],$ms);unset($ep);
            }
        }else $endpointMissing++;
        $selected++;$first=$first===null?$ms:min($first,$ms);$last=$last===null?$ms:max($last,$ms);
    };
    $files=['alerts.jsonl','events.jsonl','behaviour_events.jsonl','access.json','nginx/access.json','alerts.json','beelzebub/beelzebub.jsonl','beelzebub/beelzebub.json'];
    foreach($files as$file){
        if((microtime(true)>$deadline||memory_get_usage(true)>67108864)){$partial=true;break;}
        $path=null;foreach($baseDirs as$dir)if(is_file($dir.'/'.$file)&&is_readable($dir.'/'.$file)){$path=$dir.'/'.$file;break;}if($path===null)continue;
        $handle=@fopen($path,'rb');if(!$handle){$partial=true;$sources[]=['file'=>$file,'error'=>'Cannot open source'];continue;}
        $size=(int)fstat($handle)['size'];$read=0;$fileMalformed=0;$invalidBefore=$invalid;$futureBefore=$future;$duplicateBefore=$duplicates;$selectedBefore=$selected;$errors=[];$fileLatest=null;
        $prefix=fread($handle,256);rewind($handle);$encoding='UTF-8';$buffer=null;
        if(str_starts_with($prefix,"\xFF\xFE")||str_starts_with($prefix,"\xFE\xFF")){
            $encoding=str_starts_with($prefix,"\xFF\xFE")?'UTF-16LE':'UTF-16BE';
            if($size>16777216){$partial=true;$sources[]=['file'=>$file,'error'=>'UTF-16 source requires conversion to UTF-8 JSONL (16 MiB import limit)'];fclose($handle);continue;}
            $buffer=dg_history_utf16(substr(stream_get_contents($handle),2),$encoding==='UTF-16LE');
            if($buffer===null){$partial=true;$sources[]=['file'=>$file,'error'=>'Invalid UTF-16 encoding'];fclose($handle);continue;}
            fclose($handle);$handle=fopen('php://temp','w+b');fwrite($handle,$buffer);rewind($handle);$size=strlen($buffer);$prefix=substr($buffer,0,256);
        }
        $prefix=preg_replace('/^\xEF\xBB\xBF/','',$prefix);$firstLine=strtok($prefix,"\r\n");$wholeCandidate=str_starts_with(ltrim($prefix),'[')||(str_starts_with(ltrim($prefix),'{')&&json_decode(trim((string)$firstLine),true)===null);
        $wholeRead=false;
        if($wholeCandidate&&$size<=16777216){
            $payload=preg_replace('/^\xEF\xBB\xBF/','',stream_get_contents($handle));$decoded=json_decode($payload,true);
            if(is_array($decoded)){
                if(array_is_list($decoded))foreach($decoded as$entry){if(microtime(true)>$deadline||memory_get_usage(true)>67108864){$partial=true;break;}$consume($entry);$read++;}
                else{$consume($decoded);$read=1;}
                $wholeRead=true;
            }
            unset($payload,$decoded);rewind($handle);
        }elseif($wholeCandidate&&$size>16777216){$partial=true;$errors[]='Oversized multiline JSON; use UTF-8 JSONL';}
        if(!$wholeRead){
            while(ftell($handle)<$size&&($line=fgets($handle))!==false){
                if(microtime(true)>$deadline||memory_get_usage(true)>67108864){$partial=true;break;}$read++;
                $line=preg_replace('/^\xEF\xBB\xBF/','',trim($line));if($line==='')continue;
                $entry=json_decode($line,true);if(is_array($entry))$consume($entry);else{$malformed++;$fileMalformed++;if(count($errors)<3)$errors[]='Line '.$read.': '.json_last_error_msg();}
            }
        }
        fclose($handle);unset($buffer);$sources[]=['file'=>$file,'format'=>$wholeRead?'JSON document':'JSONL','encoding'=>$encoding,'entries_read'=>$read,'latest_selected'=>$fileLatest===null?null:gmdate('c',$fileLatest),'selected'=>$selected-$selectedBefore,'malformed'=>$fileMalformed,'invalid_dates'=>$invalid-$invalidBefore,'future_dates'=>$future-$futureBefore,'duplicates'=>$duplicates-$duplicateBefore,'errors'=>$errors];
    }
    $fitActivity=($_GET['fit']??'')==='1';
    $start=($fitActivity||$period==='retained')?($first===null?$now:(int)(floor($first/60)*60)):(int)(floor($from/60)*60);
    $end=($fitActivity||$period==='retained')?($last??$now):$now;
    $interval=max(60,(int)(ceil(max(1,$end-$start+1)/24/60)*60));$length=$selected?min(25,(int)floor(($end-$start)/$interval)+1):0;
    $buckets=array_fill(0,$length,['high'=>0,'medium'=>0,'low'=>0,'info'=>0,'sites'=>new stdClass(),'risk_max'=>null]);$totals=['total'=>0,'high'=>0,'medium'=>0,'low'=>0,'info'=>0];$sites=[];
    foreach($minutes as$minute=>$values){$index=min($length-1,max(0,(int)floor(($minute-$start)/$interval)));if($index<0)continue;$buckets[$index]['risk_max']=$buckets[$index]['risk_max']===null?$values['risk_max']:max($buckets[$index]['risk_max'],$values['risk_max']);$buckets[$index]['sites']=(array)$buckets[$index]['sites'];foreach(['high','medium','low','info']as$tier){$n=$values[$tier];$buckets[$index][$tier]+=$n;$totals[$tier]+=$n;$totals['total']+=$n;}foreach($values['sites']as$id=>$n){$buckets[$index]['sites'][$id]=($buckets[$index]['sites'][$id]??0)+$n;$sites[$id]??=['id'=>(string)$id,'count'=>0,'values'=>array_fill(0,$length,0)];$sites[$id]['count']+=$n;$sites[$id]['values'][$index]+=$n;}}
    foreach($sites as$id=>&$details){$details['high']=$siteDetails[$id]['high']??0;$details['decoy']=$siteDetails[$id]['decoy']??0;}unset($details);arsort($attackTypes);
    $sites=array_values($sites);usort($sites,static fn($a,$b)=>$b['count']<=>$a['count']);$occupied=count(array_filter($buckets,static fn($b)=>$b['high']+$b['medium']+$b['low']+$b['info']>0));
    foreach($buckets as&$bucket)$bucket['sites']=(object)$bucket['sites'];unset($bucket);
    $note=($partial?'PARTIAL history: scan time, memory budget or legacy-file limit reached. ':'Historical aggregation over available stored files. ').'Each point counts detection records in a '.($interval/60).'-minute interval; not unique attacks. '.($invalid?$invalid.' unusable date(s) omitted. ':'').($malformed?$malformed.' malformed line(s) omitted. ':'').($future?$future.' future-dated record(s) omitted. ':'').'Duplicate IDs are counted once. Zero bins mean no matching stored detections, not verified collection coverage.';
    $endpointRows=array_values($endpoints);usort($endpointRows,static fn($a,$b)=>$b['count']<=>$a['count']?:strcmp($a['path'],$b['path']));
    foreach($endpointRows as &$ep){$ep['sites']=array_keys($ep['sites']);$ep['types']=array_keys($ep['types']);$ep['last_seen']=gmdate('c',$ep['last_seen']);}unset($ep);
    exit(json_encode(['risk_summary'=>['max_score'=>$riskMax,'recorded_source_addresses'=>count($riskSources)],'endpoints'=>$endpointRows,'endpoint_overflow_records'=>$endpointOverflow,'endpoint_missing_records'=>$endpointMissing,'summary'=>$summary,'attack_types'=>$attackTypes,'buckets'=>$buckets,'totals'=>$totals,'interval'=>$interval*1000,'start'=>$start*1000,'end'=>$end*1000,'sites'=>$sites,'smooth'=>$length>=6&&$occupied===$length,'note'=>$note,'partial'=>$partial,'sources'=>$sources,'duplicates'=>$duplicates,'invalid_dates'=>$invalid,'malformed'=>$malformed,'future_dates'=>$future,'generated_at'=>gmdate('c')],JSON_INVALID_UTF8_SUBSTITUTE));
}

// Report submissions carry reviewer metadata in POST, protected by the dashboard session.
if (($_SERVER['REQUEST_METHOD']??'GET')==='POST' && ($_POST['action']??'')==='report') {
    if (!is_string($_POST['csrf']??null) || !hash_equals($_SESSION['csrf']??'',$_POST['csrf'])) {
        http_response_code(403);exit(json_encode(['error'=>'Invalid report session token. Reload the dashboard.']));
    }
    $_GET=$_POST;
}
// Reports read retained log files directly, independently of the dashboard's 500-line tail.
if (($_GET['action'] ?? '') === 'report') {
    function dg_report_canonical($value) {
        if (!is_array($value)) return $value;
        if (!array_is_list($value)) ksort($value,SORT_STRING);
        foreach($value as $key=>$item)$value[$key]=dg_report_canonical($item);
        return $value;
    }
    function dg_report_json($value): string {
        return json_encode(dg_report_canonical($value),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE|JSON_PRESERVE_ZERO_FRACTION|JSON_INVALID_UTF8_SUBSTITUTE);
    }
    function dg_report_private(string $ip): bool {
        if(!filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4))return false;
        $parts=array_map('intval',explode('.',$ip));
        return $parts[0]===10 || ($parts[0]===172&&$parts[1]>=16&&$parts[1]<=31) || ($parts[0]===192&&$parts[1]===168);
    }
    function dg_report_attack_context(string $type,array $source): array {
        $candidates=[];
        if($type==='ENDPOINT_ENUMERATION')$candidates[]=['id'=>'T1595','label'=>'Active Scanning','basis'=>'Candidate interpretation of repeated endpoint probing; exact sub-technique not established.'];
        if($type==='REQUEST_BURST')$candidates[]=['id'=>'T1499','label'=>'Endpoint Denial of Service','basis'=>'Review candidate only: request rate alone does not establish resource exhaustion, disruption or intent.'];
        if($type==='REPEATED_HTTP_ERRORS')$candidates[]=['id'=>'T1595','label'=>'Active Scanning','basis'=>'Review candidate only: errors may also result from a broken application or unavailable upstream.'];
        if($type==='REPEATED_POST_ACTIVITY')$candidates[]=['id'=>'T1110','label'=>'Brute Force','basis'=>'Review candidate only: requires authentication and credential-attempt evidence; repeated POSTs alone are insufficient.'];
        return $candidates;
    }
    function dg_report_csv(array $report): string {
        $out=fopen('php://temp','w+');
        fputcsv($out,['Report ID','Timezone','Period start','Period end','Incident / event ID','Time','Engine','Website','Source IP / host','Finding','Basis','Severity','Risk','Request','Status','Syslog level','Actual target','Decision','MITRE source tags','ATT&CK review candidates','Evidence','Source files'],',','"','');
        foreach($report['records'] as $r){
            $row=[$report['report_id'],$report['timezone'],$report['from'],$report['to'],$r['id'],$r['local_time'],$r['engine'],$r['site_id'],$r['source_ip'],$r['event_type'],$r['basis'],$r['severity'],$r['risk_score'],$r['request'],$r['status'],$r['log_level'],$r['target_type'],$r['decision'],implode('; ',$r['mitre_tags']),implode('; ',array_column($r['mitre_candidates'],'id')),$r['evidence'],implode('; ',$r['files'])];
            $row=array_map(static fn($v)=>preg_match('/^[\s]*[=+\-@]/',(string)$v)?"'".$v:$v,$row);fputcsv($out,$row,',','"','');
        }
        rewind($out);$data=stream_get_contents($out);fclose($out);return $data;
    }
    // Small standards-based stored ZIP writer: no additional PHP extension or project file.
    function dg_report_zip(array $files): string {
        $body='';$central='';$offset=0;
        foreach($files as $name=>$bytes){$crc=crc32($bytes);$size=strlen($bytes);$len=strlen($name);
            $entry=pack('VvvvvvVVVvv',0x04034b50,20,0,0,0,33,$crc,$size,$size,$len,0).$name.$bytes;
            $central.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,0,0,33,$crc,$size,$size,$len,0,0,0,0,0,$offset).$name;
            $body.=$entry;$offset+=strlen($entry);
        }
        return $body.$central.pack('VvvvvVVv',0x06054b50,0,0,count($files),count($files),strlen($central),strlen($body),0);
    }
    function dg_report_text($value): string {
        $text=is_scalar($value) ? (string)$value : json_encode($value,JSON_INVALID_UTF8_SUBSTITUTE);
        $text=preg_replace('/\b(password|passwd|pwd|token|secret|api[_-]?key|authorization|cookie)\s*[=:]\s*(?:"[^"]*"|\x27[^\x27]*\x27|[^\s&;,]+)/i','$1=[REDACTED]',$text ?? '');
        $text=preg_replace('/\b(password|passwd|pwd|token|secret|api[_-]?key|authorization|cookie)["\x27]\s*:\s*(?:"[^"]*"|\x27[^\x27]*\x27|[^\s&;,}]+)/i','$1=[REDACTED]',$text ?? '');
        return substr($text ?? '',0,2000);
    }
    function dg_report_time(array $event, DateTimeZone $zone): ?array {
        $stamp=null;foreach(['timestamp','DateTime','@timestamp','time_iso8601','time_local','datetime','date','ts','time'] as $key)if(isset($event[$key])&&is_scalar($event[$key])&&(string)$event[$key]!==''){$stamp=$event[$key];break;}
        if($stamp===null)return null;$value=trim((string)$stamp);$inferred=false;
        try {
            if(preg_match('/^\d{10}(?:\.\d+)?$|^\d{13}$/D',$value)){$epoch=(float)$value;if($epoch>100000000000)$epoch/=1000;$time=(new DateTimeImmutable('@'.(int)floor($epoch)))->setTimezone(new DateTimeZone('UTC'));}
            elseif(preg_match('/^\d{1,2}\/[A-Z][a-z]{2}\/\d{4}:\d{2}:\d{2}:\d{2}(?: [+-]\d{4})?$/D',$value)){$time=DateTimeImmutable::createFromFormat('!d/M/Y:H:i:s O',$value,$zone);if(!$time)$time=DateTimeImmutable::createFromFormat('!d/M/Y:H:i:s',$value,$zone);if(!$time)return null;}
            elseif(preg_match('/^[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2}$/D',$value)){$now=new DateTimeImmutable('now',$zone);$time=new DateTimeImmutable($value.' '.$now->format('Y'),$zone);if($time>$now->modify('+1 day'))$time=$time->modify('-1 year');$inferred=true;}
            elseif(preg_match('/^\d{4}[-\/]\d{2}[-\/]\d{2}[T ]\d{2}:\d{2}:\d{2}/',$value)){$time=new DateTimeImmutable($value,$zone);}
            else return null;
            $errors=DateTimeImmutable::getLastErrors();if(is_array($errors)&&($errors['warning_count']||$errors['error_count']))return null;
            return ['time'=>$time,'raw'=>$value,'inferred'=>$inferred];
        }catch(Exception $e){return null;}
    }

    function dg_report_record(array $event,string $file,DateTimeZone $zone): ?array {
        $parsed=dg_report_time($event,$zone);if(!$parsed)return null;$time=$parsed['time'];
        $id=substr(dg_report_text($event['incident_id'] ?? $event['event_id'] ?? ''),0,256);
        $engine=dg_report_text($event['engine'] ?? (($event['source'] ?? '')==='gateway-decision'?'Gateway capture':(str_starts_with($file,'syslog')?'Syslog input':'Log capture')));
        $type=strtoupper(str_replace(' ','_',dg_report_text($event['event_type'] ?? $event['attack_type'] ?? 'ACTIVITY')));
        $behaviourSource=($event['source'] ?? '')==='behaviour-monitor' || str_starts_with($id,'BE-') || stripos($engine,'Behaviour Engine')!==false;
        $signature=in_array($type,['RECON_SCANNER','SCANNER_PROBE','SQL_INJECTION','XSS_ATTACK','SHELL_INJECTION','DIRECTORY_TRAVERSAL'],true);
        $pattern=in_array($type,['REQUEST_BURST','REPEATED_POST_ACTIVITY','ENDPOINT_ENUMERATION','REPEATED_HTTP_ERRORS','ENDPOINT_HOPPING','USER_AGENT_HOPPING','BEHAVIOURAL_ESCALATION'],true);
        $basis=$behaviourSource ? ($signature?'signature':($pattern?'behavioural-pattern':'unclassified-detector')) : (!empty($event['security_finding'])?'application-check':((int)($event['risk_score'] ?? 0)>0?'signature-or-correlation':'activity'));
        $details=$event['details'] ?? $event['reasons'] ?? $event['message'] ?? $event['detection_text'] ?? '';
        if (is_array($details)) $details=implode('; ',array_map('dg_report_text',$details));
        $request=dg_report_text($event['request'] ?? '');
        $isRequest=($file==='access.json' || in_array($event['source'] ?? '',['gateway-decision','decoy-web'],true)) && $request!=='';
        $isDetection=$behaviourSource || (int)($event['risk_score'] ?? 0)>0 || !empty($event['security_finding']) || !empty($event['canary_hit']);
        return ['id'=>$id!==''?$id:hash('sha256',dg_report_json($event)),
            'timestamp'=>$time->setTimezone(new DateTimeZone('UTC'))->format('c'),'local_time'=>$time->setTimezone($zone)->format('Y-m-d H:i:s'),
            'epoch'=>$time->getTimestamp(),'engine'=>dg_report_text($engine),'site_id'=>dg_report_text($event['site_id'] ?? $event['website_id'] ?? $event['site'] ?? $event['website'] ?? ''),
            'source_ip'=>dg_report_text($event['source_ip'] ?? $event['remote_addr'] ?? $event['hostname'] ?? ''),
            'event_type'=>dg_report_text($type),'basis'=>$basis,'severity'=>dg_report_text($event['severity'] ?? ($isDetection?'UNKNOWN':'INFO')),
            'risk_score'=>(int)($event['risk_score'] ?? 0),'request'=>dg_report_text($request),
            'status'=>(int)($event['status'] ?? 0),'log_level'=>dg_report_text($event['log_level'] ?? $event['level'] ?? ''),'target_type'=>dg_report_text($event['target_type'] ?? ''),
            'decision'=>dg_report_text($event['decision'] ?? ''),'route'=>dg_report_text($event['route'] ?? ''),
            'evidence'=>dg_report_text($details),'is_request'=>$isRequest,'is_detection'=>$isDetection,'files'=>[$file],
            'source_event_id'=>dg_report_text($event['source_event_id']??$event['event_id']??''),
            'private_client_address'=>dg_report_private(dg_report_text($event['source_ip']??$event['remote_addr']??'')),
            'mitre_candidates'=>dg_report_attack_context($type,$event),
            'peer_ip'=>dg_report_text($event['peer_ip']??''),'client_ip_origin'=>dg_report_text($event['client_ip_origin']??'unspecified'),
            'source_timestamp'=>$parsed['raw'],'inferred_year'=>!empty($event['_inferred_year'])||$parsed['inferred'],'mitre_tags'=>is_array($event['mitre_tags']??$event['forensics']['mitre_tags']??null)?array_values(array_map('dg_report_text',$event['mitre_tags']??$event['forensics']['mitre_tags'])):[]];
    }
    function dg_report_syslog(string $line,DateTimeZone $zone): ?array {
        $level='';if (preg_match('/^<(\d{1,3})>/', $line,$priority) && (int)$priority[1]<=191) $level=['EMERGENCY','ALERT','CRITICAL','ERROR','WARNING','NOTICE','INFO','DEBUG'][(int)$priority[1]%8];
        if (preg_match('/^(?:<\d{1,3}>)?(?:\d+\s+)?(\d{4}-\d{2}-\d{2}T\S+)\s+(.*)$/',$line,$m))
            return ['timestamp'=>$m[1],'hostname'=>explode(' ',$m[2],2)[0],'message'=>$m[2],'source'=>'syslog','log_level'=>$level];
        if (preg_match('/^(?:<\d{1,3}>)?([A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+(.*)$/',$line,$m)) {
            try {
                $now=new DateTimeImmutable('now',$zone);
                $time=new DateTimeImmutable($m[1].' '.$now->format('Y'),$zone);
                if ($time>$now->modify('+1 day')) $time=$time->modify('-1 year');
                return ['timestamp'=>$time->format('c'),'hostname'=>$m[2],'message'=>$m[3],'source'=>'syslog','log_level'=>$level,'_inferred_year'=>true];
            } catch (Exception $e) { return null; }
        }
        return null;
    }
    try {
        foreach (['scope','format','timezone','from','to','site','team','period','reviewer','review_role','review_date','review_conclusion','ticket_id','sign_off_status'] as $key) if (isset($_GET[$key]) && !is_string($_GET[$key])) throw new InvalidArgumentException('Invalid report parameter');
        $allRetained=($_GET['period'] ?? '')==='retained';if(isset($_GET['period'])&&$_GET['period']!=='retained')throw new InvalidArgumentException('Invalid period mode');
        $scope=$_GET['scope'] ?? 'security';$format=$_GET['format'] ?? 'html';
        if (!in_array($scope,['security','behaviour','activity'],true) || !in_array($format,['html','pdf','csv','json','txt','bundle'],true)) throw new InvalidArgumentException('Invalid report type or format');
        $zoneName=$_GET['timezone'] ?? $dgDeviceZone;
        if (strlen($zoneName)>80) throw new InvalidArgumentException('Invalid timezone');
        $zone=new DateTimeZone($zoneName);$now=new DateTimeImmutable('now',$zone);
        $fromText=$_GET['from'] ?? '';$toText=$_GET['to'] ?? '';
        foreach ([$fromText,$toText] as $value) if ($value!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/D',$value)) throw new InvalidArgumentException('Use valid date/time values');
        foreach ([$fromText,$toText] as $value) if ($value!=='' && (new DateTimeImmutable($value,$zone))->format(strlen($value)===16?'Y-m-d\TH:i':'Y-m-d\TH:i:s')!==$value) throw new InvalidArgumentException('Invalid calendar date');
        $from=$fromText!==''?new DateTimeImmutable($fromText,$zone):$now->modify('-24 hours');
        $to=$toText!==''?new DateTimeImmutable($toText,$zone):$now;
        if ($from>$to || $to->getTimestamp()-$from->getTimestamp()>366*86400) throw new InvalidArgumentException('Select an ordered range of at most 366 days');
        $site=$_GET['site'] ?? '';if ($site!=='' && !preg_match('/^[a-z][a-z0-9-]{0,30}$/D',$site)) throw new InvalidArgumentException('Invalid website ID');
        $review=[];foreach(['reviewer'=>120,'review_role'=>120,'review_conclusion'=>1200,'ticket_id'=>120]as$key=>$max){$value=trim($_GET[$key]??'');if(strlen($value)>$max||preg_match('/[\x00-\x1f]/',$value))throw new InvalidArgumentException('Invalid review metadata');$review[$key]=dg_report_text($value);}
        $review['document_generated_at']=$now->format('c');
        $review['authenticated_analyst_id']=$_SESSION['analyst_id']??'Not available in this session';
        $review['sign_off_status']=$_GET['sign_off_status']??'draft';
        if(!in_array($review['sign_off_status'],['draft','reviewed'],true))throw new InvalidArgumentException('Invalid review state');
        $review['signature_status']='Not digitally signed';
        $review['status']=$review['reviewer']!==''?'User-supplied review statement; not a digital signature':'Pending review';
        $team=trim($_GET['team'] ?? 'Security Operations');if (strlen($team)>120 || preg_match('/[\x00-\x1f]/',$team)) throw new InvalidArgumentException('Invalid team name');
    } catch (Exception $error) { http_response_code(400);exit(json_encode(['error'=>$error->getMessage()])); }
    $files=['alerts.jsonl','behaviour_events.jsonl','access.json','events.jsonl','syslog.jsonl','syslog.log'];
    $records=[];$coverage=[];$scanned=0;$bytes=0;$invalid=0;$undated=0;$limited=false;
    $selection=['normalized'=>0,'excluded_period'=>0,'excluded_site'=>0,'excluded_scope'=>0,'duplicates_merged'=>0];$sourceFirst=null;$sourceLast=null;
    foreach ($files as $file) {
        $path=null;foreach ($baseDirs as $dir) if (is_file($dir.'/'.$file) && is_readable($dir.'/'.$file)) { $path=$dir.'/'.$file;break; }
        if ($path===null) continue;
        $stream=@fopen($path,'rb');if (!$stream) continue;
        $source=['file'=>$file,'lines'=>0,'invalid'=>0,'bytes'=>0,'limited'=>false];
        while (($line=fgets($stream,65537))!==false) {
            $size=strlen($line);$bytes+=$size;$source['bytes']+=$size;$source['lines']++;$scanned++;
            if ($bytes>67108864 || $scanned>200000) { $limited=true;$source['limited']=true;break; }
            if ($size>=65536 && !str_ends_with($line,"\n")) {
                do { $rest=fgets($stream,65537);if ($rest!==false) {$bytes+=strlen($rest);$source['bytes']+=strlen($rest);} } while ($rest!==false && !str_ends_with($rest,"\n") && $bytes<=67108864);
                $invalid++;$source['invalid']++;continue;
            }
            $event=$file==='syslog.log'?dg_report_syslog(trim($line),$zone):json_decode(trim($line),true,512,JSON_INVALID_UTF8_SUBSTITUTE);
            if (!is_array($event)) {$invalid++;$source['invalid']++;continue;}
            $record=dg_report_record($event,$file,$zone);
            if ($record===null) {$undated++;continue;}
            $selection['normalized']++;
            if($site!==''&&$record['site_id']!==$site){$selection['excluded_site']++;continue;}
            $sourceFirst=$sourceFirst===null?$record['epoch']:min($sourceFirst,$record['epoch']);$sourceLast=$sourceLast===null?$record['epoch']:max($sourceLast,$record['epoch']);
            if ((!$allRetained && ($record['epoch']<$from->getTimestamp() || $record['epoch']>$to->getTimestamp())) || ($site!=='' && $record['site_id']!==$site)) {$selection['excluded_period']++;continue;}
            if (($scope==='behaviour'&&$record['basis']!=='behavioural-pattern')||($scope==='security'&&(!$record['is_detection']||strtoupper($record['severity'])==='SAFE'||in_array($record['event_type'],['NORMAL_TRAFFIC','NORMAL','SAFE'],true)))){$selection['excluded_scope']++;continue;}
            $id=$record['id'];
            if (isset($records[$id])) {
                $selection['duplicates_merged']++;
                $old=$records[$id];$record['is_request']=$old['is_request']||$record['is_request'];$record['is_detection']=$old['is_detection']||$record['is_detection'];
                $record['files']=array_values(array_unique(array_merge($old['files'],$record['files'])));
                if ($old['risk_score']>$record['risk_score']) {$record['risk_score']=$old['risk_score'];$record['severity']=$old['severity'];}
                if ($record['evidence']==='') $record['evidence']=$old['evidence'];
                if ($record['engine']==='Log capture' || $record['engine']==='Gateway capture') $record['engine']=$old['engine'];
            } elseif (count($records)>=5000) {$limited=true;$source['limited']=true;break;}
            $records[$id]=$record;
        }
        fclose($stream);$coverage[]=$source;if ($limited) break;
    }
    $records=array_values($records);usort($records,static fn($a,$b)=>($b['epoch']<=>$a['epoch'])?:strcmp($a['id'],$b['id']));
    foreach($records as &$r){sort($r['files'],SORT_STRING);sort($r['mitre_tags'],SORT_STRING);}unset($r);$records=dg_report_canonical($records);
    $summary=['records'=>count($records),'requests'=>0,'detections'=>0,'behavioural_findings'=>0,'signature_findings'=>0,'syslog_records'=>0,'by_type'=>[],'by_site'=>[],'by_severity'=>[],'by_target'=>[],'by_decision'=>[]];
    $inferred=false;
    foreach ($records as $r) {
        $summary['requests']+=(int)$r['is_request'];$summary['detections']+=(int)$r['is_detection'];
        $summary['behavioural_findings']+=(int)($r['basis']==='behavioural-pattern');$summary['signature_findings']+=(int)in_array($r['basis'],['signature','signature-or-correlation'],true);
        $summary['syslog_records']+=(int)(bool)array_intersect($r['files'],['syslog.log','syslog.jsonl']);$inferred=$inferred||$r['inferred_year'];
        foreach (['by_type'=>'event_type','by_site'=>'site_id','by_severity'=>'severity','by_target'=>'target_type','by_decision'=>'decision'] as $bucket=>$field) {$value=$r[$field]?:'unspecified';$summary[$bucket][$value]=($summary[$bucket][$value]??0)+1;}
    }
    foreach (['by_type','by_site','by_severity','by_target','by_decision'] as $key) arsort($summary[$key]);
    $warnings=[];if ($limited) $warnings[]='Read limits reached: this report is incomplete. Limits are 64 MiB, 200,000 scanned lines and 5,000 selected records.';
    if ($invalid) $warnings[]=$invalid.' malformed or oversized lines were skipped.';
    if ($undated) $warnings[]=$undated.' records without a usable timestamp were skipped.';
    if ($inferred) $warnings[]='Legacy syslog timestamps omit the year/timezone; the nearest plausible year and selected timezone were used.';
    $future=count(array_filter($records,static fn($r)=>$r['epoch']>$now->getTimestamp()+300));if($future)$warnings[]=$future.' records are dated more than five minutes after generation time; source clocks require review.';
    if($allRetained&&$records){$from=(new DateTimeImmutable('@'.min(array_column($records,'epoch'))))->setTimezone($zone);$to=(new DateTimeImmutable('@'.max(array_column($records,'epoch'))))->setTimezone($zone);}
    if($allRetained&&!$records&&$sourceFirst!==null){$from=(new DateTimeImmutable('@'.$sourceFirst))->setTimezone($zone);$to=(new DateTimeImmutable('@'.$sourceLast))->setTimezone($zone);}
    if(!$records&&$selection['normalized']>0)$warnings[]='Records parsed successfully, but none matched the selected scope. Behavioural-pattern scope excludes SQL injection and XSS signature findings. Use Security Evidence or Log Activity for the broader evidence.';
    $selection['invalid_lines']=$invalid;$selection['unusable_dates']=$undated;$selection['selected_records']=count($records);
    $digest=hash('sha256',dg_report_json($records));
    $related=[];foreach($records as$event){$requestId=$event['source_event_id']?: (str_starts_with($event['id'],'DG-WEB-')?$event['id']:'');if($requestId==='')continue;
        $key=$event['site_id'].'|'.$event['source_ip'].'|'.$requestId;
        if(!isset($related[$key]))$related[$key]=['request_id'=>$requestId,'site_id'=>$event['site_id'],'source_ip'=>$event['source_ip'],'records'=>[],'engines'=>[]];
        $related[$key]['records'][]=$event['id'];$related[$key]['engines'][]=$event['engine'];
    }$related=array_values(array_filter($related,static fn($g)=>count(array_unique($g['records']))>1));
    $collector=['state'=>'no-health-file','note'=>'No collector heartbeat found in report log directories. This is not proof that no receiver exists.'];
    foreach($baseDirs as$dir){$healthPath=$dir.'/syslog-health.json';if(!is_file($healthPath)||!is_readable($healthPath))continue;
        $healthText=file_get_contents($healthPath,false,null,0,8193);$health=is_string($healthText)&&strlen($healthText)<=8192?json_decode($healthText,true):null;
        if(is_array($health)){$collector=$health;$heartbeat=strtotime((string)($health['updated_at']??''));$collector['heartbeat_age_seconds']=$heartbeat===false?null:max(0,time()-$heartbeat);$collector['fresh_heartbeat']=$heartbeat!==false&&abs(time()-$heartbeat)<=30;}
        else $collector=['state'=>'unreadable-health-data'];break;
    }
    $report=['evidence_digest'=>$digest,'period_mode'=>$allRetained?'retained':'range','assurance_status'=>'Internal evidence report; no independent audit opinion', 'report_id'=>'DG-RPT-'.substr(hash('sha256',json_encode([$scope,$from->format('c'),$to->format('c'),$site,$records],JSON_INVALID_UTF8_SUBSTITUTE)),0,16),
        'selection'=>$selection,'source_period'=>['from'=>$sourceFirst===null?null:(new DateTimeImmutable('@'.$sourceFirst))->setTimezone($zone)->format('c'),'to'=>$sourceLast===null?null:(new DateTimeImmutable('@'.$sourceLast))->setTimezone($zone)->format('c')],
        'title'=>$scope==='behaviour'?'Behavioural Pattern Evidence':($scope==='security'?'Security Evidence Report':'Log Activity Report'),'team'=>$team?:'Security Operations',
        'generated_at'=>$now->format('c'),'timezone'=>$zoneName,'from'=>$allRetained&&$sourceFirst===null?null:$from->format('c'),'to'=>$allRetained&&$sourceLast===null?null:$to->format('c'),'site'=>$site?:'All websites',
        'summary'=>$summary,'coverage'=>$coverage,'warnings'=>$warnings,'records'=>$records,
        'management_review'=>$review,'collector_health'=>$collector,'related_request_evidence'=>$related,
        'scope_note'=>'Based on retained files available at generation time. Detection records are not unique attacks. Syslog-file support does not establish that a network syslog receiver is installed.'];
    $report['digest_spec']=['algorithm'=>'SHA-256','canonicalization'=>'DG-JSON-v1: recursively sort object keys lexicographically; preserve list order; records sorted by descending epoch then ID; source file and tag sets sorted; UTF-8 unescaped Unicode/slashes; preserve zero fractions; no whitespace. Not RFC 8785.','subject'=>'Normalized selected records only'];
    $report['source_coverage']=array_map(static fn($c)=>['file'=>(string)$c['file'],'lines_scanned'=>(int)$c['lines'],'read_limited'=>(bool)$c['limited'],'invalid_lines'=>(int)$c['invalid']],$coverage);
    $privateRecords=count(array_filter($records,static fn($r)=>$r['private_client_address']));
    $report['attribution']=['private_address_records'=>$privateRecords,'note'=>'Private addresses may represent LAN clients, proxies or Docker bridges. Verify the trusted proxy chain; do not trust arbitrary forwarded headers.'];
    $recommendations=[];if($summary['detections'])$recommendations[]=['action'=>'Validate significant findings against original source records','suggested_role'=>'SOC analyst','reason'=>'Recorded detections require analyst evaluation.'];
    if(!$summary['behavioural_findings'])$recommendations[]=['action'=>'Review behavioural scope and detector telemetry','suggested_role'=>'Detection engineering','reason'=>'No behavioural-pattern findings selected; this is not proof of a detector outage.'];
    if($privateRecords)$recommendations[]=['action'=>'Verify original client attribution at the trusted ingress','suggested_role'=>'Infrastructure engineering','reason'=>'Private source addresses are present in selected evidence.'];
    if($warnings)$recommendations[]=['action'=>'Review ingestion limits, parsing warnings and source clocks','suggested_role'=>'Log platform engineering','reason'=>'Report diagnostics raised warnings.'];
    if(isset($summary['by_decision']['CONTAINED'])||isset($summary['by_decision']['REDIRECT']))$recommendations[]=['action'=>'Verify recorded containment against gateway destination evidence','suggested_role'=>'SOC lead','reason'=>'A recorded decision alone is not proof of successful routing.'];
    $report['recommendations']=$recommendations;
    $filename='decoyguard-'.$scope.'-'.$now->format('Ymd-His');
    if ($format==='txt') {
        header('Content-Type: text/plain; charset=us-ascii');
        header('Content-Disposition: attachment; filename="'.$filename.'.txt"');
        // JSON escapes preserve every non-ASCII code point without silently losing evidence.
        echo "DECOYGUARD - ".strtoupper($report['title'])."\r\n";
        echo str_repeat('=',72)."\r\n";
        echo "Internal monitoring evidence; not an independent audit opinion.\r\n";
        echo "ASCII encoding: non-ASCII characters use JSON Unicode escapes.\r\n";
        echo "The evidence digest covers the normalized records, not this text file.\r\n\r\n";
        $ascii = static fn($value)=>substr(json_encode((string)$value, JSON_INVALID_UTF8_SUBSTITUTE),1,-1);
        foreach(['report_id','generated_at','site','from','to','timezone'] as $key)
            echo strtoupper(str_replace('_',' ',$key)).': '.$ascii($report[$key]??'Not available')."\r\n";
        echo "\r\nSUMMARY\r\n".str_repeat('-',72)."\r\n";
        foreach(['records','detections','behavioural_findings','signature_findings','syslog_records'] as $key)
            echo str_pad(strtoupper(str_replace('_',' ',$key)),30).(string)($summary[$key]??0)."\r\n";
        echo "\r\nFINDINGS\r\n".str_repeat('-',72)."\r\n";
        if(!$records) echo "No evidence matched this selection. Check source coverage and filters.\r\n";
        foreach($records as $i=>$record){
            echo ($i+1).'. '.$ascii($record['id']).' | '.$ascii($record['event_type']).' | '.$ascii($record['severity'])."\r\n";
            foreach(['timestamp','site_id','source_ip','basis','request','status','evidence'] as $key)
                echo '  '.str_pad(strtoupper($key),14).': '.$ascii($record[$key]??'')."\r\n";
            echo "\r\n";
        }
        echo "COMPLETE REPORT METADATA AND NORMALIZED EVIDENCE (JSON)\r\n".str_repeat('=',72)."\r\n";
        echo str_replace("\n", "\r\n", json_encode($report, JSON_PRETTY_PRINT | JSON_INVALID_UTF8_SUBSTITUTE));
        echo "\r\n"; exit;
    }
    if ($format==='json') { header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="'.$filename.'.json"');echo json_encode($report,JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE);exit; }
    if ($format==='csv') {
        $csv=dg_report_csv($report);header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="'.$filename.'.csv"');header('X-Content-SHA256: '.hash('sha256',$csv));echo $csv;exit;
    }
    define('DG_REPORT_FONT_REGULAR', [32=>278,33=>278,34=>355,35=>556,36=>556,37=>889,38=>667,39=>191,40=>333,41=>333,42=>389,43=>584,44=>278,45=>333,46=>278,47=>278,48=>556,49=>556,50=>556,51=>556,52=>556,53=>556,54=>556,55=>556,56=>556,57=>556,58=>278,59=>278,60=>584,61=>584,62=>584,63=>556,64=>1015,65=>667,66=>667,67=>722,68=>722,69=>667,70=>611,71=>778,72=>722,73=>278,74=>500,75=>667,76=>556,77=>833,78=>722,79=>778,80=>667,81=>778,82=>722,83=>667,84=>611,85=>722,86=>667,87=>944,88=>667,89=>667,90=>611,91=>278,92=>278,93=>278,94=>469,95=>556,96=>333,97=>556,98=>556,99=>500,100=>556,101=>556,102=>278,103=>556,104=>556,105=>222,106=>222,107=>500,108=>222,109=>833,110=>556,111=>556,112=>556,113=>556,114=>333,115=>500,116=>278,117=>556,118=>500,119=>722,120=>500,121=>500,122=>500,123=>334,124=>260,125=>334,126=>584,127=>350,128=>556,129=>350,130=>222,131=>556,132=>333,133=>1000,134=>556,135=>556,136=>333,137=>1000,138=>667,139=>333,140=>1000,141=>350,142=>611,143=>350,144=>350,145=>222,146=>222,147=>333,148=>333,149=>350,150=>556,151=>1000,152=>333,153=>1000,154=>500,155=>333,156=>944,157=>350,158=>500,159=>667,160=>278,161=>333,162=>556,163=>556,164=>556,165=>556,166=>260,167=>556,168=>333,169=>737,170=>370,171=>556,172=>584,173=>333,174=>737,175=>333,176=>400,177=>584,178=>333,179=>333,180=>333,181=>556,182=>537,183=>278,184=>333,185=>333,186=>365,187=>556,188=>834,189=>834,190=>834,191=>611,192=>667,193=>667,194=>667,195=>667,196=>667,197=>667,198=>1000,199=>722,200=>667,201=>667,202=>667,203=>667,204=>278,205=>278,206=>278,207=>278,208=>722,209=>722,210=>778,211=>778,212=>778,213=>778,214=>778,215=>584,216=>778,217=>722,218=>722,219=>722,220=>722,221=>667,222=>667,223=>611,224=>556,225=>556,226=>556,227=>556,228=>556,229=>556,230=>889,231=>500,232=>556,233=>556,234=>556,235=>556,236=>278,237=>278,238=>278,239=>278,240=>556,241=>556,242=>556,243=>556,244=>556,245=>556,246=>556,247=>584,248=>611,249=>556,250=>556,251=>556,252=>556,253=>500,254=>556,255=>500]);
    define('DG_REPORT_FONT_BOLD', [32=>278,33=>333,34=>474,35=>556,36=>556,37=>889,38=>722,39=>238,40=>333,41=>333,42=>389,43=>584,44=>278,45=>333,46=>278,47=>278,48=>556,49=>556,50=>556,51=>556,52=>556,53=>556,54=>556,55=>556,56=>556,57=>556,58=>333,59=>333,60=>584,61=>584,62=>584,63=>611,64=>975,65=>722,66=>722,67=>722,68=>722,69=>667,70=>611,71=>778,72=>722,73=>278,74=>556,75=>722,76=>611,77=>833,78=>722,79=>778,80=>667,81=>778,82=>722,83=>667,84=>611,85=>722,86=>667,87=>944,88=>667,89=>667,90=>611,91=>333,92=>278,93=>333,94=>584,95=>556,96=>333,97=>556,98=>611,99=>556,100=>611,101=>556,102=>333,103=>611,104=>611,105=>278,106=>278,107=>556,108=>278,109=>889,110=>611,111=>611,112=>611,113=>611,114=>389,115=>556,116=>333,117=>611,118=>556,119=>778,120=>556,121=>556,122=>500,123=>389,124=>280,125=>389,126=>584,127=>350,128=>556,129=>350,130=>278,131=>556,132=>500,133=>1000,134=>556,135=>556,136=>333,137=>1000,138=>667,139=>333,140=>1000,141=>350,142=>611,143=>350,144=>350,145=>278,146=>278,147=>500,148=>500,149=>350,150=>556,151=>1000,152=>333,153=>1000,154=>556,155=>333,156=>944,157=>350,158=>500,159=>667,160=>278,161=>333,162=>556,163=>556,164=>556,165=>556,166=>280,167=>556,168=>333,169=>737,170=>370,171=>556,172=>584,173=>333,174=>737,175=>333,176=>400,177=>584,178=>333,179=>333,180=>333,181=>611,182=>556,183=>278,184=>333,185=>333,186=>365,187=>556,188=>834,189=>834,190=>834,191=>611,192=>722,193=>722,194=>722,195=>722,196=>722,197=>722,198=>1000,199=>722,200=>667,201=>667,202=>667,203=>667,204=>278,205=>278,206=>278,207=>278,208=>722,209=>722,210=>778,211=>778,212=>778,213=>778,214=>778,215=>584,216=>778,217=>722,218=>722,219=>722,220=>722,221=>667,222=>667,223=>611,224=>556,225=>556,226=>556,227=>556,228=>556,229=>556,230=>889,231=>556,232=>556,233=>556,234=>556,235=>556,236=>278,237=>278,238=>278,239=>278,240=>611,241=>611,242=>611,243=>611,244=>611,245=>611,246=>611,247=>584,248=>611,249=>611,250=>611,251=>611,252=>611,253=>556,254=>611,255=>556]);
    // Self-contained paginated report renderer. Core PDF fonts require no server packages.
    class DGSecurityReportPDF {
        public array $pages=[],$anchors=[];public float $y=0;public string $kind='body',$section='';public array $regular=[],$bold=[];
        public function __construct(public array $report){
            $this->regular=DG_REPORT_FONT_REGULAR;$this->bold=DG_REPORT_FONT_BOLD;
        }
        public function latin(string $value):string {if(function_exists('iconv')){$v=iconv('UTF-8','Windows-1252//TRANSLIT//IGNORE',$value);if($v!==false)return $v;}return preg_replace('/[^\x20-\x7e\n]/','?', $value)??'';}
        public function technical(string $value):bool{return (bool)preg_match('/^(?:DG-|BE-|HP-|[a-f0-9]{32,}|(?:\d{1,3}\.){3}\d{1,3}|(?:GET|POST|PUT|DELETE|HEAD|PATCH) )/', $value);}
        public function width(string $value,float $size=10.5,bool $bold=false):float{if(!$bold&&$this->technical($value))return strlen($this->latin($value))*600*$size/1000;$units=0;$map=$bold?$this->bold:$this->regular;foreach(str_split($this->latin($value))as$c)$units+=$map[ord($c)]??556;return $units*$size/1000;}
        public function lines(string $value,float $width,float $size=10.5,bool $bold=false):array{$result=[];foreach(explode("\n",str_replace("\r",'', $value))as$paragraph){if($paragraph===''){$result[]='';continue;}$line='';$words=preg_split('/\s+/u',$paragraph)?:[];foreach($words as$word){$try=$line===''?$word:$line.' '.$word;if($this->width($try,$size,$bold)<=$width){$line=$try;continue;}if($line!==''){$result[]=$line;$line='';}$characters=preg_split('//u',$word,-1,PREG_SPLIT_NO_EMPTY)?:str_split($word);foreach($characters as$char){if($this->width($line.$char,$size,$bold)>$width&&$line!==''){$result[]=$line;$line='';}$line.=$char;}}$result[]=$line;}return $result;}
        public function op(array $item):void{$this->pages[count($this->pages)-1]['items'][]=$item;}
        public function text(float $x,float $y,string $text,float $size=10.5,bool $bold=false,string $color='1e293b',?string $link=null,bool $mono=false):void{$mono=$mono||(!$bold&&$this->technical($text));$this->op(['mono'=>$mono,'type'=>'text','x'=>$x,'y'=>$y,'text'=>$text,'size'=>$size,'bold'=>$bold,'color'=>$color,'link'=>$link]);}
        public function line(float $x1,float $y1,float $x2,float $y2,string $color='cbd5e1'):void{$this->op(['type'=>'line','x1'=>$x1,'y1'=>$y1,'x2'=>$x2,'y2'=>$y2,'color'=>$color]);}
        public function rect(float $x,float $y,float $width,float $height,string $color='f1f5f9'):void{$this->op(['type'=>'rect','x'=>$x,'y'=>$y,'width'=>$width,'height'=>$height,'color'=>$color]);}
        public function page(string $kind,string $title='',?string $anchor=null):void{$this->kind=$kind;$this->section=preg_replace('/(?: \(continued\))+$/','',$title);$this->pages[]=['kind'=>$kind,'title'=>$title,'items'=>[]];$this->y=770;if($anchor!==null)$this->anchors[$anchor]=count($this->pages)-1;if($kind!=='cover'){$this->text(72,801,'CONFIDENTIAL // INTERNAL SECURITY EVIDENCE',8.2,true,'475569');$id=$this->report['report_id'];$this->text(523-$this->width($id,8),801,$id,8,false,'475569');$this->line(72,789,523,789);$this->y=758;if($title!=='')$this->heading($title,18);}}
        public function need(float $height):void{if($this->y-$height<73)$this->page($this->kind,$this->section.' (continued)');}
        public function heading(string $text,float $size=14):void{$lines=$this->lines($text,451,$size,true);$this->need(count($lines)*$size*1.2+65);foreach($lines as$line){$this->text(72,$this->y,$line,$size,true,'16374f');$this->y-=$size*1.2;}$this->y-=10;}
        public function paragraph(string $text,float $size=10.5,string $color='1e293b'):void{$lines=$this->lines($text,451,$size);$height=count($lines)*$size*1.22+8;if($height<=220)$this->need($height);foreach($lines as$i=>$line){$this->need(min(2,count($lines)-$i)*$size*1.22);$this->text(72,$this->y,$line,$size,false,$color);$this->y-=$size*1.22;}$this->y-=8;}
        public function bullet(string $text):void{foreach($this->lines($text,438,10.5)as$i=>$line){$this->need(13);$this->text(72,$this->y,$i===0?'-':'',10.5);$this->text(85,$this->y,$line,10.5);$this->y-=13;}$this->y-=6;}
        public function tableHeight(array $headers,array $rows,array $weights):float{$total=array_sum($weights);$height=14;foreach([$headers,...$rows]as$index=>$row){$n=1;foreach($row as$i=>$cell)$n=max($n,count($this->lines((string)$cell,451*$weights[$i]/$total-16,9,$index===0)));$height+=$n*11.4+12;}return $height;}
        public function table(array $headers,array $rows,array $weights=[]):void{
            $weights=$weights?:array_fill(0,count($headers),1);$total=array_sum($weights);$widths=array_map(static fn($v)=>451*$v/$total,$weights);
            $wrap=function(array $cells,bool $head=false)use($widths){$result=[];foreach($cells as$i=>$value)$result[$i]=$this->lines((string)$value,$widths[$i]-16,9,$head);return $result;};
            $draw=function(array $wrapped,bool $head=false)use($widths){$height=max(array_map('count',$wrapped))*11.4+12;
                if($head)$this->rect(72,$this->y-$height+4,451,$height,'1e293b');
                $x=72;foreach($wrapped as$i=>$lines){foreach($lines as$j=>$line)$this->text($x+8,$this->y-10-$j*11.4,$line,9,$head,$head?'ffffff':'1e293b');$x+=$widths[$i];}
                $this->line(72,$this->y-$height+4,523,$this->y-$height+4);$this->y-=$height;
            };
            $head=$wrap($headers,true);$headHeight=max(array_map('count',$head))*11.4+12;$first=$rows?$wrap($rows[0]):[['']];$this->need($headHeight+min(160,max(array_map('count',$first))*11.4+12));$draw($head,true);
            foreach($rows as$row){$wrapped=$wrap($row);$rowHeight=max(array_map('count',$wrapped))*11.4+12;
                if($rowHeight<=560&&$this->y-$rowHeight<73){$this->page($this->kind,$this->section.' (continued)');$draw($head,true);}
                while(max(array_map('count',$wrapped))>0){$available=(int)floor(($this->y-73-12)/11.4);
                    if($available<1){$this->page($this->kind,$this->section.' (continued)');$draw($head,true);continue;}
                    $chunk=[];foreach($wrapped as$i=>$lines){$chunk[$i]=array_slice($lines,0,$available);$wrapped[$i]=array_slice($lines,$available);}
                    $draw($chunk);
                    if(max(array_map('count',$wrapped))>0){$this->page($this->kind,$this->section.' (continued)');$draw($head,true);}
                }
            }$this->y-=14;
        }
        public function callout(string $text):void{$lines=$this->lines($text,423,9.5);$height=count($lines)*12+22;$this->need($height+10);$this->rect(72,$this->y-$height+5,451,$height,'fff7ed');$this->rect(72,$this->y-$height+5,3,$height,'d97706');foreach($lines as$i=>$line)$this->text(85,$this->y-10-$i*12,$line,9.5,false,'9a3412');$this->y-=$height+10;}
        public function code(string $text):void{foreach(explode("\n",wordwrap($this->latin($text),83,"\n",true))as$line){$this->need(14);$this->rect(72,$this->y-5,451,14,'f1f5f9');$this->text(82,$this->y,$line,8.5,false,'334155',null,true);$this->y-=14;}$this->y-=9;}
        public function roman(int $n):string{$out='';foreach([1000=>'m',900=>'cm',500=>'d',400=>'cd',100=>'c',90=>'xc',50=>'l',40=>'xl',10=>'x',9=>'ix',5=>'v',4=>'iv',1=>'i']as$v=>$glyph)while($n>=$v){$out.=$glyph;$n-=$v;}return $out;}
        public function finish():void{$front=count(array_filter($this->pages,static fn($p)=>$p['kind']==='front'));$body=count(array_filter($this->pages,static fn($p)=>$p['kind']==='body'));$f=0;$b=0;foreach($this->pages as$i=>$page){if($page['kind']==='cover')continue;$label=$page['kind']==='front'?'Page '.$this->roman(++$f).' of '.$this->roman($front):'Page '.(++$b).' of '.$body;$this->pages[$i]['label']=$label;$this->pages[$i]['items'][]=['type'=>'line','x1'=>72,'y1'=>55,'x2'=>523,'y2'=>55,'color'=>'cbd5e1'];$this->pages[$i]['items'][]=['type'=>'text','x'=>72,'y'=>40,'text'=>'DecoyGuard Security Telemetry | Internal evidence','size'=>8,'bold'=>false,'color'=>'64748b','link'=>null];$this->pages[$i]['items'][]=['type'=>'text','x'=>523-strlen($label)*9*.6,'y'=>40,'text'=>$label,'size'=>9,'mono'=>true,'bold'=>false,'color'=>'64748b','link'=>null];}}
        public function rgb(string $hex):string{return implode(' ',array_map(static fn($v)=>sprintf('%.3f',hexdec($v)/255),str_split($hex,2)));}
        public function escape(string $text):string{return str_replace(['\\','(',')',"\r","\n"],['\\\\','\\(','\\)',' ',' '],$this->latin($text));}
        public function bytes():string{$objects=[1=>'',2=>'',3=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',4=>'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];$objects[5]='<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>';$pageIds=[];$next=6;foreach($this->pages as$_){$pageIds[]=$next;$next+=2;}
            foreach($this->pages as$i=>$page){$stream='';$annotations=[];foreach($page['items']as$o){$color=$this->rgb($o['color']);if($o['type']==='text'){$stream.="BT /".(!empty($o['mono'])?'F3':($o['bold']?'F2':'F1')).' '.$o['size'].' Tf '.$color.' rg 1 0 0 1 '.$o['x'].' '.$o['y'].' Tm ('.$this->escape($o['text']).") Tj ET\n";if($o['link']&&isset($this->anchors[$o['link']])){$target=$pageIds[$this->anchors[$o['link']]];$a=$next++;$w=$this->width($o['text'],$o['size'],$o['bold']);$objects[$a]='<< /Type /Annot /Subtype /Link /Rect ['.$o['x'].' '.($o['y']-3).' '.($o['x']+$w).' '.($o['y']+$o['size']).'] /Border [0 0 0] /Dest ['.$target.' 0 R /Fit] >>';$annotations[]=$a.' 0 R';}}elseif($o['type']==='line')$stream.=$color.' RG 0.5 w '.$o['x1'].' '.$o['y1'].' m '.$o['x2'].' '.$o['y2']." l S\n";else$stream.=$color.' rg '.$o['x'].' '.$o['y'].' '.$o['width'].' '.$o['height']." re f\n";}
                $id=$pageIds[$i];$objects[$id]='<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.276 841.89] /Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> /Contents '.($id+1).' 0 R'.($annotations?' /Annots ['.implode(' ',$annotations).']':'').' >>';$objects[$id+1]='<< /Length '.strlen($stream).">>\nstream\n".$stream.'endstream';}
            $objects[1]='<< /Type /Catalog /Pages 2 0 R >>';$objects[2]='<< /Type /Pages /Kids ['.implode(' ',array_map(static fn($id)=>$id.' 0 R',$pageIds)).'] /Count '.count($pageIds).' >>';ksort($objects);$pdf="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offsets=[0=>0];foreach($objects as$id=>$value){$offsets[$id]=strlen($pdf);$pdf.=$id." 0 obj\n".$value."\nendobj\n";}$xref=strlen($pdf);$pdf.='xref'."\n0 ".($next)."\n0000000000 65535 f \n";for($i=1;$i<$next;$i++)$pdf.=sprintf('%010d 00000 n ', $offsets[$i])."\n";$pdf.='trailer << /Size '.$next.' /Root 1 0 R >>'."\nstartxref\n".$xref."\n%%EOF";return $pdf;
        }
        public function html():string{$e=static fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');$html='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'.$e($this->report['title']).'</title><style>@page{size:A4;margin:0}body{margin:0;background:#e5ebf1;font-family:Arial,sans-serif}.toolbar{padding:15px;background:#132c42;color:white;position:sticky;top:0;z-index:3}.toolbar a,.toolbar button{margin-right:12px;padding:9px 14px;background:#e7f6fc;color:#17374d;border:0;border-radius:4px;font:13px Arial;text-decoration:none}.sheet{max-width:794px;margin:22px auto;background:white;break-after:page}.sheet:last-child{break-after:auto}svg{display:block;width:100%;height:auto}text{font-family:Arial,Helvetica,sans-serif}@media print{body{background:white}.toolbar{display:none}.sheet{width:210mm;max-width:none;height:297mm;margin:0}}</style></head><body><div class="toolbar"><button onclick="window.print()">Print / Save as PDF</button>';
            foreach(['pdf'=>'Download PDF','txt'=>'ASCII text report','json'=>'JSON evidence','csv'=>'CSV evidence','bundle'=>'Evidence bundle + hashes']as$kind=>$label){$query=$_GET;$query['format']=$kind;$query['action']='report';$query['csrf']=$_SESSION['csrf'];$html.='<form method="post" action="api.php" target="_blank" style="display:inline">';foreach($query as$key=>$value)if(is_scalar($value))$html.='<input type="hidden" name="'.$e($key).'" value="'.$e($value).'">';$html.='<button type="submit">'.$e($label).'</button></form>';}$html.='</div><main>';foreach($this->pages as$i=>$page){$html.='<section class="sheet" id="report-page-'.$i.'"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 595.276 841.89" role="img" aria-label="'.$e($page['title'].' '.($page['label']??'Cover')).'">';foreach($page['items']as$o){if($o['type']==='text'){$text='<text style="font-family:'.(!empty($o['mono'])?'Courier New,monospace':'Arial,Helvetica,sans-serif').'" x="'.$o['x'].'" y="'.(841.89-$o['y']).'" font-size="'.$o['size'].'" font-weight="'.($o['bold']?'700':'400').'" fill="#'.$o['color'].'">'.$e($o['text']).'</text>';if($o['link']&&isset($this->anchors[$o['link']]))$text='<a href="#report-page-'.$this->anchors[$o['link']].'">'.$text.'</a>';$html.=$text;}elseif($o['type']==='line')$html.='<line x1="'.$o['x1'].'" y1="'.(841.89-$o['y1']).'" x2="'.$o['x2'].'" y2="'.(841.89-$o['y2']).'" stroke="#'.$o['color'].'" stroke-width="0.5"/>';else$html.='<rect x="'.$o['x'].'" y="'.(841.89-$o['y']-$o['height']).'" width="'.$o['width'].'" height="'.$o['height'].'" fill="#'.$o['color'].'"/>';}$html.='</svg></section>';}$html.='</main></body></html>';return $html;}
    }
    $doc=new DGSecurityReportPDF($report);
    $period=($report['source_period']['from']??null)?$report['source_period']['from'].' to '.$report['source_period']['to']:'No usable dated source records';
    $doc->page('cover');$doc->y=737;$doc->text(72,773,'INTERNAL RESTRICTED',10,true,'526b82');$doc->heading('Security Operations',27);$doc->heading('Evidence Report',27);$doc->paragraph($report['title'],14,'526b82');$doc->y-=22;
    $doc->table(['Report metadata','Recorded value'],[['Reference',$report['report_id']],['Prepared by',$report['team'].' / DecoyGuard automated reporting'],['Generated at',$report['generated_at']],['Website scope',$report['site']],['Source evidence window',$period],['Selected records',(string)$summary['records']],['Report status','Internal evidence; independent assurance not performed']],[1.2,2.8]);
    $doc->paragraph('SOC 2 Type II-inspired structure. This is not a SOC 2 audit report, certification, or independent auditor opinion. A log-capture window is not an audited operating-effectiveness evaluation period.',10,'526b82');
    $doc->page('front','Document Control and Revision History','control');
    $doc->table(['Field','Value'],[['Report ID',$report['report_id']],['Template version','2.0'],['Document type','Generated internal security evidence snapshot'],['Evidence selection',$scope.' / '.$report['site']],['Generation time',$report['generated_at']],['Source capture window',$period],['Review status',$review['status']]],[1,3]);
    $doc->heading('Revision history',14);$doc->table(['Version','Date','Author','Summary of changes','Approved by'],[['1.0',$now->format('Y-m-d'),'Automated generator','Initial evidence snapshot for this report identifier','Pending']],[.6,1.1,1.1,2,1]);
    $doc->paragraph('This table identifies the generated snapshot. It is not a historical record of system configuration changes, previous report approvals, or completed management review. Regeneration does not establish archival immutability.');
    $doc->page('front','Contents and Evidence Tables','contents');$tocIndex=count($doc->pages)-1;
    $sections=[
        'summary'=>'1. Executive Summary and Objective',
        'architecture'=>'2. Architecture and Ingestion Telemetry Pipeline',
        'models'=>'3. Detection Engine and Behavioral Models',
        'controls'=>'4. Control Evidence and Observations',
        'findings'=>'5. Empirical Findings and Honeypot Analysis',
        'integrity'=>'6. Evidence Integrity and Digest Validation',
        'review'=>'7. Management Review and Follow-up',
        'appendix'=>'Appendix A. Selected Event Evidence',
        'schema'=>'Appendix B. Parsing Schema and Rule Limitations'
    ];
    if($scope==='activity'){unset($sections['schema'],$sections['models']);$sections['appendix']='Appendix A. Activity Summary';}
    $doc->page('body',$sections['summary'],'summary');
    $doc->paragraph('Objective: provide a traceable account of the selected retained telemetry, detector findings, recorded responses and evidence limitations. The report does not independently validate exploitation, routing effectiveness, control design or operational effectiveness.');
    $doc->table(['Measure','Selected records'],[['All selected records',$summary['records']],['Request records',$summary['requests']],['Detection records',$summary['detections']],['Behavioral-pattern findings',$summary['behavioural_findings']],['Signature findings',$summary['signature_findings']],['Selected syslog records',$summary['syslog_records']]],[3,1]);
    if(!$records){$doc->heading('Why this selection is empty',14);$doc->paragraph($selection['normalized']?'Source records were parsed, but none matched the chosen report scope or filters. SQL injection and XSS entries are signature findings; they are deliberately excluded from Behavioral Patterns. Select Security Evidence or Log Activity to review them.':'No usable records were normalized from the available files. Review the ingestion diagnostics below.',10.5,'9a3412');}
    $doc->heading('Evidence scope',14);$doc->paragraph('Source capture window: '.$period.'. This period is derived from the matched website source records, including records excluded by the selected finding scope. The report does not invent a three-, six- or twelve-month audit period.');$doc->paragraph($report['scope_note']);
    $doc->page('body',$sections['architecture'],'architecture');
    $doc->paragraph('Observed evidence path: retained JSON/syslog files -> date and field normalization -> website/period/scope selection -> identifier-based merging -> summary and evidence snapshot. This describes this generator, not a verified deployment topology.');
    $diagnostics=[['Source lines scanned',$scanned],['Records with usable dates',$selection['normalized']],['Malformed / oversized lines',$invalid],['Unusable dates',$undated],['Excluded by website',$selection['excluded_site']],['Excluded by period',$selection['excluded_period']],['Excluded by finding scope',$selection['excluded_scope']],['Duplicate identifiers merged',$selection['duplicates_merged']],['Final selected records',count($records)]];
    $doc->table(['Ingestion stage','Count'],$diagnostics,[3,1]);
    $doc->heading('Source coverage',14);$rows=[];foreach($report['source_coverage']as$c)$rows[]=[$c['file'],$c['lines_scanned'],$c['read_limited']?'Yes':'No',$c['invalid_lines']];$doc->table(['File','Lines Scanned','Read Limited','Invalid Lines'],$rows,[2.1,.95,.95,1]);
    $doc->paragraph('A readable source file is not evidence of a currently healthy collector. Native network syslog transport is not installed or tested by this reporting endpoint. Empty uploaded files and absent files are not automatically classified as outages.');
    $doc->heading('Collector diagnostics at generation',12);
    $doc->paragraph('State: '.($collector['state']??'unknown').' | Heartbeat: '.(!empty($collector['fresh_heartbeat'])?'fresh (within 30 seconds)':'missing, stale or invalid').' | Accepted this process session: '.($collector['accepted']??'unknown').' | Last accepted: '.($collector['last_received_at']??'none recorded'),9);
    $doc->paragraph('This is a local status claim, not a transport certification. Counters reset on restart. Zero selected syslog findings can result from scope filtering.',9);
    if($scope!=='activity'){
    $doc->page('body',$sections['models'],'models');
    $doc->heading('3.1 Signature and application findings',14);$doc->paragraph('Signature findings include explicitly labelled SQL injection, cross-site scripting and similar classes. Application-check findings are identified only when a source security_finding is supplied. Source risk scores and classifications are preserved; scores from different engines are not assumed to use identical scales.');
    $doc->heading('3.2 Behavioral-pattern evidence',14);$doc->paragraph('Pattern evidence requires an explicit known request-pattern event such as REQUEST_BURST, REPEATED_HTTP_ERRORS or ENDPOINT_ENUMERATION from a behavioral source. A filename or engine name alone does not turn an SQL_INJECTION or XSS_ATTACK signature into a behavioral pattern.');
    $doc->table(['Evidence basis','Meaning'],[['behavioral-pattern','Explicit recognized activity pattern from a behavioral source'],['signature','Explicit signature class from a behavioral source'],['signature-or-correlation','Positive-risk detector record without an application-check flag'],['application-check','Source supplies a security_finding'],['unclassified-detector','Behavioral source with an unrecognized event class'],['activity','Other source activity without the supplied detection indicators']],[1.4,3]);
    $contexts=[];foreach($records as$r)foreach($r['mitre_candidates']as$m)$contexts[$r['event_type'].'|'.$m['id']]=[$r['event_type'],$m['id'].' - '.$m['label'],$m['basis']];
    if($contexts){$doc->heading('ATT&CK review context',12);$doc->table(['Observed pattern','Candidate technique','Interpretation limit'],array_values($contexts),[1.3,1.1,2]);}
    $doc->paragraph('Training data, learned baselines, detector rule definitions, model validation and efficacy measurements are not supplied by the logs. No machine-learning performance or anomaly accuracy is claimed.');
    }
    $doc->page('body',$sections['controls'],'controls');
    $doc->paragraph('The following are candidate evidence mappings for internal review. They do not establish compliance with the AICPA Trust Services Criteria or replace an independent examination.');
    $doc->table(['Theme / mapping','Observed evidence','Review limitation'],[['Monitoring / CC7.2',$summary['detections'].' selected detections; '.$summary['behavioural_findings'].' behavioral patterns','Detection coverage, completeness and effectiveness are not independently tested.'],['Event evaluation / CC7.3','Recorded classifications, severities and decisions','Incident determination and completed response require management review.'],['Logical access / CC6','Only request and target fields supplied in telemetry','Authentication/authorization control effectiveness is not assessed.'],['Log collection','Readable source files and normalization diagnostics','Transport security, retention controls and clock synchronization are not verified.']],[1.3,1.4,1.8]);
    $doc->paragraph('Availability, confidentiality, processing integrity and privacy are not assessed as separate control domains in this report. Management assertions and auditor test results are not generated.');
    $doc->page('body',$sections['findings'],'findings');
    if($privateRecords)$doc->callout('Attribution limitation: '.$privateRecords.' selected records contain a private source address. A private address such as 172.18.0.1 may be a Docker bridge, proxy or LAN client; it is not a verified external attacker identity. Verify forwarded-address handling only at trusted ingress.');
    $doc->heading('5.1 Classifications observed',14);$rows=[];foreach(array_slice($summary['by_type'],0,18,true)as$type=>$count)$rows[]=[$type,$count];$doc->table(['Classification','Records'],$rows?:[['No selected findings',0]],[3,1]);
    $doc->heading('5.2 Recorded outcomes',14);$rows=[];foreach($summary['by_decision']as$decision=>$count)$rows[]=[$decision,$count];$doc->table(['Decision','Records'],$rows?:[['No supplied decisions',0]],[3,1]);
    $doc->paragraph('CONTAINED, ALLOW, REDIRECT or similar values describe recorded decisions. They do not independently prove that a gateway switched destinations or that an exploit succeeded. Record counts are not unique attacks or attackers.');
    $chronology=[];foreach($records as $r){$key=$r['site_id'].' | '.$r['target_type'].' | '.$r['decision'];if(!isset($chronology[$key]))$chronology[$key]=['first'=>$r['timestamp'],'last'=>$r['timestamp'],'count'=>0];$chronology[$key]['first']=min($chronology[$key]['first'],$r['timestamp']);$chronology[$key]['last']=max($chronology[$key]['last'],$r['timestamp']);$chronology[$key]['count']++;}
    uasort($chronology,static fn($a,$b)=>strcmp($a['first'],$b['first']));$rows=[];foreach(array_slice($chronology,0,8,true)as$key=>$range)$rows[]=[$key,$range['first'].' to '.$range['last'],$range['count']];
    $siteRows=[];foreach($summary['by_site']as$label=>$count)$siteRows[]=[$label,$count];
    $doc->need(min(580,$doc->tableHeight(['Website / target / decision','Observed UTC interval','Records'],$rows,[1.6,1.9,.5])+$doc->tableHeight(['Website label','Selected records'],$siteRows,[3,1])+110));
    $doc->heading('Recorded target and decision chronology',12);$doc->table(['Website / target / decision','Observed UTC interval','Records'],$rows?:[['No selected outcomes','Not available',0]],[1.6,1.9,.5]);
    $doc->paragraph('These intervals describe recorded observations. They do not establish a baseline-to-containment transition or explain why production was monitored; verify request identifiers, routing policy and destination logs before drawing that conclusion.',9);
    $doc->heading('5.3 Website attribution',14);$rows=[];foreach($summary['by_site']as$siteLabel=>$count)$rows[]=[$siteLabel,$count];$doc->table(['Website label','Selected records'],$rows?:[['No selected website evidence',0]],[3,1]);
    if($related){$doc->heading('5.4 Shared request identifiers',12);$doc->paragraph(count($related).' request identifiers link multiple detector records. These links use supplied identifiers, website and client; records, classifications and scores are preserved separately. No time-window guess is treated as a confirmed incident.',9);$rows=[];foreach(array_slice($related,0,$scope==='activity'?0:5)as$group)$rows[]=[$group['site_id'].' / '.$group['request_id'],count($group['records']),implode(', ',array_unique($group['engines']))];if($rows)$doc->table(['Shared request','Records','Reporting engines'],$rows,[2.2,.5,1.3]);}
    $doc->page('body',$sections['integrity'],'integrity');
    $doc->heading('6.1 Normalized evidence fingerprint',14);$doc->code($report['evidence_digest']);$doc->paragraph('Algorithm: SHA-256 over the UTF-8 JSON array of normalized selected records, serialized using the DG-JSON-v1 rules in the JSON export: recursively sorted object keys, stable record ordering and compact UTF-8 JSON with unescaped Unicode/slashes and preserved zero fractions. This is not an RFC 8785 implementation. The JSON export includes the fingerprint, serialization rules and normalized records for validation. The evidence bundle includes exact PDF/CSV/JSON file hashes in manifest.json. Do not hash the entire exported report file to compare against this records-only digest.');
    $doc->paragraph('The fingerprint helps compare a defined snapshot. It does not prove that original source logs were never modified. This report is not digitally signed or independently timestamped, and no chain of custody is asserted.');
    $doc->paragraph('Client addresses reflect the recorded network path. A Docker bridge or NAT address does not identify a unique external visitor. Forwarded headers are meaningful only across configured trusted proxies; this report cannot reconstruct an address lost before the gateway. UDP syslog is best-effort and unauthenticated; receipt is not proof of sender authenticity or completeness.');
    $doc->heading('6.2 Timing, redaction and limits',14);$doc->paragraph('Original timestamp strings are retained alongside normalized UTC and local times. Epoch seconds/milliseconds, supported ISO/custom date strings and supported syslog-style dates are normalized. Inferred legacy year values are marked. Unusable dates are counted instead of silently relabelled as current time.');
    if($warnings)foreach($warnings as$warning)$doc->bullet($warning);else$doc->paragraph('No parser/read-limit warnings were raised for this snapshot. This is not a completeness certification.');
    $doc->paragraph('Sensitive fields are redacted and long source values may be bounded before normalization. The Activity PDF summarizes routine traffic without printing individual activity payloads. Other PDF appendices contain at most 20 grouped evidence examples; the CSV and JSON exports include all selected normalized records within the 64 MiB, 200,000-line and 5,000-record read limits. PDF core fonts may transliterate unsupported characters; JSON retains normalized Unicode text.');
    $doc->page('body',$sections['review'],'review');
    $doc->paragraph('Recommendations below are derived from this snapshot. Suggested functional roles are guidance, not assigned owners, deadlines or completed work. No management approval or completed remediation is generated automatically.');
    $rows=[];foreach($recommendations as $item)$rows[]=[$item['action'],$item['suggested_role'],$item['reason']];$doc->table(['Recommended action','Suggested role','Evidence basis'],$rows?:[['No incident-specific action generated','Not applicable','No selected detections or diagnostic warnings.']],[1.9,1,1.7]);
    $doc->heading('Recorded reviewer statement',14);
    $reviewRows=[['Authenticated requesting account',$review['authenticated_analyst_id']],['Document generated (automatic)',$review['document_generated_at']],['Review state (user declared)',$review['sign_off_status']]];
    if($review['reviewer']!==''||$review['review_role']!=='')$reviewRows[]=['Reviewer name / role',trim($review['reviewer'].' / '.$review['review_role'],' /')];
    if($review['ticket_id']!=='')$reviewRows[]=['Ticket / case reference',$review['ticket_id']];
    if($review['review_conclusion']!=='')$reviewRows[]=['Reviewer conclusion (user supplied)',$review['review_conclusion']];
    $doc->table(['Review field','Recorded value'],$reviewRows,[1.4,2.6]);
    if($review['reviewer']===''&&$review['review_conclusion']==='')$doc->paragraph('No reviewer statement was submitted with this generation. Enter the optional reviewer details on the dashboard before generating a new report. The requesting account is not automatically treated as its reviewer.',9);
    $doc->callout('This report is not digitally signed. An authenticated account identifies the report requester, not a verified human reviewer. A declared review state or typed name is not a cryptographic signature or independent verification of containment.');
    $doc->page('body',$sections['appendix'],'appendix');
    if($scope==='activity'){
        $doc->paragraph('This PDF summarizes all '.count($records).' selected normalized records. Routine traffic, including Socket.IO polling, remains in JSON/CSV; individual benign payloads are intentionally omitted from this PDF.');
        $endpoints=[];foreach($records as$event){$parts=explode(' ',$event['request'],3);$path=parse_url($parts[1]??'/',PHP_URL_PATH)?:'/';if(str_starts_with($path,'/socket.io'))$path='/socket.io/*';
            $key=($event['site_id']?:'Unspecified').' | '.($parts[0]??'').' '.$path;
            if(!isset($endpoints[$key]))$endpoints[$key]=0;$endpoints[$key]++;
        }arsort($endpoints);$rows=[];foreach(array_slice($endpoints,0,10,true)as$endpoint=>$count)$rows[]=[substr($endpoint,0,110),$count];
        $doc->table(['Top website / endpoint (query strings omitted)','Records'],$rows?:[['No selected activity',0]],[3.4,.6]);
        $doc->paragraph('Counts represent selected normalized records, including detector records when present; they are not necessarily unique HTTP requests. Suppression affects PDF/HTML presentation only, not the evidence digest, selection totals or JSON/CSV export.',9);
    }else{
    $groups=[];
    foreach($records as$event){
        $key=hash('sha256',json_encode([$event['site_id'],$event['event_type'],$event['request'],$event['source_ip'],$event['target_type'],$event['decision'],$event['basis'],$event['severity']],JSON_INVALID_UTF8_SUBSTITUTE));
        if(!isset($groups[$key]))$groups[$key]=['event'=>$event,'ids'=>[],'first'=>$event['timestamp'],'last'=>$event['timestamp'],'files'=>[]];
        $groups[$key]['ids'][]=$event['id'];
        $groups[$key]['first']=min($groups[$key]['first'],$event['timestamp']);$groups[$key]['last']=max($groups[$key]['last'],$event['timestamp']);
        $groups[$key]['files']=array_values(array_unique(array_merge($groups[$key]['files'],$event['files'])));
    }
    $doc->paragraph(count($records).' selected records consolidated into '.count($groups).' groups by website, classification, exact request, client, target, decision, detection basis and severity. Grouping changes presentation only; individual identifiers and normalized evidence remain in the complete JSON/CSV export. Different payloads may occur within a group; the excerpt below is representative, not every payload.');
    if(!$records)$doc->paragraph('No records match this scope. See Section 2 for normalization and exclusion counts.');
    foreach(array_slice(array_values($groups),0,20)as$i=>$group){$event=$group['event'];$doc->need(160);$doc->heading('A.'.($i+1).' '.$event['event_type'],12);
        $doc->table(['Website / client','Records','First / last observed (UTC)'],[[($event['site_id']?:'Unspecified').' / '.$event['source_ip'],count($group['ids']),$group['first'].' to '.$group['last']]],[1.4,.5,2.1]);
        $doc->paragraph('Basis: '.$event['basis'].' | Severity: '.$event['severity'].' | Decision: '.($event['decision']?:'Unspecified').' | Target: '.($event['target_type']?:'Unspecified'),9);
        $doc->code(substr($event['request'],0,450));$doc->paragraph(substr($event['evidence'],0,650),9);
        $doc->code('Example IDs: '.implode(', ',array_slice($group['ids'],0,3)));
        $doc->code('Client: '.$event['source_ip']);
        if($event['private_client_address'])$doc->paragraph('Private address: verify proxy/bridge attribution before identifying an external visitor.',8.5,'9a3412');
        if($event['mitre_tags'])$doc->code('Source ATT&CK tags (not independently verified): '.implode(', ',$event['mitre_tags']));
        foreach($event['mitre_candidates']as$mapping)$doc->paragraph('ATT&CK review candidate '.$mapping['id'].' - '.$mapping['label'].': '.$mapping['basis'],9,'526b82');
        $doc->paragraph('Files: '.implode(', ',$group['files']),8.5,'526b82');$doc->y-=8;
    }
    if(count($groups)>20)$doc->paragraph('Appendix limited to 20 groups; use JSON/CSV for the complete selected dataset.');
    }
    if($scope!=='activity'){
    $doc->page('body',$sections['schema'],'schema');
    $doc->heading('B.1 Input normalization schema',14);$doc->table(['Normalized field','Accepted source fields / treatment'],[['Event date','timestamp, DateTime, @timestamp, time_iso8601, time_local, datetime, date, ts, time'],['Website attribution','site_id, website_id, site, website; missing values remain unspecified'],['Identifier','incident_id or event_id; otherwise a normalized source-content hash'],['Source / client','engine/source and source_ip/remote_addr/hostname'],['Classification','event_type or attack_type; severity preserved as supplied'],['ATT&CK context','Source tags preserved from mitre_tags / forensics.mitre_tags; report-derived candidates shown separately and require review'],['Sensitive values','Credential/token patterns are redacted before report output']],[1,3]);
    $doc->paragraph('ATT&CK interpretation references: attack.mitre.org/techniques/T1595/ (Active Scanning), T1499/ (Endpoint Denial of Service), T1110/ (Brute Force). Candidate mappings are contextual review aids, not proof of attacker intent or successful exploitation.',9);
    $doc->heading('B.2 Syslog samples and rule definitions',14);$syslogSamples=array_values(array_filter($records,static fn($e)=>array_intersect($e['files'],['syslog.log','syslog.jsonl'])));if($syslogSamples){$doc->paragraph('The following are redacted normalized syslog excerpts, not unmodified originals.');foreach(array_slice($syslogSamples,0,3)as$event)$doc->code($event['timestamp'].' '.$event['source_ip'].' '.$event['evidence']);}else$doc->paragraph('No syslog records are included in this selection. This does not establish whether a receiver exists or whether a different report scope contains syslog activity.');
    $doc->paragraph('Detection engine regex/rule definitions were not supplied and are not reconstructed from attack labels. Timestamp recognizers are input-normalization rules, not attack signatures. Absolute dates and supported epoch values are required; a time-of-day alone is not assigned an invented calendar date.');
    // Fill the reserved contents page after section start pages are known.
    }
    $savedPages=$doc->pages;$doc->pages=[$savedPages[$tocIndex]];$doc->y=704;
    foreach($sections as$anchor=>$title){$physical=$doc->anchors[$anchor];$bodyNumber=0;for($i=0;$i<=$physical;$i++)if($savedPages[$i]['kind']==='body')$bodyNumber++;$pageNumber=(string)$bodyNumber;$dots=str_repeat('.',max(3,(int)((451-$doc->width($title,10.5)-$doc->width($pageNumber,10.5)-15)/$doc->width('.',10.5))));$doc->text(72,$doc->y,$title.' '.$dots.' '.$pageNumber,10.5,false,'16374f',$anchor);$doc->y-=29;}
    $doc->y-=15;$doc->heading('Tables and evidence blocks',14);foreach(['Executive metrics - Section 1','Ingestion reconciliation and source coverage - Section 2','Detection bases - Section 3','Candidate control evidence mappings - Section 4','Findings, outcomes and websites - Section 5','Follow-up matrix - Section 7','Event evidence blocks - Appendix A',...($scope==='activity'?[]:['Parsing schema and syslog excerpts - Appendix B'])]as$label)$doc->paragraph($label,9.5,'526b82');$savedPages[$tocIndex]=$doc->pages[0];$doc->pages=$savedPages;$doc->finish();
    if($format==='bundle'){
        $files=['report.pdf'=>$doc->bytes(),'evidence.csv'=>dg_report_csv($report),'evidence.json'=>json_encode($report,JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE)];
        $manifest=['report_id'=>$report['report_id'],'generated_at'=>$report['generated_at'],'algorithm'=>'SHA-256','evidence_digest'=>$digest,'files'=>[],'note'=>'Hashes verify byte equality, not authenticity. Manifest is not signed. ZIP hash is supplied in X-Content-SHA256, not inside its own manifest.'];
        foreach($files as$name=>$bytes)$manifest['files'][]=['file'=>$name,'bytes'=>strlen($bytes),'sha256'=>hash('sha256',$bytes)];
        $files['manifest.json']=json_encode($manifest,JSON_PRETTY_PRINT|JSON_INVALID_UTF8_SUBSTITUTE);$zip=dg_report_zip($files);
        header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.$filename.'-evidence.zip"');header('X-Content-SHA256: '.hash('sha256',$zip));echo $zip;exit;
    }
    if($format==='pdf'){header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="'.$filename.'.pdf"');$pdf=$doc->bytes();header('X-Content-SHA256: '.hash('sha256',$pdf));echo $pdf;exit;}
    header('Content-Type: text/html; charset=utf-8');echo $doc->html();exit;

}


$rawAlerts = [];
$seenEvents = [];
$loadedSources = [];
$logFiles = [
    'alerts.jsonl',
    'events.jsonl',
    'behaviour_events.jsonl',
    'alerts.json',
    'beelzebub/beelzebub.jsonl',
    'beelzebub/beelzebub.json'
];

$addEvent = static function ($event) use (&$rawAlerts, &$seenEvents, &$addEvent) {
    if (!is_array($event)) return;
    if (isset($event['event']) && is_array($event['event'])) {
        $event = $event['event'];
        $event['source'] = $event['source'] ?? 'honeypot';
    }
    if (isset($event['events']) && is_array($event['events'])) {
        foreach ($event['events'] as $nested) {
            if (is_array($nested)) $addEvent($nested);
        }
        return;
    }
    if (!isset($event['timestamp']) && !isset($event['DateTime']) &&
        !isset($event['incident_id']) && !isset($event['request']) &&
        !isset($event['event_type']) && !isset($event['Command'])) return;
    if (in_array(strtoupper(str_replace(' ','_', (string)($event['attack_type']??''))), ['NORMAL_TRAFFIC','NORMAL','NONE'],true)
        && empty($event['security_finding']) && empty($event['canary_hit'])) return;
    // Routine decoy telemetry is retained in JSONL, not counted as an attack.
    if (($event['source'] ?? '') === 'decoy-web' &&
        (int)($event['risk_score'] ?? 0) === 0 &&
        strtoupper((string)($event['severity'] ?? 'INFO')) === 'INFO' &&
        empty($event['canary_hit'])) return;
    // Hide SAFE informational core exports from older deployments too.
    if ((int)($event['risk_score'] ?? 0) === 0 && empty($event['canary_hit']) &&
        in_array(strtoupper((string)($event['severity'] ?? 'INFO')), ['INFO', 'SAFE'], true) &&
        !isset($event['Protocol']) && !isset($event['Command'])) return;
    $fingerprint = (string)($event['incident_id'] ?? $event['event_id'] ?? '');
    if ($fingerprint === '') $fingerprint = hash('sha256', json_encode($event));
    if (isset($seenEvents[$fingerprint])) return;
    $seenEvents[$fingerprint] = true;
    $event['incident_id'] = $event['incident_id'] ?? $event['event_id'] ?? $fingerprint;
    $rawAlerts[] = $event;
};

// Read only a bounded tail of each log. Avoid loading multi-MB JSONL files into PHP memory.
$maxLinesPerFile = 500;
$maxBytesPerFile = 2097152;
foreach ($logFiles as $filename) {
    foreach ($baseDirs as $dir) {
        $path = $dir . '/' . $filename;
        if (!is_file($path) || !is_readable($path)) continue;
        $handle = @fopen($path, 'rb');
        if ($handle === false) continue;
        $loadedSources[] = $filename;
        $size = @filesize($path);
        if ($size === false) $size = 0;
        $start = max(0, $size - $maxBytesPerFile);
        if ($start > 0) {
            fseek($handle, $start);
            fgets($handle); // Skip partial first line.
        }
        $lines = [];
        while (($line = fgets($handle)) !== false) {
            $lines[] = $line;
            if (count($lines) > $maxLinesPerFile) array_shift($lines);
        }
        fclose($handle);
        if (str_ends_with($filename, '.json') && !str_ends_with($filename, '.jsonl') && $start === 0) {
            $whole = json_decode(implode('', $lines), true);
            if (is_array($whole)) {
                if (array_is_list($whole)) {
                    foreach (array_slice($whole, -$maxLinesPerFile) as $entry) $addEvent($entry);
                } else $addEvent($whole);
            }
        } else {
            foreach ($lines as $line) {
                $event = json_decode(trim($line), true);
                if (is_array($event)) $addEvent($event);
            }
        }
        break;
    }
}

// Ingest directly from Decoy Website SQLite Database
$decoyDbPaths = [
    dirname(__DIR__) . '/decoy-website/decoy-database/decoy_website.db',
    '/var/www/decoy-website/decoy-database/decoy_website.db',
    __DIR__ . '/../decoy-website/decoy-database/decoy_website.db',
    'C:/Users/HP ProBook/Documents/decoyguard/decoy-website/decoy-database/decoy_website.db'
];

// Structured web events are authoritative; SQLite has no event IDs and would
// otherwise display the same attack again under an unrelated HP-WB identifier.
$hasStructuredWeb = false;
foreach ($rawAlerts as $entry) {
    if (($entry['source'] ?? '') === 'decoy-web' || ($entry['target_type'] ?? '') === 'decoy') {
        $hasStructuredWeb = true; break;
    }
}
foreach ($hasStructuredWeb ? [] : $decoyDbPaths as $dbPath) {
    if (file_exists($dbPath) && is_readable($dbPath)) {
        try {
            $sqlite = new PDO("sqlite:" . $dbPath);
            $sqlite->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_SILENT);
            $stmt = $sqlite->query("SELECT * FROM security_events ORDER BY id DESC LIMIT 20");
            if ($stmt) {
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    // The database also contains routine decoy interactions.
                    if (in_array(strtoupper(trim((string)($row['severity'] ?? 'INFO'))), ['INFO', 'SAFE', 'LOW'], true)) continue;
                    $cleanRowTime = isset($row['created_at']) ? date("H:i:s", strtotime($row['created_at'])) : date("H:i:s");
                    $rawAlerts[] = [
                        'incident_id' => 'HP-WB' . str_pad($row['id'], 4, '0', STR_PAD_LEFT),
                        'timestamp'   => $row['created_at'],
                        'DateTime'    => $row['created_at'],
                        'source_ip'   => $row['source_ip'],
                        'SourceIp'    => $row['source_ip'],
                        'event_type'  => $row['event_type'],
                        'severity'    => $row['severity'],
                        'details'     => $row['description'],
                        'Command'     => $row['event_type'],
                        'subsystem'   => 'DECOY_BANKING_CORE',
                        'source'      => 'honeypot',
                        'target_type' => 'honeypot',
                        'engine'      => 'Honeypot Engine',
                        'route'       => 'HONEYPOT',
                        'decision'    => 'REDIRECT',
                        'risk_score'  => (strtoupper((string)$row['severity']) === 'CRITICAL' ? 100 : 85),
                        'forensics'   => [
                            'session_log' => [
                                [
                                    'time'   => $cleanRowTime,
                                    'text'   => $row['event_type'],
                                    'output' => $row['description']
                                ]
                            ],
                            'artifacts' => []
                        ]
                    ];
                }
            }
        } catch (Exception $e) {}
        break;
    }
}

// Roll up scanner-only telemetry before the latest-feed limit. Source logs are untouched.
// Fixed session keys use a 120-second inactivity split, keeping different sites separate.
function dg_scan_feed(array $events): array {
usort($events, static fn($a,$b)=>strtotime($a['timestamp']??'')<=>strtotime($b['timestamp']??''));
$scanGroups=[];$rolled=[];
foreach($events as $event){
    $type=(string)($event['attack_type']??$event['attack']??$event['event_type']??'');
    $scanner=preg_match('/scanner|scanning|enumerat|probe/i',$type)
        && !preg_match('/sql|cross.site|xss|traversal|execution|tamper|canary|ownership/i',$type);
    if(!$scanner){$rolled[]=$event;continue;}
    $key=implode('|',[$event['site_id']??'', $event['source_ip']??$event['remote_addr']??'', $event['target_type']??'', $event['engine']??$event['source']??'']);
    $t=strtotime($event['timestamp']??'')?:0;
    $index=$scanGroups[$key]??null;
    if($index!==null && $t-($rolled[$index]['_last_epoch']??0)<=120){
        $group=&$rolled[$index];$group['probe_count']++;$group['risk']=max((int)($group['risk']??0),(int)($event['risk']??0));$group['last_seen']=$event['timestamp']??'';
        $group['_last_epoch']=$t;$group['timestamp']=$event['timestamp']??$group['timestamp'];$group['time']=$event['time']??$group['time'];
        if(count($group['sample_requests'])<8 && !in_array($event['request']??'', $group['sample_requests'],true))$group['sample_requests'][]=$event['request']??'';
        if(($event['risk_score']??$event['risk']??0)>($group['risk_score']??$group['risk']??0)){$group['risk_score']=$event['risk_score']??$event['risk'];$group['severity']=$event['severity']??$group['severity'];}
        unset($group);
    }else{
        $event['first_seen']=$event['timestamp']??'';$event['last_seen']=$event['timestamp']??'';
        $event['probe_count']=1;$event['_last_epoch']=$t;$event['sample_requests']=[$event['request']??''];
        $event['attack_type']='Scanner probing process';$event['attack']='Scanner probing process';
        $scanGroups[$key]=count($rolled);$rolled[]=$event;
    }
}
usort($rolled, static fn($a,$b)=>strtotime($b['timestamp']??'')<=>strtotime($a['timestamp']??''));
return array_slice($rolled,0,100);
}

// 2. Sort newest first
usort($rawAlerts, function($a, $b) {
    $t1 = isset($a['timestamp']) ? strtotime($a['timestamp']) : (isset($a['DateTime']) ? strtotime($a['DateTime']) : 0);
    $t2 = isset($b['timestamp']) ? strtotime($b['timestamp']) : (isset($b['DateTime']) ? strtotime($b['DateTime']) : 0);
    return $t2 <=> $t1;
});

$totalRequests = count($rawAlerts);
$critical = 0;
$high = 0;
$safe = 0;
$honeypot = 0;
$blocked = 0;

$hpTrappedEntities = [];
$hpSessions = [];
$hpCommandsCount = 0;
$hpWebRequests = 0;

$sigScore = 0;
$scnScore = 0;
$behScore = 0;
$crlScore = 0;
$appScore = 0;

$recentThreats = [];

foreach ($rawAlerts as $alert) {
    $isSsh = strtoupper((string)($alert['Protocol'] ?? '')) === 'SSH'
        || str_contains(strtoupper((string)($alert['forensics']['target_port'] ?? '')), 'SSH')
        || str_starts_with(strtoupper((string)($alert['attack_type'] ?? '')), 'SSH')
        || (($alert['source'] ?? '') === 'honeypot' && empty($alert['request']) && isset($alert['Command']) && ($alert['subsystem'] ?? '') !== 'DECOY_BANKING_CORE');
    $isWebSandbox = !$isSsh && (in_array($alert['target_type'] ?? '', ['decoy','honeypot_sandbox'], true)
        || ($alert['source'] ?? '') === 'decoy-web' || ($alert['subsystem'] ?? '') === 'DECOY_BANKING_CORE'
        || (($alert['target_type'] ?? '') === 'honeypot' && !empty($alert['request'])));
    $isHoneypotSource = $isSsh || $isWebSandbox;

    // Calculate live metrics based on normalized IP
    $sourceIp = $alert["source_ip"] ?? $alert["SourceIp"] ?? $alert["remote_addr"] ?? $alert["ip"] ?? "Unknown";
    if (strpos($sourceIp, ':') !== false) {
        if (substr_count($sourceIp, ':') === 1) $sourceIp = explode(':', $sourceIp)[0];
    }

    if ($isHoneypotSource) {
        $entityKey = ($alert["site_id"] ?? ($isSsh ? "ssh" : "web"))."|".$sourceIp;
        $hpTrappedEntities[$entityKey] = true;
        $hpSessions[(string)($alert["session_id"] ?? $alert["SessionID"] ?? $entityKey)] = true;

        if ($isWebSandbox) $hpWebRequests++;
        if ($isSsh && !empty($alert["Command"])) {
            $hpCommandsCount++;
        }
    }

    // Dynamic risk extraction
    $risk = (int)($alert["risk_score"] ?? $alert["score"] ?? $alert["risk"] ?? 0);
    if ($risk === 0 && $isHoneypotSource && strtoupper(trim((string)($alert['severity'] ?? ''))) !== 'INFO') {
        if (!empty($alert["Command"])) $risk = 85;
        elseif (!empty($alert["Password"])) $risk = 60;
        else $risk = 40;
    }

    // Preserve the source engine's severity; only infer it if missing.
    $rawSeverity = strtoupper(trim((string)($alert["severity"] ?? '')));
    if ($rawSeverity !== '' && $rawSeverity !== 'INFO') {
        $severity = $rawSeverity;
    } elseif ($risk >= 300) {
        $severity = 'CRITICAL';
    } elseif ($risk >= 225) {
        $severity = 'VERY HIGH';
    } elseif ($risk >= 150) {
        $severity = 'HIGH';
    } elseif ($risk >= 85) {
        $severity = 'MEDIUM';
    } elseif ($risk >= 30) {
        $severity = 'LOW';
    } else {
        $severity = 'SAFE';
    }

    $decision = strtoupper(trim($alert["decision"] ?? ($isHoneypotSource ? "HONEYPOT" : "ALLOW")));
    $route    = strtoupper(trim($alert["route"] ?? ($isHoneypotSource ? "HONEYPOT" : "")));
    
    // Label real SSH actions or Web Sandbox Traps
    if ($isWebSandbox) {
        $attack = "[WEB] " . ($alert["attack_type"] ?? $alert["event_type"] ?? "EXPLOIT") . ": " . ($alert["details"] ?? "");
    } elseif ($isHoneypotSource) {
        if (!empty($alert["Password"]) || ($alert["Msg"] ?? "") === "New SSH Login Attempt") {
            $attack = "SSH Auth Attempt: " . (($alert["User"] ?? "root"));
        } elseif (!empty($alert["Command"])) {
            $attack = "SSH Command: " . $alert["Command"];
        } else {
            $attack = "Honeypot SSH Session";
        }
    } else {
        $attack = $alert["attack_type"] ?? $alert["event_type"] ?? $alert["attack"] ?? "Normal Traffic";
    }

    $incidentId = $alert["incident_id"] ?? '';
    if (empty($incidentId)) {
        $incidentId = $isHoneypotSource ? "HP-" . substr(md5(json_encode($alert)), 0, 8) : "DG-" . substr(md5(json_encode($alert)), 0, 8);
    }
    
    $engine = $alert["engine"] ?? ($isHoneypotSource ? "Honeypot Engine" : (strpos($incidentId, 'BE-') === 0 ? "Behaviour Engine" : "DecoyGuard"));

    // KPI Counters
    if ($severity === "CRITICAL") $critical++;
    elseif (in_array($severity, ["HIGH", "VERY HIGH"], true)) $high++;
    elseif (in_array($severity, ["SAFE", "INFO"], true)) $safe++;

    if ($route === "HONEYPOT" || $decision === "HONEYPOT" || $decision === "REDIRECT" || ($alert["target_type"] ?? "") === "honeypot" || $isHoneypotSource) {
        $honeypot++;
    }
    if (in_array($decision, ["ISOLATE", "BLOCK", "ISOLATED"])) {
        $blocked++;
    }

    // Engine Accumulators for 4-Engine Chart
    if (isset($alert["risk_breakdown"])) {
        $rb = $alert["risk_breakdown"];
        $appScore = max($appScore, (int)($rb["application"]["score"] ?? 0));
        $sigScore = max($sigScore, (int)($rb["signature"]["score"] ?? 0));
        $scnScore = max($scnScore, (int)($rb["scanner"]["score"] ?? 0));
        $behScore = max($behScore, (int)($rb["behaviour"]["score"] ?? 0));
        $crlScore = max($crlScore, (int)($rb["correlation"]["score"] ?? 0));
    } else {
        if ($isSsh) {
            // SSH telemetry does not imply a correlation-engine finding.
        } elseif (stripos($attack, 'SQL') !== false || stripos($attack, 'XSS') !== false || stripos($attack, 'TRAVERSAL') !== false) {
            $sigScore = max($sigScore, $risk);
        } elseif (stripos($attack, 'SCANNER') !== false || stripos($attack, 'ENUM') !== false || stripos($attack, 'NMAP') !== false || stripos($attack, 'NIKTO') !== false) {
            $scnScore = max($scnScore, $risk);
        } else {
            $behScore = max($behScore, $risk);
        }
    }

    // Extract forensics from real command logs
    $forensics = $alert["forensics"] ?? null;
    $timestampStr = $alert["timestamp"] ?? $alert["DateTime"] ?? null;
    $cleanTime = $timestampStr ? date("H:i:s", strtotime($timestampStr)) : date("H:i:s");

    if ($isHoneypotSource && empty($forensics)) {
        $cmd = $alert["Command"] ?? $alert["request"] ?? "";
        $out = trim($alert["CommandOutput"] ?? "");
        $artifacts = [];

        // Payload extraction from observed wget/curl commands
        if (!empty($cmd) && preg_match('/(?:wget|curl).*?(?:https?:\/\/\S+\/(\S+))/i', $cmd, $match)) {
            $filename = basename($match[1]);
            $artifacts[] = [
                "name"        => $filename,
                "artifact_id" => hash('sha256', $filename),
                "source_cmd"  => $cmd
            ];
        }

        $forensics = [
            "target_port" => $isWebSandbox ? "HTTP / web decoy" : "2222 / SSH",
            "client_tool" => ($alert["Client"] ?? ($isWebSandbox ? "Not recorded" : "SSH Terminal Client")),
            "session_log" => !empty($cmd) ? [
                [
                    "time"   => $cleanTime,
                    "text"   => $cmd,
                    "output" => $out
                ]
            ] : [],
            "artifacts" => $artifacts
        ];
    }

    // Determine lifecycle stage
    $attackStage = $alert["attack_stage"] ?? null;
    if (empty($attackStage)) {
        if ($isHoneypotSource || $decision === "HONEYPOT" || $decision === "REDIRECT") {
            $attackStage = "CONTAINED";
        } elseif ($risk >= 100 || stripos($attack, 'SQL') !== false || stripos($attack, 'COMMAND') !== false) {
            $attackStage = "EXPLOITATION";
        } elseif ($risk >= 60 || stripos($attack, 'SCANNER') !== false) {
            $attackStage = "RECONNAISSANCE";
        } else {
            $attackStage = "NORMAL";
        }
    }

    // Build event object
    if ($risk > 0 || $severity !== "SAFE" || $isHoneypotSource) {
        $threat = [
            "incident_id"  => $incidentId,
            "timestamp" => $alert["timestamp"] ?? $alert["DateTime"] ?? null,
            "time"         => $cleanTime,
            "source_ip"    => $sourceIp,
            "attack"       => str_replace("_", " ", $attack),
            "risk"         => $risk,
            "severity"     => $severity,
            "decision"     => $decision,
            "attack_stage" => $attackStage,
            "engine"       => $engine,
            "forensics"    => $forensics,
            "request" => $alert["request"] ?? "",
            "site_id" => $alert["site_id"] ?? "",
            "target_type" => $alert["target_type"] ?? ($isHoneypotSource ? "honeypot" : "production"),
            "channel" => $isWebSandbox ? "web" : ($isHoneypotSource ? "ssh" : "production"),
            "route" => $route,
            "confidence" => $alert["confidence"] ?? "MEDIUM",
            "risk_breakdown" => $alert["risk_breakdown"] ?? [],
            "risk_calculation" => $alert["risk_calculation"] ?? [],
            "status" => $alert["status"] ?? null,
            "event_type" => $alert["event_type"] ?? null,
            "probe_count" => $alert["probe_count"] ?? null,
            "first_seen" => $alert["first_seen"] ?? null,
            "last_seen" => $alert["last_seen"] ?? null,
            "mitre_tags" => is_array($alert["mitre_tags"] ?? null) ? $alert["mitre_tags"] : (is_array($forensics["mitre_tags"] ?? null) ? $forensics["mitre_tags"] : []),
            "security_finding" => $alert["security_finding"] ?? null,
            "exploit_result" => $alert["exploit_result"] ?? null
        ];

        if (!empty($alert["Password"])) {
            $threat["auth_attempt"] = [
                "user"     => ($alert["User"] ?? "root"),
                "password" => "[REDACTED]"
            ];
        }

        $recentThreats[] = $threat;
    }
}

$recentThreats = dg_scan_feed($recentThreats);

// Fallback baseline if no alerts exist
if (empty($recentThreats) && $totalRequests > 0) {
    foreach (array_slice($rawAlerts, 0, 8) as $alert) {
        $recentThreats[] = [
            "incident_id"  => $alert["incident_id"] ?? "DG-000",
            "time"         => isset($alert["timestamp"]) ? date("H:i:s", strtotime($alert["timestamp"])) : date("H:i:s"),
            "source_ip"    => $alert["source_ip"] ?? $alert["ip"] ?? "-",
            "attack"       => "Normal Traffic",
            "risk"         => 0,
            "severity"     => "SAFE",
            "decision"     => "ALLOW",
            "attack_stage" => "NORMAL",
            "engine"       => "DecoyGuard"
        ];
    }
}

// Select active incident: prioritize highest active threat so normal browsing doesn't reset dashboard
$relevantAlert = [];
foreach ($recentThreats as $th) {
    if (!empty($th["risk"]) && $th["risk"] >= 25) {
        $relevantAlert = $th;
        break;
    }
}
if (empty($relevantAlert)) {
    $relevantAlert = !empty($recentThreats) ? $recentThreats[0] : ($totalRequests > 0 ? $rawAlerts[0] : []);
}

$latestRisk = (int)($relevantAlert["risk"] ?? $relevantAlert["risk_score"] ?? 0);
$rawConfidence = strtoupper(trim($relevantAlert["confidence"] ?? "MEDIUM"));
$confidenceMap = ["LOW" => 30, "MEDIUM" => 60, "HIGH" => 85, "VERY HIGH" => 100];
$confidence = $confidenceMap[$rawConfidence] ?? 60;

// Website-aware attack trend: retained, attributed incidents only.
// The existing "trend" field is preserved for older dashboard clients.
$trendBySite = [];
$trendSeverity = ['low'=>0, 'medium'=>0, 'high'=>0, 'critical'=>0];
$trendEvents = [];
foreach (array_reverse($recentThreats) as $th) {
    $severity = strtoupper((string)($th['severity'] ?? ''));
    $risk = (int)($th['risk'] ?? 0);
    if (preg_match('/normal[ _]traffic|decoy[ _]interaction/i', (string)($th['attack'] ?? '')) || (in_array($severity, ['SAFE','INFO'], true) && $risk <= 0)) continue;
    $tier = in_array($severity, ['CRITICAL','VERY HIGH'], true) ? 'critical'
        : ($severity === 'HIGH' ? 'high'
        : ($severity === 'MEDIUM' ? 'medium'
        : ($severity === 'LOW' ? 'low'
        : ($risk >= 300 ? 'critical' : ($risk >= 150 ? 'high' : ($risk >= 85 ? 'medium' : 'low'))))));
    $site = trim((string)($th['site_id'] ?? ''));
    if ($site === '') $site = 'unattributed';
    $trendBySite[$site] ??= ['total'=>0, 'low'=>0, 'medium'=>0, 'high'=>0, 'critical'=>0];
    $trendBySite[$site]['total']++;
    $trendBySite[$site][$tier]++;
    $trendSeverity[$tier]++;
    $trendEvents[] = [
        'incident_id'=>(string)($th['incident_id'] ?? ''),'site_id'=>$site, 'time'=>(string)($th['time'] ?? ''),
        'timestamp'=>$th['timestamp'] ?? null,'epoch'=>!empty($th['timestamp']) && strtotime((string)$th['timestamp'])!==false ? strtotime((string)$th['timestamp']) : null,
        'severity'=>$severity,'tier'=>$tier,'risk'=>$risk,'attack'=>(string)($th['attack'] ?? ''),'target_type'=>$th['target_type'] ?? '', 'channel'=>$th['channel'] ?? '', 'request'=>$th['request'] ?? '', 'source_ip'=>$th['source_ip'] ?? ''
    ];
}

// Threat Trend (Latest 8 events)
$trendLabels = [];
$trendData = [];
$chronologicalAlerts = array_slice(array_reverse($rawAlerts), -8);

foreach ($chronologicalAlerts as $a) {
    $timestampVal = $a["timestamp"] ?? $a["DateTime"] ?? null;
    $trendLabels[] = $timestampVal ? date("H:i:s", strtotime($timestampVal)) : "--:--";
    $trendData[] = (int)($a["risk_score"] ?? $a["score"] ?? 0);
}



// Use the same fallback severity thresholds as the Python analyzer.
$computedLatestSeverity = 'SAFE';
if ($latestRisk >= 300) {
    $computedLatestSeverity = 'CRITICAL';
} elseif ($latestRisk >= 225) {
    $computedLatestSeverity = 'VERY HIGH';
} elseif ($latestRisk >= 150) {
    $computedLatestSeverity = 'HIGH';
} elseif ($latestRisk >= 85) {
    $computedLatestSeverity = 'MEDIUM';
} elseif ($latestRisk >= 30) {
    $computedLatestSeverity = 'LOW';
}

$response = [
    "ingestion" => ["sources" => $loadedSources, "events_loaded" => count($rawAlerts), "status" => empty($loadedSources) ? "NO_LOG_FILES_FOUND" : "OK"],
    "stats" => [
        "total_requests" => $totalRequests,
        "critical"       => $critical,
        "high"           => $high,
        "safe"           => $safe,
        "honeypot"       => $honeypot,
        "blocked"        => $blocked,
        "hp_trapped"     => count($hpTrappedEntities),
        "hp_sessions"    => count($hpSessions),
        "hp_commands"    => $hpCommandsCount,
        "hp_web_requests" => $hpWebRequests,
        "total_alerts" => $totalRequests,
        "scope" => "Retained log tail; session counts use visitor identity when session IDs are absent"
    ],
    "gauges" => [
        "risk"       => $latestRisk,
        "confidence" => $confidence
    ],
    "trend_by_site" => $trendBySite,
    "trend_severity" => $trendSeverity,
    "trend_events" => $trendEvents,
    "trend" => [
        "labels" => count($trendLabels) > 0 ? $trendLabels : [],
        "data"   => count($trendData) > 0 ? $trendData : []
    ],
    "risk" => [$sigScore, $scnScore, $behScore, $crlScore, $appScore],
    "ssh" => array_values(array_filter($recentThreats, static fn($e)=>$e["channel"] === "ssh")),
    "web" => array_values(array_filter($recentThreats, static fn($e)=>$e["channel"] === "web")),
    "latest" => [
        "incident_id"  => $relevantAlert["incident_id"] ?? "DG-000",
        "site_id" => $relevantAlert["site_id"] ?? "",
        "channel" => $relevantAlert["channel"] ?? "",
        "target_type" => $relevantAlert["target_type"] ?? "",
        "source_ip"    => $relevantAlert["source_ip"] ?? "-",
        "attack_type"  => $relevantAlert["attack"] ?? "Normal Traffic",
        "attack_stage" => $relevantAlert["attack_stage"] ?? ($latestRisk >= 80 ? "EXPLOITATION" : ($latestRisk >= 40 ? "RECONNAISSANCE" : "NORMAL")),
        "severity"     => !empty($relevantAlert["severity"]) && $relevantAlert["severity"] !== "SAFE" ? $relevantAlert["severity"] : $computedLatestSeverity,
        "decision"     => strtoupper($relevantAlert["decision"] ?? ($latestRisk >= 60 ? "REDIRECT" : "ALLOW"))
    ],
    "recent" => $recentThreats
];

echo json_encode($response, JSON_PRETTY_PRINT);
exit();