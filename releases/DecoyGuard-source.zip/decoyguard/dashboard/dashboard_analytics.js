/* DecoyGuard analytic widgets: evidence-only, read-only. */
(()=>{'use strict';
const defs = {
 trapHits:['Total Decoy Hits','Selected feed · decoy-targeted records'],trapIsolation:['Recorded Containment Ratio','Recorded decoy/redirect outcomes'],trapFiles:['Captured Artifacts','Unique supplied artifact entries'],trapPrimary:['Most Frequent Source IP','Recorded address · not verified adversary identity'],
 postureSummary:['Security Posture','Selected latest feed · historical trend has its own period'],
 riskContainment:['Risk Bands & Containment Decisions','Numeric score bands and recorded response decisions'],
 trapSummary:['Honeypot Evidence Summary','Selected feed · decoy-targeted records only'],
 trapTaxonomy:['Attack Taxonomy Breakdown','Recorded classes among decoy-targeted records'],
 trapTranscript:['Honeypot Transcript','Read-only captured command and HTTP evidence'],
 trapEvidence:['Captured Artifacts & Sources','Supplied metadata · no quarantine or listener state inferred'],
 trapRouting:['Response Routing & Containment','Recorded decisions among decoy-targeted records'],
 trapActivity:['Decoy Activity Stream','Selected feed filtered to recorded decoy/honeypot targets'], 
 incidentDock:['Session Context & Forensics','Selected source · recorded evidence only'],
 incidentBanner:['Summary & Recorded Threat Stage','Source-attributed context and latest supplied stage'],
 portExposure:['Port & Service Evidence','Recorded target details · not an exposure scan'],
 incidentTriage:['Incident Triage','Source-attributed evidence · selected feed'],
 payloadInspector:['Payload & Telemetry Inspector','Select a sequence record to inspect its supplied telemetry'],
 incidentSource:['Investigated Source','Source address · not verified session identity'],
 incidentPort:['Recorded Target Port','Only ports explicitly supplied in evidence'],
 incidentFiles:['Captured Artifacts','Unique artifacts supplied for this source'],
 incidentDuration:['Observed Time Span','First to last record · not connection duration'],
 incidentProgress:['Incident Progression','Latest recorded stage · previous stages are not inferred'],
 artifactInspector:['Captured Artifacts Inspector','Supplied artifact metadata · no quarantine status inferred'],
 incidentRouting:['Containment & Traffic Routing','Recorded decisions for the investigated source'],
  sourceInvestigation: ['Source Investigation','Selected latest feed · source IP attribution'],
  intelMitre: ['Reported ATT&CK IDs','Selected feed · supplied identifiers'],
  intelContained: ['Decoy / Redirect Decisions','Selected feed · recorded decisions'],
  behaviourEvidence: ['Behavioural Pattern Evidence','Selected feed · counts and supplied rule evidence'],
  intelRisk: ['Latest Global Score','Latest global assessment'],
  intelConfidence: ['Recorded Confidence','Latest global assessment'],
  intelReporters: ['Reporting Engines in Feed','Selected feed · observed reporters'],
  intelDecision: ['Latest Global Decision','Recorded response · global assessment'],
  engineEventLog: ['Recent Engine Findings', 'Selected feed · individual detector records'],
  attackSequence: ['Attack Sequence — Table', 'Chronological requests · separate method and endpoint columns'],
  attackSequenceTimeline: ['Attack Sequence — Timeline', 'Connected source activity · expandable supplied evidence'],
  attackHeatmap: ['24-Hour Activity Density', 'Last 24 hours within selected feed · device-local hour'],
  riskDistribution: ['Risk Distribution', 'Observed risk score bands'],
  detectionBreakdown: ['Events by Reporting Engine', 'Record counts by reporter · not score contribution'],
  containmentFlow: ['Response & Containment', 'Recorded response decisions · summary or flow'],
  mitreProgression: ['Reported ATT&CK Evidence', 'Technique IDs explicitly recorded in source evidence'],
  forensicTerminal: ['Honeypot Terminal & Artifacts', 'Read-only captured commands and trapped session logs']
};

const main = document.querySelector('main');
if (!main) return;

const staging = document.createElement('section');
staging.style.display = 'none';
main.append(staging);

const nodes = {};
for (const [id, [title, description]] of Object.entries(defs)) {
  const panel = document.createElement('article');
  panel.className = 'panel-box dg-analytics'+((id.startsWith('intel')||['trapHits','trapIsolation','trapFiles','trapPrimary'].includes(id))?' kpi-card dg-intel-kpi':'');
  panel.dataset.dashboardPanel = id;
  const h = document.createElement('h3');
  h.textContent = title;
  const p = document.createElement('p');
  p.className = 'dg-note';
  p.textContent = description;
  const b = document.createElement('div');
  b.innerHTML = '<div class="dg-empty">Waiting for SOC data…</div>';
  panel.append(h, p, b);
  staging.append(panel);
  nodes[id] = b;
}

const sitePanel = document.querySelector('[data-dashboard-panel="siteChart"]');
if (sitePanel) {
  sitePanel.replaceChildren();
  const siteHeading = document.createElement('h3');
  siteHeading.textContent = 'Monitoring Coverage & Targeted Endpoints';
  sitePanel.append(siteHeading);
  const siteNote = document.createElement('p');
  siteNote.className = 'dg-note';
  siteNote.textContent = 'Selected detection scope · file scan diagnostics and targeted request paths';
  sitePanel.append(siteNote);
  nodes.siteOverview = document.createElement('div');
  sitePanel.append(nodes.siteOverview);
}

const modes = {};
try {
  Object.assign(modes, JSON.parse(localStorage.getItem('dg-widget-views-v1') || '{}'));
} catch (_) {}

function addViews(panel, id, options) {
  if (!panel) return;
  const controls = document.createElement('div');
  controls.className = 'dg-widget-views';
  controls.setAttribute('role', 'group');
  controls.setAttribute('aria-label', id === 'siteOverview' ? 'Website display' : 'Response display');
  for (const [value, label] of options) {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = label;
    b.dataset.widgetView = value;
    b.setAttribute('aria-pressed', String((modes[id] || options[0][0]) === value));
    b.addEventListener('click', () => {
      modes[id] = value;
      try {
        localStorage.setItem('dg-widget-views-v1', JSON.stringify(modes));
      } catch (_) {}
      for (const x of controls.children) x.setAttribute('aria-pressed', String(x === b));
      if (last) render(last, true);
    });
    controls.append(b);
  }
  panel.insertBefore(controls, panel.lastElementChild);
}

// The combined monitoring panel has one consolidated view.
if (nodes.containmentFlow?.parentNode) addViews(nodes.containmentFlow.parentNode, 'response', [['summary', 'Summary'], ['flow', 'Flow']]);

let signature = '';
let sites = [], last = null, history = null;
const hiddenPatterns=new Set();

const str = v => String(v ?? '');
const escape = v => str(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const empty = (s = 'No matching retained evidence available.') => `<div class="dg-empty">${escape(s)}</div>`;
const row = (a, b) => `<div class="dg-row"><span>${escape(a)}</span><b>${escape(b)}</b></div>`;
const tile = (a, b, c = '') => `<div class="dg-tile"><span class="dg-kicker">${escape(a)}</span><strong>${escape(b)}</strong><small>${escape(c)}</small></div>`;
const bar = (v, max, color = 'var(--dg-accent)') => `<div class="dg-bar"><i style="width:${max ? Math.min(100, 100 * v / max) : 0}%;background:${color}"></i></div>`;
const count = (a, fn) => a.reduce((m, x) => { const k = fn(x); if (k) m.set(k, (m.get(k) || 0) + 1); return m; }, new Map());
const ranked = m => [...m].sort((a, b) => b[1] - a[1]);
const color = () => window.dgThemePalette?.series || ['#118ab2', '#ef476f', '#06d6a0', '#ffd166', '#073b4c'];

function formatSequenceRequest(raw) {
  if (!raw) return 'Normal Traffic';
  let s = str(raw).replace(/(undefined)+/gi, '').trim();
  s = s.replace(/(\?[^\s]+)/, '');
  return s || 'Normal Request';
}

const triageState={method:'',status:'',event:'',format:'raw'};
function triageEventKey(e){return str(e.event_id||e.incident_id||JSON.stringify([e._time,e.request,e._decision,e._site]));}
function safeEvidence(value){
 if(Array.isArray(value))return value.map(safeEvidence);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).filter(([k])=>!k.startsWith('_')).map(([k,v])=>[k,/password|authorization|cookie|secret|token|api.?key/i.test(k)?'[REDACTED]':safeEvidence(v)]));
 return value;
}
function decodeEvidence(value){if(typeof value==='string'){try{return decodeURIComponent(value);}catch{return value;}}if(Array.isArray(value))return value.map(decodeEvidence);if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,decodeEvidence(v)]));return value;}
function incidentMethod(e){
 const supplied=str(e.method).trim().toUpperCase();
 if(supplied)return supplied;
 const match=str(e.request).match(/^([A-Z]+)\s+\S+/);return match?match[1]:'';
}
function incidentEndpoint(e){
 const direct=e.uri||e.path||e.endpoint;
 if(direct)return str(direct);
 const match=str(e.request).match(/^[A-Z]+\s+(\S+)/);return match?match[1]:str(e.request||'Not supplied');
}
function incidentBadge(value,kind){
 const label=str(value||'Not supplied');const normalized=label.toUpperCase();
 const tone=kind==='severity'?(['CRITICAL','VERY HIGH'].includes(normalized)?'critical':normalized==='HIGH'?'high':normalized==='MEDIUM'?'medium':normalized==='LOW'?'low':'neutral'):['CONTAINED','REDIRECT','HONEYPOT','REDIRECT_TO_HONEYPOT'].includes(normalized)?'contained':['BLOCK','BLOCKED','ISOLATE','ISOLATED'].includes(normalized)?'critical':normalized==='ALLOW'?'low':'neutral';
 return '<span class="dg-sequence-badge dg-sequence-'+tone+'">'+escape(label)+'</span>';
}
function renderIncidentSequence(events,selected,timeline){
 const time=e=>Number.isFinite(Date.parse(e._time))?new Date(e._time).toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'Not supplied';
 if(!events.length)return empty('No records match these filters.');
 if(timeline)return '<ol class="dg-forensic-sequence">'+events.map((e,i)=>{
  const details=e.reasons||e.details||e.detection_text;
  const text=Array.isArray(details)?details.map(str).join(' · '):details&&typeof details==='object'?JSON.stringify(safeEvidence(details)):str(details);
  return '<li class="'+(e===selected?'is-selected':'')+'"><div class="dg-forensic-sequence-row"><time title="'+escape(e._time)+'">'+escape(time(e))+'</time><span class="dg-sequence-method">'+escape(incidentMethod(e)||'—')+'</span><button type="button" data-triage-record="'+i+'" aria-pressed="'+(e===selected)+'" title="'+escape(incidentEndpoint(e))+'">'+escape(incidentEndpoint(e))+'</button>'+incidentBadge(e._decision,'decision')+incidentBadge(e._severity,'severity')+'</div>'+(text?'<details class="dg-sequence-evidence"><summary>Supplied detection evidence</summary><p>'+escape(text)+'</p></details>':'')+'</li>';
 }).join('')+'</ol>';
 return '<div class="dg-sequence-table-wrap"><table class="dg-incident-table dg-sequence-table"><thead><tr><th>Time</th><th>Method</th><th>Endpoint / Path</th><th>Decision</th><th>Severity</th></tr></thead><tbody>'+events.map((e,i)=>'<tr class="'+(e===selected?'dg-selected-record':'')+'"><td title="'+escape(e._time)+'">'+escape(time(e))+'</td><td><span class="dg-sequence-method">'+escape(incidentMethod(e)||'—')+'</span></td><td><button type="button" data-triage-record="'+i+'" aria-pressed="'+(e===selected)+'" title="'+escape(incidentEndpoint(e))+'">'+escape(incidentEndpoint(e))+'</button></td><td>'+incidentBadge(e._decision,'decision')+'</td><td>'+incidentBadge(e._severity,'severity')+'</td></tr>').join('')+'</tbody></table></div>';
}
function policyOutcomeCounts(rows){
 const counts={decoy:0,allowed:0,monitored:0,blocked:0,other:0};
 for(const e of rows){const decision=String(e._decision||e.decision||'').toUpperCase(),route=String(e._route||e.route||'').toUpperCase();
 if(['HONEYPOT','DECOY'].includes(route)||['HONEYPOT','REDIRECT','REDIRECT_TO_HONEYPOT','CONTAINED'].includes(decision))counts.decoy++;
 else if(['BLOCK','BLOCKED','DROP','ISOLATE','ISOLATED'].includes(decision))counts.blocked++;
 else if(['ALLOW','ALLOWED','PASS'].includes(decision))counts.allowed++;
 else if(['MONITOR','MONITORED','MONITOR_DECOY'].includes(decision))counts.monitored++;
 else counts.other++;
 }return counts;
}
function renderPolicyMatrix(rows){
 const counts=policyOutcomeCounts(rows),total=rows.length;
 const definitions=[['decoy','Decoy / Redirect','Recorded containment outcome','shield-halved','purple'],['allowed','Allowed','Recorded allow decision','check','success'],['monitored','Monitored','Recorded monitor decision','eye','info'],['blocked','Blocked','Recorded block / isolation','ban','danger'],['other','Other / Unspecified','Retained without guessing an outcome','circle-question','warning']];
 return '<div class="dg-policy-matrix-heading"><span>Recorded outcome baseline</span><strong>'+total+' records</strong></div><div class="dg-policy-matrix">'+definitions.filter(([key],i)=>i<3||counts[key]>0).map(([key,label,note,icon,tone])=>'<article class="'+(counts[key]?'':'is-zero')+'" style="--policy-color:var(--dg-'+tone+')"><div><i class="fa-solid fa-'+icon+'" aria-hidden="true"></i><span>'+label+'</span></div><strong>'+counts[key]+' <small>('+ (total?Math.round(counts[key]/total*100)+'%':'—')+')</small></strong><p>'+note+'</p></article>').join('')+'</div><p class="dg-note">Selected-feed decisions. These counters do not prove sandbox execution or measure traffic reaching production.</p>';
}
function renderRecordedStageIndicator(stage,response){
 const labels=[['NORMAL','Normal'],['SUSPICIOUS','Suspicious'],['DETECTED','Detected'],['ESCALATED','Escalated'],['HONEYPOT','Honeypot']];
 return '<section class="dg-recorded-path"><span class="dg-recorded-path-kicker">INCIDENT PATH</span><h4>Latest Stage Indicator</h4><div class="dg-recorded-path-nodes">'+labels.map(([value,label])=>'<div class="dg-recorded-path-node '+(stage===value?'is-current':'')+'"><span class="dg-recorded-path-dot" aria-hidden="true">•</span><span>'+label+'</span>'+(stage===value?'<span class="dg-sr-only">Current recorded stage</span>':'')+'</div>').join('')+'</div><div class="dg-recorded-path-context"><div><span>Reported stage</span><strong>'+escape(stage||'Not supplied')+'</strong></div><div><span>Recorded response</span><strong>'+escape(response||'Not supplied')+'</strong></div></div><p class="dg-note">Latest assessment for the investigated source. Highlighted stage does not prove every preceding step occurred.</p></section>';
}
function incidentInfoCards(items){
 return '<div class="dg-incident-info-cards">'+items.map(([label,value])=>'<article><span>'+escape(label)+'</span><strong title="'+escape(value||'Not supplied')+'">'+escape(value||'Not supplied')+'</strong></article>').join('')+'</div>';
}
function incidentPortSummary(ports){
 const values=[...new Set(ports.map(port=>{const match=str(port).match(/^\s*(\d{1,5})(?:\s*\/\s*([A-Za-z][A-Za-z0-9-]*))?/);return match?match[1]+(match[2]?' / '+match[2].toUpperCase():''):str(port);} ))];
 return values.join(', ')||'Not supplied';
}
function renderArtifactCards(artifacts){
 if(!artifacts.length)return empty('No captured artifacts supplied for this source.');
 return '<div class="dg-artifact-cards">'+artifacts.map(a=>'<article><div class="dg-artifact-heading"><i class="fa-solid fa-file-lines" aria-hidden="true"></i><strong>'+escape(a.name||a.filename||'Unnamed artifact')+'</strong><span>'+escape(a.status||'Status not supplied')+'</span></div><dl><div><dt>Hash supplied</dt><dd><code>'+escape(a.sha256||a.hash||'Not supplied')+'</code></dd></div><div><dt>Size supplied</dt><dd>'+escape(a.size??'Not supplied')+'</dd></div></dl></article>').join('')+'</div>';
}
function renderTriage(rows,sources,src,ports,span){
 const latest=rows.at(-1),targets=[...new Set(rows.map(e=>e._site).filter(Boolean))];
 const duration=span===null?'Not supplied':Math.floor(span/86400)+'d '+Math.floor(span%86400/3600)+'h '+Math.floor(span%3600/60)+'m '+span%60+'s';
 if(nodes.incidentTriage)nodes.incidentTriage.innerHTML=incidentInfoCards([['Target',targets.join(', ')],['Source IP',src],['Observed span',duration],['Recorded port',incidentPortSummary(ports)],['Latest decision',latest?._decision]])+'<p class="dg-note">Source grouping, not a verified session. Span includes gaps. '+ports.length+' supplied port/service descriptions.</p>';

 const method=incidentMethod;
 const filtered=rows.filter(e=>(!triageState.method||method(e)===triageState.method)&&(!triageState.status||str(e.status)===triageState.status));
 let selected=filtered.find(e=>triageEventKey(e)===triageState.event)||filtered.at(-1);triageState.event=selected?triageEventKey(selected):'';
 const options=(values,selected,label)=>'<option value="">'+label+'</option>'+[...new Set(values.filter(Boolean))].sort().map(v=>'<option value="'+escape(v)+'" '+(v===selected?'selected':'')+'>'+escape(v)+'</option>').join('');
 for(const [host,timeline] of [[nodes.attackSequence,false],[nodes.attackSequenceTimeline,true]]){if(!host)continue;host.innerHTML='<div class="dg-triage-filters"><label>Source<select data-triage-source>'+sources.map(([ip,n])=>'<option value="'+escape(ip)+'" '+(ip===src?'selected':'')+'>'+escape(ip)+' · '+n+'</option>').join('')+'</select></label><label>Method<select data-triage-method>'+options(rows.map(method),triageState.method,'All methods')+'</select></label><label>Status<select data-triage-status>'+options(rows.map(e=>str(e.status)),triageState.status,'All statuses')+'</select></label><span>'+filtered.length+' / '+rows.length+' records</span></div>'+renderIncidentSequence(filtered,selected,timeline);
 host.querySelector('[data-triage-source]')?.addEventListener('change',e=>{nodes.attackSequence.dataset.src=e.target.value;triageState.event='';render(last,true);});
 for(const field of ['method','status'])host.querySelector('[data-triage-'+field+']')?.addEventListener('change',e=>{triageState[field]=e.target.value;render(last,true);});
 for(const button of host.querySelectorAll('[data-triage-record]'))button.addEventListener('click',()=>{triageState.event=triageEventKey(filtered[Number(button.dataset.triageRecord)]);render(last,true);});}
 if(nodes.payloadInspector){const evidence=selected?safeEvidence(selected):null;const matched=selected?.reasons||selected?.details||selected?.detection_text||'Not supplied';nodes.payloadInspector.innerHTML='<div class="dg-payload-modes">'+['raw','decoded','headers','matched'].map(mode=>'<button class="settings-action" type="button" data-payload-mode="'+mode+'" aria-pressed="'+(triageState.format===mode)+'">'+mode.toUpperCase()+'</button>').join('')+'</div>'+(selected?'<dl class="dg-payload-metadata">'+[['Timestamp',selected._time],['Source',src],['Endpoint',selected.request||selected.uri],['HTTP status',selected.status],['Matched evidence',Array.isArray(matched)?matched.join('; '):matched]].map(([k,v])=>'<div><dt>'+k+'</dt><dd>'+escape(v??'Not supplied')+'</dd></div>').join('')+'</dl><pre class="dg-incident-terminal">'+escape(JSON.stringify(triageState.format==='decoded'?decodeEvidence(evidence):triageState.format==='headers'?(evidence.headers||evidence.request_headers||'Headers not supplied'):triageState.format==='matched'?safeEvidence({matched}):evidence,null,2))+'</pre>':empty('Select an available record.'))+'<p class="dg-note">RAW shows the supplied event fields, not original network bytes. DECODED applies URL decoding once. HEADERS and MATCHED show supplied fields only. Secrets remain redacted; payloads are displayed as text.</p>';
 for(const button of nodes.payloadInspector.querySelectorAll('[data-payload-mode]'))button.addEventListener('click',()=>{triageState.format=button.dataset.payloadMode;render(last,true);});}
}

let investigatedSource='';
function renderSourceInvestigation(events){
 const host=nodes.sourceInvestigation;if(!host)return;
 const sources=ranked(count(events,e=>e._src)).filter(([ip])=>ip&&ip!=='-');
 if(!investigatedSource&&sources.length)investigatedSource=sources[0][0];
 if(!host.querySelector('.dg-source-selector')){
  host.innerHTML='<label class="dg-source-selector">Source IP<select aria-label="Source IP to investigate"></select></label><div class="dg-source-actions"><button type="button" class="settings-action" data-source-apply>Filter Activity Stream</button><button type="button" class="settings-action" data-source-clear>Clear stream filter</button></div><p class="dg-source-filter-state dg-note" role="status"></p><div class="dg-source-detail"></div>';
  host.querySelector('select').addEventListener('change',e=>{investigatedSource=e.target.value;if(last)render(last,true);});
  host.querySelector('[data-source-apply]').addEventListener('click',()=>{if(investigatedSource)window.dispatchEvent(new CustomEvent('dg:activity-source',{detail:investigatedSource}));if(last)render(last,true);});
  host.querySelector('[data-source-clear]').addEventListener('click',()=>{window.dispatchEvent(new CustomEvent('dg:activity-source',{detail:''}));if(last)render(last,true);});
 }
 const select=host.querySelector('select');const sourceSignature=JSON.stringify([sources,investigatedSource]);
 if(select.dataset.signature!==sourceSignature){
  select.replaceChildren();for(const [ip,n]of sources){const option=document.createElement('option');option.value=ip;option.textContent=ip+' · '+n+' records';select.append(option);}
  if(investigatedSource&&!sources.some(([ip])=>ip===investigatedSource)){const option=document.createElement('option');option.value=investigatedSource;option.textContent=investigatedSource+' · not in current feed';select.append(option);}
  if(!select.children.length){const option=document.createElement('option');option.value='';option.textContent='No source IPs supplied';select.append(option);}
  select.value=investigatedSource;select.dataset.signature=sourceSignature;
 }
 const rows=events.filter(e=>e._src===investigatedSource),detail=host.querySelector('.dg-source-detail');
 host.querySelector('[data-source-apply]').disabled=!rows.length;
 host.querySelector('[data-source-clear]').disabled=!window.dgActivitySource;
 host.querySelector('.dg-source-filter-state').textContent=window.dgActivitySource?'Activity Stream filtered to '+window.dgActivitySource:'Activity Stream shows all sources in the selected scope.';
 const detailSignature=JSON.stringify([rows,investigatedSource]);if(detail.dataset.signature===detailSignature)return;detail.dataset.signature=detailSignature;
 if(!rows.length){detail.innerHTML=empty('No records for this source in the selected latest feed. Change the source or scope.');return;}
 const dates=rows.map(e=>Date.parse(e._time)).filter(Number.isFinite).sort((a,b)=>a-b);
 const format=t=>t===undefined?'Not supplied':new Date(t).toLocaleString();
 const risks=rows.map(e=>e._risk).filter(Number.isFinite),peak=risks.length?Math.max(...risks):'Not supplied';
 const websites=ranked(count(rows,e=>e._site||'Unassigned website'));
 const attacks=ranked(count(rows,e=>e._attack||e.event_type||'Unclassified'));
 const decisions=ranked(count(rows,e=>e._decision||'Not supplied'));
 const targets=ranked(count(rows,e=>str(e.target_type)||'Unspecified'));
 const patterns=ranked(count(rows.filter(e=>/REQUEST[ _]BURST|REPEATED[ _]HTTP[ _]ERRORS|ENDPOINT[ _]ENUMERATION|REPEATED[ _]POST/i.test(str(e.event_type)+' '+e._attack)),e=>str(e.event_type)||e._attack));
 const privateIP=/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.)/.test(investigatedSource)||investigatedSource==='::1'||/^(fc|fd)[0-9a-f]{2}:/i.test(investigatedSource);
 const list=(title,values)=>'<section class="dg-source-section"><h4>'+title+'</h4>'+(values.length?values.slice(0,6).map(([name,n])=>'<div class="dg-source-fact"><span>'+escape(name)+'</span><strong>'+n+'</strong></div>').join(''): '<p class="dg-note">No matching pattern records.</p>')+(values.length>6?'<p class="dg-note">'+(values.length-6)+' more categories in selected records.</p>':'')+'</section>';
 detail.innerHTML='<div class="dg-source-identity"><i class="fa-solid fa-network-wired" aria-hidden="true"></i><div><span>Recorded source IP</span><code>'+escape(investigatedSource)+'</code></div></div>'+(privateIP?'<p class="dg-source-attribution">Private or loopback address. It may represent a proxy, NAT gateway or local client; it does not identify a unique visitor.</p>':'<p class="dg-note">Recorded address only; not a verified person or device identity.</p>')+'<div class="dg-source-metrics"><div><strong>'+rows.length+'</strong><span>Selected records</span></div><div><strong>'+escape(peak)+'</strong><span>Peak recorded risk</span></div><div><strong>'+websites.filter(([name])=>name!=='Unassigned website').length+'</strong><span>Named websites</span></div></div><dl class="dg-source-times"><div><dt>First observed in feed</dt><dd>'+escape(format(dates[0]))+'</dd></div><div><dt>Last observed in feed</dt><dd>'+escape(format(dates[dates.length-1]))+'</dd></div></dl>'+list('Targeted websites',websites)+list('Recorded attack labels',attacks)+list('Behavioural patterns',patterns)+list('Target environments',targets)+list('Recorded decisions',decisions)+'<p class="dg-note">Limited to the selected latest feed. Record counts are not unique attacks; decisions do not verify forwarding.</p>';
}

function render(data, force = false) {
  last = data;
  const sig = JSON.stringify([data.gauges,data.latest,data.recent, sites, document.getElementById('dgSiteSelect')?.value, document.getElementById('dgSeverityFilter')?.value, document.getElementById('dgAttackSearch')?.value, document.getElementById('dgEnvironmentFilter')?.value, modes, history, document.body.dataset.dgPreset, window.dgThemePalette]);
  if (!force && sig === signature) return;
  signature = sig;

  const raw = typeof dgFilteredEvents === 'function' ? dgFilteredEvents(data) : (Array.isArray(data.recent) ? data.recent : []);
  const site = document.getElementById('dgSiteSelect')?.value || '';
  const ev = raw.filter(e => !site || str(e.site_id) === site).map(e => ({
    ...e,
    _site: str(e.site_id),
    _src: str(e.source_ip||e.remote_addr),
    _time: str(e.timestamp || e.time),
    _attack: str(e.attack || e.attack_type),
    _severity: str(e.severity).toUpperCase(),
    _decision: str(e.decision).toUpperCase(),
    _route: str(e.route).toUpperCase(),
    _engine: str(e.engine),
    _risk: Number(e.risk ?? e.risk_score),
    _stage: str(e.attack_stage).toUpperCase()
  }));

  renderSourceInvestigation(ev);
  const trapped = e => e._route === 'HONEYPOT' || e._route === 'DECOY' || ['HONEYPOT', 'REDIRECT', 'REDIRECT_TO_HONEYPOT', 'CONTAINED'].includes(e._decision);
  const outcome = e => trapped(e) ? 'Decoy / Redirect' : (['BLOCK', 'BLOCKED', 'ISOLATE', 'ISOLATED', 'DROP'].includes(e._decision) ? 'Blocked' : (['ALLOW', 'ALLOWED', 'PASS'].includes(e._decision) ? 'Allowed' : (e._decision || 'Unspecified')));
  const outcomes = ranked(count(ev, outcome));

  const engines = ranked(count(ev, e => e._engine || 'Unattributed'));
  const validIntelNumeric=v=>v!==null&&v!==undefined&&v!==''&&Number.isFinite(Number(v));
  const intel=[['intelRisk',validIntelNumeric(data.gauges?.risk)?String(data.gauges.risk):'—','crosshairs','Global score · no assumed maximum'],['intelConfidence',validIntelNumeric(data.gauges?.confidence)?String(data.gauges.confidence)+'%':'—','bullseye','Recorded assessment confidence'],['intelReporters',String(engines.filter(([name])=>name!=='Unattributed').length),'layer-group','Named reporters in selected feed'],['intelDecision',str(data.latest?.decision)||'Not supplied','shield-halved','Recorded global decision']];
  const reportedIds=new Set(ev.flatMap(e=>{const tags=e.mitre_tags||e.forensics?.mitre_tags||[];return Array.isArray(tags)?tags.filter(t=>/^T\d{4}(?:\.\d{3})?$/.test(str(t))):[];}));
  intel.push(['intelMitre',String(reportedIds.size),'crosshairs','Distinct IDs supplied in selected feed'],['intelContained',String(ev.filter(trapped).length),'shield-halved','Recorded decisions · selected feed']);
  const intelLabels={intelMitre:'Reported ATT&CK IDs',intelContained:'Decoy / Redirect Decisions',intelRisk:'Latest global score',intelConfidence:'Recorded confidence',intelReporters:'Reporting engines in feed',intelDecision:'Latest global decision'};
  for(const [id,value,icon,note]of intel)if(nodes[id])nodes[id].innerHTML='<div class="dg-intel-standard-heading"><span>'+escape(intelLabels[id])+'</span><i class="fa-solid fa-'+icon+'" aria-hidden="true"></i></div><div class="dg-intel-standard-value">'+escape(value)+'</div><div class="dg-intel-standard-note"><span aria-hidden="true">●</span> '+escape(note)+'</div>';
  if(nodes.engineEventLog){
    const ordered=ev.slice().sort((a,b)=>(Date.parse(b._time)||0)-(Date.parse(a._time)||0)).slice(0,12);
    nodes.engineEventLog.innerHTML=ordered.length?'<div class="dg-engine-findings">'+ordered.map(e=>{const date=new Date(e._time);const time=isNaN(date.getTime())?'Time not supplied':date.toLocaleString();return '<article><div class="dg-finding-icon"><i class="fa-solid fa-magnifying-glass-chart" aria-hidden="true"></i></div><div class="dg-finding-content"><div class="dg-finding-meta"><time>'+escape(time)+'</time><span class="dg-finding-severity">'+escape(e._severity||'Unspecified')+'</span></div><strong>'+escape(e._engine||'Unattributed')+'</strong><p>'+escape(e._attack||e.event_type||'Unclassified record')+'</p><small><i class="fa-solid fa-globe" aria-hidden="true"></i> '+escape(e._site||'Unassigned website')+'</small></div></article>';}).join('')+'</div><p class="dg-note">Up to 12 selected-feed records. Separate engine reports are not automatically merged into an incident.</p>':empty();
  }

  if (nodes.detectionBreakdown) {
    const palette=color(),reportColors=[palette[5],palette[3],palette[4],palette[2],palette[1],palette[0]].filter(Boolean);
    const largest=Math.max(1,...engines.map(([,n])=>n));
    nodes.detectionBreakdown.innerHTML=ev.length?'<div class="dg-reporting-bars">'+engines.map(([name,n],i)=>'<div class="dg-reporting-row"><div class="dg-reporting-label"><span>'+escape(name)+'</span><strong>'+n+' <small>records</small></strong></div><div class="dg-reporting-track"><i style="width:'+(100*n/largest)+'%;background:'+reportColors[i%reportColors.length]+'"></i></div></div>').join('')+'</div><p class="dg-note">Selected-feed record counts. Bar lengths are scaled to the largest reporting count.</p>':empty();
  }

  const patterns = [
    ['Request burst', /REQUEST[ _]BURST/i],
    ['Repeated HTTP errors', /REPEATED[ _]HTTP[ _]ERRORS/i],
    ['Endpoint enumeration', /ENDPOINT[ _]ENUMERATION/i],
    ['Repeated POST', /REPEATED[ _]POST/i]
  ];
  const patternRows = patterns.map(([name, rx]) => [name, ev.filter(e => rx.test(str(e.event_type) + ' ' + e._attack)).length]);
  if(nodes.behaviourEvidence){
    const ranks=['INFO','SAFE','LOW','MEDIUM','HIGH','VERY HIGH','CRITICAL'];
    const peak=Math.max(1,...patternRows.map(([,n])=>n));
    const rows=patterns.map(([name,rx],i)=>{
      const matched=ev.filter(e=>rx.test(str(e.event_type)+' '+e._attack)).sort((a,b)=>(Date.parse(b._time)||0)-(Date.parse(a._time)||0));
      const severity=matched.map(e=>e._severity).filter(v=>ranks.includes(v)).sort((a,b)=>ranks.indexOf(b)-ranks.indexOf(a))[0]||'Not supplied';
      const evidence=matched.length?str(matched[0].details||matched[0].reasons||matched[0]._attack||matched[0].event_type):'No matching pattern records';
      return '<tr><th scope="row"><span class="dg-pattern-dot" style="background:'+color()[i%color().length]+'"></span>'+escape(name)+'</th><td><strong>'+matched.length+'</strong><div class="dg-pattern-count-track"><i style="width:'+(matched.length/peak*100)+'%;background:'+color()[i%color().length]+'"></i></div></td><td><span class="dg-pattern-severity">'+escape(matched.length?severity:'—')+'</span></td><td class="dg-pattern-evidence">'+escape(evidence)+'</td></tr>';
    });
    nodes.behaviourEvidence.innerHTML='<div class="dg-pattern-table-wrap"><table class="dg-pattern-table"><thead><tr><th>Observed pattern</th><th>Records</th><th>Peak recorded severity</th><th>Supplied rule evidence</th></tr></thead><tbody>'+rows.join('')+'</tbody></table></div><p class="dg-note">Selected-feed pattern records. Severity and evidence come from telemetry. Bars compare record counts, not request volumes or trajectories.</p>';
  }
  const patternCount = ev.filter(e => patterns.some(([, rx]) => rx.test(str(e.event_type) + ' ' + e._attack))).length;
  const patternList = document.getElementById('dgBehaviourPatterns');
  if (patternList) {
    const roseSignature=JSON.stringify([patternRows,color(),[...hiddenPatterns],document.body.dataset.dgPreset]);
    if(patternList.dataset.roseSignature!==roseSignature){
    patternList.dataset.roseSignature=roseSignature;
    const maxPattern=Math.max(1,...patternRows.map(([,n])=>n));
    patternList.innerHTML=patternRows.map(([name,n],i)=>`<li class="dg-pattern-legend-row"><button type="button" data-pattern-index="${i}" aria-pressed="${!hiddenPatterns.has(name)}" title="Show or hide ${escape(name)}"><i aria-hidden="true" style="background:${color()[i%color().length]}"></i><span>${escape(name)}</span><b>${n}</b></button></li>`).join('');
    const rose=document.getElementById('dgBehaviourRose');
    if(rose){
      const radius=90,cx=110,cy=110;
      const polar=a=>[cx+radius*Math.cos(a),cy+radius*Math.sin(a)];
      let angle=-Math.PI/2;
      const slices=patternRows.map(([name,n],i)=>{
        const start=angle;angle+=patternCount?2*Math.PI*n/patternCount:0;
        if(!n||hiddenPatterns.has(name))return '';
        const a=polar(start),b=polar(angle),mid=polar(start+Math.PI);
        const arc=n===patternCount?`A ${radius} ${radius} 0 1 1 ${mid} A ${radius} ${radius} 0 1 1 ${b}`:`A ${radius} ${radius} 0 ${angle-start>Math.PI?1:0} 1 ${b}`;
        return `<path tabindex="0" data-pattern-index="${i}" aria-label="${escape(name)}: ${n} records" d="M ${cx} ${cy} L ${a} ${arc} Z" fill="${color()[i%color().length]}" stroke="var(--dg-card)" stroke-width="2" stroke-linejoin="round"><title>${escape(name)}: ${n} records</title></path>`;
      }).join('');
      rose.innerHTML=patternCount?`<svg viewBox="0 0 220 220" role="img" aria-label="Behaviour pattern counts; Pie chart: sector angles represent shares of recorded pattern counts"><title>Recorded behavioural patterns</title>${slices}${document.body.dataset.dgPreset==='threat'?`<circle cx="110" cy="110" r="46" fill="var(--dg-card)"/><text x="110" y="108" text-anchor="middle" fill="var(--dg-text)" font-size="25" font-weight="600">${patternCount}</text><text x="110" y="128" text-anchor="middle" fill="var(--dg-muted)" font-size="11">records</text>`:''}</svg>`:'<p class="dg-empty">No recorded patterns</p>';
    }
    patternList.querySelectorAll('button[data-pattern-index]').forEach(button=>button.addEventListener('click',()=>{
      const name=patternRows[Number(button.dataset.patternIndex)][0];
      if(hiddenPatterns.has(name))hiddenPatterns.delete(name);else hiddenPatterns.add(name);
      if(last)render(last,true);
    }));
    let controls=document.getElementById('dgRoseControls');
    if(!controls){controls=document.createElement('div');controls.id='dgRoseControls';controls.className='dg-rose-controls';rose?.parentNode.after(controls);}
    if(controls){
      controls.innerHTML='<p id="dgRoseTooltip" role="status">Hover a slice for details. Click legend items to show or hide slices; totals stay unchanged.</p>';
      for(const path of rose?.querySelectorAll('path')||[]){
        const describe=()=>{const [name,n]=patternRows[Number(path.dataset.patternIndex)];document.getElementById('dgRoseTooltip').textContent=name+': '+n+' records ('+(patternCount?Math.round(n/patternCount*100):0)+'% of pattern records).';};
        path.addEventListener('pointerenter',describe);path.addEventListener('focus',describe);
        if(!rose.dataset.animated&&!document.body.classList.contains('dg-ws-motion')&&!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches)path.animate?.([{opacity:0,transform:'scale(.7)'},{opacity:1,transform:'scale(1)'}],{duration:450,easing:'ease-out'});
      }
    }
    }
    if(document.getElementById('dgBehaviourRose'))document.getElementById('dgBehaviourRose').dataset.animated='1';
    const behScore = document.getElementById('behRiskScore');
    const behBadge = document.getElementById('behRiskBadge');
    if (behScore) behScore.textContent = patternCount;
    if (behBadge) {behBadge.textContent = patternCount ? 'PATTERNS' : 'NO PATTERNS';behBadge.className=patternCount?'badge-purple':'badge-safe';}
  }

  const scored = ev.filter(e => {const value=e.risk??e.risk_score;return value!==null&&value!==undefined&&value!==''&&Number.isFinite(Number(value));});
  const bins = [['0–39', 0, 40], ['40–79', 40, 80], ['80–149', 80, 150], ['150+', 150, Infinity]];
  if (nodes.riskDistribution) {
    nodes.riskDistribution.innerHTML = scored.length ? `<div class="dg-cards">${bins.map(([k, lo, hi], i) => {
      const v = scored.filter(e => e._risk >= lo && e._risk < hi).length;
      return `<div class="dg-tile"><span class="dg-kicker">${k}</span><strong>${v}</strong>${bar(v, scored.length, color()[i])}</div>`;
    }).join('')}</div><p class="dg-note">Display bands only; not official severity thresholds.</p>` : empty('No numeric risk evidence.');
  }

  const heat=Array(24).fill(0),now=Date.now();let valid=0;
  ev.forEach(e=>{const d=new Date(e._time),t=d.getTime();if(Number.isFinite(t)&&t>=now-86400000&&t<=now){heat[d.getHours()]++;valid++;}});
  const peak=Math.max(1,...heat);
  if(nodes.attackHeatmap)nodes.attackHeatmap.innerHTML='<div class="dg-hour-matrix">'+[0,6,12,18].map(start=>'<section><h4>'+String(start).padStart(2,'0')+':00–'+String(start+6).padStart(2,'0')+':00</h4><div>'+heat.slice(start,start+6).map((v,j)=>'<div class="dg-hour-cell" tabindex="0" title="'+String(start+j).padStart(2,'0')+':00 · '+v+' records" style="--heat:color-mix(in srgb,var(--dg-accent) '+(v?20+Math.round(80*v/peak):0)+'%,var(--dg-raised))"><span>'+String(start+j).padStart(2,'0')+'</span><strong>'+v+'</strong></div>').join('')+'</div></section>').join('')+'</div><p class="dg-note">'+valid+' selected-feed records in the last 24 hours, grouped by device-local hour. Zero means no matching records in this feed, not verified inactivity.</p>';
  const routingBars=rows=>{const distribution=ranked(count(rows,outcome));return rows.length?'<div class="dg-reporting-bars">'+distribution.map(([label,n],i)=>'<div><div class="dg-reporting-label"><span>'+escape(label)+'</span><strong>'+n+' <small>('+Math.round(n/rows.length*100)+'%)</small></strong></div><div class="dg-reporting-track"><i style="width:'+n/rows.length*100+'%;background:'+color()[i%color().length]+'"></i></div></div>').join('')+'</div>':empty('No matching recorded decisions.');};
  if(nodes.postureSummary)nodes.postureSummary.innerHTML=incidentInfoCards([['Latest global severity',str(data.latest?.severity)||'Not supplied'],['Selected telemetry records',String(ev.length)],['Distinct requested paths',String(new Set(ev.map(e=>incidentEndpoint(e)).filter(Boolean)).size)]])+'<p class="dg-note">Latest global severity is independent of the selected website. Counts cover the selected latest feed, not every retained request.</p>';
  if(nodes.riskContainment)nodes.riskContainment.innerHTML='<h4>Numeric Risk Score Bands</h4>'+(scored.length?'<div class="dg-reporting-bars">'+bins.map(([label,lo,hi],i)=>{const n=scored.filter(e=>e._risk>=lo&&e._risk<hi).length;return '<div><div class="dg-reporting-label"><span>'+label+'</span><strong>'+n+' records</strong></div><div class="dg-reporting-track"><i style="width:'+n/scored.length*100+'%;background:'+color()[i%color().length]+'"></i></div></div>';}).join('')+'</div>':empty('No numeric scores supplied.'))+'<p class="dg-note">Display bands, not severity classifications. '+(ev.length-scored.length)+' records without numeric scores.</p><section class="dg-dock-section"><h4>Recorded Routing Decisions</h4>'+routingBars(ev)+'</section>';
  const decoyRows=ev.filter(e=>['decoy','honeypot'].includes(str(e.target_type).toLowerCase())||['HONEYPOT','DECOY'].includes(e._route));
  const sessionIds=new Set(decoyRows.map(e=>e.session_id||e.forensics?.session_id).filter(Boolean));
  const commandRows=decoyRows.filter(e=>e.Command||e.command);
  const decoyArtifacts=[...new Map(decoyRows.flatMap(e=>e.forensics?.artifacts||e.artifacts||[]).filter(a=>a&&typeof a==='object').map(a=>[JSON.stringify([a.name||a.filename,a.hash||a.sha256]),a])).values()];
  if(nodes.trapSummary)nodes.trapSummary.innerHTML=incidentInfoCards([['Decoy-targeted records',String(decoyRows.length)],['Supplied session IDs',String(sessionIds.size)],['Records with commands',String(commandRows.length)],['Recorded blocks',String(decoyRows.filter(e=>['BLOCK','BLOCKED','DROP','ISOLATE','ISOLATED'].includes(e._decision)).length)]])+'<p class="dg-note">No live trap-health signal is supplied. Source IPs are not treated as verified sessions.</p>';
  const containedDecoy=decoyRows.filter(trapped).length,sourceRanks=ranked(count(decoyRows,e=>e._src)).filter(([ip])=>ip);
  const trapKpis=[['trapHits',String(decoyRows.length),'Selected decoy-targeted records','jar'],['trapIsolation',decoyRows.length?Math.round(containedDecoy/decoyRows.length*100)+'%':'—',containedDecoy+' / '+decoyRows.length+' recorded decoy/redirect outcomes','shield-halved'],['trapFiles',String(decoyArtifacts.length),'Unique supplied artifact entries','file-shield'],['trapPrimary',sourceRanks[0]?.[0]||'Not supplied','Most frequent address · may be a proxy/NAT','network-wired']];
  for(const [id,value,note,icon]of trapKpis)if(nodes[id])nodes[id].innerHTML='<div class="dg-intel-standard-heading"><span>'+escape(defs[id][0])+'</span><i class="fa-solid fa-'+icon+'" aria-hidden="true"></i></div><div class="dg-intel-standard-value">'+escape(value)+'</div><div class="dg-intel-standard-note">● '+escape(note)+'</div>';
  if(nodes.trapTaxonomy){const rankedAttacks=ranked(count(decoyRows,e=>e._attack||e.event_type||'Unclassified')),severityOrder=['INFO','SAFE','LOW','MEDIUM','HIGH','VERY HIGH','CRITICAL'];nodes.trapTaxonomy.innerHTML=(rankedAttacks.length?'<table class="dg-incident-table dg-taxonomy-table"><thead><tr><th>Pattern / class</th><th>Hits</th><th>Ratio</th><th>Peak severity</th></tr></thead><tbody>'+rankedAttacks.slice(0,8).map(([label,n])=>{const peak=decoyRows.filter(e=>(e._attack||e.event_type||'Unclassified')===label).map(e=>e._severity).filter(v=>severityOrder.includes(v)).sort((a,b)=>severityOrder.indexOf(b)-severityOrder.indexOf(a))[0];return '<tr><td>'+escape(label)+'</td><td>'+n+'</td><td>'+Math.round(n/decoyRows.length*100)+'%</td><td>'+incidentBadge(peak||'Not supplied','severity')+'</td></tr>';}).join('')+'</tbody></table><p class="dg-note">Top eight recorded classes · '+decoyRows.length+' total records. Severity is supplied, not inferred from count.</p>':empty('No decoy-targeted evidence.'))+'<section class="dg-dock-section"><h4>Traffic Containment Decisions</h4>'+renderPolicyMatrix(decoyRows)+'</section>';}

  if(nodes.trapTranscript){const lines=decoyRows.slice().sort((a,b)=>(Date.parse(a._time)||0)-(Date.parse(b._time)||0)).flatMap(e=>{if(e.Command||e.command)return ['['+e._time+'] COMMAND '+str(e.Command||e.command)+(e.output?' → '+str(e.output):'')];const logs=Array.isArray(e.forensics?.session_log)?e.forensics.session_log:[];if(logs.length)return logs.map(l=>'['+(l.time||e._time)+'] CAPTURE '+str(l.text||'')+(l.output?' → '+str(l.output):''));return e.request?['['+e._time+'] HTTP '+e.request+(e.status?' → '+e.status:'')]:[];});nodes.trapTranscript.innerHTML=lines.length?'<pre class="dg-incident-terminal">'+escape(lines.slice(-80).join('\n'))+'</pre><p class="dg-note">Up to 80 supplied transcript lines. HTTP records are not shell commands; no emulated prompt or execution is invented.</p>':empty('No commands or request transcripts supplied.');}
  if(nodes.trapRouting)nodes.trapRouting.innerHTML=renderPolicyMatrix(decoyRows);
  if(nodes.trapEvidence){const links=decoyArtifacts.map(a=>{const linked=decoyRows.filter(e=>(e.forensics?.artifacts||e.artifacts||[]).some(x=>x&&JSON.stringify([x.name||x.filename,x.hash||x.sha256])===JSON.stringify([a.name||a.filename,a.hash||a.sha256])));return {a,linked};});nodes.trapEvidence.innerHTML=links.length?'<div class="dg-artifact-table-wrap"><table class="dg-incident-table"><thead><tr><th>File name</th><th>Linked incident</th><th>Supplied checksum</th><th>Target website</th><th>Recorded status</th></tr></thead><tbody>'+links.map(({a,linked},i)=>'<tr><td>'+escape(a.name||a.filename||'Not supplied')+'</td><td>'+escape(linked.map(e=>e.incident_id||e.event_id).filter(Boolean).join(', ')||'Not supplied')+'</td><td><code>'+escape(a.sha256||a.hash||'Not supplied')+'</code>'+((a.sha256||a.hash)?'<button type="button" class="settings-action" data-trap-hash="'+i+'">Copy</button>':'')+'</td><td>'+escape([...new Set(linked.map(e=>e._site).filter(Boolean))].join(', ')||'Not supplied')+'</td><td>'+escape(a.quarantine_status||a.status||'Not supplied')+'</td></tr>').join('')+'</tbody></table></div><p class="dg-note" data-trap-copy-status>Artifact presence does not prove quarantine. Hash algorithm is only established when supplied.</p>':empty('No artifact metadata supplied for these decoy records.');for(const button of nodes.trapEvidence.querySelectorAll('[data-trap-hash]'))button.addEventListener('click',async()=>{const a=links[Number(button.dataset.trapHash)].a,notice=nodes.trapEvidence.querySelector('[data-trap-copy-status]');try{await navigator.clipboard.writeText(str(a.sha256||a.hash));notice.textContent='Checksum copied.';}catch{notice.textContent='Clipboard unavailable. Select and copy the displayed checksum.';}});}

  if(nodes.trapActivity)nodes.trapActivity.innerHTML=decoyRows.length?'<div class="dg-trap-table-wrap"><table class="dg-incident-table"><thead><tr><th>Timestamp</th><th>Trigger / class</th><th>Source</th><th>Target / port</th><th>Decision</th></tr></thead><tbody>'+decoyRows.slice().sort((a,b)=>(Date.parse(b._time)||0)-(Date.parse(a._time)||0)).map(e=>'<tr><td>'+escape(Number.isFinite(Date.parse(e._time))?new Date(e._time).toLocaleString():e._time)+'</td><td>'+escape(e._attack||e.event_type||'Unclassified')+'</td><td>'+escape(e._src||'Not supplied')+'</td><td>'+escape(e._site||'Unassigned')+' · '+escape(e.target_port||e.forensics?.target_port||'Not supplied')+'</td><td>'+incidentBadge(e._decision,'decision')+'</td></tr>').join('')+'</tbody></table></div>':empty('No decoy-targeted records in the selected feed.');

  const reg = sites.filter(s => !site || str(s.site_id) === site);
  const ids = [...new Set([...reg.map(s => str(s.site_id)), ...ev.map(e => e._site || 'Unattributed')])];
  let perSite = ids.map(id => {
    const registered = reg.find(s => str(s.site_id) === id);
    const records = ev.filter(e => (e._site || 'Unattributed') === id);
    return {
      id,
      name: registered?.display_name || registered?.name || id,
      records: records.length,
      high: records.filter(e => ['HIGH', 'VERY HIGH', 'CRITICAL'].includes(e._severity)).length,
      decoy: records.filter(trapped).length
    };
  }).sort((a, b) => b.records - a.records);

  if (history) {
    perSite = (history.sites || []).map(s => ({
      id: s.id,
      name: sites.find(r => str(r.site_id) === s.id)?.display_name || sites.find(r => str(r.site_id) === s.id)?.name || s.id,
      records: s.count,
      high: s.high || 0,
      decoy: s.decoy || 0
    }));
  }
  const siteTotal = history?.totals?.total || 0;
  const websiteMode = modes.siteOverview || 'table';

  if(nodes.siteOverview){
    if(!history)nodes.siteOverview.innerHTML=empty('Loading monitoring evidence…');
    else{
      const sources=history.sources||[],endpoints=history.endpoints||[];
      const issues=Number(history.malformed||0)+Number(history.invalid_dates||0);
      const formatTime=value=>{const date=new Date(value);return value&&Number.isFinite(date.getTime())?escape(date.toLocaleString()):'No selected detections';};
      const endpointRows=entries=>entries.map(e=>`<tr><th scope="row"><code>${escape(e.path)}</code><small>${e.types.map(escape).join(' · ')}</small></th><td>${e.count}</td><td>${e.sites.map(id=>escape(sites.find(s=>str(s.site_id)===str(id))?.name||id)).join(', ')}</td></tr>`).join('');
      if(document.body.dataset.dgPreset==='global'){
        nodes.siteOverview.parentNode.querySelector('h3').textContent='Telemetry & Ingestion Sources';
        nodes.siteOverview.innerHTML=`<div class="dg-coverage-summary"><span><b>${sources.length}</b> sources scanned</span><span>${history.partial?'Partial history':'History scan complete'}</span></div><div class="dg-global-source-scroll"><table><thead><tr><th>Source file</th><th>Scan</th><th>Selected</th></tr></thead><tbody>${sources.map(source=>{const issue=(source.malformed||0)+(source.invalid_dates||0)+(source.future_dates||0);const state=source.error||source.errors?.length||issue?'ISSUES':source.selected?'READ':'NO MATCH';return `<tr><td><code>${escape(source.file)}</code></td><td><span class="dg-source-state">${state}</span></td><td>${source.selected||0}</td></tr>`;}).join('')||'<tr><td colspan="3">No readable sources</td></tr>'}</tbody></table></div><h4>Frequently targeted paths</h4><div class="dg-global-targets">${endpoints.slice(0,3).map(endpoint=>`<div><code>${escape(endpoint.path)}</code><b>${endpoint.count}</b></div>`).join('')||'<p>No selected endpoints.</p>'}</div><p class="dg-note">Selected detections, not all HTTP traffic. File status describes this scan, not collector health.</p>`;
      }else{
        nodes.siteOverview.parentNode.querySelector('h3').textContent='Monitoring Coverage & Targeted Endpoints';
      nodes.siteOverview.innerHTML=`<div class="dg-coverage-summary"><span><b>${sources.length}</b> sources scanned</span><span><b>${issues}</b> parsing issues</span><span><b>${endpoints.length}${history.endpoint_overflow_records?'+':''}</b> targeted paths</span><span class="dg-coverage-status">${history.partial?'Partial scan':'Scan completed'}</span></div><div class="dg-coverage-grid"><section><h4>Log coverage</h4><div class="dg-coverage-scroll"><table><thead><tr><th>Source</th><th>Selected</th><th>Issues</th></tr></thead><tbody>${sources.map(source=>`<tr><th scope="row"><code>${escape(source.file)}</code><small>Latest selected: ${formatTime(source.latest_selected)}</small>${source.error?'<small>'+escape(source.error)+'</small>':''}</th><td>${source.selected??'—'}</td><td>${Number(source.malformed||0)+Number(source.invalid_dates||0)}</td></tr>`).join('')||'<tr><td colspan="3">No readable sources found.</td></tr>'}</tbody></table></div></section><section><h4>Frequently targeted endpoints</h4><div class="dg-coverage-scroll"><table><thead><tr><th>Endpoint / attack type</th><th>Detections</th><th>Websites</th></tr></thead><tbody>${endpointRows(endpoints.slice(0,5))||'<tr><td colspan="3">No HTTP paths recorded for selected detections.</td></tr>'}</tbody></table>${endpoints.length>5?`<details><summary>Show ${endpoints.length-5} more paths</summary><table><tbody>${endpointRows(endpoints.slice(5))}</tbody></table></details>`:''}</div></section></div><p class="dg-note">Coverage describes files scanned, not collector uptime. File parsing issues are global; selected counts and latest times follow your filters. Requests without paths: ${history.endpoint_missing_records||0}.${history.endpoint_overflow_records?' Path limit reached; '+history.endpoint_overflow_records+' detection records omitted from endpoint ranking.':''}</p>`;
    }
  }

      }
  const responseMode = modes.response || 'summary';
  if (nodes.containmentFlow) {
    nodes.containmentFlow.innerHTML = ev.length ? ((responseMode === 'flow' ? `<div class="dg-record-flow"><div class="dg-flow-origin">${ev.length}<small>selected records</small></div><div class="dg-flow-branches">${outcomes.map(([name, value]) => `<div class="dg-flow-branch">${row(name, value)}${bar(value, ev.length, 'var(--dg-accent)')}</div>`).join('')}</div></div>` : `<div class="dg-cards">${outcomes.map(([name, value]) => tile(name, value, (100 * value / ev.length).toFixed(1) + '% of selected records')).join('')}</div>`) + `<p class="dg-note">Recorded decisions; this does not verify forwarding or measure total gateway traffic.</p>`) : empty();
  }

  const tags = ranked(count(ev.flatMap(e => {
    const values = e.mitre_tags || e.forensics?.mitre_tags || [];
    return (Array.isArray(values) ? values : []).filter(x => /^T\d{4}(?:\.\d{3})?$/.test(str(x))).filter((v, i, a) => a.indexOf(v) === i).map(tag => ({ tag }));
  }), e => e.tag));

  if (nodes.mitreProgression) {
    nodes.mitreProgression.innerHTML = tags.length ? '<div class="dg-technique-list">'+tags.map(([tag,n])=>'<article class="dg-technique-card"><div class="dg-technique-icon"><i class="fa-solid fa-crosshairs" aria-hidden="true"></i></div><div><span class="dg-technique-label">Reported technique</span><code>'+escape(tag)+'</code></div><div class="dg-technique-count"><strong>'+n+'</strong><span>source records</span></div><div class="dg-technique-source"><i class="fa-solid fa-file-lines" aria-hidden="true"></i> Supplied in telemetry</div></article>').join('')+'</div>' + '<p class="dg-note">Reported identifiers, not independently validated technique attribution.</p>' : empty('No technique IDs supplied in this feed. No keyword-based MITRE mapping is inferred.');
  }

  const sources = ranked(count(ev, e => e._src)).filter(([s]) => s && s !== '-');
  let src = nodes.attackSequence.dataset.src || sources[0]?.[0] || '';
  if (!sources.some(([s]) => s === src)) src = sources[0]?.[0] || '';
  nodes.attackSequence.dataset.src = src;

  // One source selection drives every investigation panel.
  const incidentRows=ev.filter(e=>e._src===src).sort((a,b)=>(Date.parse(a._time)||0)-(Date.parse(b._time)||0));
  const artifacts=[...new Map(incidentRows.flatMap(e=>Array.isArray(e.forensics?.artifacts)?e.forensics.artifacts:Array.isArray(e.artifacts)?e.artifacts:[]).filter(a=>a&&typeof a==='object').map(a=>[JSON.stringify([a.name||a.filename,a.hash||a.sha256]),a])).values()];
  const dates=incidentRows.map(e=>Date.parse(e._time)).filter(Number.isFinite);
  const span=dates.length>1?Math.round((Math.max(...dates)-Math.min(...dates))/1000):null;
  const ports=[...new Set(incidentRows.map(e=>e.target_port||e.forensics?.target_port).filter(Boolean).map(str))];
  for(const [id,value,note]of [['incidentSource',src||'—','Use the source selector in Attack Sequence Logs'],['incidentPort',ports.join(', ')||'Not supplied','No SSH port is assumed'],['incidentFiles',String(artifacts.length),'Unique supplied artifact entries'],['incidentDuration',span===null?'—':Math.floor(span/60)+'m '+span%60+'s','Observed record span · selected feed']]){
   if(nodes[id])nodes[id].innerHTML='<div class="dg-investigation-value">'+escape(value)+'</div><p class="dg-note">'+escape(note)+'</p>';
  }
  const latest=incidentRows.at(-1);
  if(nodes.incidentProgress)nodes.incidentProgress.innerHTML=renderRecordedStageIndicator(latest?._stage,latest?._decision);
  renderTriage(incidentRows,sources,src,ports,span);
  const transcript=incidentRows.flatMap(e=>{
   const logs=Array.isArray(e.forensics?.session_log)?e.forensics.session_log:[];
   if(logs.length)return logs.map(log=>'['+(log.time||e._time||'Time unavailable')+'] '+str(log.text||'')+(log.output?' → '+str(log.output):''));
   const command=e.Command||e.command;return command?['['+e._time+'] $ '+str(command)]:e.request?['['+e._time+'] HTTP '+str(e.request)+(e.status?' → '+str(e.status):'')]:[];
  });
  if(nodes.forensicTerminal)nodes.forensicTerminal.innerHTML='<div class="dg-transcript-label">READ-ONLY CAPTURE · '+escape(src||'No source selected')+'</div>'+(transcript.length?'<pre class="dg-incident-terminal">'+escape(transcript.slice(-100).join('\n'))+'</pre>':empty('No command or HTTP transcript supplied for this source.'))+'<p class="dg-note">Recorded telemetry, not an interactive shell. HTTP requests are labelled separately from captured commands.</p>';
  if(nodes.artifactInspector)nodes.artifactInspector.innerHTML=renderArtifactCards(artifacts);
  if(nodes.incidentRouting){const routes=ranked(count(incidentRows,outcome));nodes.incidentRouting.innerHTML=routes.length?'<div class="dg-reporting-bars">'+routes.map(([label,n],i)=>'<div><div class="dg-reporting-label"><span>'+escape(label)+'</span><strong>'+n+' <small>('+Math.round(100*n/incidentRows.length)+'%)</small></strong></div><div class="dg-reporting-track"><i style="width:'+100*n/incidentRows.length+'%;background:'+color()[i%color().length]+'"></i></div></div>').join('')+'</div>'+renderPolicyMatrix(incidentRows):renderPolicyMatrix([]);}

  if(nodes.incidentBanner)nodes.incidentBanner.innerHTML=nodes.incidentTriage.innerHTML+'<section class="dg-dock-section">'+nodes.incidentProgress.innerHTML+'</section>';
  const chips=(label,values,tone)=>'<div class="dg-evidence-chip-row"><span>'+escape(label)+'</span><div>'+values.map(value=>'<span class="dg-evidence-chip" style="--chip-color:var(--dg-'+(value==='decoy'?'danger':value==='production'?'success':tone)+')">'+escape(value)+'</span>').join('')+'</div></div>';
  if(nodes.portExposure)nodes.portExposure.innerHTML=incidentInfoCards([['Recorded port',incidentPortSummary(ports)],['Target websites',[...new Set(incidentRows.map(e=>e._site).filter(Boolean))].join(', ')],['Recorded environments',[...new Set(incidentRows.map(e=>e.target_type).filter(Boolean))].join(', ')],['Latest recorded route',latest?._route]])+'<details class="dg-port-details"><summary>Supplied service descriptions</summary><ul>'+ports.map(port=>'<li>'+escape(port)+'</li>').join('')+'</ul></details><p class="dg-note">Recorded attributes, not verified open ports or forwarding.</p>';



  if(nodes.incidentDock){nodes.incidentDock.innerHTML='<section class="dg-dock-section">'+nodes.incidentProgress.innerHTML+'</section><section class="dg-dock-section"><h4>Key Evidence Attributes</h4><div class="dg-journey-context">'+nodes.incidentTriage.innerHTML+'</div><div class="dg-dock-default-context">'+nodes.portExposure.innerHTML+'</div>'+'</section><section class="dg-dock-section"><h4>Traffic Containment Decisions</h4>'+nodes.incidentRouting.innerHTML+'</section><section class="dg-dock-section"><h4>Captured Artifacts · '+artifacts.length+'</h4>'+nodes.artifactInspector.innerHTML+artifacts.filter(a=>a.hash||a.sha256).map((a,i)=>'<button type="button" class="settings-action" data-copy-artifact="'+i+'">Copy hash · '+escape(a.name||a.filename||'Artifact')+'</button>').join('')+'<p class="dg-note" data-copy-status role="status"></p></section>';
   if(dates.length){const format=t=>new Date(t).toLocaleString();nodes.incidentDock.innerHTML+='<section class="dg-dock-section dg-session-metadata"><h4>Observed Time Metadata</h4>'+incidentInfoCards([['First seen',format(Math.min(...dates))],['Last seen',format(Math.max(...dates))],['Observed span',span===null?'Not supplied':Math.floor(span/86400)+'d '+Math.floor(span%86400/3600)+'h '+Math.floor(span%3600/60)+'m']])+'<p class="dg-note">Selected records; includes gaps between requests.</p></section>';}
   const hashes=artifacts.filter(a=>a.hash||a.sha256);for(const button of nodes.incidentDock.querySelectorAll('[data-copy-artifact]'))button.addEventListener('click',async()=>{const status=nodes.incidentDock.querySelector('[data-copy-status]');try{await navigator.clipboard.writeText(str(hashes[Number(button.dataset.copyArtifact)].hash||hashes[Number(button.dataset.copyArtifact)].sha256));status.textContent='Hash copied.';}catch{status.textContent='Clipboard unavailable. Select and copy the displayed hash.';}});
  }

}

window.addEventListener('dg:activity-source',()=>{if(last)render(last,true);});
window.addEventListener('dg:layout-changed',()=>{if(last)render(last,true);});
window.addEventListener('dg:theme-changed', () => { if (last) render(last, true); });
window.addEventListener('dg:history-data', e => { history = e.detail; if (last) render(last, true); });
window.addEventListener('dg:soc-data', e => render(e.detail));

fetch('api.php?action=sites', { cache: 'no-store' }).then(r => r.ok ? r.json() : null).then(d => {
  sites = Array.isArray(d?.sites) ? d.sites : [];
  if (last) render(last);
}).catch(() => {});

document.getElementById('dgSiteSelect')?.addEventListener('change', () => last && render(last));
})();
