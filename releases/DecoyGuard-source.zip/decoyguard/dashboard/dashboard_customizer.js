/* GridStack 12.3.3 — bundled to work without a CDN.
MIT License

Copyright (c) 2019-2025 Alain Dumesny. v0.4.0 and older (c) 2014-2018 Pavel Reznikov, Dylan Weiss

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

*/
/*! For license information please see gridstack-all.js.LICENSE.txt */
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==typeof exports?exports.GridStack=t():e.GridStack=t()}(self,(()=>(()=>{"use strict";var e={d:(t,i)=>{for(var s in i)e.o(i,s)&&!e.o(t,s)&&Object.defineProperty(t,s,{enumerable:!0,get:i[s]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t)},t={};e.d(t,{GridStack:()=>x});class i{static getElements(e,t=document){if("string"==typeof e){const i="getElementById"in t?t:void 0;if(i&&!isNaN(+e[0])){const t=i.getElementById(e);return t?[t]:[]}let s=t.querySelectorAll(e);return s.length||"."===e[0]||"#"===e[0]||(s=t.querySelectorAll("."+e),s.length||(s=t.querySelectorAll("#"+e))),Array.from(s)}return[e]}static getElement(e,t=document){if("string"==typeof e){const i="getElementById"in t?t:void 0;if(!e.length)return null;if(i&&"#"===e[0])return i.getElementById(e.substring(1));if("#"===e[0]||"."===e[0]||"["===e[0])return t.querySelector(e);if(i&&!isNaN(+e[0]))return i.getElementById(e);let s=t.querySelector(e);return i&&!s&&(s=i.getElementById(e)),s||(s=t.querySelector("."+e)),s}return e}static lazyLoad(e){return e.lazyLoad||e.grid?.opts?.lazyLoad&&!1!==e.lazyLoad}static createDiv(e,t){const i=document.createElement("div");return e.forEach((e=>{e&&i.classList.add(e)})),t?.appendChild(i),i}static shouldSizeToContent(e,t=!1){return e?.grid&&(t?!0===e.sizeToContent||!0===e.grid.opts.sizeToContent&&void 0===e.sizeToContent:!!e.sizeToContent||e.grid.opts.sizeToContent&&!1!==e.sizeToContent)}static isIntercepted(e,t){return!(e.y>=t.y+t.h||e.y+e.h<=t.y||e.x+e.w<=t.x||e.x>=t.x+t.w)}static isTouching(e,t){return i.isIntercepted(e,{x:t.x-.5,y:t.y-.5,w:t.w+1,h:t.h+1})}static areaIntercept(e,t){const i=e.x>t.x?e.x:t.x,s=e.x+e.w<t.x+t.w?e.x+e.w:t.x+t.w;if(s<=i)return 0;const o=e.y>t.y?e.y:t.y,n=e.y+e.h<t.y+t.h?e.y+e.h:t.y+t.h;return n<=o?0:(s-i)*(n-o)}static area(e){return e.w*e.h}static sort(e,t=1){const i=1e4;return e.sort(((e,s)=>{const o=t*((e.y??i)-(s.y??i));return 0===o?t*((e.x??i)-(s.x??i)):o}))}static find(e,t){return t?e.find((e=>e.id===t)):void 0}static toBool(e){return"boolean"==typeof e?e:"string"==typeof e?!(""===(e=e.toLowerCase())||"no"===e||"false"===e||"0"===e):Boolean(e)}static toNumber(e){return null===e||0===e.length?void 0:Number(e)}static parseHeight(e){let t,i="px";if("string"==typeof e)if("auto"===e||""===e)t=0;else{const s=e.match(/^(-[0-9]+\.[0-9]+|[0-9]*\.[0-9]+|-[0-9]+|[0-9]+)(px|em|rem|vh|vw|%|cm|mm)?$/);if(!s)throw new Error(`Invalid height val = ${e}`);i=s[2]||"px",t=parseFloat(s[1])}else t=e;return{h:t,unit:i}}static defaults(e,...t){return t.forEach((t=>{for(const s in t){if(!t.hasOwnProperty(s))return;null===e[s]||void 0===e[s]?e[s]=t[s]:"object"==typeof t[s]&&"object"==typeof e[s]&&i.defaults(e[s],t[s])}})),e}static same(e,t){if("object"!=typeof e)return e==t;if(typeof e!=typeof t)return!1;if(Object.keys(e).length!==Object.keys(t).length)return!1;for(const i in e)if(e[i]!==t[i])return!1;return!0}static copyPos(e,t,i=!1){return void 0!==t.x&&(e.x=t.x),void 0!==t.y&&(e.y=t.y),void 0!==t.w&&(e.w=t.w),void 0!==t.h&&(e.h=t.h),i&&(t.minW&&(e.minW=t.minW),t.minH&&(e.minH=t.minH),t.maxW&&(e.maxW=t.maxW),t.maxH&&(e.maxH=t.maxH)),e}static samePos(e,t){return e&&t&&e.x===t.x&&e.y===t.y&&(e.w||1)===(t.w||1)&&(e.h||1)===(t.h||1)}static sanitizeMinMax(e){e.minW||delete e.minW,e.minH||delete e.minH,e.maxW||delete e.maxW,e.maxH||delete e.maxH}static removeInternalAndSame(e,t){if("object"==typeof e&&"object"==typeof t&&!Array.isArray(e)&&!Array.isArray(t))for(let s in e){const o=e[s],n=t[s];"_"===s[0]||o===n?delete e[s]:o&&"object"==typeof o&&void 0!==n&&(i.removeInternalAndSame(o,n),Object.keys(o).length||delete e[s])}}static removeInternalForSave(e,t=!0){for(let t in e)"_"!==t[0]&&null!==e[t]&&void 0!==e[t]||delete e[t];delete e.grid,t&&delete e.el,e.autoPosition||delete e.autoPosition,e.noResize||delete e.noResize,e.noMove||delete e.noMove,e.locked||delete e.locked,1!==e.w&&e.w!==e.minW||delete e.w,1!==e.h&&e.h!==e.minH||delete e.h}static throttle(e,t){let i=!1;return(...s)=>{i||(i=!0,setTimeout((()=>{e(...s),i=!1}),t))}}static removePositioningStyles(e){const t=e.style;t.position&&t.removeProperty("position"),t.left&&t.removeProperty("left"),t.top&&t.removeProperty("top"),t.width&&t.removeProperty("width"),t.height&&t.removeProperty("height")}static getScrollElement(e){if(!e)return document.scrollingElement||document.documentElement;const t=getComputedStyle(e);return/(auto|scroll)/.test(t.overflow+t.overflowY)?e:i.getScrollElement(e.parentElement)}static updateScrollPosition(e,t,s){const o=i.getScrollElement(e);if(!o)return;const n=e.getBoundingClientRect(),r=o.getBoundingClientRect(),a=window.innerHeight||document.documentElement.clientHeight,h=n.bottom-Math.min(r.bottom,a),l=n.top-Math.max(r.top,0),d=o.scrollTop;l<0&&s<0?e.offsetHeight>r.height?o.scrollTop+=s:o.scrollTop+=Math.abs(l)>Math.abs(s)?s:l:h>0&&s>0&&(e.offsetHeight>r.height?o.scrollTop+=s:o.scrollTop+=h>s?s:h),t.top+=o.scrollTop-d}static updateScrollResize(e,t,s){const o=i.getScrollElement(t),n=o.clientHeight,r=o===i.getScrollElement()?0:o.getBoundingClientRect().top,a=e.clientY-r,h=a>n-s;a<s?o.scrollBy({behavior:"smooth",top:a-s}):h&&o.scrollBy({behavior:"smooth",top:s-(n-a)})}static clone(e){return null==e||"object"!=typeof e?e:e instanceof Array?[...e]:{...e}}static cloneDeep(e){const t=["parentGrid","el","grid","subGrid","engine"],s=i.clone(e);for(const o in s)s.hasOwnProperty(o)&&"object"==typeof s[o]&&"__"!==o.substring(0,2)&&!t.find((e=>e===o))&&(s[o]=i.cloneDeep(e[o]));return s}static cloneNode(e){const t=e.cloneNode(!0);return t.removeAttribute("id"),t}static appendTo(e,t){let s;s="string"==typeof t?i.getElement(t):t,s&&s.appendChild(e)}static addElStyles(e,t){if(t instanceof Object)for(const i in t)t.hasOwnProperty(i)&&(Array.isArray(t[i])?t[i].forEach((t=>{e.style[i]=t})):e.style[i]=t[i])}static initEvent(e,t){const i={type:t.type},s={button:0,which:0,buttons:1,bubbles:!0,cancelable:!0,target:t.target?t.target:e.target};return["altKey","ctrlKey","metaKey","shiftKey"].forEach((t=>i[t]=e[t])),["pageX","pageY","clientX","clientY","screenX","screenY"].forEach((t=>i[t]=e[t])),{...i,...s}}static simulateMouseEvent(e,t,i){const s=e,o=new MouseEvent(t,{bubbles:!0,composed:!0,cancelable:!0,view:window,detail:1,screenX:e.screenX,screenY:e.screenY,clientX:e.clientX,clientY:e.clientY,ctrlKey:s.ctrlKey??!1,altKey:s.altKey??!1,shiftKey:s.shiftKey??!1,metaKey:s.metaKey??!1,button:0,relatedTarget:e.target});(i||e.target).dispatchEvent(o)}static getValuesFromTransformedElement(e){const t=document.createElement("div");i.addElStyles(t,{opacity:"0",position:"fixed",top:"0px",left:"0px",width:"1px",height:"1px",zIndex:"-999999"}),e.appendChild(t);const s=t.getBoundingClientRect();return e.removeChild(t),t.remove(),{xScale:1/s.width,yScale:1/s.height,xOffset:s.left,yOffset:s.top}}static swap(e,t,i){if(!e)return;const s=e[t];e[t]=e[i],e[i]=s}static canBeRotated(e){return!(!e||e.w===e.h||e.locked||e.noResize||e.grid?.opts.disableResize||e.minW&&e.minW===e.maxW||e.minH&&e.minH===e.maxH)}}class s{constructor(e={}){this.addedNodes=[],this.removedNodes=[],this.defaultColumn=12,this.column=e.column||this.defaultColumn,this.column>this.defaultColumn&&(this.defaultColumn=this.column),this.maxRow=e.maxRow,this._float=e.float,this.nodes=e.nodes||[],this.onChange=e.onChange}batchUpdate(e=!0,t=!0){return!!this.batchMode===e||(this.batchMode=e,e?(this._prevFloat=this._float,this._float=!0,this.cleanNodes(),this.saveInitial()):(this._float=this._prevFloat,delete this._prevFloat,t&&this._packNodes(),this._notify())),this}_useEntireRowArea(e,t){return(!this.float||this.batchMode&&!this._prevFloat)&&!this._hasLocked&&(!e._moving||e._skipDown||t.y<=e.y)}_fixCollisions(e,t=e,s,o={}){if(this.sortNodes(-1),!(s=s||this.collide(e,t)))return!1;if(e._moving&&!o.nested&&!this.float&&this.swap(e,s))return!0;let n=t;!this._loading&&this._useEntireRowArea(e,t)&&(n={x:0,w:this.column,y:t.y,h:t.h},s=this.collide(e,n,o.skip));let r=!1;const a={nested:!0,pack:!1};let h=0;for(;s=s||this.collide(e,n,o.skip);){if(h++>2*this.nodes.length)throw new Error("Infinite collide check");let n;if(s.locked||this._loading||e._moving&&!e._skipDown&&t.y>e.y&&!this.float&&(!this.collide(s,{...s,y:e.y},e)||!this.collide(s,{...s,y:t.y-s.h},e))){e._skipDown=e._skipDown||t.y>e.y;const h={...t,y:s.y+s.h,...a};n=!(!this._loading||!i.samePos(e,h))||this.moveNode(e,h),(s.locked||this._loading)&&n?i.copyPos(t,e):!s.locked&&n&&o.pack&&(this._packNodes(),t.y=s.y+s.h,i.copyPos(e,t)),r=r||n}else n=this.moveNode(s,{...s,y:t.y+t.h,skip:e,...a});if(!n)return r;s=void 0}return r}collide(e,t=e,s){const o=e._id,n=s?._id;return this.nodes.find((e=>e._id!==o&&e._id!==n&&i.isIntercepted(e,t)))}collideAll(e,t=e,s){const o=e._id,n=s?._id;return this.nodes.filter((e=>e._id!==o&&e._id!==n&&i.isIntercepted(e,t)))}directionCollideCoverage(e,t,i){if(!t.rect||!e._rect)return;const s=e._rect,o={...t.rect};let n;o.y>s.y?(o.h+=o.y-s.y,o.y=s.y):o.h+=s.y-o.y,o.x>s.x?(o.w+=o.x-s.x,o.x=s.x):o.w+=s.x-o.x;let r=.5;for(let e of i){if(e.locked||!e._rect)break;const t=e._rect;let i=Number.MAX_VALUE,a=Number.MAX_VALUE;s.y<t.y?i=(o.y+o.h-t.y)/t.h:s.y+s.h>t.y+t.h&&(i=(t.y+t.h-o.y)/t.h),s.x<t.x?a=(o.x+o.w-t.x)/t.w:s.x+s.w>t.x+t.w&&(a=(t.x+t.w-o.x)/t.w);const h=Math.min(a,i);h>r&&(r=h,n=e)}return t.collide=n,n}cacheRects(e,t,i,s,o,n){return this.nodes.forEach((r=>r._rect={y:r.y*t+i,x:r.x*e+n,w:r.w*e-n-s,h:r.h*t-i-o})),this}swap(e,t){if(!t||t.locked||!e||e.locked)return!1;function s(){const i=t.x,s=t.y;return t.x=e.x,t.y=e.y,e.h!=t.h?(e.x=i,e.y=t.y+t.h):e.w!=t.w?(e.x=t.x+t.w,e.y=s):(e.x=i,e.y=s),e._dirty=t._dirty=!0,!0}let o;if(e.w===t.w&&e.h===t.h&&(e.x===t.x||e.y===t.y)&&(o=i.isTouching(e,t)))return s();if(!1!==o){if(e.w===t.w&&e.x===t.x&&(o||(o=i.isTouching(e,t)))){if(t.y<e.y){const i=e;e=t,t=i}return s()}if(!1!==o){if(e.h===t.h&&e.y===t.y&&(o||(o=i.isTouching(e,t)))){if(t.x<e.x){const i=e;e=t,t=i}return s()}return!1}}}isAreaEmpty(e,t,i,s){const o={x:e||0,y:t||0,w:i||1,h:s||1};return!this.collide(o)}compact(e="compact",t=!0){if(0===this.nodes.length)return this;t&&this.sortNodes();const i=this.batchMode;i||this.batchUpdate();const s=this._inColumnResize;s||(this._inColumnResize=!0);const o=this.nodes;return this.nodes=[],o.forEach(((t,i,s)=>{let o;t.locked||(t.autoPosition=!0,"list"===e&&i&&(o=s[i-1])),this.addNode(t,!1,o)})),s||delete this._inColumnResize,i||this.batchUpdate(!1),this}set float(e){this._float!==e&&(this._float=e||!1,e||this._packNodes()._notify())}get float(){return this._float||!1}sortNodes(e=1){return this.nodes=i.sort(this.nodes,e),this}_packNodes(){return this.batchMode||(this.sortNodes(),this.float?this.nodes.forEach((e=>{if(e._updating||void 0===e._orig||e.y===e._orig.y)return;let t=e.y;for(;t>e._orig.y;)--t,this.collide(e,{x:e.x,y:t,w:e.w,h:e.h})||(e._dirty=!0,e.y=t)})):this.nodes.forEach(((e,t)=>{if(!e.locked)for(;e.y>0;){const i=0===t?0:e.y-1;if(0!==t&&this.collide(e,{x:e.x,y:i,w:e.w,h:e.h}))break;e._dirty=e.y!==i,e.y=i}}))),this}prepareNode(e,t){e._id=e._id??s._idSeq++;const o=e.id;if(o){let t=1;for(;this.nodes.find((t=>t.id===e.id&&t!==e));)e.id=o+"_"+t++}void 0!==e.x&&void 0!==e.y&&null!==e.x&&null!==e.y||(e.autoPosition=!0);const n={x:0,y:0,w:1,h:1};return i.defaults(e,n),e.autoPosition||delete e.autoPosition,e.noResize||delete e.noResize,e.noMove||delete e.noMove,i.sanitizeMinMax(e),"string"==typeof e.x&&(e.x=Number(e.x)),"string"==typeof e.y&&(e.y=Number(e.y)),"string"==typeof e.w&&(e.w=Number(e.w)),"string"==typeof e.h&&(e.h=Number(e.h)),isNaN(e.x)&&(e.x=n.x,e.autoPosition=!0),isNaN(e.y)&&(e.y=n.y,e.autoPosition=!0),isNaN(e.w)&&(e.w=n.w),isNaN(e.h)&&(e.h=n.h),this.nodeBoundFix(e,t),e}nodeBoundFix(e,t){const s=e._orig||i.copyPos({},e);if(e.maxW&&(e.w=Math.min(e.w||1,e.maxW)),e.maxH&&(e.h=Math.min(e.h||1,e.maxH)),e.minW&&(e.w=Math.max(e.w||1,e.minW)),e.minH&&(e.h=Math.max(e.h||1,e.minH)),(e.x||0)+(e.w||1)>this.column&&this.column<this.defaultColumn&&!this._inColumnResize&&!this.skipCacheUpdate&&null!=e._id&&-1===this.findCacheLayout(e,this.defaultColumn)){const t={...e};t.autoPosition||void 0===t.x?(delete t.x,delete t.y):t.x=Math.min(this.defaultColumn-1,t.x),t.w=Math.min(this.defaultColumn,t.w||1),this.cacheOneLayout(t,this.defaultColumn)}return e.w>this.column?e.w=this.column:e.w<1&&(e.w=1),this.maxRow&&e.h>this.maxRow?e.h=this.maxRow:e.h<1&&(e.h=1),e.x<0&&(e.x=0),e.y<0&&(e.y=0),e.x+e.w>this.column&&(t?e.w=this.column-e.x:e.x=this.column-e.w),this.maxRow&&e.y+e.h>this.maxRow&&(t?e.h=this.maxRow-e.y:e.y=this.maxRow-e.h),i.samePos(e,s)||(e._dirty=!0),this}getDirtyNodes(e){return e?this.nodes.filter((e=>e._dirty&&!i.samePos(e,e._orig))):this.nodes.filter((e=>e._dirty))}_notify(e){if(this.batchMode||!this.onChange)return this;const t=(e||[]).concat(this.getDirtyNodes());return this.onChange(t),this}cleanNodes(){return this.batchMode||this.nodes.forEach((e=>{delete e._dirty,delete e._lastTried})),this}saveInitial(){return this.nodes.forEach((e=>{e._orig=i.copyPos({},e),delete e._dirty})),this._hasLocked=this.nodes.some((e=>e.locked)),this}restoreInitial(){return this.nodes.forEach((e=>{e._orig&&!i.samePos(e,e._orig)&&(i.copyPos(e,e._orig),e._dirty=!0)})),this._notify(),this}findEmptyPosition(e,t=this.nodes,s=this.column,o){let n=!1;for(let r=o?o.y*s+(o.x+o.w):0;!n;++r){const o=r%s,a=Math.floor(r/s);if(o+e.w>s)continue;const h={x:o,y:a,w:e.w,h:e.h};t.find((e=>i.isIntercepted(h,e)))||(e.x===o&&e.y===a||(e._dirty=!0),e.x=o,e.y=a,delete e.autoPosition,n=!0)}return n}addNode(e,t=!1,i){const s=this.nodes.find((t=>t._id===e._id));if(s)return s;let o;return this._inColumnResize?this.nodeBoundFix(e):this.prepareNode(e),delete e._temporaryRemoved,delete e._removeDOM,e.autoPosition&&this.findEmptyPosition(e,this.nodes,this.column,i)&&(delete e.autoPosition,o=!0),this.nodes.push(e),t&&this.addedNodes.push(e),o||this._fixCollisions(e),this.batchMode||this._packNodes()._notify(),e}removeNode(e,t=!0,i=!1){return this.nodes.find((t=>t._id===e._id))?(i&&this.removedNodes.push(e),t&&(e._removeDOM=!0),this.nodes=this.nodes.filter((t=>t._id!==e._id)),e._isAboutToRemove||this._packNodes(),this._notify([e]),this):this}removeAll(e=!0,t=!0){if(delete this._layouts,!this.nodes.length)return this;e&&this.nodes.forEach((e=>e._removeDOM=!0));const i=this.nodes;return this.removedNodes=t?i:[],this.nodes=[],this._notify(i)}moveNodeCheck(e,t){if(!this.changedPosConstrain(e,t))return!1;if(t.pack=!0,!this.maxRow)return this.moveNode(e,t);let o;const n=new s({column:this.column,float:this.float,nodes:this.nodes.map((t=>t._id===e._id?(o={...t},o):{...t}))});if(!o)return!1;const r=n.moveNode(o,t)&&n.getRow()<=Math.max(this.getRow(),this.maxRow);if(!r&&!t.resizing&&t.collide){const i=t.collide.el.gridstackNode;if(this.swap(e,i))return this._notify(),!0}return!!r&&(n.nodes.filter((e=>e._dirty)).forEach((e=>{const t=this.nodes.find((t=>t._id===e._id));t&&(i.copyPos(t,e),t._dirty=!0)})),this._notify(),!0)}willItFit(e){if(delete e._willFitPos,!this.maxRow)return!0;const t=new s({column:this.column,float:this.float,nodes:this.nodes.map((e=>({...e})))}),o={...e};return this.cleanupNode(o),delete o.el,delete o._id,delete o.content,delete o.grid,t.addNode(o),t.getRow()<=this.maxRow&&(e._willFitPos=i.copyPos({},o),!0)}changedPosConstrain(e,t){return t.w=t.w||e.w,t.h=t.h||e.h,e.x!==t.x||e.y!==t.y||(e.maxW&&(t.w=Math.min(t.w,e.maxW)),e.maxH&&(t.h=Math.min(t.h,e.maxH)),e.minW&&(t.w=Math.max(t.w,e.minW)),e.minH&&(t.h=Math.max(t.h,e.minH)),e.w!==t.w||e.h!==t.h)}moveNode(e,t){if(!e||!t)return!1;let s;void 0!==t.pack||this.batchMode||(s=t.pack=!0),"number"!=typeof t.x&&(t.x=e.x),"number"!=typeof t.y&&(t.y=e.y),"number"!=typeof t.w&&(t.w=e.w),"number"!=typeof t.h&&(t.h=e.h);const o=e.w!==t.w||e.h!==t.h,n=i.copyPos({},e,!0);if(i.copyPos(n,t),this.nodeBoundFix(n,o),i.copyPos(t,n),!t.forceCollide&&i.samePos(e,t))return!1;const r=i.copyPos({},e),a=this.collideAll(e,n,t.skip);let h=!0;if(a.length){const o=e._moving&&!t.nested;let r=o?this.directionCollideCoverage(e,t,a):a[0];if(o&&r&&e.grid?.opts?.subGridDynamic&&!e.grid._isTemp){const s=i.areaIntercept(t.rect,r._rect),o=i.area(t.rect),n=i.area(r._rect);s/(o<n?o:n)>.8&&(r.grid.makeSubGrid(r.el,void 0,e),r=void 0)}r?h=!this._fixCollisions(e,n,r,t):(h=!1,s&&delete t.pack)}return h&&!i.samePos(e,n)&&(e._dirty=!0,i.copyPos(e,n)),t.pack&&this._packNodes()._notify(),!i.samePos(e,r)}getRow(){return this.nodes.reduce(((e,t)=>Math.max(e,t.y+t.h)),0)}beginUpdate(e){return e._updating||(e._updating=!0,delete e._skipDown,this.batchMode||this.saveInitial()),this}endUpdate(){const e=this.nodes.find((e=>e._updating));return e&&(delete e._updating,delete e._skipDown),this}save(e=!0,t,s){const o=this._layouts?.length||0;let n;o&&(s?s!==this.column&&(n=this._layouts[s]):this.column!==o-1&&(n=this._layouts[o-1]));const r=[];return this.sortNodes(),this.nodes.forEach((s=>{const o=n?.find((e=>e._id===s._id)),a={...s,...o||{}};i.removeInternalForSave(a,!e),t&&t(s,a),r.push(a)})),r}layoutsNodesChange(e){return!this._layouts||this._inColumnResize||this._layouts.forEach(((t,i)=>{if(!t||i===this.column)return this;if(i<this.column)this._layouts[i]=void 0;else{const s=i/this.column;e.forEach((e=>{if(!e._orig)return;const i=t.find((t=>t._id===e._id));i&&(i.y>=0&&e.y!==e._orig.y&&(i.y+=e.y-e._orig.y),e.x!==e._orig.x&&(i.x=Math.round(e.x*s)),e.w!==e._orig.w&&(i.w=Math.round(e.w*s)))}))}})),this}columnChanged(e,t,s="moveScale"){if(!this.nodes.length||!t||e===t)return this;const o="compact"===s||"list"===s;o&&this.sortNodes(1),t<e&&this.cacheLayout(this.nodes,e),this.batchUpdate();let n=[],r=o?this.nodes:i.sort(this.nodes,-1);if(t>e&&this._layouts){const i=this._layouts[t]||[],s=this._layouts.length-1;!i.length&&e!==s&&this._layouts[s]?.length&&(e=s,this._layouts[s].forEach((e=>{const t=r.find((t=>t._id===e._id));t&&(o||e.autoPosition||(t.x=e.x??t.x,t.y=e.y??t.y),t.w=e.w??t.w,null!=e.x&&void 0!==e.y||(t.autoPosition=!0))}))),i.forEach((e=>{const t=r.findIndex((t=>t._id===e._id));if(-1!==t){const i=r[t];if(o)return void(i.w=e.w);(e.autoPosition||isNaN(e.x)||isNaN(e.y))&&this.findEmptyPosition(e,n),e.autoPosition||(i.x=e.x??i.x,i.y=e.y??i.y,i.w=e.w??i.w,n.push(i)),r.splice(t,1)}}))}if(o)this.compact(s,!1);else{if(r.length)if("function"==typeof s)s(t,e,n,r);else{const i=o||"none"===s?1:t/e,a="move"===s||"moveScale"===s,h="scale"===s||"moveScale"===s;r.forEach((s=>{s.x=1===t?0:a?Math.round(s.x*i):Math.min(s.x,t-1),s.w=1===t||1===e?1:h?Math.round(s.w*i)||1:Math.min(s.w,t),n.push(s)})),r=[]}n=i.sort(n,-1),this._inColumnResize=!0,this.nodes=[],n.forEach((e=>{this.addNode(e,!1),delete e._orig}))}return this.nodes.forEach((e=>delete e._orig)),this.batchUpdate(!1,!o),delete this._inColumnResize,this}cacheLayout(e,t,i=!1){const o=[];return e.forEach(((e,t)=>{if(void 0===e._id){const t=e.id?this.nodes.find((t=>t.id===e.id)):void 0;e._id=t?._id??s._idSeq++}o[t]={x:e.x,y:e.y,w:e.w,_id:e._id}})),this._layouts=i?[]:this._layouts||[],this._layouts[t]=o,this}cacheOneLayout(e,t){e._id=e._id??s._idSeq++;const i={x:e.x,y:e.y,w:e.w,_id:e._id};(e.autoPosition||void 0===e.x)&&(delete i.x,delete i.y,e.autoPosition&&(i.autoPosition=!0)),this._layouts=this._layouts||[],this._layouts[t]=this._layouts[t]||[];const o=this.findCacheLayout(e,t);return-1===o?this._layouts[t].push(i):this._layouts[t][o]=i,this}findCacheLayout(e,t){return this._layouts?.[t]?.findIndex((t=>t._id===e._id))??-1}removeNodeFromLayoutCache(e){if(this._layouts)for(let t=0;t<this._layouts.length;t++){const i=this.findCacheLayout(e,t);-1!==i&&this._layouts[t].splice(i,1)}}cleanupNode(e){for(const t in e)"_"===t[0]&&"_id"!==t&&delete e[t];return this}}s._idSeq=0;const o={alwaysShowResizeHandle:"mobile",animate:!0,auto:!0,cellHeight:"auto",cellHeightThrottle:100,cellHeightUnit:"px",column:12,draggable:{handle:".grid-stack-item-content",appendTo:"body",scroll:!0},handle:".grid-stack-item-content",itemClass:"grid-stack-item",margin:10,marginUnit:"px",maxRow:0,minRow:0,placeholderClass:"grid-stack-placeholder",placeholderText:"",removableOptions:{accept:"grid-stack-item",decline:"grid-stack-non-removable"},resizable:{handles:"se"},rtl:"auto"};class n{}const r="undefined"!=typeof window&&"undefined"!=typeof document&&("ontouchstart"in document||"ontouchstart"in window||window.DocumentTouch&&document instanceof window.DocumentTouch||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0);class a{}function h(e,t){e.touches.length>1||(e.cancelable&&e.preventDefault(),i.simulateMouseEvent(e.changedTouches[0],t))}function l(e,t){e.cancelable&&e.preventDefault(),i.simulateMouseEvent(e,t)}function d(e){a.touchHandled||(a.touchHandled=!0,h(e,"mousedown"))}function c(e){a.touchHandled&&h(e,"mousemove")}function g(e){if(!a.touchHandled)return;a.pointerLeaveTimeout&&(window.clearTimeout(a.pointerLeaveTimeout),delete a.pointerLeaveTimeout);const t=!!n.dragElement;h(e,"mouseup"),t||h(e,"click"),a.touchHandled=!1}function u(e){"mouse"!==e.pointerType&&e.target.releasePointerCapture(e.pointerId)}function p(e){n.dragElement&&"mouse"!==e.pointerType&&l(e,"mouseenter")}function m(e){n.dragElement&&"mouse"!==e.pointerType&&(a.pointerLeaveTimeout=window.setTimeout((()=>{delete a.pointerLeaveTimeout,l(e,"mouseleave")}),10))}class f{constructor(e,t,i){this.host=e,this.dir=t,this.option=i,this.moving=!1,this._mouseDown=this._mouseDown.bind(this),this._mouseMove=this._mouseMove.bind(this),this._mouseUp=this._mouseUp.bind(this),this._keyEvent=this._keyEvent.bind(this),this._init()}_init(){const e=this.el=document.createElement("div");return e.classList.add("ui-resizable-handle"),e.classList.add(`${f.prefix}${this.dir}`),e.style.zIndex="100",e.style.userSelect="none",this.host.appendChild(this.el),this.el.addEventListener("mousedown",this._mouseDown),r&&(this.el.addEventListener("touchstart",d),this.el.addEventListener("pointerdown",u)),this}destroy(){return this.moving&&this._mouseUp(this.mouseDownEvent),this.el.removeEventListener("mousedown",this._mouseDown),r&&(this.el.removeEventListener("touchstart",d),this.el.removeEventListener("pointerdown",u)),this.host.removeChild(this.el),delete this.el,delete this.host,this}_mouseDown(e){this.mouseDownEvent=e,document.addEventListener("mousemove",this._mouseMove,{capture:!0,passive:!0}),document.addEventListener("mouseup",this._mouseUp,!0),r&&(this.el.addEventListener("touchmove",c),this.el.addEventListener("touchend",g)),e.stopPropagation(),e.preventDefault()}_mouseMove(e){const t=this.mouseDownEvent;this.moving?this._triggerEvent("move",e):Math.abs(e.x-t.x)+Math.abs(e.y-t.y)>2&&(this.moving=!0,this._triggerEvent("start",this.mouseDownEvent),this._triggerEvent("move",e),document.addEventListener("keydown",this._keyEvent)),e.stopPropagation()}_mouseUp(e){this.moving&&(this._triggerEvent("stop",e),document.removeEventListener("keydown",this._keyEvent)),document.removeEventListener("mousemove",this._mouseMove,!0),document.removeEventListener("mouseup",this._mouseUp,!0),r&&(this.el.removeEventListener("touchmove",c),this.el.removeEventListener("touchend",g)),delete this.moving,delete this.mouseDownEvent,e.stopPropagation(),e.preventDefault()}_keyEvent(e){"Escape"===e.key&&(this.host.gridstackNode?.grid?.engine.restoreInitial(),this._mouseUp(this.mouseDownEvent))}_triggerEvent(e,t){return this.option[e]&&this.option[e](t),this}}f.prefix="ui-resizable-";class v{constructor(){this._eventRegister={}}get disabled(){return this._disabled}on(e,t){this._eventRegister[e]=t}off(e){delete this._eventRegister[e]}enable(){this._disabled=!1}disable(){this._disabled=!0}destroy(){delete this._eventRegister}triggerEvent(e,t){if(!this.disabled&&this._eventRegister&&this._eventRegister[e])return this._eventRegister[e](t)}}class _ extends v{constructor(e,t={}){super(),this.el=e,this.option=t,this.rectScale={x:1,y:1},this._ui=()=>{const e=this.el.parentElement.getBoundingClientRect(),t={width:this.originalRect.width,height:this.originalRect.height+this.scrolled,left:this.originalRect.left,top:this.originalRect.top-this.scrolled},i=this.temporalRect||t;return{position:{left:(i.left-e.left)*this.rectScale.x,top:(i.top-e.top)*this.rectScale.y},size:{width:i.width*this.rectScale.x,height:i.height*this.rectScale.y}}},this._mouseOver=this._mouseOver.bind(this),this._mouseOut=this._mouseOut.bind(this),this.enable(),this._setupAutoHide(this.option.autoHide),this._setupHandlers()}on(e,t){super.on(e,t)}off(e){super.off(e)}enable(){super.enable(),this.el.classList.remove("ui-resizable-disabled"),this._setupAutoHide(this.option.autoHide)}disable(){super.disable(),this.el.classList.add("ui-resizable-disabled"),this._setupAutoHide(!1)}destroy(){this._removeHandlers(),this._setupAutoHide(!1),delete this.el,super.destroy()}updateOption(e){const t=e.handles&&e.handles!==this.option.handles,i=e.autoHide&&e.autoHide!==this.option.autoHide;return Object.keys(e).forEach((t=>this.option[t]=e[t])),t&&(this._removeHandlers(),this._setupHandlers()),i&&this._setupAutoHide(this.option.autoHide),this}_setupAutoHide(e){return e?(this.el.classList.add("ui-resizable-autohide"),this.el.addEventListener("mouseover",this._mouseOver),this.el.addEventListener("mouseout",this._mouseOut)):(this.el.classList.remove("ui-resizable-autohide"),this.el.removeEventListener("mouseover",this._mouseOver),this.el.removeEventListener("mouseout",this._mouseOut),n.overResizeElement===this&&delete n.overResizeElement),this}_mouseOver(e){n.overResizeElement||n.dragElement||(n.overResizeElement=this,this.el.classList.remove("ui-resizable-autohide"))}_mouseOut(e){n.overResizeElement===this&&(delete n.overResizeElement,this.el.classList.add("ui-resizable-autohide"))}_setupHandlers(){return this.handlers=this.option.handles.split(",").map((e=>e.trim())).map((e=>new f(this.el,e,{start:e=>{this._resizeStart(e)},stop:e=>{this._resizeStop(e)},move:t=>{this._resizing(t,e)}}))),this}_resizeStart(e){this.sizeToContent=i.shouldSizeToContent(this.el.gridstackNode,!0),this.originalRect=this.el.getBoundingClientRect(),this.scrollEl=i.getScrollElement(this.el),this.scrollY=this.scrollEl.scrollTop,this.scrolled=0,this.startEvent=e,this._setupHelper(),this._applyChange();const t=i.initEvent(e,{type:"resizestart",target:this.el});return this.option.start&&this.option.start(t,this._ui()),this.el.classList.add("ui-resizable-resizing"),this.triggerEvent("resizestart",t),this}_resizing(e,t){this.scrolled=this.scrollEl.scrollTop-this.scrollY,this.temporalRect=this._getChange(e,t),this._applyChange();const s=i.initEvent(e,{type:"resize",target:this.el});return this.option.resize&&this.option.resize(s,this._ui()),this.triggerEvent("resize",s),this}_resizeStop(e){const t=i.initEvent(e,{type:"resizestop",target:this.el});return this._cleanHelper(),this.option.stop&&this.option.stop(t),this.el.classList.remove("ui-resizable-resizing"),this.triggerEvent("resizestop",t),delete this.startEvent,delete this.originalRect,delete this.temporalRect,delete this.scrollY,delete this.scrolled,this}_setupHelper(){this.elOriginStyleVal=_._originStyleProp.map((e=>this.el.style[e])),this.parentOriginStylePosition=this.el.parentElement.style.position;const e=this.el.parentElement,t=i.getValuesFromTransformedElement(e);return this.rectScale={x:t.xScale,y:t.yScale},getComputedStyle(this.el.parentElement).position.match(/static/)&&(this.el.parentElement.style.position="relative"),this.el.style.position="absolute",this.el.style.opacity="0.8",this}_cleanHelper(){return _._originStyleProp.forEach(((e,t)=>{this.el.style[e]=this.elOriginStyleVal[t]||null})),this.el.parentElement.style.position=this.parentOriginStylePosition||null,this}_getChange(e,t){const i=this.startEvent,s={width:this.originalRect.width,height:this.originalRect.height+this.scrolled,left:this.originalRect.left,top:this.originalRect.top-this.scrolled},o=e.clientX-i.clientX,n=this.sizeToContent?0:e.clientY-i.clientY;let r,a;t.indexOf("e")>-1?s.width+=o:t.indexOf("w")>-1&&(s.width-=o,s.left+=o,r=!0),t.indexOf("s")>-1?s.height+=n:t.indexOf("n")>-1&&(s.height-=n,s.top+=n,a=!0);const h=this._constrainSize(s.width,s.height,r,a);return Math.round(s.width)!==Math.round(h.width)&&(t.indexOf("w")>-1&&(s.left+=s.width-h.width),s.width=h.width),Math.round(s.height)!==Math.round(h.height)&&(t.indexOf("n")>-1&&(s.top+=s.height-h.height),s.height=h.height),s}_constrainSize(e,t,i,s){const o=this.option,n=(i?o.maxWidthMoveLeft:o.maxWidth)||Number.MAX_SAFE_INTEGER,r=o.minWidth/this.rectScale.x||e,a=(s?o.maxHeightMoveUp:o.maxHeight)||Number.MAX_SAFE_INTEGER,h=o.minHeight/this.rectScale.y||t;return{width:Math.min(n,Math.max(r,e)),height:Math.min(a,Math.max(h,t))}}_applyChange(){let e={left:0,top:0,width:0,height:0};if("absolute"===this.el.style.position){const t=this.el.parentElement,{left:i,top:s}=t.getBoundingClientRect();e={left:i,top:s,width:0,height:0}}return this.temporalRect?(Object.keys(this.temporalRect).forEach((t=>{const i=this.temporalRect[t],s="width"===t||"left"===t?this.rectScale.x:"height"===t||"top"===t?this.rectScale.y:1;this.el.style[t]=(i-e[t])*s+"px"})),this):this}_removeHandlers(){return this.handlers.forEach((e=>e.destroy())),delete this.handlers,this}}_._originStyleProp=["width","height","position","left","top","opacity","zIndex"];class y extends v{constructor(e,t={}){super(),this.el=e,this.option=t,this.dragTransform={xScale:1,yScale:1,xOffset:0,yOffset:0};const i=t?.handle?.substring(1),s=e.gridstackNode;this.dragEls=!i||e.classList.contains(i)?[e]:s?.subGrid?[e.querySelector(t.handle)||e]:Array.from(e.querySelectorAll(t.handle)),0===this.dragEls.length&&(this.dragEls=[e]),this._mouseDown=this._mouseDown.bind(this),this._mouseMove=this._mouseMove.bind(this),this._mouseUp=this._mouseUp.bind(this),this._keyEvent=this._keyEvent.bind(this),this.enable()}on(e,t){super.on(e,t)}off(e){super.off(e)}enable(){!1!==this.disabled&&(super.enable(),this.dragEls.forEach((e=>{e.addEventListener("mousedown",this._mouseDown),r&&(e.addEventListener("touchstart",d),e.addEventListener("pointerdown",u))})),this.el.classList.remove("ui-draggable-disabled"))}disable(e=!1){!0!==this.disabled&&(super.disable(),this.dragEls.forEach((e=>{e.removeEventListener("mousedown",this._mouseDown),r&&(e.removeEventListener("touchstart",d),e.removeEventListener("pointerdown",u))})),e||this.el.classList.add("ui-draggable-disabled"))}destroy(){this.dragTimeout&&window.clearTimeout(this.dragTimeout),delete this.dragTimeout,this.mouseDownEvent&&this._mouseUp(this.mouseDownEvent),this.disable(!0),delete this.el,delete this.helper,delete this.option,super.destroy()}updateOption(e){return Object.keys(e).forEach((t=>this.option[t]=e[t])),this}_mouseDown(e){if(!n.mouseHandled)return 0!==e.button||!this.dragEls.find((t=>t===e.target))&&e.target.closest('input,textarea,button,select,option,[contenteditable="true"],.ui-resizable-handle')||this.option.cancel&&e.target.closest(this.option.cancel)||(this.mouseDownEvent=e,delete this.dragging,delete n.dragElement,delete n.dropElement,document.addEventListener("mousemove",this._mouseMove,{capture:!0,passive:!0}),document.addEventListener("mouseup",this._mouseUp,!0),r&&(e.currentTarget.addEventListener("touchmove",c),e.currentTarget.addEventListener("touchend",g)),e.preventDefault(),document.activeElement&&document.activeElement.blur(),n.mouseHandled=!0),!0}_callDrag(e){if(!this.dragging)return;const t=i.initEvent(e,{target:this.el,type:"drag"});this.option.drag&&this.option.drag(t,this.ui()),this.triggerEvent("drag",t)}_mouseMove(e){const t=this.mouseDownEvent;if(this.lastDrag=e,this.dragging)if(this._dragFollow(e),n.pauseDrag){const t=Number.isInteger(n.pauseDrag)?n.pauseDrag:100;this.dragTimeout&&window.clearTimeout(this.dragTimeout),this.dragTimeout=window.setTimeout((()=>this._callDrag(e)),t)}else this._callDrag(e);else if(Math.abs(e.x-t.x)+Math.abs(e.y-t.y)>3){this.dragging=!0,n.dragElement=this;const t=this.el.gridstackNode?.grid;t?n.dropElement=t.el.ddElement.ddDroppable:delete n.dropElement,this.helper=this._createHelper(),this._setupHelperContainmentStyle(),this.dragTransform=i.getValuesFromTransformedElement(this.helperContainment),this.dragOffset=this._getDragOffset(e,this.el,this.helperContainment),this._setupHelperStyle(e);const s=i.initEvent(e,{target:this.el,type:"dragstart"});this.option.start&&this.option.start(s,this.ui()),this.triggerEvent("dragstart",s),document.addEventListener("keydown",this._keyEvent)}return!0}_mouseUp(e){if(document.removeEventListener("mousemove",this._mouseMove,!0),document.removeEventListener("mouseup",this._mouseUp,!0),r&&e.currentTarget&&(e.currentTarget.removeEventListener("touchmove",c,!0),e.currentTarget.removeEventListener("touchend",g,!0)),this.dragging){delete this.dragging,delete this.el.gridstackNode?._origRotate,document.removeEventListener("keydown",this._keyEvent),n.dropElement?.el===this.el.parentElement&&delete n.dropElement,this.helperContainment.style.position=this.parentOriginStylePosition||null,this.helper!==this.el&&this.helper.remove(),this._removeHelperStyle();const t=i.initEvent(e,{target:this.el,type:"dragstop"});this.option.stop&&this.option.stop(t),this.triggerEvent("dragstop",t),n.dropElement&&n.dropElement.drop(e)}delete this.helper,delete this.mouseDownEvent,delete n.dragElement,delete n.dropElement,delete n.mouseHandled,e.preventDefault()}_keyEvent(e){const t=this.el.gridstackNode,s=t?.grid||n.dropElement?.el?.gridstack;if("Escape"===e.key)t&&t._origRotate&&(t._orig=t._origRotate,delete t._origRotate),s?.cancelDrag(),this._mouseUp(this.mouseDownEvent);else if(t&&s&&("r"===e.key||"R"===e.key)){if(!i.canBeRotated(t))return;t._origRotate=t._origRotate||{...t._orig},delete t._moving,s.setAnimation(!1).rotate(t.el,{top:-this.dragOffset.offsetTop,left:-this.dragOffset.offsetLeft}).setAnimation(),t._moving=!0,this.dragOffset=this._getDragOffset(this.lastDrag,t.el,this.helperContainment),this.helper.style.width=this.dragOffset.width+"px",this.helper.style.height=this.dragOffset.height+"px",i.swap(t._orig,"w","h"),delete t._rect,this._mouseMove(this.lastDrag)}}_createHelper(){let e=this.el;return"function"==typeof this.option.helper?e=this.option.helper(this.el):"clone"===this.option.helper&&(e=i.cloneNode(this.el)),e.parentElement||i.appendTo(e,"parent"===this.option.appendTo?this.el.parentElement:this.option.appendTo),this.dragElementOriginStyle=y.originStyleProp.map((e=>this.el.style[e])),e}_setupHelperStyle(e){this.helper.classList.add("ui-draggable-dragging"),this.el.gridstackNode?.grid?.el.classList.add("grid-stack-dragging");const t=this.helper.style;return t.pointerEvents="none",t.width=this.dragOffset.width+"px",t.height=this.dragOffset.height+"px",t.willChange="left, top",t.position="fixed",this._dragFollow(e),t.transition="none",setTimeout((()=>{this.helper&&(t.transition=null)}),0),this}_removeHelperStyle(){this.helper.classList.remove("ui-draggable-dragging"),this.el.gridstackNode?.grid?.el.classList.remove("grid-stack-dragging");const e=this.helper?.gridstackNode;if(!e?._isAboutToRemove&&this.dragElementOriginStyle){const e=this.helper,t=this.dragElementOriginStyle.transition||null;e.style.transition=this.dragElementOriginStyle.transition="none",y.originStyleProp.forEach((t=>e.style[t]=this.dragElementOriginStyle[t]||null)),setTimeout((()=>e.style.transition=t),50)}return delete this.dragElementOriginStyle,this}_dragFollow(e){const t=this.helper.style,i=this.dragOffset;t.left=(e.clientX+i.offsetLeft-0)*this.dragTransform.xScale+"px",t.top=(e.clientY+i.offsetTop-0)*this.dragTransform.yScale+"px"}_setupHelperContainmentStyle(){return this.helperContainment=this.helper.parentElement,"fixed"!==this.helper.style.position&&(this.parentOriginStylePosition=this.helperContainment.style.position,getComputedStyle(this.helperContainment).position.match(/static/)&&(this.helperContainment.style.position="relative")),this}_getDragOffset(e,t,i){let s=0,o=0;i&&(s=this.dragTransform.xOffset,o=this.dragTransform.yOffset);const n=t.getBoundingClientRect();return{left:n.left,top:n.top,offsetLeft:-e.clientX+n.left-s,offsetTop:-e.clientY+n.top-o,width:n.width*this.dragTransform.xScale,height:n.height*this.dragTransform.yScale}}ui(){const e=this.el.parentElement.getBoundingClientRect(),t=this.helper.getBoundingClientRect();return{position:{top:(t.top-e.top)*this.dragTransform.yScale,left:(t.left-e.left)*this.dragTransform.xScale}}}}y.originStyleProp=["width","height","transform","transform-origin","transition","pointerEvents","position","left","top","minWidth","willChange"];class b extends v{constructor(e,t={}){super(),this.el=e,this.option=t,this._mouseEnter=this._mouseEnter.bind(this),this._mouseLeave=this._mouseLeave.bind(this),this.enable(),this._setupAccept()}on(e,t){super.on(e,t)}off(e){super.off(e)}enable(){!1!==this.disabled&&(super.enable(),this.el.classList.add("ui-droppable"),this.el.classList.remove("ui-droppable-disabled"),this.el.addEventListener("mouseenter",this._mouseEnter),this.el.addEventListener("mouseleave",this._mouseLeave),r&&(this.el.addEventListener("pointerenter",p),this.el.addEventListener("pointerleave",m)))}disable(e=!1){!0!==this.disabled&&(super.disable(),this.el.classList.remove("ui-droppable"),e||this.el.classList.add("ui-droppable-disabled"),this.el.removeEventListener("mouseenter",this._mouseEnter),this.el.removeEventListener("mouseleave",this._mouseLeave),r&&(this.el.removeEventListener("pointerenter",p),this.el.removeEventListener("pointerleave",m)))}destroy(){this.disable(!0),this.el.classList.remove("ui-droppable"),this.el.classList.remove("ui-droppable-disabled"),super.destroy()}updateOption(e){return Object.keys(e).forEach((t=>this.option[t]=e[t])),this._setupAccept(),this}_mouseEnter(e){if(!n.dragElement)return;if(!this._canDrop(n.dragElement.el))return;e.preventDefault(),e.stopPropagation(),n.dropElement&&n.dropElement!==this&&n.dropElement._mouseLeave(e,!0),n.dropElement=this;const t=i.initEvent(e,{target:this.el,type:"dropover"});this.option.over&&this.option.over(t,this._ui(n.dragElement)),this.triggerEvent("dropover",t),this.el.classList.add("ui-droppable-over")}_mouseLeave(e,t=!1){if(!n.dragElement||n.dropElement!==this)return;e.preventDefault(),e.stopPropagation();const s=i.initEvent(e,{target:this.el,type:"dropout"});if(this.option.out&&this.option.out(s,this._ui(n.dragElement)),this.triggerEvent("dropout",s),n.dropElement===this&&(delete n.dropElement,!t)){let t,i=this.el.parentElement;for(;!t&&i;)t=i.ddElement?.ddDroppable,i=i.parentElement;t&&t._mouseEnter(e)}}drop(e){e.preventDefault();const t=i.initEvent(e,{target:this.el,type:"drop"});this.option.drop&&this.option.drop(t,this._ui(n.dragElement)),this.triggerEvent("drop",t)}_canDrop(e){return e&&(!this.accept||this.accept(e))}_setupAccept(){return this.option.accept?("string"==typeof this.option.accept?this.accept=e=>e.classList.contains(this.option.accept)||e.matches(this.option.accept):this.accept=this.option.accept,this):this}_ui(e){return{draggable:e.el,...e.ui()}}}class w{static init(e){return e.ddElement||(e.ddElement=new w(e)),e.ddElement}constructor(e){this.el=e}on(e,t){return this.ddDraggable&&["drag","dragstart","dragstop"].indexOf(e)>-1?this.ddDraggable.on(e,t):this.ddDroppable&&["drop","dropover","dropout"].indexOf(e)>-1?this.ddDroppable.on(e,t):this.ddResizable&&["resizestart","resize","resizestop"].indexOf(e)>-1&&this.ddResizable.on(e,t),this}off(e){return this.ddDraggable&&["drag","dragstart","dragstop"].indexOf(e)>-1?this.ddDraggable.off(e):this.ddDroppable&&["drop","dropover","dropout"].indexOf(e)>-1?this.ddDroppable.off(e):this.ddResizable&&["resizestart","resize","resizestop"].indexOf(e)>-1&&this.ddResizable.off(e),this}setupDraggable(e){return this.ddDraggable?this.ddDraggable.updateOption(e):this.ddDraggable=new y(this.el,e),this}cleanDraggable(){return this.ddDraggable&&(this.ddDraggable.destroy(),delete this.ddDraggable),this}setupResizable(e){return this.ddResizable?this.ddResizable.updateOption(e):this.ddResizable=new _(this.el,e),this}cleanResizable(){return this.ddResizable&&(this.ddResizable.destroy(),delete this.ddResizable),this}setupDroppable(e){return this.ddDroppable?this.ddDroppable.updateOption(e):this.ddDroppable=new b(this.el,e),this}cleanDroppable(){return this.ddDroppable&&(this.ddDroppable.destroy(),delete this.ddDroppable),this}}const E=new class{resizable(e,t,i,s){return this._getDDElements(e,t).forEach((e=>{if("disable"===t||"enable"===t)e.ddResizable&&e.ddResizable[t]();else if("destroy"===t)e.ddResizable&&e.cleanResizable();else if("option"===t)e.setupResizable({[i]:s});else{const i=e.el.gridstackNode.grid;let s=e.el.getAttribute("gs-resize-handles")||i.opts.resizable.handles||"e,s,se";"all"===s&&(s="n,e,s,w,se,sw,ne,nw");const o=!i.opts.alwaysShowResizeHandle;e.setupResizable({...i.opts.resizable,handles:s,autoHide:o,start:t.start,stop:t.stop,resize:t.resize})}})),this}draggable(e,t,i,s){return this._getDDElements(e,t).forEach((e=>{if("disable"===t||"enable"===t)e.ddDraggable&&e.ddDraggable[t]();else if("destroy"===t)e.ddDraggable&&e.cleanDraggable();else if("option"===t)e.setupDraggable({[i]:s});else{const i=e.el.gridstackNode.grid;e.setupDraggable({...i.opts.draggable,start:t.start,stop:t.stop,drag:t.drag})}})),this}dragIn(e,t){return this._getDDElements(e).forEach((e=>e.setupDraggable(t))),this}droppable(e,t,i,s){return"function"!=typeof t.accept||t._accept||(t._accept=t.accept,t.accept=e=>t._accept(e)),this._getDDElements(e,t).forEach((e=>{"disable"===t||"enable"===t?e.ddDroppable&&e.ddDroppable[t]():"destroy"===t?e.ddDroppable&&e.cleanDroppable():"option"===t?e.setupDroppable({[i]:s}):e.setupDroppable(t)})),this}isDroppable(e){return!(!e?.ddElement?.ddDroppable||e.ddElement.ddDroppable.disabled)}isDraggable(e){return!(!e?.ddElement?.ddDraggable||e.ddElement.ddDraggable.disabled)}isResizable(e){return!(!e?.ddElement?.ddResizable||e.ddElement.ddResizable.disabled)}on(e,t,i){return this._getDDElements(e).forEach((e=>e.on(t,(e=>{i(e,n.dragElement?n.dragElement.el:e.target,n.dragElement?n.dragElement.helper:null)})))),this}off(e,t){return this._getDDElements(e).forEach((e=>e.off(t))),this}_getDDElements(e,t){const s=e.gridstack||"destroy"!==t&&"disable"!==t,o=i.getElements(e);return o.length?o.map((e=>e.ddElement||(s?w.init(e):null))).filter((e=>e)):[]}};class x{static init(e={},t=".grid-stack"){if("undefined"==typeof document)return null;const s=x.getGridElement(t);return s?(s.gridstack||(s.gridstack=new x(s,i.cloneDeep(e))),s.gridstack):("string"==typeof t?console.error('GridStack.initAll() no grid was found with selector "'+t+'" - element missing or wrong selector ?\nNote: ".grid-stack" is required for proper CSS styling and drag/drop, and is the default selector.'):console.error("GridStack.init() no grid element was passed."),null)}static initAll(e={},t=".grid-stack"){const s=[];return"undefined"==typeof document||(x.getGridElements(t).forEach((t=>{t.gridstack||(t.gridstack=new x(t,i.cloneDeep(e))),s.push(t.gridstack)})),0===s.length&&console.error('GridStack.initAll() no grid was found with selector "'+t+'" - element missing or wrong selector ?\nNote: ".grid-stack" is required for proper CSS styling and drag/drop, and is the default selector.')),s}static addGrid(e,t={}){if(!e)return null;let s=e;if(s.gridstack){const e=s.gridstack;return t&&(e.opts={...e.opts,...t}),void 0!==t.children&&e.load(t.children),e}return e.classList.contains("grid-stack")&&!x.addRemoveCB||(s=x.addRemoveCB?x.addRemoveCB(e,t,!0,!0):i.createDiv(["grid-stack",t.class],e)),x.init(t,s)}static registerEngine(e){x.engineClass=e}get placeholder(){if(!this._placeholder){this._placeholder=i.createDiv([this.opts.placeholderClass,o.itemClass,this.opts.itemClass]);const e=i.createDiv(["placeholder-content"],this._placeholder);this.opts.placeholderText&&(e.textContent=this.opts.placeholderText)}return this._placeholder}constructor(e,t={}){this.el=e,this.opts=t,this.animationDelay=310,this._gsEventHandler={},this._extraDragRow=0,this.dragTransform={xScale:1,yScale:1,xOffset:0,yOffset:0},e.gridstack=this,this.opts=t=t||{},e.classList.contains("grid-stack")||this.el.classList.add("grid-stack"),t.row&&(t.minRow=t.maxRow=t.row,delete t.row);const a=i.toNumber(e.getAttribute("gs-row"));"auto"===t.column&&delete t.column,void 0!==t.alwaysShowResizeHandle&&(t._alwaysShowResizeHandle=t.alwaysShowResizeHandle);const h=t.columnOpts;if(h){const e=h.breakpoints;h.columnWidth||e?.length?(h.columnMax=h.columnMax||12,e?.length>1&&e.sort(((e,t)=>(t.w||0)-(e.w||0)))):delete t.columnOpts}const l={...i.cloneDeep(o),column:i.toNumber(e.getAttribute("gs-column"))||o.column,minRow:a||i.toNumber(e.getAttribute("gs-min-row"))||o.minRow,maxRow:a||i.toNumber(e.getAttribute("gs-max-row"))||o.maxRow,staticGrid:i.toBool(e.getAttribute("gs-static"))||o.staticGrid,sizeToContent:i.toBool(e.getAttribute("gs-size-to-content"))||void 0,draggable:{handle:(t.handleClass?"."+t.handleClass:t.handle?t.handle:"")||o.draggable.handle},removableOptions:{accept:t.itemClass||o.removableOptions.accept,decline:o.removableOptions.decline}};e.getAttribute("gs-animate")&&(l.animate=i.toBool(e.getAttribute("gs-animate"))),t=i.defaults(t,l),this._initMargin(),this.checkDynamicColumn(),this._updateColumnVar(t),"auto"===t.rtl&&(t.rtl="rtl"===e.style.direction),t.rtl&&this.el.classList.add("grid-stack-rtl");const d=this.el.closest("."+o.itemClass),c=d?.gridstackNode;if(c&&(c.subGrid=this,this.parentGridNode=c,this.el.classList.add("grid-stack-nested"),c.el.classList.add("grid-stack-sub-grid")),this._isAutoCellHeight="auto"===t.cellHeight,this._isAutoCellHeight||"initial"===t.cellHeight)this.cellHeight(void 0);else{"number"==typeof t.cellHeight&&t.cellHeightUnit&&t.cellHeightUnit!==o.cellHeightUnit&&(t.cellHeight=t.cellHeight+t.cellHeightUnit,delete t.cellHeightUnit);const e=t.cellHeight;delete t.cellHeight,this.cellHeight(e)}"mobile"===t.alwaysShowResizeHandle&&(t.alwaysShowResizeHandle=r),this._setStaticClass();const g=t.engineClass||x.engineClass||s;if(this.engine=new g({column:this.getColumn(),float:t.float,maxRow:t.maxRow,onChange:e=>{e.forEach((e=>{const t=e.el;t&&(e._removeDOM?(t&&t.remove(),delete e._removeDOM):this._writePosAttr(t,e))})),this._updateContainerHeight()}}),t.auto&&(this.batchUpdate(),this.engine._loading=!0,this.getGridItems().forEach((e=>this._prepareElement(e))),delete this.engine._loading,this.batchUpdate(!1)),t.children){const e=t.children;delete t.children,e.length&&this.load(e)}this.setAnimation(),t.subGridDynamic&&!n.pauseDrag&&(n.pauseDrag=!0),void 0!==t.draggable?.pause&&(n.pauseDrag=t.draggable.pause),this._setupRemoveDrop(),this._setupAcceptWidget(),this._updateResizeEvent()}_updateColumnVar(e=this.opts){this.el.classList.add("gs-"+e.column),"number"==typeof e.column&&this.el.style.setProperty("--gs-column-width",100/e.column+"%")}addWidget(e){if(!e)return;if("string"==typeof e)return void console.error("V11: GridStack.addWidget() does not support string anymore. see #2736");if(e.ELEMENT_NODE)return console.error("V11: GridStack.addWidget() does not support HTMLElement anymore. use makeWidget()"),this.makeWidget(e);let t,s=e;if(s.grid=this,t=s.el?s.el:x.addRemoveCB?x.addRemoveCB(this.el,e,!0,!1):this.createWidgetDivs(s),!t)return;if(s=t.gridstackNode,s&&t.parentElement===this.el&&this.engine.nodes.find((e=>e._id===s._id)))return t;const o=this._readAttr(t);return i.defaults(e,o),this.engine.prepareNode(e),this.el.appendChild(t),this.makeWidget(t,e),t}createWidgetDivs(e){const t=i.createDiv(["grid-stack-item",this.opts.itemClass]),s=i.createDiv(["grid-stack-item-content"],t);return i.lazyLoad(e)?e.visibleObservable||(e.visibleObservable=new IntersectionObserver((([t])=>{t.isIntersecting&&(e.visibleObservable?.disconnect(),delete e.visibleObservable,x.renderCB(s,e),e.grid?.prepareDragDrop(e.el))})),window.setTimeout((()=>e.visibleObservable?.observe(t)))):x.renderCB(s,e),t}makeSubGrid(e,t,s,o=!0){let n,r=e.gridstackNode;if(r||(r=this.makeWidget(e).gridstackNode),r.subGrid?.el)return r.subGrid;let a,h=this;for(;h&&!n;)n=h.opts?.subGridOpts,h=h.parentGridNode?.grid;t=i.cloneDeep({...this.opts,id:void 0,children:void 0,column:"auto",columnOpts:void 0,layout:"list",subGridOpts:void 0,...n||{},...t||r.subGridOpts||{}}),r.subGridOpts=t,"auto"===t.column&&(a=!0,t.column=Math.max(r.w||1,s?.w||1),delete t.columnOpts);let l,d,c=r.el.querySelector(".grid-stack-item-content");if(o&&(this._removeDD(r.el),d={...r,x:0,y:0},i.removeInternalForSave(d),delete d.subGridOpts,r.content&&(d.content=r.content,delete r.content),x.addRemoveCB?l=x.addRemoveCB(this.el,d,!0,!1):(l=i.createDiv(["grid-stack-item"]),l.appendChild(c),c=i.createDiv(["grid-stack-item-content"],r.el)),this.prepareDragDrop(r.el)),s){const e=a?t.column:r.w,i=r.h+s.h,o=r.el.style;o.transition="none",this.update(r.el,{w:e,h:i}),setTimeout((()=>o.transition=null))}const g=r.subGrid=x.addGrid(c,t);return s?._moving&&(g._isTemp=!0),a&&(g._autoColumn=!0),o&&g.makeWidget(l,d),s&&(s._moving?window.setTimeout((()=>i.simulateMouseEvent(s._event,"mouseenter",g.el)),0):g.makeWidget(r.el,r)),this.resizeToContentCheck(!1,r),g}removeAsSubGrid(e){const t=this.parentGridNode?.grid;t&&(t.batchUpdate(),t.removeWidget(this.parentGridNode.el,!0,!0),this.engine.nodes.forEach((e=>{e.x+=this.parentGridNode.x,e.y+=this.parentGridNode.y,t.makeWidget(e.el,e)})),t.batchUpdate(!1),this.parentGridNode&&delete this.parentGridNode.subGrid,delete this.parentGridNode,e&&window.setTimeout((()=>i.simulateMouseEvent(e._event,"mouseenter",t.el)),0))}save(e=!0,t=!1,s=x.saveCB,n){const r=this.engine.save(e,s,n);if(r.forEach((i=>{if(e&&i.el&&!i.subGrid&&!s){const e=i.el.querySelector(".grid-stack-item-content");i.content=e?.innerHTML,i.content||delete i.content}else if(e||s||delete i.content,i.subGrid?.el){const o=i.w||i.subGrid.getColumn(),n=i.subGrid.save(e,t,s,o);i.subGridOpts=t?n:{children:n},delete i.subGrid}delete i.el})),t){const e=i.cloneDeep(this.opts);e.marginBottom===e.marginTop&&e.marginRight===e.marginLeft&&e.marginTop===e.marginRight&&(e.margin=e.marginTop,delete e.marginTop,delete e.marginRight,delete e.marginBottom,delete e.marginLeft),e.rtl===("rtl"===this.el.style.direction)&&(e.rtl="auto"),this._isAutoCellHeight&&(e.cellHeight="auto"),this._autoColumn&&(e.column="auto");const t=e._alwaysShowResizeHandle;return delete e._alwaysShowResizeHandle,void 0!==t?e.alwaysShowResizeHandle=t:delete e.alwaysShowResizeHandle,i.removeInternalAndSame(e,o),e.children=r,e}return r}load(e,t=x.addRemoveCB||!0){e=i.cloneDeep(e);const s=this.getColumn();e.forEach((e=>{e.w=e.w||e.minW||1,e.h=e.h||e.minH||1})),e=i.sort(e),this.engine.skipCacheUpdate=this._ignoreLayoutsNodeChange=!0;let o=0;e.forEach((e=>{o=Math.max(o,(e.x||0)+e.w)})),o>this.engine.defaultColumn&&(this.engine.defaultColumn=o),o>s&&(0===this.engine.nodes.length&&this.responseLayout?(this.engine.nodes=e,this.engine.columnChanged(o,s,this.responseLayout),e=this.engine.nodes,this.engine.nodes=[],delete this.responseLayout):this.engine.cacheLayout(e,o,!0));const n=x.addRemoveCB;"function"==typeof t&&(x.addRemoveCB=t);const r=[];this.batchUpdate();const a=!this.engine.nodes.length,h=a&&this.opts.animate;h&&this.setAnimation(!1),!a&&t&&[...this.engine.nodes].forEach((t=>{t.id&&(i.find(e,t.id)||(x.addRemoveCB&&x.addRemoveCB(this.el,t,!1,!1),r.push(t),this.removeWidget(t.el,!0,!1)))})),this.engine._loading=!0;const l=[];return this.engine.nodes=this.engine.nodes.filter((t=>!i.find(e,t.id)||(l.push(t),!1))),e.forEach((e=>{const s=i.find(l,e.id);if(s){if(i.shouldSizeToContent(s)&&(e.h=s.h),this.engine.nodeBoundFix(e),(e.autoPosition||void 0===e.x||void 0===e.y)&&(e.w=e.w||s.w,e.h=e.h||s.h,this.engine.findEmptyPosition(e)),this.engine.nodes.push(s),i.samePos(s,e)&&this.engine.nodes.length>1&&(this.moveNode(s,{...e,forceCollide:!0}),i.copyPos(e,s)),this.update(s.el,e),e.subGridOpts?.children){const t=s.el.querySelector(".grid-stack");t&&t.gridstack&&t.gridstack.load(e.subGridOpts.children)}}else t&&this.addWidget(e)})),delete this.engine._loading,this.engine.removedNodes=r,this.batchUpdate(!1),delete this._ignoreLayoutsNodeChange,delete this.engine.skipCacheUpdate,n?x.addRemoveCB=n:delete x.addRemoveCB,h&&this.setAnimation(!0,!0),this}batchUpdate(e=!0){return this.engine.batchUpdate(e),e||(this._updateContainerHeight(),this._triggerRemoveEvent(),this._triggerAddEvent(),this._triggerChangeEvent()),this}getCellHeight(e=!1){if(this.opts.cellHeight&&"auto"!==this.opts.cellHeight&&(!e||!this.opts.cellHeightUnit||"px"===this.opts.cellHeightUnit))return this.opts.cellHeight;if("rem"===this.opts.cellHeightUnit)return this.opts.cellHeight*parseFloat(getComputedStyle(document.documentElement).fontSize);if("em"===this.opts.cellHeightUnit)return this.opts.cellHeight*parseFloat(getComputedStyle(this.el).fontSize);if("cm"===this.opts.cellHeightUnit)return this.opts.cellHeight*(96/2.54);if("mm"===this.opts.cellHeightUnit)return this.opts.cellHeight*(96/2.54)/10;const t=this.el.querySelector("."+this.opts.itemClass);if(t){const e=i.toNumber(t.getAttribute("gs-h"))||1;return Math.round(t.offsetHeight/e)}const s=parseInt(this.el.getAttribute("gs-current-row"));return s?Math.round(this.el.getBoundingClientRect().height/s):this.opts.cellHeight}cellHeight(e){if(void 0!==e&&this._isAutoCellHeight!==("auto"===e)&&(this._isAutoCellHeight="auto"===e,this._updateResizeEvent()),"initial"!==e&&"auto"!==e||(e=void 0),void 0===e){const t=-this.opts.marginRight-this.opts.marginLeft+this.opts.marginTop+this.opts.marginBottom;e=this.cellWidth()+t}const t=i.parseHeight(e);return this.opts.cellHeightUnit===t.unit&&this.opts.cellHeight===t.h||(this.opts.cellHeightUnit=t.unit,this.opts.cellHeight=t.h,this.el.style.setProperty("--gs-cell-height",`${this.opts.cellHeight}${this.opts.cellHeightUnit}`),this._updateContainerHeight(),this.resizeToContentCheck()),this}cellWidth(){return this._widthOrContainer()/this.getColumn()}_widthOrContainer(e=!1){return e&&this.opts.columnOpts?.breakpointForWindow?window.innerWidth:this.el.clientWidth||this.el.parentElement.clientWidth||window.innerWidth}checkDynamicColumn(){const e=this.opts.columnOpts;if(!e||!e.columnWidth&&!e.breakpoints?.length)return!1;const t=this.getColumn();let i=t;const s=this._widthOrContainer(!0);if(e.columnWidth)i=Math.min(Math.round(s/e.columnWidth)||1,e.columnMax);else{i=e.columnMax;let o=0;for(;o<e.breakpoints.length&&s<=e.breakpoints[o].w;)i=e.breakpoints[o++].c||t}if(i!==t){const t=e.breakpoints?.find((e=>e.c===i));return this.column(i,t?.layout||e.layout),!0}return!1}compact(e="compact",t=!0){return this.engine.compact(e,t),this._triggerChangeEvent(),this}column(e,t="moveScale"){if(!e||e<1||this.opts.column===e)return this;const i=this.getColumn();return this.opts.column=e,this.engine?(this.engine.column=e,this.el.classList.remove("gs-"+i),this._updateColumnVar(),this.engine.columnChanged(i,e,t),this._isAutoCellHeight&&this.cellHeight(),this.resizeToContentCheck(!0),this._ignoreLayoutsNodeChange=!0,this._triggerChangeEvent(),delete this._ignoreLayoutsNodeChange,this):(this.responseLayout=t,this)}getColumn(){return this.opts.column}getGridItems(){return Array.from(this.el.children).filter((e=>e.matches("."+this.opts.itemClass)&&!e.matches("."+this.opts.placeholderClass)))}isIgnoreChangeCB(){return this._ignoreLayoutsNodeChange}destroy(e=!0){if(this.el)return this.offAll(),this._updateResizeEvent(!0),this.setStatic(!0,!1),this.setAnimation(!1),e?this.el.parentNode.removeChild(this.el):(this.removeAll(e),this.el.removeAttribute("gs-current-row")),this.parentGridNode&&delete this.parentGridNode.subGrid,delete this.parentGridNode,delete this.opts,delete this._placeholder?.gridstackNode,delete this._placeholder,delete this.engine,delete this.el.gridstack,delete this.el,this}float(e){return this.opts.float!==e&&(this.opts.float=this.engine.float=e,this._triggerChangeEvent()),this}getFloat(){return this.engine.float}getCellFromPixel(e,t=!1){const i=this.el.getBoundingClientRect();let s;s=t?{top:i.top+document.documentElement.scrollTop,left:i.left}:{top:this.el.offsetTop,left:this.el.offsetLeft};const o=e.left-s.left,n=e.top-s.top,r=i.width/this.getColumn(),a=i.height/parseInt(this.el.getAttribute("gs-current-row"));return{x:Math.floor(o/r),y:Math.floor(n/a)}}getRow(){return Math.max(this.engine.getRow(),this.opts.minRow||0)}isAreaEmpty(e,t,i,s){return this.engine.isAreaEmpty(e,t,i,s)}makeWidget(e,t){const i=x.getElement(e);if(!i||i.gridstackNode)return i;i.parentElement||this.el.appendChild(i),this._prepareElement(i,!0,t);const s=i.gridstackNode;let o;return this._updateContainerHeight(),s.subGridOpts&&this.makeSubGrid(i,s.subGridOpts,void 0,!1),1!==this.opts.column||this._ignoreLayoutsNodeChange||(o=this._ignoreLayoutsNodeChange=!0),this._triggerAddEvent(),this._triggerChangeEvent(),o&&delete this._ignoreLayoutsNodeChange,i}on(e,t){if(-1!==e.indexOf(" "))return e.split(" ").forEach((e=>this.on(e,t))),this;if("change"===e||"added"===e||"removed"===e||"enable"===e||"disable"===e){const i="enable"===e||"disable"===e;this._gsEventHandler[e]=i?e=>t(e):e=>{e.detail&&t(e,e.detail)},this.el.addEventListener(e,this._gsEventHandler[e])}else"drag"===e||"dragstart"===e||"dragstop"===e||"resizestart"===e||"resize"===e||"resizestop"===e||"dropped"===e||"resizecontent"===e?this._gsEventHandler[e]=t:console.error("GridStack.on("+e+") event not supported");return this}off(e){return-1!==e.indexOf(" ")?(e.split(" ").forEach((e=>this.off(e))),this):("change"!==e&&"added"!==e&&"removed"!==e&&"enable"!==e&&"disable"!==e||this._gsEventHandler[e]&&this.el.removeEventListener(e,this._gsEventHandler[e]),delete this._gsEventHandler[e],this)}offAll(){return Object.keys(this._gsEventHandler).forEach((e=>this.off(e))),this}removeWidget(e,t=!0,i=!0){return e?(x.getElements(e).forEach((e=>{if(e.parentElement&&e.parentElement!==this.el)return;let s=e.gridstackNode;s||(s=this.engine.nodes.find((t=>e===t.el))),s&&(t&&x.addRemoveCB&&x.addRemoveCB(this.el,s,!1,!1),delete e.gridstackNode,this._removeDD(e),this.engine.removeNode(s,t,i),t&&e.parentElement&&e.remove())})),i&&(this._triggerRemoveEvent(),this._triggerChangeEvent()),this):(console.error("Error: GridStack.removeWidget(undefined) called"),this)}removeAll(e=!0,t=!0){return this.engine.nodes.forEach((t=>{e&&x.addRemoveCB&&x.addRemoveCB(this.el,t,!1,!1),delete t.el.gridstackNode,this.opts.staticGrid||this._removeDD(t.el)})),this.engine.removeAll(e,t),t&&this._triggerRemoveEvent(),this}setAnimation(e=this.opts.animate,t){return t?setTimeout((()=>{this.opts&&this.setAnimation(e)})):e?this.el.classList.add("grid-stack-animate"):this.el.classList.remove("grid-stack-animate"),this.opts.animate=e,this}hasAnimationCSS(){return this.el.classList.contains("grid-stack-animate")}setStatic(e,t=!0,i=!0){return!!this.opts.staticGrid===e||(e?this.opts.staticGrid=!0:delete this.opts.staticGrid,this._setupRemoveDrop(),this._setupAcceptWidget(),this.engine.nodes.forEach((s=>{this.prepareDragDrop(s.el),s.subGrid&&i&&s.subGrid.setStatic(e,t,i)})),t&&this._setStaticClass()),this}updateOptions(e){const t=this.opts;return e===t||(void 0!==e.acceptWidgets&&(t.acceptWidgets=e.acceptWidgets,this._setupAcceptWidget()),void 0!==e.animate&&this.setAnimation(e.animate),e.cellHeight&&this.cellHeight(e.cellHeight),void 0!==e.class&&e.class!==t.class&&(t.class&&this.el.classList.remove(t.class),e.class&&this.el.classList.add(e.class)),e.columnOpts?(this.opts.columnOpts=e.columnOpts,this.checkDynamicColumn()):null===e.columnOpts&&this.opts.columnOpts?(delete this.opts.columnOpts,this._updateResizeEvent()):"number"==typeof e.column&&this.column(e.column),void 0!==e.margin&&this.margin(e.margin),void 0!==e.staticGrid&&this.setStatic(e.staticGrid),void 0===e.disableDrag||e.staticGrid||this.enableMove(!e.disableDrag),void 0===e.disableResize||e.staticGrid||this.enableResize(!e.disableResize),void 0!==e.float&&this.float(e.float),void 0!==e.row?(t.minRow=t.maxRow=t.row=e.row,this._updateContainerHeight()):(void 0!==e.minRow&&(t.minRow=e.minRow,this._updateContainerHeight()),void 0!==e.maxRow&&(t.maxRow=e.maxRow)),e.children?.length&&this.load(e.children)),this}update(e,t){return x.getElements(e).forEach((e=>{const s=e?.gridstackNode;if(!s)return;const o={...i.copyPos({},s),...i.cloneDeep(t)};this.engine.nodeBoundFix(o),delete o.autoPosition;const n=["x","y","w","h"];let r;if(n.some((e=>void 0!==o[e]&&o[e]!==s[e]))&&(r={},n.forEach((e=>{r[e]=void 0!==o[e]?o[e]:s[e],delete o[e]}))),!r&&(o.minW||o.minH||o.maxW||o.maxH)&&(r={}),void 0!==o.content){const t=e.querySelector(".grid-stack-item-content");t&&t.textContent!==o.content&&(s.content=o.content,x.renderCB(t,o),s.subGrid?.el&&(t.appendChild(s.subGrid.el),s.subGrid._updateContainerHeight())),delete o.content}let a=!1,h=!1;for(const e in o)"_"!==e[0]&&s[e]!==o[e]&&(s[e]=o[e],a=!0,h=h||!this.opts.staticGrid&&("noResize"===e||"noMove"===e||"locked"===e));if(i.sanitizeMinMax(s),r){const e=void 0!==r.w&&r.w!==s.w;this.moveNode(s,r),e&&s.subGrid?s.subGrid.onResize(this.hasAnimationCSS()?s.w:void 0):this.resizeToContentCheck(e,s),delete s._orig}(r||a)&&this._writeAttr(e,s),h&&this.prepareDragDrop(s.el),x.updateCB&&x.updateCB(s)})),this}moveNode(e,t){const i=e._updating;i||this.engine.cleanNodes().beginUpdate(e),this.engine.moveNode(e,t),this._updateContainerHeight(),i||(this._triggerChangeEvent(),this.engine.endUpdate())}resizeToContent(e){if(!e)return;if(e.classList.remove("size-to-content-max"),!e.clientHeight)return;const t=e.gridstackNode;if(!t)return;const i=t.grid;if(!i||e.parentElement!==i.el)return;const s=i.getCellHeight(!0);if(!s)return;let o,n=t.h?t.h*s:e.clientHeight;if(t.resizeToContentParent&&(o=e.querySelector(t.resizeToContentParent)),o||(o=e.querySelector(x.resizeToContentParent)),!o)return;const r=e.clientHeight-o.clientHeight,a=t.h?t.h*s-r:o.clientHeight;let h;if(t.subGrid){h=t.subGrid.getRow()*t.subGrid.getCellHeight(!0);const i=t.subGrid.el.getBoundingClientRect(),s=e.getBoundingClientRect();h+=i.top-s.top}else{if(t.subGridOpts?.children?.length)return;{const e=o.firstElementChild;if(!e)return void console.error(`Error: GridStack.resizeToContent() widget id:${t.id} '${x.resizeToContentParent}'.firstElementChild is null, make sure to have a div like container. Skipping sizing.`);h=e.getBoundingClientRect().height||a}}if(a===h)return;n+=h-a;let l=Math.ceil(n/s);const d=Number.isInteger(t.sizeToContent)?t.sizeToContent:0;d&&l>d&&(l=d,e.classList.add("size-to-content-max")),t.minH&&l<t.minH?l=t.minH:t.maxH&&l>t.maxH&&(l=t.maxH),l!==t.h&&(i._ignoreLayoutsNodeChange=!0,i.moveNode(t,{h:l}),delete i._ignoreLayoutsNodeChange)}resizeToContentCBCheck(e){x.resizeToContentCB?x.resizeToContentCB(e):this.resizeToContent(e)}rotate(e,t){return x.getElements(e).forEach((e=>{const s=e.gridstackNode;if(!i.canBeRotated(s))return;const o={w:s.h,h:s.w,minH:s.minW,minW:s.minH,maxH:s.maxW,maxW:s.maxH};if(t){const e=t.left>0?Math.floor(t.left/this.cellWidth()):0,i=t.top>0?Math.floor(t.top/this.opts.cellHeight):0;o.x=s.x+e-(s.h-(i+1)),o.y=s.y+i-e}Object.keys(o).forEach((e=>{void 0===o[e]&&delete o[e]}));const n=s._orig;this.update(e,o),s._orig=n})),this}margin(e){if(!("string"==typeof e&&e.split(" ").length>1)){const t=i.parseHeight(e);if(this.opts.marginUnit===t.unit&&this.opts.margin===t.h)return}return this.opts.margin=e,this.opts.marginTop=this.opts.marginBottom=this.opts.marginLeft=this.opts.marginRight=void 0,this._initMargin(),this}getMargin(){return this.opts.margin}willItFit(e){if(arguments.length>1){console.warn("gridstack.ts: `willItFit(x,y,w,h,autoPosition)` is deprecated. Use `willItFit({x, y,...})`. It will be removed soon");const e=arguments;let t=0,i={x:e[t++],y:e[t++],w:e[t++],h:e[t++],autoPosition:e[t++]};return this.willItFit(i)}return this.engine.willItFit(e)}_triggerChangeEvent(){if(this.engine.batchMode)return this;const e=this.engine.getDirtyNodes(!0);return e&&e.length&&(this._ignoreLayoutsNodeChange||this.engine.layoutsNodesChange(e),this._triggerEvent("change",e)),this.engine.saveInitial(),this}_triggerAddEvent(){if(this.engine.batchMode)return this;if(this.engine.addedNodes?.length){this._ignoreLayoutsNodeChange||this.engine.layoutsNodesChange(this.engine.addedNodes),this.engine.addedNodes.forEach((e=>{delete e._dirty}));const e=[...this.engine.addedNodes];this.engine.addedNodes=[],this._triggerEvent("added",e)}return this}_triggerRemoveEvent(){if(this.engine.batchMode)return this;if(this.engine.removedNodes?.length){const e=[...this.engine.removedNodes];this.engine.removedNodes=[],this._triggerEvent("removed",e)}return this}_triggerEvent(e,t){const i=t?new CustomEvent(e,{bubbles:!1,detail:t}):new Event(e);let s=this;for(;s.parentGridNode;)s=s.parentGridNode.grid;return s.el.dispatchEvent(i),this}_updateContainerHeight(){if(!this.engine||this.engine.batchMode)return this;const e=this.parentGridNode;let t=this.getRow()+this._extraDragRow;const s=this.opts.cellHeight,o=this.opts.cellHeightUnit;if(!s)return this;if(!e&&!this.opts.minRow){const e=i.parseHeight(getComputedStyle(this.el).minHeight);if(e.h>0&&e.unit===o){const i=Math.floor(e.h/s);t<i&&(t=i)}}return this.el.setAttribute("gs-current-row",String(t)),this.el.style.removeProperty("min-height"),this.el.style.removeProperty("height"),t&&(this.el.style[e?"minHeight":"height"]=t*s+o),e&&i.shouldSizeToContent(e)&&e.grid.resizeToContentCBCheck(e.el),this}_prepareElement(e,t=!1,s){s=s||this._readAttr(e),e.gridstackNode=s,s.el=e,s.grid=this,s=this.engine.addNode(s,t),this._writeAttr(e,s),e.classList.add(o.itemClass,this.opts.itemClass);const n=i.shouldSizeToContent(s);return n?e.classList.add("size-to-content"):e.classList.remove("size-to-content"),n&&this.resizeToContentCheck(!1,s),i.lazyLoad(s)||this.prepareDragDrop(s.el),this}_writePosAttr(e,t){return(t._moving||t._resizing)&&this._placeholder!==e||(e.style.top=t.y?1===t.y?"var(--gs-cell-height)":`calc(${t.y} * var(--gs-cell-height))`:null,e.style.left=t.x?1===t.x?"var(--gs-column-width)":`calc(${t.x} * var(--gs-column-width))`:null,e.style.width=t.w>1?`calc(${t.w} * var(--gs-column-width))`:null,e.style.height=t.h>1?`calc(${t.h} * var(--gs-cell-height))`:null),t.x>0?e.setAttribute("gs-x",String(t.x)):e.removeAttribute("gs-x"),t.y>0?e.setAttribute("gs-y",String(t.y)):e.removeAttribute("gs-y"),t.w>1?e.setAttribute("gs-w",String(t.w)):e.removeAttribute("gs-w"),t.h>1?e.setAttribute("gs-h",String(t.h)):e.removeAttribute("gs-h"),this}_writeAttr(e,t){if(!t)return this;this._writePosAttr(e,t);const i={noResize:"gs-no-resize",noMove:"gs-no-move",locked:"gs-locked",id:"gs-id",sizeToContent:"gs-size-to-content"};for(const s in i)t[s]?e.setAttribute(i[s],String(t[s])):e.removeAttribute(i[s]);return this}_readAttr(e,t=!0){const s={};s.x=i.toNumber(e.getAttribute("gs-x")),s.y=i.toNumber(e.getAttribute("gs-y")),s.w=i.toNumber(e.getAttribute("gs-w")),s.h=i.toNumber(e.getAttribute("gs-h")),s.autoPosition=i.toBool(e.getAttribute("gs-auto-position")),s.noResize=i.toBool(e.getAttribute("gs-no-resize")),s.noMove=i.toBool(e.getAttribute("gs-no-move")),s.locked=i.toBool(e.getAttribute("gs-locked"));const o=e.getAttribute("gs-size-to-content");o&&(s.sizeToContent="true"===o||"false"===o?i.toBool(o):parseInt(o,10)),s.id=e.getAttribute("gs-id"),s.maxW=i.toNumber(e.getAttribute("gs-max-w")),s.minW=i.toNumber(e.getAttribute("gs-min-w")),s.maxH=i.toNumber(e.getAttribute("gs-max-h")),s.minH=i.toNumber(e.getAttribute("gs-min-h")),t&&(1===s.w&&e.removeAttribute("gs-w"),1===s.h&&e.removeAttribute("gs-h"),s.maxW&&e.removeAttribute("gs-max-w"),s.minW&&e.removeAttribute("gs-min-w"),s.maxH&&e.removeAttribute("gs-max-h"),s.minH&&e.removeAttribute("gs-min-h"));for(const e in s){if(!s.hasOwnProperty(e))return;s[e]||0===s[e]||"sizeToContent"===e||delete s[e]}return s}_setStaticClass(){const e=["grid-stack-static"];return this.opts.staticGrid?(this.el.classList.add(...e),this.el.setAttribute("gs-static","true")):(this.el.classList.remove(...e),this.el.removeAttribute("gs-static")),this}onResize(e=this.el?.clientWidth){if(!e)return;if(this.prevWidth===e)return;this.prevWidth=e,this.batchUpdate();let t=!1;return this._autoColumn&&this.parentGridNode?this.opts.column!==this.parentGridNode.w&&(this.column(this.parentGridNode.w,this.opts.layout||"list"),t=!0):t=this.checkDynamicColumn(),this._isAutoCellHeight&&this.cellHeight(),this.engine.nodes.forEach((e=>{e.subGrid&&e.subGrid.onResize()})),this._skipInitialResize||this.resizeToContentCheck(t),delete this._skipInitialResize,this.batchUpdate(!1),this}resizeToContentCheck(e=!1,t=void 0){if(this.engine){if(e&&this.hasAnimationCSS())return setTimeout((()=>this.resizeToContentCheck(!1,t)),this.animationDelay);if(t)i.shouldSizeToContent(t)&&this.resizeToContentCBCheck(t.el);else if(this.engine.nodes.some((e=>i.shouldSizeToContent(e)))){const e=[...this.engine.nodes];this.batchUpdate(),e.forEach((e=>{i.shouldSizeToContent(e)&&this.resizeToContentCBCheck(e.el)})),this._ignoreLayoutsNodeChange=!0,this.batchUpdate(!1),this._ignoreLayoutsNodeChange=!1}this._gsEventHandler.resizecontent&&this._gsEventHandler.resizecontent(null,t?[t]:this.engine.nodes)}}_updateResizeEvent(e=!1){const t=!this.parentGridNode&&(this._isAutoCellHeight||this.opts.sizeToContent||this.opts.columnOpts||this.engine.nodes.find((e=>e.sizeToContent)));return e||!t||this.resizeObserver?!e&&t||!this.resizeObserver||(this.resizeObserver.disconnect(),delete this.resizeObserver,delete this._sizeThrottle):(this._sizeThrottle=i.throttle((()=>this.onResize()),this.opts.cellHeightThrottle),this.resizeObserver=new ResizeObserver((()=>this._sizeThrottle())),this.resizeObserver.observe(this.el),this._skipInitialResize=!0),this}static getElement(e=".grid-stack-item"){return i.getElement(e)}static getElements(e=".grid-stack-item"){return i.getElements(e)}static getGridElement(e){return x.getElement(e)}static getGridElements(e){return i.getElements(e)}_initMargin(){let e,t=0,s=[];"string"==typeof this.opts.margin&&(s=this.opts.margin.split(" ")),2===s.length?(this.opts.marginTop=this.opts.marginBottom=s[0],this.opts.marginLeft=this.opts.marginRight=s[1]):4===s.length?(this.opts.marginTop=s[0],this.opts.marginRight=s[1],this.opts.marginBottom=s[2],this.opts.marginLeft=s[3]):(e=i.parseHeight(this.opts.margin),this.opts.marginUnit=e.unit,t=this.opts.margin=e.h),["marginTop","marginRight","marginBottom","marginLeft"].forEach((s=>{void 0===this.opts[s]?this.opts[s]=t:(e=i.parseHeight(this.opts[s]),this.opts[s]=e.h,delete this.opts.margin)})),this.opts.marginUnit=e.unit,this.opts.marginTop===this.opts.marginBottom&&this.opts.marginLeft===this.opts.marginRight&&this.opts.marginTop===this.opts.marginRight&&(this.opts.margin=this.opts.marginTop);const o=this.el.style;return o.setProperty("--gs-item-margin-top",`${this.opts.marginTop}${this.opts.marginUnit}`),o.setProperty("--gs-item-margin-bottom",`${this.opts.marginBottom}${this.opts.marginUnit}`),o.setProperty("--gs-item-margin-right",`${this.opts.marginRight}${this.opts.marginUnit}`),o.setProperty("--gs-item-margin-left",`${this.opts.marginLeft}${this.opts.marginUnit}`),this}static getDD(){return E}static setupDragIn(e,t,s,o=document){void 0!==t?.pause&&(n.pauseDrag=t.pause),t={appendTo:"body",helper:"clone",...t||{}},("string"==typeof e?i.getElements(e,o):e).forEach(((e,i)=>{E.isDraggable(e)||E.dragIn(e,t),s?.[i]&&(e.gridstackNode=s[i])}))}movable(e,t){return this.opts.staticGrid||x.getElements(e).forEach((e=>{const i=e.gridstackNode;i&&(t?delete i.noMove:i.noMove=!0,this.prepareDragDrop(i.el))})),this}resizable(e,t){return this.opts.staticGrid||x.getElements(e).forEach((e=>{const i=e.gridstackNode;i&&(t?delete i.noResize:i.noResize=!0,this.prepareDragDrop(i.el))})),this}disable(e=!0){if(!this.opts.staticGrid)return this.enableMove(!1,e),this.enableResize(!1,e),this._triggerEvent("disable"),this}enable(e=!0){if(!this.opts.staticGrid)return this.enableMove(!0,e),this.enableResize(!0,e),this._triggerEvent("enable"),this}enableMove(e,t=!0){return this.opts.staticGrid||(e?delete this.opts.disableDrag:this.opts.disableDrag=!0,this.engine.nodes.forEach((i=>{this.prepareDragDrop(i.el),i.subGrid&&t&&i.subGrid.enableMove(e,t)}))),this}enableResize(e,t=!0){return this.opts.staticGrid||(e?delete this.opts.disableResize:this.opts.disableResize=!0,this.engine.nodes.forEach((i=>{this.prepareDragDrop(i.el),i.subGrid&&t&&i.subGrid.enableResize(e,t)}))),this}cancelDrag(){const e=this._placeholder?.gridstackNode;e&&(e._isExternal?(e._isAboutToRemove=!0,this.engine.removeNode(e)):e._isAboutToRemove&&x._itemRemoving(e.el,!1),this.engine.restoreInitial())}_removeDD(e){return E.draggable(e,"destroy").resizable(e,"destroy"),e.gridstackNode&&delete e.gridstackNode._initDD,delete e.ddElement,this}_setupAcceptWidget(){if(this.opts.staticGrid||!this.opts.acceptWidgets&&!this.opts.removable)return E.droppable(this.el,"destroy"),this;let e,t;const s=(s,o,n)=>{const r=(n=n||o).gridstackNode;if(!r)return;if(!r.grid?.el){n.style.transform=`scale(${1/this.dragTransform.xScale},${1/this.dragTransform.yScale})`;const e=n.getBoundingClientRect();n.style.left=e.x+(this.dragTransform.xScale-1)*(s.clientX-e.x)/this.dragTransform.xScale+"px",n.style.top=e.y+(this.dragTransform.yScale-1)*(s.clientY-e.y)/this.dragTransform.yScale+"px",n.style.transformOrigin="0px 0px"}let{top:a,left:h}=n.getBoundingClientRect();const l=this.el.getBoundingClientRect();h-=l.left,a-=l.top;const d={position:{top:a*this.dragTransform.xScale,left:h*this.dragTransform.yScale}};if(r._temporaryRemoved){if(r.x=Math.max(0,Math.round(h/t)),r.y=Math.max(0,Math.round(a/e)),delete r.autoPosition,this.engine.nodeBoundFix(r),!this.engine.willItFit(r)){if(r.autoPosition=!0,!this.engine.willItFit(r))return void E.off(o,"drag");r._willFitPos&&(i.copyPos(r,r._willFitPos),delete r._willFitPos)}this._onStartMoving(n,s,d,r,t,e)}else this._dragOrResize(n,s,d,r,t,e)};return E.droppable(this.el,{accept:e=>{const t=e.gridstackNode||this._readAttr(e,!1);if(t?.grid===this)return!0;if(!this.opts.acceptWidgets)return!1;let i=!0;if("function"==typeof this.opts.acceptWidgets)i=this.opts.acceptWidgets(e);else{const t=!0===this.opts.acceptWidgets?".grid-stack-item":this.opts.acceptWidgets;i=e.matches(t)}if(i&&t&&this.opts.maxRow){const e={w:t.w,h:t.h,minW:t.minW,minH:t.minH};i=this.engine.willItFit(e)}return i}}).on(this.el,"dropover",((i,o,n)=>{let r=n?.gridstackNode||o.gridstackNode;if(r?.grid===this&&!r._temporaryRemoved)return!1;if(r?._sidebarOrig&&(r.w=r._sidebarOrig.w,r.h=r._sidebarOrig.h),r?.grid&&r.grid!==this&&!r._temporaryRemoved&&r.grid._leave(o,n),n=n||o,t=this.cellWidth(),e=this.getCellHeight(!0),!r){const e=n.getAttribute("data-gs-widget")||n.getAttribute("gridstacknode");if(e){try{r=JSON.parse(e)}catch(t){console.error("Gridstack dropover: Bad JSON format: ",e)}n.removeAttribute("data-gs-widget"),n.removeAttribute("gridstacknode")}r||(r=this._readAttr(n)),r._sidebarOrig={w:r.w,h:r.h}}r.grid||(r.el||(r={...r}),r._isExternal=!0,n.gridstackNode=r);const a=r.w||Math.round(n.offsetWidth/t)||1,h=r.h||Math.round(n.offsetHeight/e)||1;return r.grid&&r.grid!==this?(o._gridstackNodeOrig||(o._gridstackNodeOrig=r),o.gridstackNode=r={...r,w:a,h,grid:this},delete r.x,delete r.y,this.engine.cleanupNode(r).nodeBoundFix(r),r._initDD=r._isExternal=r._temporaryRemoved=!0):(r.w=a,r.h=h,r._temporaryRemoved=!0),x._itemRemoving(r.el,!1),E.on(o,"drag",s),s(i,o,n),!1})).on(this.el,"dropout",((e,t,i)=>{const s=i?.gridstackNode||t.gridstackNode;return!!s&&(s.grid&&s.grid!==this||(this._leave(t,i),this._isTemp&&this.removeAsSubGrid(s)),!1)})).on(this.el,"drop",((e,t,s)=>{const o=s?.gridstackNode||t.gridstackNode;if(o?.grid===this&&!o._isExternal)return!1;const n=!!this.placeholder.parentElement,r=t!==s;this.placeholder.remove(),delete this.placeholder.gridstackNode,n&&this.opts.animate&&(this.setAnimation(!1),this.setAnimation(!0,!0));const a=t._gridstackNodeOrig;if(delete t._gridstackNodeOrig,n&&a?.grid&&a.grid!==this){const e=a.grid;e.engine.removeNodeFromLayoutCache(a),e.engine.removedNodes.push(a),e._triggerRemoveEvent()._triggerChangeEvent(),e.parentGridNode&&!e.engine.nodes.length&&e.opts.subGridDynamic&&e.removeAsSubGrid()}if(!o)return!1;if(n&&(this.engine.cleanupNode(o),o.grid=this),delete o.grid?._isTemp,E.off(t,"drag"),s!==t?(s.remove(),t=s):t.remove(),this._removeDD(t),!n)return!1;const h=o.subGrid?.el?.gridstack;return i.copyPos(o,this._readAttr(this.placeholder)),i.removePositioningStyles(t),r&&(o.content||o.subGridOpts||x.addRemoveCB)?(delete o.el,t=this.addWidget(o)):(this._prepareElement(t,!0,o),this.el.appendChild(t),this.resizeToContentCheck(!1,o),h&&(h.parentGridNode=o),this._updateContainerHeight()),this.engine.addedNodes.push(o),this._triggerAddEvent(),this._triggerChangeEvent(),this.engine.endUpdate(),this._gsEventHandler.dropped&&this._gsEventHandler.dropped({...e,type:"dropped"},a&&a.grid?a:void 0,o),!1})),this}static _itemRemoving(e,t){if(!e)return;const i=e?e.gridstackNode:void 0;i?.grid&&!e.classList.contains(i.grid.opts.removableOptions.decline)&&(t?i._isAboutToRemove=!0:delete i._isAboutToRemove,t?e.classList.add("grid-stack-item-removing"):e.classList.remove("grid-stack-item-removing"))}_setupRemoveDrop(){if("string"!=typeof this.opts.removable)return this;const e=document.querySelector(this.opts.removable);return e?(this.opts.staticGrid||E.isDroppable(e)||E.droppable(e,this.opts.removableOptions).on(e,"dropover",((e,t)=>x._itemRemoving(t,!0))).on(e,"dropout",((e,t)=>x._itemRemoving(t,!1))),this):this}prepareDragDrop(e,t=!1){const s=e?.gridstackNode;if(!s)return;const o=s.noMove||this.opts.disableDrag,n=s.noResize||this.opts.disableResize,r=this.opts.staticGrid||o&&n;if((t||r)&&(s._initDD&&(this._removeDD(e),delete s._initDD),r&&e.classList.add("ui-draggable-disabled","ui-resizable-disabled"),!t))return this;if(!s._initDD){let t,o;const n=(i,n)=>{this.triggerEvent(i,i.target),t=this.cellWidth(),o=this.getCellHeight(!0),this._onStartMoving(e,i,n,s,t,o)},r=(i,n)=>{this._dragOrResize(e,i,n,s,t,o)},a=t=>{this.placeholder.remove(),delete this.placeholder.gridstackNode,delete s._moving,delete s._resizing,delete s._event,delete s._lastTried;const o=s.w!==s._orig.w,n=t.target;if(n.gridstackNode&&n.gridstackNode.grid===this){if(s.el=n,s._isAboutToRemove){const i=e.gridstackNode.grid;i._gsEventHandler[t.type]&&i._gsEventHandler[t.type](t,n),i.engine.nodes.push(s),i.removeWidget(e,!0,!0)}else i.removePositioningStyles(n),s._temporaryRemoved?(this._writePosAttr(n,s),this.engine.addNode(s)):this._writePosAttr(n,s),this.triggerEvent(t,n);this._extraDragRow=0,this._updateContainerHeight(),this._triggerChangeEvent(),this.engine.endUpdate(),"resizestop"===t.type&&(Number.isInteger(s.sizeToContent)&&(s.sizeToContent=s.h),this.resizeToContentCheck(o,s))}};E.draggable(e,{start:n,stop:a,drag:r}).resizable(e,{start:n,stop:a,resize:r}),s._initDD=!0}return E.draggable(e,o?"disable":"enable").resizable(e,n?"disable":"enable"),this}_onStartMoving(e,t,s,o,n,r){if(this.engine.cleanNodes().beginUpdate(o),this._writePosAttr(this.placeholder,o),this.el.appendChild(this.placeholder),this.placeholder.gridstackNode=o,o.grid?.el)this.dragTransform=i.getValuesFromTransformedElement(e);else if(this.placeholder&&this.placeholder.closest(".grid-stack")){const e=this.placeholder.closest(".grid-stack");this.dragTransform=i.getValuesFromTransformedElement(e)}else this.dragTransform={xScale:1,xOffset:0,yScale:1,yOffset:0};if(o.el=this.placeholder,o._lastUiPosition=s.position,o._prevYPix=s.position.top,o._moving="dragstart"===t.type,o._resizing="resizestart"===t.type,delete o._lastTried,"dropover"===t.type&&o._temporaryRemoved&&(this.engine.addNode(o),o._moving=!0),this.engine.cacheRects(n,r,this.opts.marginTop,this.opts.marginRight,this.opts.marginBottom,this.opts.marginLeft),"resizestart"===t.type){const t=this.getColumn()-o.x,i=(this.opts.maxRow||Number.MAX_SAFE_INTEGER)-o.y;E.resizable(e,"option","minWidth",n*Math.min(o.minW||1,t)).resizable(e,"option","minHeight",r*Math.min(o.minH||1,i)).resizable(e,"option","maxWidth",n*Math.min(o.maxW||Number.MAX_SAFE_INTEGER,t)).resizable(e,"option","maxWidthMoveLeft",n*Math.min(o.maxW||Number.MAX_SAFE_INTEGER,o.x+o.w)).resizable(e,"option","maxHeight",r*Math.min(o.maxH||Number.MAX_SAFE_INTEGER,i)).resizable(e,"option","maxHeightMoveUp",r*Math.min(o.maxH||Number.MAX_SAFE_INTEGER,o.y+o.h))}}_dragOrResize(e,t,s,o,n,r){const a={...o._orig};let h,l=this.opts.marginLeft,d=this.opts.marginRight,c=this.opts.marginTop,g=this.opts.marginBottom;const u=Math.round(.1*r),p=Math.round(.1*n);if(l=Math.min(l,p),d=Math.min(d,p),c=Math.min(c,u),g=Math.min(g,u),"drag"===t.type){if(o._temporaryRemoved)return;const t=s.position.top-o._prevYPix;o._prevYPix=s.position.top,!1!==this.opts.draggable.scroll&&i.updateScrollPosition(e,s.position,t);const h=s.position.left+(s.position.left>o._lastUiPosition.left?-d:l),u=s.position.top+(s.position.top>o._lastUiPosition.top?-g:c);a.x=Math.round(h/n),a.y=Math.round(u/r);const p=this._extraDragRow;if(this.engine.collide(o,a)){const e=this.getRow();let t=Math.max(0,a.y+o.h-e);this.opts.maxRow&&e+t>this.opts.maxRow&&(t=Math.max(0,this.opts.maxRow-e)),this._extraDragRow=t}else this._extraDragRow=0;if(this._extraDragRow!==p&&this._updateContainerHeight(),o.x===a.x&&o.y===a.y)return}else if("resize"===t.type){if(a.x<0)return;if(i.updateScrollResize(t,e,r),a.w=Math.round((s.size.width-l)/n),a.h=Math.round((s.size.height-c)/r),o.w===a.w&&o.h===a.h)return;if(o._lastTried&&o._lastTried.w===a.w&&o._lastTried.h===a.h)return;const d=s.position.left+l,g=s.position.top+c;a.x=Math.round(d/n),a.y=Math.round(g/r),h=!0}o._event=t,o._lastTried=a;const m={x:s.position.left+l,y:s.position.top+c,w:(s.size?s.size.width:o.w*n)-l-d,h:(s.size?s.size.height:o.h*r)-c-g};if(this.engine.moveNodeCheck(o,{...a,cellWidth:n,cellHeight:r,rect:m,resizing:h})){o._lastUiPosition=s.position,this.engine.cacheRects(n,r,c,d,g,l),delete o._skipDown,h&&o.subGrid&&o.subGrid.onResize(),this._extraDragRow=0,this._updateContainerHeight();const e=t.target;o._sidebarOrig||this._writePosAttr(e,o),this.triggerEvent(t,e)}}triggerEvent(e,t){let i=this;for(;i.parentGridNode;)i=i.parentGridNode.grid;i._gsEventHandler[e.type]&&i._gsEventHandler[e.type](e,t)}_leave(e,t){const i=(t=t||e).gridstackNode;if(!i)return;if(t.style.transform=t.style.transformOrigin=null,E.off(e,"drag"),i._temporaryRemoved)return;i._temporaryRemoved=!0,this.engine.removeNode(i),i.el=i._isExternal&&t?t:e;const s=i._sidebarOrig;i._isExternal&&this.engine.cleanupNode(i),i._sidebarOrig=s,!0===this.opts.removable&&x._itemRemoving(e,!0),e._gridstackNodeOrig?(e.gridstackNode=e._gridstackNodeOrig,delete e._gridstackNodeOrig):i._isExternal&&this.engine.restoreInitial()}commit(){return this.batchUpdate(!1).prototype,this}}return x.renderCB=(e,t)=>{e&&t?.content&&(e.textContent=t.content)},x.resizeToContentParent=".grid-stack-item-content",x.Utils=i,x.Engine=s,x.GDRev="12.3.3",t.GridStack})()));

/* DecoyGuard unified workspace — presentation only, no changes to telemetry */
(()=>{'use strict';
const $=id=>document.getElementById(id), key='dg-unified-workspace-v1';

const names = {
 trapHits:'Total Decoy Hits',trapIsolation:'Recorded Containment Ratio',trapFiles:'Captured Artifacts',trapPrimary:'Most Frequent Source IP',
 postureSummary:'Posture Summary', riskContainment:'Risk Bands & Containment', trapSummary:'Honeypot Evidence Summary', trapTaxonomy:'Decoy Attack Taxonomy', trapTranscript:'Captured Honeypot Transcript', trapEvidence:'Decoy Artifacts & Sources', trapRouting:'Decoy Routing Decisions', trapActivity:'Decoy Activity Stream', 
 incidentDock:'Session Context & Forensics Dock', incidentBanner:'Summary & Recorded Stage', portExposure:'Port & Service Evidence', incidentTriage:'Incident Triage', payloadInspector:'Payload & Telemetry Inspector',
  incidentSource:'Investigated Source', incidentPort:'Recorded Target Port', incidentFiles:'Captured Artifacts', incidentDuration:'Observed Time Span', incidentProgress:'Incident Progression', artifactInspector:'Captured Artifacts Inspector', incidentRouting:'Containment & Routing',
  sourceInvestigation: 'Source Investigation',
  intelMitre: 'Reported ATT&CK IDs',
  intelContained: 'Decoy / Redirect Decisions',
  behaviourEvidence: 'Behavioural Pattern Evidence — Table',
  intelRisk: 'Latest Global Score',
  intelConfidence: 'Recorded Confidence',
  intelReporters: 'Reporting Engines in Feed',
  intelDecision: 'Latest Global Decision',
  engineEventLog: 'Recent Engine Findings',
  total: 'Detections in Period',
  critical: 'Critical Threats',
  high: 'High Risk',
  honeypotHits: 'Decoy-Targeted Detections',
  blocked: 'Blocked Detections',
  siteChart: 'Monitoring Coverage & Targeted Endpoints',
  severitySplit: 'Severity Split',
  attackTrendChart: 'Attack Trend',
  attackTypesChart: 'Top Attack Types',
  threatCore: 'Latest Global Assessment',
  attackTimeline: 'Latest Stage Indicator',
  behaviour: 'Behaviour Engine — Pie Chart',
  honeypot: 'Honeypot Monitor',
  riskLayers: 'Latest Assessment Contributions',
  activityStream: 'Activity Stream',
  threatHistory: 'Risk Over Time',
  attackSequence: 'Attack Sequence — Table',
  attackSequenceTimeline: 'Attack Sequence — Timeline',
  attackHeatmap: 'Activity by Hour',
  riskDistribution: 'Risk Distribution',
  detectionBreakdown: 'Events by Reporting Engine',
  containmentFlow: 'Response & Containment',
  mitreProgression: 'Reported ATT&CK Evidence',
  forensicTerminal: 'Honeypot Terminal & Artifacts',
  engineDetails: 'Detection Engine Details (collapsible group)'
};

const aliases = {
  siteMatrix: 'siteChart',
  websiteComparison: 'siteChart',
  responseOutcomes: 'containmentFlow'
};

const engineCards = ['threatCore', 'attackTimeline', 'behaviour', 'honeypot', 'riskLayers'];
const all = Object.keys(names);
const metrics = ['total', 'critical', 'high', 'honeypotHits', 'blocked'];
const intelMetrics=['intelRisk','intelConfidence','intelReporters','intelDecision'];
const analystMetrics=['intelRisk','intelConfidence','intelMitre','intelReporters','intelContained'];

const presets = {
  classic: {
    name: 'Classic Overview',
    description: 'Presentation overview with paired charts and collapsible engine details',
    widgets: ['honeypotHits', 'blocked', 'total', 'critical', 'high', 'attackTrendChart', 'attackTypesChart', 'engineDetails', 'threatCore', 'attackTimeline', 'behaviour', 'honeypot', 'riskLayers', 'activityStream', 'threatHistory']
  },
  global: {
    name: 'Global Overview',
    description: 'Telemetry sources, detection trends and dense incident triage',
    widgets: ['total', 'critical', 'high', 'honeypotHits', 'blocked', 'siteChart', 'attackTrendChart', 'attackTypesChart', 'severitySplit', 'activityStream', 'threatHistory']
  },
  threat: {
    name: 'Threat Intelligence',
    description: 'Engine assessment, source investigation and supplied threat evidence',
    widgets: ['intelRisk','intelConfidence','intelMitre','intelReporters','intelContained','riskLayers','behaviourEvidence','sourceInvestigation','mitreProgression','engineEventLog','activityStream']
  },
  incidents: {
    name: 'Incident · Split-Pane Forensics',
    description: 'Context and forensics dock beside a sequence and payload workspace',
    widgets: ['incidentTriage','incidentDock','attackSequenceTimeline','payloadInspector']
  },
  incidentPipeline: {name:'Incident · Horizontal Pipeline', description:'Unified context and stage, paired inspection, three balanced evidence cards', widgets:['incidentBanner','attackSequence','payloadInspector','incidentRouting','artifactInspector','portExposure']},
  journey: {
    name: 'Attack Journey',
    description: 'Entity and containment rail beside chronological requests and payload analysis',
    widgets: ['incidentProgress', 'incidentDock', 'attackSequence', 'payloadInspector']
  },
  posture: {
    name: 'Security Posture',
    description: 'Cross-site exposure, 24h heatmap, risk bands & containment flow',
    widgets: ['postureSummary','siteChart','attackHeatmap','attackTrendChart','riskContainment']
  },
  honeypot: {
    name: 'Honeypot Operations',
    description: 'Decoy-targeted evidence, captured commands, artifacts and recorded routing',
    widgets: ['trapHits','trapIsolation','trapFiles','trapPrimary','trapTaxonomy','trapTranscript','trapEvidence','trapActivity']
  },
  blank: {
    name: 'Blank Canvas',
    description: 'Build your own SOC workspace',
    widgets: []
  },
  custom: {
    name: 'My Workspace',
    description: 'Drag, resize and arrange your widgets',
    widgets: all.filter(id => id !== 'engineDetails')
  }
};

const themePalettes = {
  original: {
    base: "#02080f", card: "#061722", raised: "#0c2332", text: "#e8f2ff", muted: "#a0b3c9", line: "#25465b",
    accent: "#00d9ff", danger: "#ff609a", warning: "#ffd452", success: "#35ec9c", info: "#00d9ff", purple: "#b895ff",
    series: ["#00d9ff", "#ff609a", "#b895ff", "#ffd452", "#35ec9c", "#72a9ff"]
  },
  midnight: {
    base: "#050b25", card: "#0d1740", raised: "#15234c", text: "#ecf4ff", muted: "#a3b6d0", line: "#34477e",
    accent: "#83a1ff", danger: "#ff7895", warning: "#ffd36c", success: "#4be0c3", info: "#69baff", purple: "#a89aff",
    series: ["#83a1ff", "#69baff", "#4be0c3", "#ffd36c", "#ff7895", "#a89aff"]
  },
  amethyst: {
    base: "#11001f", card: "#25063d", raised: "#330d4c", text: "#f3e8fc", muted: "#d4bfe5", line: "#683280",
    accent: "#8494ff", danger: "#ef7cbb", warning: "#efc47c", success: "#6ce6dd", info: "#6acafc", purple: "#8494ff", lime: "#dbf094",
    series: ["#8494ff", "#6acafc", "#6ce6dd", "#dbf094", "#ef7cbb", "#efc47c"]
  },
  daylight: {
    base: "#e5f4fb", card: "#ffffff", raised: "#f3f9fc", text: "#183747", muted: "#526978", line: "#c6dfe9",
    accent: "#167ca8", danger: "#FA26A0", warning: "#FFF591", success: "#A3F7BF", info: "#05DFD7", purple: "#6acafc", lime: "#C4FB6D",
    series: ["#05DFD7", "#FA26A0", "#C4FB6D", "#FFF591", "#A3F7BF", "#6acafc"]
  },
  dracula: {
    base: "#262630", card: "#30303d", raised: "#373745", text: "#f8f8f2", muted: "#b6b8d0", line: "#67627b",
    accent: "#bd93f9", danger: "#ff838c", warning: "#f1fa8c", success: "#50fa7b", info: "#8be9fd", purple: "#bd93f9",
    series: ["#bd93f9", "#ff79c6", "#8be9fd", "#f1fa8c", "#50fa7b", "#ffb86c"]
  },
  nord: {
    base: "#203139", card: "#2b4048", raised: "#324952", text: "#edf7f8", muted: "#b8ced2", line: "#607d85",
    accent: "#62e0e2", danger: "#ffa4b4", warning: "#ffdb8f", success: "#a5e6a0", info: "#8bd4ff", purple: "#d1b4f3",
    series: ["#62e0e2", "#8bd4ff", "#d1b4f3", "#ffdb8f", "#a5e6a0", "#ffa4b4"]
  }
};

const themes = {
  original: ['Original Dark', '#030c18', '#64b8dc'],
  midnight: ['Midnight', '#071126', '#85b6ed'],
  amethyst: ['Goth Rave', '#0c0416', '#cb8aff'],
  daylight: ['Soft Daylight', '#f1f6f8', '#118ab2'],
  dracula: ['Dracula', '#282a36', '#bd93f9'],
  nord: ['Nord', '#2e3440', '#88c0d0']
};

for (const preset of Object.values(presets)) {
  preset.widgets = [...new Set(preset.widgets.map(id => aliases[id] || id))];
}

const defaults = {
  preset: 'classic',
  theme: 'original',
  reading: 'standard',
  scale: 100,
  density: 'normal',
  charts: true,
  motion: false,
  widgets: presets.classic.widgets.slice(),
  order: all.slice(),
  sizes: {}
};

let state = JSON.parse(JSON.stringify(defaults)), draft = null, dragId = null;

try {
  const v = JSON.parse(localStorage.getItem(key) || 'null');
  if(v?.preset==='analyst')v.preset='threat';
  if (v && presets[v.preset] && themes[v.theme]) {
    state = { ...defaults, ...v, widgets: Array.isArray(v.widgets) ? v.widgets : defaults.widgets.slice(), order: Array.isArray(v.order) ? v.order : all.slice(), sizes: v.sizes || {} };
  }
} catch (_) {}

/* Expand the previous combined strip without losing saved widget selection. */
for(const field of ['widgets','order'])state[field]=state[field].flatMap(id=>id==='intelStatus'?intelMetrics:[id]);
for(const [key,layout]of Object.entries(state.gridLayouts||{})){
 const old=layout.intelStatus;if(!old)continue;
 const c=key.endsWith(':phone')?1:key.endsWith(':tablet')?30:60;
 intelMetrics.forEach((id,i)=>{layout[id]={x:c===1?0:c===30?(i%2)*15:i*15,y:old.y+(c===1?i*4:c===30?Math.floor(i/2)*4:0),w:c===1?1:15,h:4};});delete layout.intelStatus;
}
const customSelection = preset => ['custom','blank'].includes(preset);
const selectedWidgets = () => (customSelection(state.preset)?state.widgets:presets[state.preset].widgets).slice();
const layoutSpans={global:{total:12,critical:12,high:12,honeypotHits:12,blocked:12,siteChart:20,attackTrendChart:20,attackTypesChart:20,severitySplit:20,activityStream:40,threatHistory:20},classic:{honeypotHits:12,blocked:12,total:12,critical:12,high:12,attackTrendChart:40,attackTypesChart:20,engineDetails:60,activityStream:30,threatHistory:30},threat:{critical:30,high:30,threatCore:30,behaviour:30,riskLayers:30,mitreProgression:30,detectionBreakdown:30,activityStream:30},incidents:{critical:30,high:30,attackSequence:40,threatHistory:20,activityStream:40,attackTimeline:20},journey:{total:20,high:20,honeypotHits:20,attackTimeline:60,attackSequence:40,forensicTerminal:20,containmentFlow:60},posture:{total:20,critical:20,high:20,siteChart:30,attackTrendChart:30,containmentFlow:30,attackHeatmap:30,riskDistribution:60},honeypot:{honeypotHits:30,blocked:30,honeypot:30,forensicTerminal:30,attackTypesChart:30,containmentFlow:30,activityStream:60}};
function adoptCustom(){if(customSelection(state.preset))return;const selected=selectedWidgets();state.widgets=selected;state.order=[...new Set([...grid.children].map(el=>el.dataset.dashboardPanel).filter(Boolean).concat(state.order))];for(const id of selected){const el=panels.get(id);if(el){const width=Number(el.style.getPropertyValue('--dg-span'));if(width)state.sizes[id]=width;}}state.preset='custom';}
const canonical = id => aliases[id] || id;
state.widgets = [...new Set(state.widgets.map(canonical))].filter(id => all.includes(id));
state.order = [...new Set(state.order.map(canonical))].filter(id => all.includes(id));for(const [old,id]of Object.entries(aliases))if(state.sizes[old]&&!state.sizes[id])state.sizes[id]=state.sizes[old];

const panels = new Map(), anchors = new Map();
for (const el of document.querySelectorAll('[data-dashboard-panel]')) {
  const id = el.dataset.dashboardPanel;
  if (!names[id] || panels.has(id)) continue;
  panels.set(id, el);
  const marker = document.createComment('dg-home:' + id);
  el.before(marker);
  anchors.set(id, marker);
}

const main = document.querySelector('.dg-main') || document.querySelector('main');
const grid = document.createElement('section');
grid.id = 'dgCustomGrid';
grid.className = 'dg-custom-grid';
grid.setAttribute('aria-label', 'Custom SOC widgets');
grid.hidden = true;
const reference = $('dgWebsiteDirectory') || document.querySelector('.dashboard-stat-grid');
reference?.before(grid);

const engineGroup = $('dgEngineDetails');
const engineGrid = document.createElement('section');
engineGrid.className = 'dg-engine-custom-grid';
engineGrid.setAttribute('aria-label', 'Detection engine widgets');
engineGroup.append(engineGrid);

let dgResizeFrame=0;
const pendingChartPanels=new Set();
function resizeWidgetCharts(target){
  if(target?.querySelectorAll)pendingChartPanels.add(target);
  else for(const panel of panels.values())if(!panel.hidden)pendingChartPanels.add(panel);
  if(dgResizeFrame)return;
  dgResizeFrame=requestAnimationFrame(()=>{
    dgResizeFrame=0;
    for(const panel of pendingChartPanels){
      if(panel.hidden||panel.closest('[hidden]'))continue;
      for(const canvas of panel.querySelectorAll('canvas'))window.Chart?.getChart?.(canvas)?.resize();
      for(const surface of panel.querySelectorAll('.dg-severity-echart'))window.echarts?.getInstanceByDom?.(surface)?.resize();
    }
    pendingChartPanels.clear();
  });
}
if(window.ResizeObserver){
  const widths=new WeakMap();
  const observer=new ResizeObserver(entries=>{
    for(const entry of entries){
      const width=entry.contentRect.width;
      if(width>0&&Math.abs(width-(widths.get(entry.target)||0))>1){
        widths.set(entry.target,width);resizeWidgetCharts(entry.target);
      }
    }
  });
  for(const panel of panels.values())observer.observe(panel);
}
/* Chart.js observes each chart wrapper; do not also resize every chart for every
   window event. Panel observation covers layout and sidebar width changes. */
grid.addEventListener('dragover',e=>{
  if(!dragId||e.target.closest?.('[data-dashboard-panel]'))return;
  e.preventDefault();if(e.dataTransfer)e.dataTransfer.dropEffect='move';
});
grid.addEventListener('drop',e=>{
  if(!dragId||e.target.closest?.('[data-dashboard-panel]'))return;
  e.preventDefault();
  const source=panels.get(dragId);if(source?.parentNode!==grid)return;
  const candidates=[...grid.children].filter(el=>el!==source&&!el.hidden&&el.dataset.dashboardPanel);
  const target=candidates.map(el=>{const r=el.getBoundingClientRect();return {el,r,d:Math.hypot(e.clientX-Math.max(r.left,Math.min(e.clientX,r.right)),e.clientY-Math.max(r.top,Math.min(e.clientY,r.bottom)))}}).sort((a,b)=>a.d-b.d)[0];
  if(!target)return;adoptCustom();
  const sameRow=e.clientY>=target.r.top&&e.clientY<=target.r.bottom;
  const after=sameRow?e.clientX>target.r.left+target.r.width/2:e.clientY>target.r.top+target.r.height/2;
  if(after)target.el.after(source);else target.el.before(source);
  state.order=[...new Set([...grid.children].map(el=>el.dataset.dashboardPanel).filter(Boolean).concat(state.order))];
  persist();apply();
});
const tools = new Map();

function makeTools(id) {
  const bar = document.createElement('div');
  bar.className = 'dg-widget-tools';
  bar.title = 'Drag with handle to reorder';
  
  const grip = document.createElement('button');grip.type='button';grip.className='dg-widget-grip';grip.title='Drag to reorder, or use arrow keys while focused';grip.setAttribute('aria-label','Move '+names[id]+' with arrow keys');
  grip.innerHTML = '<i class="fa-solid fa-grip-vertical"></i> ' + names[id];
  grip.style.flex = '1';
  grip.draggable = true;
  grip.style.cursor = 'grab';

  const size = document.createElement('select');
  size.setAttribute('aria-label', 'Width for ' + names[id]);
  [['12', '⅕'], ['15', '¼'], ['20', '⅓'], ['30', '½'], ['40', '⅔'], ['60', 'Full']].forEach(([v, t]) => {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = t;
    size.append(o);
  });

  size.addEventListener('pointerdown', e => e.stopPropagation());
  size.addEventListener('mousedown', e => e.stopPropagation());
  size.addEventListener('change', () => {
    const width = Number(size.value);
    if (![12, 15, 20, 30, 40, 60].includes(width)) return;
    if(layoutGrid){
      if(!editing)return;
      const shell=panels.get(id).closest('.dg-grid-shell'),node=shell?.gridstackNode;
      if(!node)return;
      const columns=layoutGrid.getColumn();
      const cells=Math.max(1,Math.round(width*columns/60));
      layoutGrid.update(shell,{w:cells,x:Math.min(node.x,columns-cells)});
      recordGrid();requestAnimationFrame(resizeGridCharts);size.focus();return;
    }
    adoptCustom();state.sizes[id]=width;persist();
    panels.get(id).style.setProperty('--dg-span',String(width));apply();resizeWidgetCharts();size.focus();
  });

  bar.addEventListener('click',e=>e.stopPropagation());bar.append(grip, size);

  grip.addEventListener('dragstart', e => {
    e.stopPropagation();dragId = id;
    e.dataTransfer.setData('text/plain', id);
    e.dataTransfer.effectAllowed = 'move';
    panels.get(id).classList.add('dg-dragging');
  });

  grip.addEventListener('dragend', () => {
    dragId = null;
    panels.get(id).classList.remove('dg-dragging');
    document.querySelectorAll('.dg-drag-target, .dg-drag-target-after').forEach(el => {
      el.classList.remove('dg-drag-target', 'dg-drag-target-after');
    });
  });

  const panel = panels.get(id);

  panel.addEventListener('dragover', e => {
    if (!dragId || dragId === id || panel.parentNode!==grid || panels.get(dragId)?.parentNode!==grid) return;
    e.stopPropagation();e.preventDefault();
    const rect = panel.getBoundingClientRect();
    const sourceRect=panels.get(dragId).getBoundingClientRect();const sameRow=sourceRect.top<rect.bottom&&sourceRect.bottom>rect.top;const isAfter=sameRow?e.clientX>rect.left+rect.width/2:e.clientY>rect.top+rect.height/2;
    panel.classList.toggle('dg-drag-target-after', isAfter);
    panel.classList.toggle('dg-drag-target', !isAfter);
  });

  panel.addEventListener('dragleave', () => {
    panel.classList.remove('dg-drag-target', 'dg-drag-target-after');
  });

  panel.addEventListener('drop', e => {
    if(panel.parentNode!==grid||panels.get(dragId)?.parentNode!==grid)return;e.stopPropagation();e.preventDefault();
    const isAfter = panel.classList.contains('dg-drag-target-after');
    panel.classList.remove('dg-drag-target', 'dg-drag-target-after');
    if (!dragId || dragId === id) return;

    adoptCustom();const sourceEl = panels.get(dragId);
    if (!sourceEl) return;

    if (isAfter) {
      panel.after(sourceEl);
    } else {
      panel.before(sourceEl);
    }

    const currentOrder = Array.from(grid.children)
      .map(child => child.dataset.dashboardPanel)
      .filter(Boolean);

    state.order = [...new Set([...currentOrder, ...state.order])];
    persist();
    apply();
  });

  function moveBeside(target,after){const source=panels.get(id);if(source.parentNode!==grid||target?.parentNode!==grid||target===source)return;adoptCustom();if(after)target.after(source);else target.before(source);state.order=[...new Set([...grid.children].map(x=>x.dataset.dashboardPanel).filter(Boolean).concat(state.order))];persist();apply();grip.focus();}
  grip.addEventListener('keydown',e=>{if(layoutGrid&&editing){if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();const shell=panels.get(id).closest('.dg-grid-shell'),n=shell?.gridstackNode;if(n){layoutGrid.update(shell,{x:Math.max(0,Math.min(layoutGrid.getColumn()-n.w,n.x+(e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0))),y:Math.max(0,n.y+(e.key==='ArrowDown'?1:e.key==='ArrowUp'?-1:0))});recordGrid();}}return;}if(!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key))return;e.preventDefault();e.stopPropagation();const visible=[...grid.children].filter(x=>!x.hidden&&x.dataset.dashboardPanel),at=visible.indexOf(panels.get(id)),forward=['ArrowDown','ArrowRight'].includes(e.key);moveBeside(visible[at+(forward?1:-1)],forward);});
  let touchTarget=null,touchAfter=false;
  grip.addEventListener('pointerdown',e=>{if(layoutGrid)return;if(!['touch','pen'].includes(e.pointerType))return;e.preventDefault();e.stopPropagation();grip.setPointerCapture?.(e.pointerId);touchTarget=null;});
  grip.addEventListener('pointermove',e=>{if(!['touch','pen'].includes(e.pointerType)||!grip.hasPointerCapture?.(e.pointerId))return;e.preventDefault();touchTarget=null;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('[data-dashboard-panel]');for(const el of grid.children)el.classList.remove('dg-drag-target','dg-drag-target-after');if(!target||target===panels.get(id)||target.parentNode!==grid)return;touchTarget=target;const rect=target.getBoundingClientRect();touchAfter=e.clientY>rect.top+rect.height/2;target.classList.add(touchAfter?'dg-drag-target-after':'dg-drag-target');});
  grip.addEventListener('pointerup',e=>{if(layoutGrid)return;if(!['touch','pen'].includes(e.pointerType))return;grip.releasePointerCapture?.(e.pointerId);if(touchTarget)moveBeside(touchTarget,touchAfter);touchTarget=null;for(const el of grid.children)el.classList.remove('dg-drag-target','dg-drag-target-after');});
  grip.addEventListener('pointercancel',()=>{touchTarget=null;for(const el of grid.children)el.classList.remove('dg-drag-target','dg-drag-target-after');});
  tools.set(id, { bar, size });
}

for (const id of panels.keys()) makeTools(id);

function restore() {
  engineGroup.classList.remove('dg-engine-grouped');
  for (const [id, marker] of anchors) {
    const el = panels.get(id);
    marker.after(el);
    const t = tools.get(id);
    if (t?.bar.parentNode) t.bar.remove();
    el.style.removeProperty('--dg-span');
  }
}

function setVisible(ids) {
  for (const [id, el] of panels) {
    if (id !== 'engineDetails') el.hidden = !ids.includes(id);
  }
}

function arrangeEngineGroup(custom, selected) {
  const grouped = custom && selected.includes('engineDetails');
  const wasGrouped = engineGroup.classList.contains('dg-engine-grouped');
  engineGroup.classList.toggle('dg-engine-grouped', grouped);
  if (!grouped) return;
  engineGroup.querySelector('summary').append(tools.get('engineDetails').bar);
  let columns=[...engineGrid.querySelectorAll('.dg-engine-column')];
  if(columns.length!==2){columns=[document.createElement('div'),document.createElement('div')];for(const column of columns){column.className='dg-engine-column';engineGrid.append(column);}}
  const ids=[...new Set([...state.order,...engineCards])].filter(id=>engineCards.includes(id));
  ids.forEach(id=>{const column=['threatCore','behaviour'].includes(id)?0:1;columns[column].append(panels.get(id));tools.get(id).bar.remove();});
  if (!wasGrouped) engineGroup.open = state.preset !== 'classic';
}


/* GridStack owns placement. Telemetry DOM nodes are moved, never recreated. */
let layoutGrid=null, rebuilding=false, editing=false, activeLayoutKey='';
const stash=document.createElement('div');stash.hidden=true;grid.after(stash);
const editor=document.createElement('div');editor.className='dg-grid-editor';
const editButton=$('dgEditLayout')||document.createElement('button');editButton.type='button';editButton.className='settings-action';
editButton.textContent='Edit layout';editButton.setAttribute('aria-pressed','false');
const compactButton=document.createElement('button');compactButton.type='button';compactButton.className='settings-action';compactButton.textContent='Close gaps';compactButton.hidden=true;
const editorNote=document.createElement('span');editorNote.textContent='Layout locked · widgets update live';
if(!editButton.isConnected)editor.append(editButton);editor.append(compactButton,editorNote);grid.before(editor);
function setEditing(value){editing=value;editor.hidden=grid.hidden||!value;editButton.hidden=grid.hidden;editButton.textContent=value?'Done editing':'Edit layout';editButton.setAttribute('aria-pressed',String(value));compactButton.hidden=!value;document.body.classList.toggle('dg-grid-editing',value);editorNote.textContent=value?'Drag a heading or resize a bottom corner · changes save automatically':'Layout locked · widgets update live';layoutGrid?.setStatic(!value);}
editButton.addEventListener('click',()=>{if(!layoutGrid&&state.preset==='classic'){adoptCustom();editing=true;apply();persist();return;}setEditing(!editing);});
compactButton.addEventListener('click',()=>{layoutGrid?.compact();recordGrid();});
function gridCellHeight(){return Math.max(28,Math.min(38,Math.round(window.innerHeight/30*.94)));}
function updateViewportDensity(){if(!layoutGrid)return;layoutGrid.cellHeight(gridCellHeight());fitEngineDetails();resizeGridCharts();}
let viewportDensityTimer;
window.addEventListener('resize',()=>{clearTimeout(viewportDensityTimer);viewportDensityTimer=setTimeout(updateViewportDensity,160);});
function layoutBucket(){const w=grid.clientWidth||main.clientWidth;return w<=900?'phone':w<=1200?'tablet':'desktop';}
function syncWidthControl(id,width){
 const select=tools.get(id)?.size;if(!select)return;
 for(const old of select.querySelectorAll('[data-grid-custom-width]'))old.remove();
 if(![12,15,20,30,40,60].includes(width)){
  const option=document.createElement('option');option.value=String(width);
  option.textContent=Math.round(width/60*100)+'%';option.dataset.gridCustomWidth='true';select.append(option);
 }
 select.value=String(width);
}
function recordGrid(){
 if(!layoutGrid||rebuilding||!editing)return;
 state.order=[...new Set([...layoutGrid.engine.nodes].sort((a,b)=>a.y-b.y||a.x-b.x).map(n=>n.id).concat(state.order))];
 const coordinates={};for(const n of layoutGrid.engine.nodes)coordinates[n.id]={x:n.x,y:n.y,w:n.w,h:n.h};
 if(!customSelection(state.preset)){adoptCustom();document.body.dataset.dgPreset='custom';}
 state.gridLayouts=state.gridLayouts||{};state.gridLayouts['custom:'+layoutBucket()]=coordinates;
 activeLayoutKey='custom:'+layoutBucket();
 for(const [id,n]of Object.entries(coordinates)){
   const width=Math.round(n.w/layoutGrid.getColumn()*60);
   if(layoutGrid.getColumn()>1)state.sizes[id]=width;
   syncWidthControl(id,width);
 }
 persist();const title=$('dgWorkspaceName');if(title)title.textContent=presets.custom.name;
}
function releaseGrid(){
 if(!layoutGrid)return;rebuilding=true;
 layoutGrid.destroy(false);layoutGrid=null;
 for(const shell of [...grid.children]){if(!shell.classList.contains('dg-grid-shell'))continue;const panel=shell.querySelector('[data-dashboard-panel]');if(panel){panel.style.removeProperty('grid-row-end');grid.append(panel);}shell.remove();}
 for(const panel of [...stash.children])grid.append(panel);
 grid.classList.remove('grid-stack');grid.style.removeProperty('height');rebuilding=false;
}
let evidenceFitTimer;
const supportingEvidencePanels=['portExposure','incidentRouting','artifactInspector','incidentBanner'];
const fullEvidencePanels=['attackSequence','attackSequenceTimeline','payloadInspector','trapTaxonomy','trapTranscript','trapEvidence',...supportingEvidencePanels];
function fitEvidencePanels(){
 clearTimeout(evidenceFitTimer);evidenceFitTimer=setTimeout(()=>{
 if(!layoutGrid||rebuilding||editing)return;
 layoutGrid.batchUpdate();
 for(const id of fullEvidencePanels){if(['incidents','incidentPipeline'].includes(state.preset)&&!supportingEvidencePanels.includes(id))continue;const panel=panels.get(id),shell=panel?.closest('.grid-stack-item');if(!shell||panel.hidden||panel.closest('[hidden]'))continue;
 const content=shell.querySelector('.grid-stack-item-content');const oldHeight=panel.style.height,oldMin=panel.style.minHeight;
 panel.style.setProperty('height','auto','important');panel.style.setProperty('min-height','0','important');
 const height=Math.ceil(panel.scrollHeight+14);panel.style.height=oldHeight;panel.style.minHeight=oldMin;
 const h=Math.max(5,Math.ceil(height/gridCellHeight()));if(shell.gridstackNode?.h!==h)layoutGrid.update(shell,{h});
 }
 if(state.preset==='honeypot'){const pair=['trapTaxonomy','trapTranscript'].map(id=>panels.get(id)?.closest('.grid-stack-item')).filter(Boolean);if(pair.length===2&&layoutGrid.getColumn()>1){const h=Math.max(...pair.map(el=>el.gridstackNode.h));for(const el of pair)layoutGrid.update(el,{h});}}
 layoutGrid.batchUpdate(false);
 },80);
}
const evidenceObserver=new MutationObserver(fitEvidencePanels);
for(const id of fullEvidencePanels){const panel=panels.get(id);if(panel)evidenceObserver.observe(panel,{childList:true,subtree:true,characterData:true});}
grid.addEventListener('toggle',fitEvidencePanels,true);
window.addEventListener('dg:layout-changed',fitEvidencePanels);
window.addEventListener('resize',fitEvidencePanels);
function resizeGridCharts(){for(const panel of panels.values())if(!panel.hidden)resizeWidgetCharts(panel);window.dispatchEvent(new Event('dg:grid-resized'));}
function globalPresetLayout(columns){
 const result={};
 const put=(id,x,y,w,h)=>{result[id]={x,y,w,h};};
 if(columns===1){
  let y=0;for(const id of metrics){put(id,0,y,1,3);y+=3;}
  for(const [id,h]of [['siteChart',11],['severitySplit',9],['attackTrendChart',18],['attackTypesChart',13],['activityStream',10],['threatHistory',9]]){put(id,0,y,1,h);y+=h;}
 }else if(columns===30){
  metrics.forEach((id,i)=>put(id,i*6,0,6,4));
  put('siteChart',0,4,15,10);put('severitySplit',0,14,15,9);
  put('attackTrendChart',15,4,15,19);
  put('attackTypesChart',0,23,15,13);put('activityStream',15,23,15,13);
  put('threatHistory',0,36,30,9);
 }else{
  metrics.forEach((id,i)=>put(id,i*12,0,12,4));
  put('siteChart',0,4,16,10);put('severitySplit',0,14,16,8);
  put('attackTrendChart',16,4,28,18);put('attackTypesChart',44,4,16,18);
  put('activityStream',0,22,30,9);put('threatHistory',30,22,30,9);
 }
 return result;
}
function threatPresetLayout(columns){
 const result={},put=(id,x,y,w,h)=>{result[id]={x,y,w,h};};
 if(columns===1){let y=0;for(const id of analystMetrics){put(id,0,y,1,4);y+=4;}for(const [id,h]of [['riskLayers',9],['behaviourEvidence',15],['sourceInvestigation',20],['mitreProgression',11],['engineEventLog',12],['activityStream',10]]){put(id,0,y,1,h);y+=h;}}
 else if(columns===30){analystMetrics.forEach((id,i)=>put(id,i<4?(i%2)*15:0,Math.floor(i/2)*4,i<4?15:30,4));put('riskLayers',0,12,15,9);put('behaviourEvidence',0,21,15,15);put('sourceInvestigation',15,12,15,24);put('mitreProgression',0,36,15,12);put('engineEventLog',15,36,15,12);put('activityStream',0,48,30,10);}
 else{analystMetrics.forEach((id,i)=>put(id,i*12,0,12,4));put('riskLayers',0,4,18,8);put('behaviourEvidence',0,12,18,14);put('sourceInvestigation',18,4,19,22);put('mitreProgression',37,4,23,12);put('engineEventLog',37,16,23,10);put('activityStream',0,26,60,10);}
 return result;
}
function incidentPresetLayout(columns,preset='incidents'){
 const result={},put=(id,x,y,w,h)=>result[id]={x,y,w,h};
 const split=preset==='incidents';
 if(columns===1){let y=0;const items=split?[['incidentDock',20],['attackSequenceTimeline',14],['payloadInspector',15],['incidentTriage',8]]:[['incidentBanner',10],['attackSequence',14],['payloadInspector',18],['portExposure',8],['incidentRouting',9],['artifactInspector',8]];for(const [id,h]of items){put(id,0,y,1,h);y+=h;}}
 else if(split){const dock=columns/3;put('incidentDock',0,0,dock,30);put('attackSequenceTimeline',dock,0,columns-dock,14);put('payloadInspector',dock,14,columns-dock,16);put('incidentTriage',0,30,columns,8);}
 else{const left=columns===60?35:17;put('incidentBanner',0,0,columns,10);put('attackSequence',0,10,left,14);put('payloadInspector',left,10,columns-left,30);put('portExposure',0,24,left,7);const half=Math.floor(left/2);put('incidentRouting',0,31,half,9);put('artifactInspector',half,31,left-half,9);}
 return result;
}
function journeyPresetLayout(columns){
 const result={},put=(id,x,y,w,h)=>result[id]={x,y,w,h};
 if(columns===1){put('incidentProgress',0,0,1,3);put('incidentDock',0,3,1,22);put('attackSequence',0,25,1,13);put('payloadInspector',0,38,1,13);}
 else{const rail=columns/3;put('incidentProgress',0,0,columns,2);put('incidentDock',0,2,rail,26);put('attackSequence',rail,2,columns-rail,13);put('payloadInspector',rail,15,columns-rail,13);}
 return result;
}
function operationsPresetLayout(columns,preset){
 const result={},put=(id,x,y,w,h)=>result[id]={x,y,w,h};
 const posture=preset==='posture';
 if(columns===1){let y=0;const items=posture?[['postureSummary',6],['siteChart',13],['attackHeatmap',10],['attackTrendChart',18],['riskContainment',16]]:[['trapHits',4],['trapIsolation',4],['trapFiles',4],['trapPrimary',4],['trapTaxonomy',19],['trapTranscript',19],['trapEvidence',10],['trapActivity',12]];for(const [id,h]of items){put(id,0,y,1,h);y+=h;}}
 else{const half=columns/2;if(posture)put('postureSummary',0,0,columns,4);else ['trapHits','trapIsolation','trapFiles','trapPrimary'].forEach((id,i)=>{const x=Math.floor(i*columns/4);put(id,x,0,Math.floor((i+1)*columns/4)-x,4);});if(posture){put('siteChart',0,4,half,13);put('attackHeatmap',half,4,half,13);put('attackTrendChart',0,17,half,18);put('riskContainment',half,17,half,18);}else{put('trapTaxonomy',0,4,half,19);put('trapTranscript',half,4,half,19);put('trapEvidence',0,23,columns,6);put('trapActivity',0,29,columns,12);}}
 return result;
}
function buildGrid(){
 editor.hidden=grid.hidden||!editing;editButton.hidden=grid.hidden;if(grid.hidden||!window.GridStack)return;
 if(state.preset==='classic'){setEditing(false);for(const panel of panels.values())panel.style.removeProperty('grid-row-end');return;}
 rebuilding=true;const evidence=panels.get('behaviourEvidence');if(evidence){evidence.style.removeProperty('height');evidence.classList.remove('dg-evidence-aligned');}grid.classList.add('grid-stack');
 activeLayoutKey=state.preset+':'+layoutBucket();
 const saved=['threat','incidents','incidentPipeline','journey','posture','honeypot'].includes(state.preset)?{}:(state.gridLayouts?.[activeLayoutKey]||{});
 const visible=[...grid.children].filter(el=>el.dataset.dashboardPanel&&!el.hidden);
 for(const el of [...grid.children])if(el.dataset.dashboardPanel&&el.hidden)stash.append(el);
 const measured=new Map(visible.map(el=>[el,el.getBoundingClientRect().height]));
 layoutGrid=GridStack.init({column:60,cellHeight:gridCellHeight(),margin:7,float:false,animate:false,staticGrid:!editing,handle:'.dg-widget-grip',resizable:{handles:'se,sw'},columnOpts:{columnMax:60,breakpoints:[{w:900,c:1},{w:1200,c:30}],breakpointForWindow:false}},grid);
 layoutGrid.batchUpdate();
 for(const panel of visible){
  const id=panel.dataset.dashboardPanel;panel.style.removeProperty('grid-row-end');
  const shell=document.createElement('div');shell.className='grid-stack-item dg-grid-shell';shell.dataset.widgetId=id;
  const content=document.createElement('div');content.className='grid-stack-item-content';shell.append(content);grid.append(shell);content.append(panel);panel.scrollTop=0;
  const grip=tools.get(id)?.bar.querySelector('.dg-widget-grip');if(grip)grip.draggable=false;
  const col=layoutGrid.getColumn();const previous=saved[id]||(['posture','honeypot'].includes(state.preset)?operationsPresetLayout(col,state.preset)[id]:state.preset==='journey'?journeyPresetLayout(col)[id]:state.preset==='global'?globalPresetLayout(col)[id]:state.preset==='threat'?threatPresetLayout(col)[id]:['incidents','incidentPipeline'].includes(state.preset)?incidentPresetLayout(col,state.preset)[id]:null);
  const width=Math.max(1,Math.round((Number(panel.style.getPropertyValue('--dg-span'))||30)*col/60));
  const h=id==='incidentProgress'?2:id==='sourceInvestigation'?18:id==='engineDetails'&&!panel.open?3:Math.max((metrics.includes(id)||(intelMetrics.includes(id)||analystMetrics.includes(id)))?3:5,Math.ceil(((measured.get(panel)||300)+14)/gridCellHeight()));
  const options={id,w:width,h,minW:Math.max(1,Math.round(col/5)),minH:(metrics.includes(id)||(intelMetrics.includes(id)||analystMetrics.includes(id)))?3:id==='engineDetails'?2:id==='severitySplit'?8:5};
  if(id==='incidentProgress'){options.minH=2;if(previous)previous.h=2;}
  if(state.preset==='journey'&&id==='incidentTriage')options.minH=4;
  if(previous)Object.assign(options,previous,{w:Math.min(col,previous.w),x:Math.min(previous.x,Math.max(0,col-Math.min(col,previous.w)))});
  else options.autoPosition=true;
  layoutGrid.makeWidget(shell,options);
  syncWidthControl(id,Math.round(shell.gridstackNode.w/layoutGrid.getColumn()*60));
 }
 layoutGrid.batchUpdate(false);layoutGrid.on('change',recordGrid);
 layoutGrid.on('dragstop resizestop',()=>{recordGrid();requestAnimationFrame(resizeGridCharts);});
 rebuilding=false;setEditing(editing);requestAnimationFrame(resizeGridCharts);fitEngineDetails();fitEvidencePanels();
}
let layoutResizeTimer;
if(window.ResizeObserver){const watch=new ResizeObserver(()=>{clearTimeout(layoutResizeTimer);layoutResizeTimer=setTimeout(()=>{if(!layoutGrid)return;const next=state.preset+':'+layoutBucket();if(next!==activeLayoutKey){releaseGrid();buildGrid();}else resizeGridCharts();},150);});watch.observe(main);}
let engineFitFrame=0;
function fitEngineDetails(){
 if(engineFitFrame)return;
 engineFitFrame=requestAnimationFrame(()=>{
  engineFitFrame=0;if(!layoutGrid||engineGroup.hidden)return;
  const shell=engineGroup.closest('.dg-grid-shell');if(!shell)return;
  const height=Math.max(3,Math.ceil((engineGroup.getBoundingClientRect().height+14)/gridCellHeight()));
  if(shell.gridstackNode?.h!==height)layoutGrid.update(shell,{h:height});
  resizeWidgetCharts(engineGroup);
 });
}
engineGroup.addEventListener('toggle',fitEngineDetails);
if(window.ResizeObserver)new ResizeObserver(fitEngineDetails).observe(engineGrid);

function persist() {
  try {
    localStorage.setItem(key, JSON.stringify(state));
  } catch (e) {
    console.warn('Workspace preferences could not be saved', e);
  }
}

function apply() {
  releaseGrid();
  document.body.dataset.dgTheme = state.theme;
  document.body.dataset.dgPreset = state.preset;
  const palette = themePalettes[state.theme] || themePalettes.original;
  window.dgThemePalette = palette;
  for (const [k, value] of Object.entries(palette)) {
    if (typeof value === 'string') document.body.style.setProperty('--dg-' + k, value);
  }
  for (const [name, k] of Object.entries({
    cyan: 'info', pink: 'danger', lime: (palette.lime ? 'lime' : 'warning'), green: 'success', purple: 'purple',
    bg: 'base', panel: 'card', 'panel-2': 'raised', text: 'text', muted: 'muted', line: 'line'
  })) {
    document.body.style.setProperty('--' + name, palette[k]);
  }
  document.body.style.setProperty('--dg-fg', palette.text);
  document.body.style.colorScheme = state.theme === 'daylight' ? 'light' : 'dark';
  window.dispatchEvent(new CustomEvent('dg:theme-changed', { detail: palette }));

  document.body.classList.toggle('dg-ws-reading', true);
  for (const c of ['dg-ws-focus', 'dg-ws-no-charts', 'dg-ws-motion', 'dg-ws-contrast', 'dg-ws-density-compact', 'dg-ws-density-spacious']) {
    document.body.classList.remove(c);
  }
  if (state.reading === 'focus') document.body.classList.add('dg-ws-focus');
  if (state.reading === 'contrast') document.body.classList.add('dg-ws-contrast');
  if (!state.charts) document.body.classList.add('dg-ws-no-charts');
  if (state.motion) document.body.classList.add('dg-ws-motion');
  if (state.density === 'compact' || state.density === 'spacious') {
    document.body.classList.add('dg-ws-density-' + state.density);
  }
  document.body.style.setProperty('--dg-reading-scale', String(state.scale / 100));
  document.body.style.setProperty('--dg-reading-leading', state.reading === 'comfortable' ? '1.85' : '1.5');

  const custom = ['global', 'classic', 'custom', 'blank', 'journey', 'posture', 'threat', 'incidents', 'incidentPipeline', 'honeypot'].includes(state.preset);
  document.body.dataset.dgWorkspaceManaged = String(custom);

  if (custom) {
    grid.hidden = false;
    const activeWidgets = selectedWidgets();
    const primaryOrder=customSelection(state.preset)?state.order:presets[state.preset].widgets;const order = [...new Set([...primaryOrder, ...all])].filter(id => panels.has(id));
    for (const id of order) {
      const el = panels.get(id), t = tools.get(id);
      grid.append(el);
      el.prepend(t.bar);
      const defaultSpan = id==='sourceInvestigation'?20:(intelMetrics.includes(id)||analystMetrics.includes(id))?15:metrics.includes(id) ? 12 : (['attackSequence', 'forensicTerminal', 'containmentFlow', 'attackTrendChart'].includes(id) ? 60 : 30);
      t.size.value = String(customSelection(state.preset)?(state.sizes[id]||defaultSpan):(layoutSpans[state.preset]?.[id]||defaultSpan));
      el.style.setProperty('--dg-span', t.size.value);
    }
    setVisible(activeWidgets);
  } else {
    grid.hidden = true;
    restore();
    setVisible(presets[state.preset].widgets);
  }

  for (const toggle of document.querySelectorAll('[data-dashboard-toggle]')) {
    const id = toggle.dataset.dashboardToggle;
    if (panels.has(id)) {
      toggle.checked = selectedWidgets().includes(id);
    }
  }

  if (typeof updateDashboardPanels === 'function') updateDashboardPanels();setVisible(selectedWidgets());
  const detail = $('dgEngineDetails');
  if (detail && !custom) {
    detail.open = state.preset === 'classic' || state.preset === 'threat';
  }
  const title = $('dgWorkspaceName');
  if (title) title.textContent = presets[state.preset].name;
  const caption = $('dgWorkspaceCaption');
  if (caption) caption.textContent = ' / ' + presets[state.preset].description;
  const header = $('dgWsActiveLabel');
  if (header) header.textContent = presets[state.preset].name;

  syncView(typeof dgView === 'undefined' ? 'overview' : dgView);
  buildGrid();
  grid.dataset.empty=String(custom&&!selectedWidgets().length);window.dgApplySharedTheme?.(state.theme);window.dispatchEvent(new Event('resize'));window.dispatchEvent(new Event('dg:layout-changed'));
}

function syncView(view) {
  const custom = ['global', 'classic', 'custom', 'blank', 'journey', 'posture', 'threat', 'incidents', 'incidentPipeline', 'honeypot'].includes(state.preset);
  const selected = selectedWidgets();

  document.querySelector('.dashboard-stat-grid').hidden = custom || view === 'websites' || view === 'reports';
  document.querySelector('.dg-global-charts').hidden = custom || view !== 'overview';
  arrangeEngineGroup(custom, selected);
  $('dgEngineDetails').hidden = view !== 'overview' || (custom ? !selected.includes('engineDetails') : !engineCards.some(id=>selected.includes(id)));
  $('overviewBottomPanels').hidden = custom || view === 'websites' || view === 'reports';
  $('securityReports').hidden = view !== 'reports';
  grid.hidden = !custom || view === 'websites' || view === 'reports';

  setVisible(view === 'incidents' ? selected.filter(id => ['activityStream','attackSequence','attackSequenceTimeline','mitreProgression','forensicTerminal','incidentSource','incidentPort','incidentFiles','incidentDuration','incidentProgress','artifactInspector','incidentRouting','incidentTriage','payloadInspector','incidentDock','incidentBanner','portExposure'].includes(id)) : selected);
  if (view === 'incidents' && panels.has('activityStream')) panels.get('activityStream').hidden = false;

  const labels = {
    websites: ['Protected Websites', 'Website inventory'],
    incidents: ['Incident Investigation', 'Retained incident feed'],
    reports: ['Security Reports', 'Evidence exports and review']
  };
  const title = $('dgWorkspaceName'), caption = $('dgWorkspaceCaption');
  if (title) title.textContent = labels[view]?.[0] || presets[state.preset].name;
  if (caption) caption.textContent = ' / ' + (labels[view]?.[1] || presets[state.preset].description);
}

document.addEventListener('dg-view-changed', e => {releaseGrid();syncView(e.detail);buildGrid();});

const modal = $('dgWorkspaceModal');
if (!modal) {
  console.warn('Dashboard layout editor missing');
  return;
}

const presetBox = $('dgWsPresets');
for (const [id, p] of Object.entries(presets)) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'dg-ws-preset';
  btn.dataset.preset = id;
  const title = document.createElement('strong');
  title.textContent = p.name;
  const mini = document.createElement('div');
  mini.className = 'dg-ws-mini';
  for (let i = 0; i < 4; i++) mini.append(document.createElement('i'));
  const desc = document.createElement('small');
  desc.textContent = p.description;
  btn.append(mini, title, desc);
  btn.addEventListener('click', () => {
    if (id !== 'custom') draft.widgets = presets[id].widgets.slice();
    draft.preset = id;
    refreshModal();
  });
  presetBox.append(btn);
}

const purposes = {
  sourceInvestigation: 'Investigate one source IP across the selected feed and optionally filter only the Activity Stream.',
  intelMitre: 'Distinct ATT&CK identifiers supplied in the selected feed.',
  intelContained: 'Selected-feed records with decoy/redirect decisions; does not verify delivery.',
  behaviourEvidence: 'Pattern counts, recorded severity and supplied evidence; an alternative to the pattern chart.',
  intelRisk: 'Latest global assessment score; no assumed maximum.',
  intelConfidence: 'Confidence supplied with the latest global assessment.',
  intelReporters: 'Distinct named reporting engines represented in the selected feed; not engine availability.',
  intelDecision: 'Decision recorded by the latest global assessment.',
  engineEventLog: 'Recent individual findings with timestamps and their reporting engines.',
  total: 'Historical detections in the selected Attack Trend period.',
  critical: 'Critical and very-high severity detections in the history period.',
  high: 'High detections in the history period; excludes Critical.',
  honeypotHits: 'Historical detections targeting the decoy.',
  blocked: 'Recorded block decisions in the selected historical detection set.',
  siteChart: 'Log-source scan diagnostics and ranked paths from selected detections.',
  severitySplit: 'Severity counts for the selected website and history period; same detection set as the KPI cards.',
  attackTrendChart: 'Detection counts over time, split by severity.',
  attackTypesChart: 'Ranked detection classes from the same history period as Attack Trend.',
  threatCore: 'Latest global assessment, not a selected incident.',
  attackTimeline: 'Stage indicator for the latest global assessment.',
  behaviour: 'Recorded burst, repeated-error and enumeration patterns.',
  honeypot: 'Global honeypot counters and most recent source.',
  riskLayers: 'Score contributions to the latest global assessment.',
  activityStream: 'Individual records and their recorded decisions.',
  threatHistory: 'Recorded numeric risk scores over time.',
  attackSequence: 'Chronological table with separate method, endpoint, decision and severity columns.',
  attackSequenceTimeline: 'Connected chronological events with expandable supplied evidence. Select a record to inspect its payload.',
  attackHeatmap: 'Heatmap showing 24-hour retained activity patterns.',
  riskDistribution: 'Distribution of numeric risk scores across the selected feed.',
  detectionBreakdown: 'Counts by reporting engine.',
  containmentFlow: 'Visual routing from evaluated traffic to containment/block.',
  mitreProgression: 'Technique identifiers explicitly supplied in telemetry.',
  forensicTerminal: 'Captured commands and supplied forensic artifacts.',
  engineDetails: 'Collapsible group containing the core detection engines.'
};

const widgetBox = $('dgWsWidgets');
for (const id of all) {
  const label = document.createElement('label');
  label.className = 'dg-ws-widget';
  const input = document.createElement('input');
  input.type = 'checkbox';
  input.value = id;
  input.addEventListener('change', () => {
    draft.preset = 'custom';
    draft.widgets = input.checked ? [...new Set([...draft.widgets, id, ...(id === 'engineDetails' ? engineCards : [])])] : draft.widgets.filter(v => v !== id);
    refreshModal();
  });
  const name = document.createElement('span');
  name.textContent = names[id];
  const purpose = document.createElement('small');
  purpose.textContent = purposes[id] || '';
  name.append(purpose);
  label.title = purposes[id] || names[id];
  label.append(input, name);
  widgetBox.append(label);
}

const themeBox = $('dgWsThemes');
for (const [id, [name]] of Object.entries(themes)) {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'dg-ws-theme';
  btn.dataset.theme = id;
  const palette = themePalettes[id];
  btn.style.setProperty('--preview-base', palette.base);
  btn.style.setProperty('--preview-card', palette.card);
  btn.style.setProperty('--preview-text', palette.text);
  btn.style.setProperty('--preview-line', palette.line);
  btn.style.setProperty('--preview-accent', palette.accent);
  const swatch = document.createElement('span');
  swatch.style.background = `linear-gradient(110deg,${palette.base} 0 40%,${palette.card} 40% 65%,${palette.accent} 65% 82%,${palette.success} 82% 91%,${palette.danger} 91%)`;
  btn.append(swatch, document.createTextNode(name));
  btn.title = name + ' theme';
  btn.addEventListener('click', () => {
    draft.theme = id;
    refreshModal();
  });
  themeBox.append(btn);
}

const openers = document.querySelectorAll('[data-open-layouts]');
for (const b of openers) b.addEventListener('click', open);

const settings = $('dashboardSettingsButton');
if (settings) {
  settings.addEventListener('click', open);
  settings.setAttribute('aria-haspopup', 'dialog');
  settings.setAttribute('aria-controls', 'dgWorkspaceModal');
}

let opener = null;

function section(name) {
  document.querySelectorAll('[data-ws-section]').forEach(b => b.setAttribute('aria-selected', String(b.dataset.wsSection === name)));
  document.querySelectorAll('[data-ws-content]').forEach(el => el.hidden = el.dataset.wsContent !== name);
  modal.dataset.section = name;
}

for (const tab of document.querySelectorAll('[data-ws-section]')) {
  tab.addEventListener('click', () => section(tab.dataset.wsSection));
  tab.addEventListener('keydown', e => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault();
    const tabs = [...document.querySelectorAll('[data-ws-section]')];
    const n = e.key === 'Home' ? 0 : e.key === 'End' ? tabs.length - 1 : (tabs.indexOf(tab) + (e.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
    tabs[n].click();
    tabs[n].focus();
  });
}

function refreshModal() {
  for (const b of presetBox.children) b.classList.toggle('is-selected', b.dataset.preset === draft.preset);
  for (const b of themeBox.children) b.classList.toggle('is-selected', b.dataset.theme === draft.theme);
  for (const label of widgetBox.children) label.querySelector('input').checked = draft.widgets.includes(label.querySelector('input').value);
  $('dgWsReading').value = draft.reading;
  $('dgWsScale').value = draft.scale;
  $('dgWsScaleValue').textContent = draft.scale + '%';
  $('dgWsDensity').value = draft.density;
  $('dgWsCharts').checked = draft.charts;
  $('dgWsMotion').checked = draft.motion;
  $('dgWsStatus').textContent = draft.widgets.length + ' widgets selected · ' + (presets[draft.preset]?.name || 'Custom');
}

function open() {
  opener = document.activeElement;
  draft = JSON.parse(JSON.stringify(state));
  draft.widgets = (['custom', 'blank'].includes(state.preset) ? state.widgets : presets[state.preset].widgets).slice();
  section('layouts');
  refreshModal();
  modal.hidden = false;
  document.body.style.overflow = 'hidden';
  $('dgWsClose').focus();
}

function close() {
  modal.hidden = true;
  draft = null;
  document.body.style.overflow = '';
  opener?.focus();
}

for (const [id, field, event] of [['dgWsReading', 'reading', 'change'], ['dgWsScale', 'scale', 'input'], ['dgWsDensity', 'density', 'change'], ['dgWsCharts', 'charts', 'change'], ['dgWsMotion', 'motion', 'change']]) {
  $(id).addEventListener(event, () => {
    draft[field] = field === 'scale' ? Number($(id).value) : (field === 'charts' || field === 'motion' ? $(id).checked : $(id).value);
    refreshModal();
  });
}

$('dgWsClose').addEventListener('click', close);
$('dgWsCancel').addEventListener('click', close);
modal.addEventListener('click', e => {
  if (e.target === modal) close();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && !modal.hidden) close();
});

modal.addEventListener('keydown',e=>{if(e.key!=='Tab')return;const items=[...modal.querySelectorAll('button,input,select')].filter(x=>!x.disabled&&!x.closest('[hidden]'));if(!items.length)return;const first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}});
$('dgWsApply').addEventListener('click', () => {
  state = draft;
  persist();
  apply();
  close();
});

$('dgWsReset').addEventListener('click', () => {
  draft = JSON.parse(JSON.stringify(defaults));
  draft.widgets = presets.classic.widgets.slice();
  refreshModal();
});

for (const toggle of document.querySelectorAll('[data-dashboard-toggle]')) {
  toggle.addEventListener('change', () => {
    const id = toggle.dataset.dashboardToggle;
    if (!panels.has(id)) return;
    const current = state.preset === 'custom' || state.preset === 'blank' ? state.widgets.slice() : presets[state.preset].widgets.slice();
    state.widgets = toggle.checked ? [...new Set([...current, id])] : current.filter(x => x !== id);
    state.preset = 'custom';
    persist();
    apply();
  });
}

apply();
})();