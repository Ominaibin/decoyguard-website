<?php
if (!defined('DG_DASHBOARD_PAGE')) define('DG_DASHBOARD_PAGE', true);
require_once __DIR__ . '/api.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DecoyGuard — SOC Monitoring Console</title>

    <link rel="stylesheet" href="soc_theme.css?v=<?= filemtime(__DIR__.'/soc_theme.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --cyan: #20d9ff;
            --purple: #9b6cff;
            --pink: #ff3b9d;
            --green: #35e887;
            --lime: #c7ff32;
            --bg: #050811;
            --panel: #080d1e;
            --panel-2: #0a1021;
            --line: rgba(71, 85, 105, 0.22);
            --muted: #64748b;
            --text: #e2e8f0;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            background-color: var(--bg);
            color: var(--text);
            font-family: 'Plus Jakarta Sans', sans-serif;
            overflow-x: hidden;
        }
        .mono { font-family: 'JetBrains Mono', monospace; }

        .panel-box {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 10px;
        }

        .kpi-card {
            background: var(--panel);
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 12px 14px;
            position: relative;
        }
        [hidden] { display: none !important; }

        .dashboard-stat-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%, 190px), 1fr));
        }

        .soc-panel-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(min(100%, 340px), 1fr));
        }

        .settings-backdrop {
            position: fixed;
            inset: 0;
            z-index: 100;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
            background: rgba(2, 6, 18, 0.82);
            backdrop-filter: blur(6px);
        }

        .settings-window {
            width: min(100%, 980px);
            max-height: min(90vh, 720px);
            overflow-y: auto;
            background: #080d1e;
            border: 1px solid rgba(71, 85, 105, 0.28);
            border-radius: 10px;
            box-shadow: 0 24px 80px rgba(0, 0, 0, 0.55);
        }

        .settings-option {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            min-height: 38px;
            padding: 9px 12px;
            border: 1px solid rgba(71, 85, 105, 0.24);
            border-radius: 8px;
            background: rgba(15, 23, 42, 0.4);
            cursor: pointer;
        }

        .settings-option input {
            width: 16px;
            height: 16px;
            accent-color: var(--cyan);
        }

        .settings-action {
            border: 1px solid rgba(71, 85, 105, 0.35);
            border-radius: 8px;
            background: rgba(15, 23, 42, 0.5);
            color: #cbd5e1;
            padding: 7px 11px;
            cursor: pointer;
        }

        .settings-action:hover {
            border-color: rgba(32, 217, 255, 0.45);
            color: var(--cyan);
        }

        /* Circular Gauges - Squarish Cut Ends */
        .gauge-wrap {
            position: relative;
            width: 120px;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .gauge-svg {
            transform: rotate(-90deg);
            width: 120px;
            height: 120px;
        }
        .gauge-track {
            fill: none;
            stroke: #162033;
            stroke-width: 12.5;
        }
        .gauge-value {
            fill: none;
            stroke-width: 12.5;
            stroke-linecap: butt; /* Flat, squarish ends */
            transition: stroke-dashoffset 0.6s cubic-bezier(0.4, 0, 0.2, 1), stroke 0.4s ease;
        }

        /* Pill Badges */
        .badge-safe { background: rgba(53, 232, 135, 0.12); border: 1px solid rgba(53, 232, 135, 0.3); color: var(--green); }
        .badge-critical { background: rgba(199, 255, 50, 0.12); border: 1px solid rgba(199, 255, 50, 0.3); color: var(--lime); }
        .badge-honeypot { background: rgba(255, 59, 157, 0.12); border: 1px solid rgba(255, 59, 157, 0.3); color: var(--pink); }
        .badge-purple { background: rgba(155, 108, 255, 0.12); border: 1px solid rgba(155, 108, 255, 0.3); color: var(--purple); }

        /* Custom Scrollbar */
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.5); }
        .custom-scroll::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb:hover { background: #64748b; }
    </style>
    <link rel="stylesheet" href="soc_theme.css?v=6">
</head>
<body class="flex min-h-screen">

    <!-- UNIVERSAL SIDEBAR INCLUDE -->
    <?php include 'sidebar.php'; ?>

    <!-- MAIN CONSOLE -->
    <main class="flex-1 p-5 overflow-y-auto min-w-0 transition-all duration-200">
        <!-- TOP BAR -->
        <header class="flex items-center justify-between pb-4 mb-4 border-b border-[#1e293b]">
            <div>
                <div class="flex items-center gap-3">
                    <h1 class="text-lg font-extrabold tracking-tight text-white m-0">Threat Monitoring Console</h1>
                    <span class="px-2.5 py-0.5 rounded text-[10px] mono font-bold" style="background: rgba(255,59,157,0.1); border: 1px solid rgba(255,59,157,0.3); color: var(--pink);">
                        ● STREAM ACTIVE
                    </span>
                </div>
                <p class="text-[11px] mono text-[#64748b] mt-0.5">DECOYGUARD // LIVE SECURITY TELEMETRY</p>
            </div>

            <div class="flex items-center gap-2.5">
                
                <div class="px-3 py-1.5 rounded-lg flex items-center gap-2 border text-[10px] mono font-bold" style="background: rgba(32,217,255,0.08); border-color: rgba(32,217,255,0.25); color: var(--cyan);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--cyan); box-shadow: 0 0 6px var(--cyan);"></span>
                    <span class="text-[#64748b] uppercase tracking-wider text-[8px]">LAST TELEMETRY</span>
                    <span id="lastTelemetryTime" class="text-slate-200 font-extrabold">--:--:--</span>
                </div>
                <div class="px-3 py-1.5 rounded-lg flex items-center gap-2 border text-[10px] mono font-extrabold" style="background: rgba(53,232,135,0.08); border-color: rgba(53,232,135,0.25); color: var(--green);">
                    <span class="w-1.5 h-1.5 rounded-full" style="background: var(--green); box-shadow: 0 0 6px var(--green);"></span>
                    <span class="tracking-wide">ENGINE ONLINE</span>
                </div>
            </div>
        </header>

        <!-- ROW 1: 5 METRIC CARDS -->
        <section class="dashboard-stat-grid gap-3 mb-5">
            <div class="kpi-card" data-dashboard-panel="total">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Total Evaluated</span>
                    <i class="fa-solid fa-globe text-sm" style="color: var(--cyan);"></i>
                </div>
                <div id="statTotal" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--cyan);">
                    <span>●</span> Live Telemetry
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="critical">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Critical Threats</span>
                    <i class="fa-solid fa-triangle-exclamation text-sm" style="color: var(--lime);"></i>
                </div>
                <div id="statCritical" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--lime);">
                    <span id="statCriticalPercent">0%</span> of telemetry
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="high">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>High Risk</span>
                    <i class="fa-solid fa-shield-heart text-sm" style="color: var(--green);"></i>
                </div>
                <div id="statHigh" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--green);">
                    <span id="statHighPercent">0%</span> of telemetry
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="honeypotHits">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Honeypot Hits</span>
                    <i class="fa-solid fa-jar text-sm" style="color: var(--pink);"></i>
                </div>
                <div id="statHoneypot" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--pink);">
                    <span>●</span> Deception Layer
                </div>
            </div>

            <div class="kpi-card" data-dashboard-panel="blocked">
                <div class="flex items-center justify-between text-[#64748b] text-[10px] font-bold uppercase tracking-wider mb-2">
                    <span>Blocked Entities</span>
                    <i class="fa-solid fa-ban text-sm" style="color: var(--purple);"></i>
                </div>
                <div id="statBlocked" class="text-2xl font-extrabold mono text-white">0</div>
                <div class="text-[10px] mono mt-2 flex items-center gap-1.5" style="color: var(--purple);">
                    <span>●</span> Automated Response
                </div>
            </div>
        </section>

        <!-- TOP TIER: THREAT INTELLIGENCE & DETECTION ENGINES (50/50) -->
        <section id="overviewTopPanels" class="soc-panel-grid gap-4 mb-4" data-dashboard-layout>

            <!-- LEFT COLUMN: Gauges & Timeline -->
            <div class="flex flex-col gap-4" data-dashboard-group>
                <div class="panel-box p-4 flex-1 flex flex-col justify-between" data-dashboard-panel="threatCore">
                    <div class="flex items-center justify-between mb-2">
                        <div>
                            <h3 class="text-xs font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-crosshairs text-xs" style="color: var(--pink);"></i> Threat Intelligence Core
                            </h3>
                            <p class="text-[10px] text-[#64748b] m-0">Live behavioural assessment</p>
                        </div>
                        <span class="px-2 py-0.5 rounded text-[9px] mono font-bold" style="background: rgba(255,59,157,0.1); color: var(--pink);">LIVE</span>
                    </div>

                    <!-- Centered Gauges with Smaller Numbers -->
                    <div class="grid grid-cols-2 gap-4 py-4 flex-1 items-center border-b border-[#1e293b]">
                        <div class="flex flex-col items-center justify-center">
                            <div class="gauge-wrap">
                                <svg class="gauge-svg" viewBox="0 0 140 140">
                                    <circle class="gauge-track" cx="70" cy="70" r="54"></circle>
                                    <circle id="riskGaugeCircle" class="gauge-value" cx="70" cy="70" r="54" stroke="#ff3b9d"
                                            stroke-linecap="butt"
                                            stroke-dasharray="339.29" stroke-dashoffset="339.29"></circle>
                                </svg>
                                <div class="absolute text-center">
                                    <span id="gaugeRiskVal" class="text-xl font-extrabold mono text-white">0</span>
                                </div>
                            </div>
                            <span class="text-xs font-bold text-slate-300 mt-2">Risk Score</span>
                            <span id="gaugeRiskBadge" class="px-2.5 py-0.5 rounded-full text-[9px] mono font-bold badge-safe mt-1">SAFE</span>
                        </div>

                        <div class="flex flex-col items-center justify-center">
                            <div class="gauge-wrap">
                                <svg class="gauge-svg" viewBox="0 0 140 140">
                                    <circle class="gauge-track" cx="70" cy="70" r="54"></circle>
                                    <circle id="confGaugeCircle" class="gauge-value" cx="70" cy="70" r="54" stroke="#20d9ff"
                                            stroke-linecap="butt"
                                            stroke-dasharray="339.29" stroke-dashoffset="339.29"></circle>
                                </svg>
                                <div class="absolute text-center">
                                    <span id="gaugeConfVal" class="text-xl font-extrabold mono text-white">0%</span>
                                </div>
                            </div>
                            <span class="text-xs font-bold text-slate-300 mt-2">Confidence</span>
                        </div>
                    </div>

                    <!-- Response Strip -->
                    <div class="grid grid-cols-3 text-center pt-3">
                        <div>
                            <span class="text-[9px] mono text-[#64748b] block uppercase">Current Response</span>
                            <span id="stripResponse" class="text-xs font-extrabold text-white mt-1 block" style="color: var(--cyan);">ALLOW</span>
                        </div>
                        <div class="border-x border-[#1e293b]">
                            <span class="text-[9px] mono text-[#64748b] block uppercase">Attack Stage</span>
                            <span id="stripStage" class="text-xs font-extrabold text-white mt-1 block" style="color: var(--purple);">NORMAL</span>
                        </div>
                        <div>
                            <span class="text-[9px] mono text-[#64748b] block uppercase">Threat Level</span>
                            <span id="stripSeverity" class="text-xs font-extrabold text-white mt-1 block" style="color: var(--green);">SAFE</span>
                        </div>
                    </div>
                </div>

                <!-- Attack Timeline -->
                <div class="panel-box p-3" data-dashboard-panel="attackTimeline">
                    <span class="text-[8px] mono text-[#64748b] uppercase block">INCIDENT PATH</span>
                    <h3 class="text-xs font-bold text-white mb-2">Attack Timeline</h3>
                    
                    <div class="relative flex items-center justify-between px-3 py-1">
                        <div class="absolute left-6 right-6 top-[15px] h-[2px] bg-white/20 z-0"></div>

                        <!-- Nodes -->
                        <div id="tlNodeNormal" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Normal</span>
                        </div>
                        <div id="tlNodeSuspicious" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Suspicious</span>
                        </div>
                        <div id="tlNodeDetected" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Detected</span>
                        </div>
                        <div id="tlNodeEscalated" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Escalated</span>
                        </div>
                        <div id="tlNodeHoneypot" class="relative z-10 flex flex-col items-center">
                            <span class="tl-dot w-4 h-4 rounded-full flex items-center justify-center text-[8px] bg-[#080d1e] border-2 border-slate-700 text-slate-700">●</span>
                            <span class="tl-text text-[8px] mono text-slate-500 mt-1">Honeypot</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN: Behaviour, Honeypot & Risk Layer Analysis -->
            <div class="flex flex-col gap-4" data-dashboard-group>
                <div class="grid grid-cols-2 gap-3" data-dashboard-group>
                    <!-- Behaviour Engine -->
                    <div class="panel-box p-4 border-l-4 flex flex-col justify-between" data-dashboard-panel="behaviour" style="border-left-color: var(--purple);">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-xs font-bold text-white flex items-center gap-2">
                                    <i class="fa-solid fa-wave-square text-xs" style="color: var(--purple);"></i> Behaviour
                                </span>
                                <span class="text-[9px] mono font-bold px-2 py-0.5 rounded badge-purple">ACTIVE</span>
                            </div>
                            <ul class="text-[11px] space-y-2 text-slate-300 mb-4">
                                <li class="flex items-center justify-between"><span class="font-medium">● Request Burst</span><span class="mono text-[9px] font-bold text-slate-400">HIGH</span></li>
                                <li class="flex items-center justify-between"><span class="font-medium">● Repeated POST</span><span class="mono text-[9px] font-bold text-slate-400">MED</span></li>
                                <li class="flex items-center justify-between"><span class="font-medium">● Enumeration</span><span class="mono text-[9px] font-bold text-slate-400">HIGH</span></li>
                            </ul>
                        </div>
                        <div class="pt-3 border-t border-[#1e293b] flex items-center justify-between">
                            <span id="behRiskScore" class="text-2xl font-extrabold mono" style="color: var(--purple);">0</span>
                            <span id="behRiskBadge" class="text-[9px] mono font-bold px-2.5 py-1 rounded badge-safe">SAFE</span>
                        </div>
                    </div>

                    <!-- Honeypot -->
                    <div class="panel-box p-4 border-l-4 flex flex-col justify-between" data-dashboard-panel="honeypot" style="border-left-color: var(--pink);">
                        <div>
                            <div class="flex items-center justify-between mb-3">
                                <span class="text-xs font-bold text-white flex items-center gap-2">
                                    <i class="fa-solid fa-jar text-xs" style="color: var(--pink);"></i> Honeypot
                                </span>
                                <span class="text-[9px] mono font-bold px-2 py-0.5 rounded badge-honeypot">ACTIVE</span>
                            </div>
                            <div class="grid grid-cols-3 gap-2 text-center mb-4">
                                <div class="p-2 rounded bg-slate-900/60 border border-slate-800">
                                    <span id="hpTrapped" class="text-sm font-bold mono text-white block" style="color: var(--pink);">0</span>
                                    <span class="text-[8px] font-bold text-[#64748b] block uppercase mt-0.5">Trapped</span>
                                </div>
                                <div class="p-2 rounded bg-slate-900/60 border border-slate-800">
                                    <span id="hpSessions" class="text-sm font-bold mono text-white block">1</span>
                                    <span class="text-[8px] font-bold text-[#64748b] block uppercase mt-0.5">Sessions</span>
                                </div>
                                <div class="p-2 rounded bg-slate-900/60 border border-slate-800">
                                    <span id="hpCommands" class="text-sm font-bold mono text-white block">0</span>
                                    <span class="text-[8px] font-bold text-[#64748b] block uppercase mt-0.5">Cmds</span>
                                </div>
                            </div>
                        </div>
                        <div class="text-[9px] mono text-[#64748b] truncate pt-3 border-t border-[#1e293b]">
                            SSH: <span id="hpLatestIp" class="text-slate-300 font-semibold">127.0.0.1:2222</span>
                        </div>
                    </div>
                </div>

                <!-- Risk Layer Analysis (Thicker, Less Roundish Bars) -->
                <div class="panel-box p-4 flex-1 flex flex-col justify-between" data-dashboard-panel="riskLayers">
                    <div class="flex items-center justify-between mb-2">
                        <div>
                            <h3 class="text-xs font-bold text-white flex items-center gap-2">
                                <i class="fa-solid fa-layer-group text-xs" style="color: var(--purple);"></i> Risk Layer Analysis
                            </h3>
                            <p class="text-[10px] text-[#64748b] m-0">Contribution of each detection engine</p>
                        </div>
                        <span class="px-2 py-1 rounded text-[9px] mono font-bold border border-slate-800 text-slate-400 bg-slate-900/60">
                            4 ENGINE MODEL
                        </span>
                    </div>
                    <div class="relative w-full" style="height: 180px;">
                        <canvas id="riskLayerChart"></canvas>
                    </div>
                </div>
            </div>
        </section>

        <!-- BOTTOM TIER: ACTIVITY STREAM & THREAT HISTORY (50/50) -->
        <section id="overviewBottomPanels" class="soc-panel-grid gap-4" data-dashboard-layout>

            <!-- Activity Stream Table (Max 8 Visible, Scrollable) -->
            <div class="panel-box p-4 flex flex-col justify-between" data-dashboard-panel="activityStream">
                <div>
                    <div class="flex items-center justify-between mb-3">
                        <div class="flex items-center gap-2">
                            <span class="w-2 h-2 rounded-full bg-[#ff3b9d] shadow-[0_0_6px_#ff3b9d]"></span>
                            <h3 class="text-xs font-bold text-white m-0">DecoyGuard Activity Stream</h3>
                        </div>
                        <span class="text-[9px] mono text-[#64748b]">Live telemetry & responses</span>
                    </div>

                    <div class="overflow-y-auto overflow-x-auto max-h-[220px] custom-scroll pr-1">
                        <table class="w-full text-left border-collapse">
                            <thead class="sticky top-0 bg-[#080d1e] z-10">
                                <tr class="text-[8px] mono text-[#64748b] border-b border-[#1e293b]">
                                    <th class="py-2 px-1">INCIDENT</th>
                                    <th class="py-2 px-1">TIME</th>
                                    <th class="py-2 px-1">SOURCE IP</th>
                                    <th class="py-2 px-1">ATTACK</th>
                                    <th class="py-2 px-1">RISK</th>
                                    <th class="py-2 px-1 text-center">SEVERITY</th>
                                    <th class="py-2 px-1 text-right">DECISION</th>
                                </tr>
                            </thead>
                            <tbody id="activityStreamBody" class="text-[9px] mono divide-y divide-[#1e293b]/50">
                                <tr>
                                    <td colspan="7" class="py-4 text-center text-[#64748b]">Polling logs...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Threat History Chart -->
            <div class="panel-box p-4 flex flex-col justify-between" data-dashboard-panel="threatHistory">
                <div class="flex items-center justify-between mb-1">
                    <h3 class="text-xs font-bold text-white flex items-center gap-2">
                        <i class="fa-solid fa-chart-line text-xs" style="color: var(--cyan);"></i> Threat History
                    </h3>
                    <span class="text-[9px] mono text-[#64748b]">LIVE TELEMETRY</span>
                </div>
                <div class="w-full relative" style="height: 190px;">
                    <canvas id="threatHistoryChart"></canvas>
                </div>
            </div>

        </section>
<section class="panel-box p-5 mb-4 report-builder" id="securityReports" >
            <div class="brief-header"><div><p class="brief-kicker">EVIDENCE &amp; REPORTING</p><h2>Generate a security report</h2></div><span class="report-tag">From retained logs</span></div>
            <p class="report-help">Security Evidence includes detector findings. Behavioural Patterns includes only request-pattern anomalies; signatures remain separate. Log Activity includes retained request and log records.</p>
            <form id="securityReportForm" action="api.php" method="post" target="_blank" class="report-form">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf'], ENT_QUOTES, 'UTF-8') ?>"><input type="hidden" name="action" value="report"><input type="hidden" name="team" id="reportTeam" value="Security Operations">
                <label>Report type<select name="scope"><option value="security">Security Evidence · all detector findings</option><option value="behaviour">Behavioural Patterns · excludes signatures</option><option value="activity">Log Activity Report</option></select></label>
                <label>Website<select name="site" id="reportSite"><option value="">All websites</option></select></label>
                <input type="hidden" name="period" value="retained"><input type="hidden" name="timezone" id="reportTimezone" value="UTC">
                
                <label>Format<select name="format"><option value="pdf">Professional A4 PDF</option><option value="bundle">Evidence bundle (PDF, CSV, JSON + hashes)</option><option value="html">Print preview / HTML report</option><option value="txt">ASCII text report (.txt)</option><option value="csv">CSV evidence export</option><option value="json">JSON report &amp; metadata</option></select></label>
                <details class="report-help" style="grid-column:1 / -1"><summary>Optional reviewer statement</summary>
                <label>Reviewer name<input name="reviewer" maxlength="120" placeholder="Enter your name"></label>
                <label>Role<input name="review_role" maxlength="120" placeholder="e.g. Security analyst"></label>
                <p>Document date and time are recorded automatically when the report is generated, using this device's time zone.</p>
                <label>Ticket / case reference<input name="ticket_id" maxlength="120" placeholder="Optional case reference"></label><label>Review state<select name="sign_off_status"><option value="draft">Draft / not yet reviewed</option><option value="reviewed">Reviewed (your statement)</option></select></label>
                <label>Review conclusion<input name="review_conclusion" maxlength="1200" placeholder="State only what you reviewed and verified"></label>
                <p>This records your statement; it does not create a digital signature or independently verify containment.</p></details>
                <div class="report-submit"><button class="settings-action" type="submit">Generate report ↗</button><span id="reportFormStatus" role="status">The evidence period is derived automatically from retained records.</span></div>
            </form>
            <p class="report-help">Reports list source coverage and read limits. JSON telemetry is supported now; local <code>syslog.log</code> / <code>syslog.jsonl</code> can be included if a collector supplies them. This interface does not install a network syslog receiver.</p>
        </section>
    </main>

    <div id="dashboardSettingsBackdrop" class="settings-backdrop" hidden>
        <section class="settings-window p-4 sm:p-5" role="dialog" aria-modal="true" aria-labelledby="dashboardSettingsTitle">
            <div class="flex items-start justify-between gap-4 mb-4">
                <div>
                    <h2 id="dashboardSettingsTitle" class="text-sm font-extrabold text-white m-0">Dashboard Settings</h2>
                    <p class="text-[10px] text-slate-500 mt-1 mb-0">Choose which cards and panels appear in your live overview. Your choices are saved in this browser.</p>
                </div>
                <div class="flex items-center gap-2 shrink-0">
                    <button id="showAllDashboardPanels" class="settings-action text-[9px] mono font-bold" type="button">Show all</button>
                    <button id="hideAllDashboardPanels" class="settings-action text-[9px] mono font-bold" type="button">Hide all</button>
                    <button id="closeDashboardSettings" class="settings-action text-xs" type="button" aria-label="Close dashboard settings">
                        <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
<section class="dg-settings-appearance" aria-label="Layout and display settings"><h3>Layout &amp; appearance</h3><p>Choose a dashboard layout, saved workspace, or reading preferences.</p><div class="dg-settings-appearance-actions"><button type="button" class="dg-layout-launch" data-open-layouts><i class="fa-solid fa-border-all"></i> Layout</button><button type="button" class="dg-layout-launch" data-open-layouts><i class="fa-solid fa-book-open" aria-hidden="true"></i> Display &amp; Reading Options</button></div></section><h3 class="dg-settings-panels-title">Visible dashboard panels</h3>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Total Evaluated</span><input type="checkbox" data-dashboard-toggle="total" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Critical Threats</span><input type="checkbox" data-dashboard-toggle="critical" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>High Risk</span><input type="checkbox" data-dashboard-toggle="high" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Honeypot Hits</span><input type="checkbox" data-dashboard-toggle="honeypotHits" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Blocked Entities</span><input type="checkbox" data-dashboard-toggle="blocked" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Threat Intelligence Core</span><input type="checkbox" data-dashboard-toggle="threatCore" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Attack Timeline</span><input type="checkbox" data-dashboard-toggle="attackTimeline"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Behaviour</span><input type="checkbox" data-dashboard-toggle="behaviour"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Honeypot</span><input type="checkbox" data-dashboard-toggle="honeypot"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Risk Layer Analysis</span><input type="checkbox" data-dashboard-toggle="riskLayers"></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Activity Stream</span><input type="checkbox" data-dashboard-toggle="activityStream" checked></label>
                <label class="settings-option text-[10px] font-semibold text-slate-300"><span>Threat History</span><input type="checkbox" data-dashboard-toggle="threatHistory"></label>
            </div>
            <p class="text-[9px] mono text-slate-600 mt-4 mb-0">Changes apply immediately to the live overview.</p>
        </section>
    </div>

    <!-- LIVE TELEMETRY LOGIC -->
    <script>
function escapeHTML(value) { return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
        const CIRCUMFERENCE = 339.29;
        const dashboardSettingsKey = 'decoyguard-dashboard-panels';
        const dashboardSettingsButton = document.getElementById('dashboardSettingsButton');
        const dashboardSettingsBackdrop = document.getElementById('dashboardSettingsBackdrop');
        const dashboardToggles = Array.from(document.querySelectorAll('[data-dashboard-toggle]'));

        function updateDashboardPanels() {
            dashboardToggles.forEach((toggle) => {
                const panel = document.querySelector(`[data-dashboard-panel="${toggle.dataset.dashboardToggle}"]`);
                panel.hidden = !toggle.checked;
            });

            document.querySelectorAll('[data-dashboard-group]').forEach((group) => {
                group.hidden = !group.querySelector('[data-dashboard-panel]:not([hidden])');
            });

            document.querySelectorAll('[data-dashboard-layout]').forEach((layout) => {
                layout.hidden = !layout.querySelector('[data-dashboard-panel]:not([hidden])');layout.dataset.visiblePanels=String(Array.from(layout.children).filter(child=>!child.hidden).length);
            });

            if (riskChart) riskChart.resize();
            if (trendChart) trendChart.resize();
        }

        function saveDashboardPreferences() {
            const preferences = Object.fromEntries(
                dashboardToggles.map((toggle) => [toggle.dataset.dashboardToggle, toggle.checked])
            );
            try {
                localStorage.setItem(dashboardSettingsKey, JSON.stringify(preferences));
            } catch (error) {
                console.warn('Could not save dashboard panel preferences:', error);
            }
        }

        try {
            const savedPreferences = JSON.parse(localStorage.getItem(dashboardSettingsKey) || '{}');
            if (savedPreferences && typeof savedPreferences === 'object' && !Array.isArray(savedPreferences)) {
                dashboardToggles.forEach((toggle) => {
                    const preference = savedPreferences[toggle.dataset.dashboardToggle];
                    if (typeof preference === 'boolean') toggle.checked = preference;
                });
            }
        } catch (error) {
            console.warn('Could not load dashboard panel preferences:', error);
        }

        dashboardToggles.forEach((toggle) => {
            toggle.addEventListener('change', () => {
                updateDashboardPanels();
                saveDashboardPreferences();
            });
        });

        function setDashboardSettingsOpen(isOpen) {
            dashboardSettingsBackdrop.hidden = !isOpen;
            if (isOpen) dashboardToggles[0]?.focus();
            else dashboardSettingsButton?.focus();
        }

        dashboardSettingsButton?.addEventListener('click', () => setDashboardSettingsOpen(true));
        document.getElementById('closeDashboardSettings').addEventListener('click', () => setDashboardSettingsOpen(false));
        dashboardSettingsBackdrop.addEventListener('click', (event) => {
            if (event.target === dashboardSettingsBackdrop) setDashboardSettingsOpen(false);
        });
        document.addEventListener('keydown', (event) => {
            if (!dashboardSettingsBackdrop.hidden && event.key === 'Escape') setDashboardSettingsOpen(false);
        });
        document.getElementById('showAllDashboardPanels').addEventListener('click', () => {
            dashboardToggles.forEach((toggle) => { toggle.checked = true; });
            updateDashboardPanels();
            saveDashboardPreferences();
        });
        document.getElementById('hideAllDashboardPanels').addEventListener('click', () => {
            dashboardToggles.forEach((toggle) => { toggle.checked = false; });
            updateDashboardPanels();
            saveDashboardPreferences();
        });

// 1. Chart Initializations
const riskCtx = document.getElementById('riskLayerChart');
let riskChart = null;
if (riskCtx && typeof Chart !== "undefined") {
    riskChart = new Chart(riskCtx, {
        type: 'bar',
        data: {
            labels: ['Signature', 'Scanner', 'Behaviour', 'Correlation', 'Application'],
            datasets: [{
                data: [0, 0, 0, 0, 0],
                // Cyan (Signature), Purple (Scanner), Solar Amber (Behaviour), Neon Magenta (Correlation)
                backgroundColor: ['#22d3ee', '#c084fc', '#facc15', '#ff2a85', '#35e887'],
                borderRadius: 3,
                borderSkipped: false,
                barThickness: 21
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    min: 0,
                    max: 200,
                    grid: { color: 'rgba(71, 85, 105, 0.15)', drawBorder: false },
                    ticks: { color: '#475569', font: { family: 'JetBrains Mono', size: 9 }, stepSize: 40 }
                },
                y: {
                    grid: { display: false, drawBorder: false },
                    ticks: { color: '#cbd5e1', font: { family: 'JetBrains Mono', size: 10, weight: 'bold' } }
                }
            }
        }
    });
}

const trendCtx = document.getElementById('threatHistoryChart');
let trendChart = null;
if (trendCtx && typeof Chart !== "undefined") {
    trendChart = new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                data: [],
                borderColor: '#22d3ee',
                backgroundColor: 'rgba(34, 211, 238, 0.08)',
                borderWidth: 2,
                pointRadius: 3,
                pointBackgroundColor: '#22d3ee',
                fill: true,
                tension: 0.25
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                x: {
                    grid: { display: false },
                    ticks: { color: '#475569', font: { size: 8 } }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: 'rgba(71, 85, 105, 0.1)' },
                    ticks: { color: '#475569', font: { size: 8 } }
                }
            }
        }
    });
}

updateDashboardPanels();

// 2. Timeline Dynamic Stage Lighting
function updateTimeline(stage, decision) {
    const stages = ['Normal', 'Suspicious', 'Detected', 'Escalated', 'Honeypot'];
    const colorMap = {
        'Normal': '#38bdf8',     // Ice Blue
        'Suspicious': '#22d3ee', // Electric Cyan
        'Detected': '#c084fc',   // Electric Purple
        'Escalated': '#facc15',  // Golden Cheese Amber
        'Honeypot': '#ff2a85'    // Shadow Milk Neon Magenta
    };

    let activeIndex = 0;
    const s = String(stage || '').toUpperCase();
    const d = String(decision || '').toUpperCase();

    if (d === 'REDIRECT' || d === 'HONEYPOT' || s.includes('HONEYPOT') || s.includes('CONTAINED')) {
        activeIndex = 4;
    } else if (s.includes('ESCALAT') || s.includes('EXPLOIT')) {
        activeIndex = 3;
    } else if (s.includes('DETECT') || s.includes('ACCESS')) {
        activeIndex = 2;
    } else if (s.includes('SUSPICIOUS') || s.includes('RECON') || s.includes('ENUM')) {
        activeIndex = 1;
    }

    stages.forEach((name, idx) => {
        const nodeEl = document.getElementById(`tlNode${name}`);
        if (!nodeEl) return;
        const dot = nodeEl.querySelector('.tl-dot');
        const text = nodeEl.querySelector('.tl-text');

        if (idx === activeIndex) {
            const color = colorMap[name];
            if (dot) {
                dot.style.borderColor = color;
                dot.style.color = color;
                dot.style.boxShadow = `0 0 8px ${color}`;
            }
            if (text) {
                text.style.color = color;
                text.classList.add('font-bold');
            }
        } else {
            if (dot) {
                dot.style.borderColor = '#334155';
                dot.style.color = '#334155';
                dot.style.boxShadow = 'none';
            }
            if (text) {
                text.style.color = '#64748b';
                text.classList.remove('font-bold');
            }
        }
    });
}

// 3. Main Data Fetcher
async function fetchSOCData() {
    try {
        const res = await fetch('api.php');
        if (res.status === 401) { location.reload(); return; }
                if (!res.ok) throw new Error(`API HTTP ${res.status}`);
        const data = await res.json();

        // Stats Cards
        const total = data.stats?.total_requests || 0;
        const statTotal = document.getElementById('statTotal');
        const statCritical = document.getElementById('statCritical');
        const statHigh = document.getElementById('statHigh');
        const statHoneypot = document.getElementById('statHoneypot');
        const statBlocked = document.getElementById('statBlocked');

        if (statTotal) statTotal.innerText = total;
        if (statCritical) statCritical.innerText = data.stats?.critical || 0;
        if (statHigh) statHigh.innerText = data.stats?.high || 0;
        if (statHoneypot) statHoneypot.innerText = data.stats?.honeypot || 0;
        if (statBlocked) statBlocked.innerText = data.stats?.blocked || 0;

        const critPct = total > 0 ? Math.round(((data.stats?.critical || 0) / total) * 100) : 0;
        const highPct = total > 0 ? Math.round(((data.stats?.high || 0) / total) * 100) : 0;
        const statCritPct = document.getElementById('statCriticalPercent');
        const statHighPct = document.getElementById('statHighPercent');
        if (statCritPct) statCritPct.innerText = `${critPct}%`;
        if (statHighPct) statHighPct.innerText = `${highPct}%`;

        // Gauges & Metric Numbers
        const risk = Number(data.gauges?.risk || 0);
        const conf = Number(data.gauges?.confidence || 0);
        const gRisk = document.getElementById('gaugeRiskVal');
        const gConf = document.getElementById('gaugeConfVal');
        if (gRisk) gRisk.innerText = risk;
        if (gConf) gConf.innerText = `${conf}%`;

        // SVG Donut Geometry Computation
        const riskCircle = document.getElementById('riskGaugeCircle');
        const confCircle = document.getElementById('confGaugeCircle');
        let circleCircumference = CIRCUMFERENCE;

        if (riskCircle) {
            const radius = riskCircle.r?.baseVal?.value;
            if (radius && radius > 0) {
                circleCircumference = 2 * Math.PI * radius;
            }
            riskCircle.style.strokeDasharray = `${circleCircumference}`;
        }
        if (confCircle) {
            confCircle.style.strokeDasharray = `${circleCircumference}`;
        }

        const riskRatio = Math.min(Math.max(risk, 0), 200) / 200;
        const confRatio = Math.min(Math.max(conf, 0), 100) / 100;
        const riskOffset = circleCircumference - (riskRatio * circleCircumference);
        const confOffset = circleCircumference - (confRatio * circleCircumference);

        // Palette Mapping
        let activeRiskColor = '#38bdf8';
        let activeRiskBadge = 'SAFE';
        let activeBadgeClass = 'text-[#38bdf8] bg-[#38bdf8]/10 border border-[#38bdf8]/30';

        if (risk >= 100) {
            activeRiskColor = '#ff2a85'; // Shadow Milk Magenta
            activeRiskBadge = 'CRITICAL';
            activeBadgeClass = 'text-[#ff2a85] bg-[#ff2a85]/10 border border-[#ff2a85]/40';
        } else if (risk >= 50) {
            activeRiskColor = '#facc15'; // Golden Cheese Solar Amber
            activeRiskBadge = 'ELEVATED';
            activeBadgeClass = 'text-[#facc15] bg-[#facc15]/10 border border-[#facc15]/40';
        } else if (risk >= 20) {
            activeRiskColor = '#22d3ee'; // Electric Cyan
            activeRiskBadge = 'LOW';
            activeBadgeClass = 'text-[#22d3ee] bg-[#22d3ee]/10 border border-[#22d3ee]/30';
        }

        // Render Risk Donut Ring
        if (riskCircle) {
            riskCircle.style.transition = 'stroke-dashoffset 0.6s ease, stroke 0.4s ease';
            riskCircle.style.stroke = activeRiskColor;
            riskCircle.style.strokeDashoffset = `${riskOffset}`;
        }

        // Render Risk Badge
        const riskBadge = document.getElementById('gaugeRiskBadge');
        if (riskBadge) {
            riskBadge.innerText = activeRiskBadge;
            riskBadge.className = `px-2.5 py-0.5 rounded-full text-[9px] mono font-bold mt-1 ${activeBadgeClass}`;
        }

        // Render Confidence Donut Ring
        if (confCircle) {
            confCircle.style.transition = 'stroke-dashoffset 0.6s ease';
            confCircle.style.stroke = '#22d3ee';
            confCircle.style.strokeDashoffset = `${confOffset}`;
        }

        // Response Strips
        const stripResp = document.getElementById('stripResponse');
        const stripStg = document.getElementById('stripStage');
        const stripSev = document.getElementById('stripSeverity');

        if (stripResp) stripResp.innerText = data.latest?.decision || 'ALLOW';
        if (stripStg) stripStg.innerText = data.latest?.attack_stage || 'NORMAL';
        
        if (stripSev) {
            const rawSev = String(data.latest?.severity || (risk >= 50 ? 'HIGH' : 'SAFE')).toUpperCase();
            stripSev.innerText = rawSev;
            
            // Explicit style color to overwrite old emerald classes
            if (rawSev === 'CRITICAL') {
                stripSev.style.color = '#ff2a85';
            } else if (rawSev === 'HIGH' || rawSev === 'ELEVATED') {
                stripSev.style.color = '#facc15';
            } else if (rawSev === 'MEDIUM') {
                stripSev.style.color = '#22d3ee';
            } else {
                stripSev.style.color = '#38bdf8';
            }
        }

        // Behaviour Card
        const behScore = Number(data.risk?.[2] || 0);
        const behEvent = (data.recent || []).find(e => e.engine === 'Behaviour Engine' || Number(e.risk_breakdown?.behaviour?.score || 0) > 0);
        const behSeverity = behEvent?.severity || 'SAFE';

        const behRiskScore = document.getElementById('behRiskScore');
        if (behRiskScore) behRiskScore.innerText = behScore;

        const behBadge = document.getElementById('behRiskBadge');
        if (behBadge) {
            behBadge.innerText = behSeverity;
            const sev = String(behSeverity).toUpperCase();
            if (sev === 'CRITICAL' || behScore >= 100) {
                behBadge.className = 'text-[9px] mono font-bold px-2.5 py-1 rounded text-[#ff2a85] bg-[#ff2a85]/10 border border-[#ff2a85]/40';
            } else if (sev === 'HIGH' || behScore >= 60) {
                behBadge.className = 'text-[9px] mono font-bold px-2.5 py-1 rounded text-[#facc15] bg-[#facc15]/10 border border-[#facc15]/40';
            } else if (sev === 'MEDIUM' || behScore >= 30) {
                behBadge.className = 'text-[9px] mono font-bold px-2.5 py-1 rounded text-[#22d3ee] bg-[#22d3ee]/10 border border-[#22d3ee]/30';
            } else {
                behBadge.className = 'text-[9px] mono font-bold px-2.5 py-1 rounded text-[#38bdf8] bg-[#38bdf8]/10 border border-[#38bdf8]/30';
            }
        }

        // Dynamic Honeypot Engine Counters
        const hpTrapped = document.getElementById('hpTrapped');
        const hpSessions = document.getElementById('hpSessions');
        const hpCommands = document.getElementById('hpCommands');
        const hpLatestIp = document.getElementById('hpLatestIp');

        if (hpTrapped) hpTrapped.innerText = data.stats?.hp_trapped || data.stats?.honeypot || 0;
        if (hpSessions) hpSessions.innerText = data.stats?.hp_sessions || 0;
        if (hpCommands) hpCommands.innerText = data.stats?.hp_commands || 0;

        if (hpLatestIp && data.latest?.source_ip && data.latest.source_ip !== '-') {
            hpLatestIp.innerText = `${data.latest.source_ip}`;
        }

        // Update Timeline
        updateTimeline(data.latest?.attack_stage, data.latest?.decision);

        // Update Charts
        if (data.risk && riskChart) {
            riskChart.data.datasets[0].data = data.risk;
            riskChart.update();
        }

        if (data.trend && data.trend.labels && trendChart) {
            trendChart.data.labels = data.trend.labels;
            trendChart.data.datasets[0].data = data.trend.data;
            trendChart.update();
        }

        // Populate Activity Stream Table (Capped to 8 rows)
        const tbody = document.getElementById('activityStreamBody');
        if (tbody) {
            if (data.recent && Array.isArray(data.recent) && data.recent.length > 0) {
                const rows = data.recent.slice(0, 8).map(event => {
                    if (!event) return '';
                    const riskVal = Number(event.risk || 0);
                    const severityStr = String(event.severity || 'SAFE').toUpperCase().trim();
                    
                    let sevPillStyle = 'text-[#38bdf8] bg-[#38bdf8]/10 border border-[#38bdf8]/30';
                    let riskNumColor = 'text-slate-400';

                    if (severityStr === 'CRITICAL' || riskVal >= 100) {
                        sevPillStyle = 'text-[#ff2a85] bg-[#ff2a85]/10 border border-[#ff2a85]/40';
                        riskNumColor = 'text-[#ff2a85]';
                    } else if (severityStr === 'HIGH' || riskVal >= 60) {
                        sevPillStyle = 'text-[#facc15] bg-[#facc15]/10 border border-[#facc15]/40';
                        riskNumColor = 'text-[#facc15]';
                    } else if (severityStr === 'MEDIUM' || riskVal >= 25) {
                        sevPillStyle = 'text-[#22d3ee] bg-[#22d3ee]/10 border border-[#22d3ee]/30';
                        riskNumColor = 'text-[#22d3ee]';
                    }
                    
                    const rawId = String(event.incident_id || 'DG-00000000');
                    let coloredId = `<span class="text-slate-400">${escapeHTML(rawId)}</span>`;

                    if (rawId.includes('-')) {
                        const parts = rawId.split('-');
                        const prefix = parts[0] + '-';
                        const code = parts.slice(1).join('-');

                        if (prefix === 'BE-') {
                            coloredId = `<span class="font-bold text-[#c084fc]">${escapeHTML(prefix)}</span><span class="text-slate-400">${escapeHTML(code)}</span>`;
                        } else if (prefix === 'HP-') {
                            coloredId = `<span class="font-bold text-[#ff2a85]">${escapeHTML(prefix)}</span><span class="text-slate-400">${escapeHTML(code)}</span>`;
                        } else {
                            coloredId = `<span class="font-bold text-[#22d3ee]">${escapeHTML(prefix)}</span><span class="text-slate-400">${escapeHTML(code)}</span>`;
                        }
                    }

                    const decisionStr = String(event.decision || 'ALLOW').toUpperCase();
                    const decisionColor = (decisionStr === 'REDIRECT' || decisionStr === 'ISOLATE' || decisionStr === 'HONEYPOT') 
                        ? 'text-[#ff2a85]' 
                        : 'text-slate-400';

                    return `
                        <tr>
                            <td class="py-2 px-1 mono">${coloredId}</td>
                            <td class="py-2 px-1 text-[#64748b]">${escapeHTML(event.time || '--:--:--')}</td>
                            <td class="py-2 px-1 text-slate-300">${escapeHTML(event.source_ip || '-')}</td>
                            <td class="py-2 px-1 font-sans text-slate-200">${escapeHTML(event.attack || 'Normal Traffic')}</td>
                            <td class="py-2 px-1 font-bold ${riskNumColor}">${riskVal}</td>
                            <td class="py-2 px-1 text-center">
                                <span class="px-2 py-0.5 rounded-full text-[8px] mono font-bold uppercase tracking-wider ${sevPillStyle}">
                                    ${escapeHTML(severityStr)}
                                </span>
                            </td>
                            <td class="py-2 px-1 text-right font-bold ${decisionColor}">${escapeHTML(decisionStr)}</td>
                        </tr>
                    `;
                }).join('');

                tbody.innerHTML = rows;
            } else {
                tbody.innerHTML = `<tr><td colspan="7" class="py-4 text-center text-[#64748b]">No active alerts recorded.</td></tr>`;
            }
        }

        const timeElem = document.getElementById('lastTelemetryTime');
        if (timeElem) {
            timeElem.innerText = new Date().toLocaleTimeString();
        }

    } catch (err) {
        console.error("Telemetry poll failed:", err);
        const status = document.getElementById("lastTelemetryTime") || document.getElementById("lastTelemetry"); if (status) status.textContent = "API unavailable: " + err.message;
    }
}

// Poll every 2 seconds
setInterval(fetchSOCData, 2000);
fetchSOCData();
    </script>
<?php include __DIR__ . '/layout_picker.php'; ?>

<script>
(()=>{const form=document.getElementById('securityReportForm');
const draftFields=['reviewer','review_role','ticket_id','review_conclusion'];
const draftKey='dg-report-review-draft-v1:'+<?= json_encode($_SESSION['analyst_id'] ?? 'current', JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;
try{const draft=JSON.parse(sessionStorage.getItem(draftKey)||'{}');for(const key of draftFields){const field=form.elements.namedItem(key);if(field&&typeof draft[key]==='string'&&!field.value)field.value=draft[key];}}catch(error){}
const saveDraft=()=>{try{const draft={};for(const key of draftFields)draft[key]=form.elements.namedItem(key)?.value||'';sessionStorage.setItem(draftKey,JSON.stringify(draft));}catch(error){}};
form.addEventListener('input',saveDraft);form.addEventListener('change',saveDraft);form.addEventListener('submit',saveDraft);
const syncZone=()=>{document.getElementById('reportTimezone').value=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';};syncZone();form.addEventListener('submit',e=>{syncZone();const status=document.getElementById('reportFormStatus');status.textContent='Report opens in a new tab. Print the HTML report to save as PDF.';});fetch('api.php?action=sites',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(data=>{if(!data)return;for(const site of data.sites||[]){const option=document.createElement('option');option.value=site.site_id;option.textContent=site.name||site.site_id;document.getElementById('reportSite').append(option);}}).catch(()=>{});})();
(()=>{const key='decoyguard-panel-slots-v1',nodes=new Map(),homes=new Map(),names=new Map();document.querySelectorAll('[data-dashboard-panel]').forEach(panel=>{if(panel.classList.contains('kpi-card'))return;const id=panel.dataset.dashboardPanel,anchor=document.createComment('panel-slot:'+id);panel.before(anchor);nodes.set(id,panel);homes.set(id,anchor);const toggle=document.querySelector('[data-dashboard-toggle="'+id+'"]');names.set(id,toggle?.closest('label')?.querySelector('span')?.textContent||id);});let positions=Object.fromEntries(Array.from(nodes.keys(),id=>[id,id]));try{const saved=JSON.parse(localStorage.getItem(key)||'null');if(saved&&Object.keys(saved).length===nodes.size&&Object.keys(saved).every(id=>nodes.has(id)&&nodes.has(saved[id]))&&new Set(Object.values(saved)).size===nodes.size)positions=saved;}catch(e){}
function place(){for(const [slot,id] of Object.entries(positions)){const anchor=homes.get(slot);anchor.parentNode.insertBefore(nodes.get(id),anchor.nextSibling);}updateDashboardPanels();window.dispatchEvent(new Event('resize'));}
for(const [id] of nodes){const toggle=document.querySelector('[data-dashboard-toggle="'+id+'"]'),label=toggle?.closest('label');if(!label)continue;const wrapper=document.createElement('div');wrapper.className='dg-panel-choice';label.before(wrapper);wrapper.append(label);const caption=document.createElement('label');caption.className='dg-panel-replace-label';caption.textContent='Replace with';const select=document.createElement('select');select.setAttribute('aria-label','Replace '+names.get(id));const first=document.createElement('option');first.value='';first.textContent='Choose an existing panel…';select.append(first);for(const [other,title] of names){if(other===id)continue;const option=document.createElement('option');option.value=other;option.textContent=title;select.append(option);}caption.append(select);wrapper.append(caption);select.addEventListener('change',()=>{const target=select.value;if(!nodes.has(target))return;const sourceSlot=Object.keys(positions).find(k=>positions[k]===id),targetSlot=Object.keys(positions).find(k=>positions[k]===target);positions[sourceSlot]=target;positions[targetSlot]=id;toggle.checked=false;document.querySelector('[data-dashboard-toggle="'+target+'"]').checked=true;place();saveDashboardPreferences();try{localStorage.setItem(key,JSON.stringify(positions));}catch(e){}select.value='';document.getElementById('dgPanelChoiceStatus').textContent=names.get(id)+' replaced by '+names.get(target)+'.';});}
const section=document.querySelector('.settings-window');const status=document.createElement('p');status.id='dgPanelChoiceStatus';status.className='dg-panel-choice-status';status.setAttribute('role','status');status.textContent='Show or hide panels, or replace a panel with another existing option. Choices are saved in this browser.';section.append(status);const reset=document.createElement('button');reset.type='button';reset.className='settings-action';reset.textContent='Reset panel positions';reset.addEventListener('click',()=>{positions=Object.fromEntries(Array.from(nodes.keys(),id=>[id,id]));place();try{localStorage.setItem(key,JSON.stringify(positions));}catch(e){}status.textContent='Original panel positions restored. Visibility choices are unchanged.';});section.append(reset);place();})();
</script>
</body>
</html>