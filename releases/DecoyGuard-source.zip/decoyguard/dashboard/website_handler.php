<?php
if (!defined('DG_DASHBOARD_PAGE')) define('DG_DASHBOARD_PAGE', true);
require_once __DIR__ . '/api.php';
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>DecoyGuard — Website Handler</title>
<link rel="stylesheet" href="soc_theme.css?v=<?= filemtime(__DIR__.'/soc_theme.css') ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--cyan:#20d9ff;--bg:#050811;--panel:#080d1e;--line:rgba(71,85,105,.22);--text:#e2e8f0}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:'Plus Jakarta Sans',system-ui,sans-serif;display:flex;min-height:100vh}.mono{font-family:'JetBrains Mono',monospace}
.handler-main{flex:1;min-width:0;padding:20px;max-width:1500px;margin:0 auto}.handler-header{display:flex;justify-content:space-between;align-items:center;gap:16px;padding-bottom:18px;margin-bottom:20px;border-bottom:1px solid #1e293b}.handler-header h1{font-size:20px;font-weight:800;margin:0 0 6px}.handler-header p{font-size:12px;color:#94a3b8;margin:0}.handler-chip{font:600 10px 'JetBrains Mono',monospace;color:var(--cyan);border:1px solid #20d9ff33;background:#20d9ff0d;padding:7px 10px;border-radius:6px;white-space:nowrap}
.panel-box{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:22px}.form-heading{font-size:13px;font-weight:700;margin:24px 0 14px;color:#e2e8f0}
#addWebsiteForm{display:grid;gap:16px!important}#addWebsiteForm label{font-size:11px;font-weight:600;color:#94a3b8}#addWebsiteForm input:not([type=checkbox]),#addWebsiteForm select{display:block;width:100%;height:42px;margin-top:8px;padding:10px 12px;background:#050811;border:1px solid #263247;border-radius:7px;font-size:12px;font-family:inherit;color:#e2e8f0;outline:none}#addWebsiteForm input:focus,#addWebsiteForm select:focus{border-color:var(--cyan);box-shadow:0 0 0 3px #20d9ff12}#addWebsiteForm input::placeholder{color:#536279}#addWebsiteForm input[type=checkbox]{accent-color:var(--cyan);width:16px;height:16px}#addWebsiteButton{align-self:end;min-height:42px;border:1px solid #20d9ff55;border-radius:7px;background:var(--cyan);color:#050811;font-size:12px;font-weight:800;padding:12px;cursor:pointer}button:disabled{opacity:.45;cursor:not-allowed}#websiteList{display:grid;gap:12px;margin-top:22px}#websiteList>div{background:#0a1021;border-color:#25334b!important;padding:16px!important}#websiteList button,#websiteList a{border:1px solid #25334b;border-radius:6px;background:#080d1e;padding:8px 10px;cursor:pointer;text-decoration:none}#websiteSetupMessage{min-height:20px;font-size:12px}#websiteJobs{line-height:1.8;border-top:1px solid var(--line);padding-top:14px;overflow-wrap:anywhere}.mobile-nav{display:none;color:var(--cyan);font-size:12px}.setup-note{border:1px solid var(--line);background:#0a1021;padding:14px;border-radius:8px;margin:18px 0 0;color:#94a3b8;font-size:11px;line-height:1.8}
@media(max-width:1023px){.mobile-nav{display:inline-block}}@media(max-width:600px){.handler-main{padding:16px}.panel-box{padding:16px}.handler-header{align-items:flex-start}.handler-chip{display:none}#websiteList>div{flex-direction:column;align-items:flex-start!important}}
</style></head>
<body>
<?php include __DIR__ . '/sidebar.php'; ?>
<main class="handler-main">
<header class="handler-header"><div><h1>Website Handler</h1><p>Manage protected websites, decoy deployments and gateway settings.</p><a class="mobile-nav" href="dashboard.php">← SOC overview</a></div><span class="handler-chip">WEBSITE MANAGEMENT</span></header>
        <section class="panel-box p-4 mb-5" id="websiteSetup" style="border:1px solid #25334b;border-radius:10px;background:#080d1e">
            <div class="flex justify-between items-center mb-3"><h2 class="font-bold text-white">Configured websites <span id="siteCapacity" class="text-cyan-400"></span></h2><span id="siteControllerState" class="text-xs text-slate-400">Checking controller…</span></div>
            <p class="text-xs text-slate-400 mb-3">Each website gets a separate mirror, synthetic database and protected gateway. Backend-dependent functions may need an application adapter.</p>
            <h3 class="form-heading">Add a website</h3><form id="addWebsiteForm" class="grid gap-2" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,240px),1fr))">
                <label class="text-xs text-slate-400">Website ID<input name="site_id" required pattern="[a-z][a-z0-9-]{0,30}" maxlength="31" placeholder="company-docs" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"></label>
                <label class="text-xs text-slate-400">Display name<input name="name" required maxlength="80" placeholder="Company docs" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"></label>
                <label class="text-xs text-slate-400">Original website URL<input name="source_url" type="url" required placeholder="http://localhost:3000" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"></label>
                <label class="text-xs text-slate-400">Backend profile<select name="backend_profile" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"><option value="">Automatic</option><option>generic</option><option>banking</option><option>ecommerce</option><option>corporate</option><option>education</option><option>healthcare</option><option>industrial</option></select></label>
                <label class="text-xs text-slate-400">Gateway port (optional)<input name="gateway_port" type="number" min="1024" max="65535" placeholder="Automatic" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"></label>
                <label class="text-xs text-slate-400">Decoy port (optional)<input name="decoy_port" type="number" min="1024" max="65535" placeholder="Automatic" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"></label>
                <label class="text-xs text-slate-400">Public domain (optional)<input name="domain" placeholder="protected.example.com" class="w-full p-2 mt-1 bg-slate-950 border border-slate-700 rounded text-white"></label>
                <label class="text-xs text-slate-400 flex items-center gap-2"><input name="https" type="checkbox"> Automatic HTTPS for this domain</label>
                <button type="submit" id="addWebsiteButton" class="p-2 rounded bg-cyan-400 text-slate-950 font-bold">Add website</button>
            </form>
            <p class="setup-note">Public setup: point the domain’s A/AAAA records to this host and forward ports 80/443. HTTPS certificates are requested and renewed automatically. Local gateway and direct-decoy ports stay on localhost. Change the initial admin password using Account before enabling public access.</p>
            <p id="websiteSetupMessage" role="status" class="text-sm text-cyan-300 mt-3"></p>
            <div id="websiteList" class="grid gap-2 mt-3"></div>
            <div id="websiteJobs" class="text-xs text-slate-400 mt-3"></div>
        </section>
        <script>
        (() => {
            let csrf='', state={sites:[],jobs:[]};
            const form=document.getElementById('addWebsiteForm'), message=document.getElementById('websiteSetupMessage');
            const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
            async function submit(operation,site) {
                const response=await fetch('api.php?action=sites',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({operation,site,csrf})});
                if(response.status===401){location.reload();return;}
                const result=await response.json();if(!response.ok)throw Error(result.error||`HTTP ${response.status}`);
                message.textContent='Request queued. Deployment progress appears below.';await refresh();
            }
            async function refresh(){
                try{
                    const response=await fetch('api.php?action=sites',{cache:'no-store'});
                    if(response.status===401){location.reload();return;}
                    const data=await response.json();if(!response.ok)throw Error(data.error||'Could not load websites');
                    state=data;csrf=data.csrf;
                    document.getElementById('siteCapacity').textContent=`${data.sites.length}/8`;
                    document.getElementById('siteControllerState').textContent=data.controller_online?'Deployment controller online':'Controller offline — run DecoyGuard with --saved';
                    document.getElementById('addWebsiteButton').disabled=!data.controller_online||data.sites.length>=8;
                    const list=document.getElementById('websiteList');list.replaceChildren();
                    for(const site of data.sites){
                        const row=document.createElement('div');row.className='p-3 rounded border border-slate-700 flex flex-wrap gap-3 items-center';
                        row.innerHTML=`<div class="flex-1"><strong class="text-white">${esc(site.name)}</strong> <span class="text-cyan-300">${esc(site.status)}</span><div class="text-xs text-slate-400">${esc(site.source_url)}</div><div class="text-xs text-slate-400">Gateway: localhost:${Number(site.gateway_port)} · Decoy: localhost:${Number(site.decoy_port)}${site.domain?' · '+esc(site.domain):''}</div>${site.error?'<div class="text-xs text-pink-400">'+esc(site.error)+'</div>':''}<div class="text-xs text-slate-500">${esc(site.public_status||'Public DNS/TLS has not been verified')}</div></div>`;
                        if(site.capture_ready){const link=document.createElement('a');link.href=`http://localhost:${Number(site.gateway_port)}/`;link.target='_blank';link.rel='noopener';link.className='text-cyan-300 text-xs';link.textContent='Open gateway';row.append(link);}
                        if(site.status==='failed'){const retry=document.createElement('button');retry.textContent='Retry';retry.className='text-cyan-300 text-xs';retry.disabled=!data.controller_online;retry.onclick=()=>submit('retry',{site_id:site.site_id}).catch(e=>message.textContent=e.message);row.append(retry);}
                        const remove=document.createElement('button');remove.textContent='Remove route';remove.className='text-pink-400 text-xs';remove.disabled=!data.controller_online;remove.onclick=()=>{if(confirm(`Remove ${site.name} from routing? Captured files and logs will be retained.`))submit('remove',{site_id:site.site_id}).catch(e=>message.textContent=e.message);};row.append(remove);list.append(row);
                    }
                    document.getElementById('websiteJobs').textContent=data.jobs.slice(0,6).map(job=>`${job.site?.site_id||''}: ${job.status}${job.error?' — '+job.error:''}`).join(' | ');
                }catch(error){message.textContent=error.message;}
            }
            form.addEventListener('submit',event=>{event.preventDefault();const values=new FormData(form),site=Object.fromEntries(values);site.https=form.elements.https.checked;
                for(const field of ['gateway_port','decoy_port'])site[field]=site[field]?Number(site[field]):0;
                form.elements.site_id.value=site.site_id;document.getElementById('addWebsiteButton').disabled=true;submit('add',site).then(()=>form.reset()).catch(error=>message.textContent=error.message).finally(refresh);});
            refresh();setInterval(refresh,3000);
        })();
        </script>



</main></body></html>
