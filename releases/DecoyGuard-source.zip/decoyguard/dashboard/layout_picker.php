<?php
$dgCurrentLayout = basename($_SERVER['SCRIPT_NAME']) === 'dashboard_classic.php' ? 'classic' : 'modern';
?>
<style>
.dg-layout-launch{display:inline-flex;gap:8px;align-items:center;padding:9px 13px;border:1px solid #18d8f7;border-radius:8px;color:#20d9ff;background:#061b2b;font:700 11px 'Plus Jakarta Sans',sans-serif;cursor:pointer;white-space:nowrap}
.dg-layout-launch:hover{background:#0d3041}
.dg-layout-overlay[hidden]{display:none!important}
.dg-layout-overlay{position:fixed;inset:0;z-index:250;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(0,4,15,.83);backdrop-filter:blur(8px)}
.dg-layout-dialog{width:min(1180px,98vw);max-height:94vh;display:flex;flex-direction:column;border:1px solid #28445f;border-radius:12px;background:#081325;box-shadow:0 35px 100px #000c;color:#e5eefb;font-family:'Plus Jakarta Sans',sans-serif}
.dg-layout-head{display:flex;align-items:center;justify-content:space-between;padding:19px 23px;border-bottom:1px solid #203450}
.dg-layout-head h2{font-size:19px;font-weight:800;color:white;margin:0}
.dg-layout-head p{font-size:11px;color:#9ab0ce;margin-top:5px}
.dg-layout-x{padding:6px 10px;color:#b4c5db;border:1px solid #2a3d58;border-radius:7px;font-size:16px}
.dg-layout-content{display:grid;grid-template-columns:minmax(0,1fr) 285px;min-height:0;overflow:auto}
.dg-layout-gallery{padding:18px;min-width:0;overflow:auto}
.dg-layout-gallery h3,.dg-layout-side h3{font-size:12px;color:white;font-weight:800;margin:0 0 13px}
.dg-layout-cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
.dg-layout-card{display:flex;flex-direction:column;gap:9px;text-align:left;padding:12px;background:#060f20;border:1px solid #1b304d;border-radius:9px;cursor:pointer;min-width:0;color:#dbe8fb}
.dg-layout-card:hover{border-color:#5f8dac}
.dg-layout-card.is-selected{border:2px solid #19d7fa;padding:11px;box-shadow:0 0 0 1px #19d7fa22}
.dg-layout-card strong{font-size:12px;color:white}
.dg-layout-card p{font-size:11px;line-height:1.5;color:#9fb3cf;min-height:32px}
.dg-layout-card small{font-size:10px;color:#32ec94}
.dg-layout-thumb{height:110px;border:1px solid #1c3553;border-radius:5px;background:#091b32;padding:9px;display:flex;flex-direction:column;gap:7px;overflow:hidden}
.dg-layout-thumb .thumb-top{height:9px;width:72%;background:#1a4562;border-radius:3px}
.dg-layout-thumb .thumb-metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:5px}
.dg-layout-thumb .thumb-metrics i{height:22px;border-radius:4px;background:linear-gradient(150deg,#12385b,#0a2643);border:1px solid #1a5270}
.dg-layout-thumb .thumb-panels{display:grid;grid-template-columns:1fr 1.2fr .75fr;gap:5px;flex:1}
.dg-layout-thumb .thumb-panels i{border:1px solid #285074;border-radius:4px;background:repeating-linear-gradient(0deg,#0c2443 0 8px,#123356 8px 10px)}
.dg-layout-thumb.classic .thumb-panels{grid-template-columns:1.7fr 1fr}
.dg-layout-thumb.classic .thumb-panels i:last-child{display:none}
.dg-layout-thumb.compact{gap:3px;padding:6px}
.dg-layout-thumb.compact .thumb-metrics i{height:16px}
.dg-layout-thumb.comfortable .thumb-metrics{grid-template-columns:repeat(3,1fr)}
.dg-layout-thumb.focus .thumb-panels{grid-template-columns:1fr}
.dg-layout-thumb.focus .thumb-panels i:not(:first-child){display:none}
.dg-layout-thumb.contrast{background:#020304;border-color:#eee}
.dg-layout-thumb.contrast .thumb-metrics i{background:#090909;border-color:#fff}
.dg-layout-thumb.contrast .thumb-panels i{background:#070707;border-color:#fff}
.dg-layout-side{padding:20px;border-left:1px solid #223953;background:#0b1930;overflow:auto}
.dg-layout-side p{font-size:11px;color:#9db1ce;line-height:1.6;margin-bottom:20px}
.dg-layout-side label{display:block;font-size:11px;color:#cdd9eb;margin:16px 0 7px}
.dg-layout-side select,.dg-layout-side input[type=range]{width:100%}
.dg-layout-side select{background:#091326;border:1px solid #2c4463;color:white;border-radius:6px;padding:9px;font-size:11px}
.dg-layout-side .dg-layout-check{display:flex;align-items:center;gap:9px;margin-top:15px;font-size:11px}
.dg-layout-side .dg-layout-check input{accent-color:#20d9ff}
.dg-layout-side .dg-layout-check label{margin:0}
.dg-layout-note{padding:12px 15px;margin-top:16px;border:1px solid #23405e;border-radius:8px;color:#94a9c5;font-size:11px;line-height:1.6}
.dg-layout-footer{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:13px 20px;border-top:1px solid #243852}
.dg-layout-footer label{font-size:11px;color:#c5d5eb;display:flex;align-items:center;gap:9px}
.dg-layout-footer input{accent-color:#20d9ff}
.dg-layout-footer button{padding:10px 16px;border:1px solid #304a67;border-radius:7px;font-size:11px;color:#dbe9f7}
.dg-layout-footer button.dg-layout-apply{background:#16d1ef;border-color:#16d1ef;color:#03111f;font-weight:800}
@media(max-width:980px){.dg-layout-content{grid-template-columns:1fr}.dg-layout-side{border-left:0;border-top:1px solid #223953}.dg-layout-cards{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:550px){.dg-layout-cards{grid-template-columns:1fr}.dg-layout-head{padding:14px}.dg-layout-gallery{padding:12px}.dg-layout-footer{flex-wrap:wrap}}
</style>
<div id="dgLayoutOverlay" class="dg-layout-overlay" hidden>
 <section class="dg-layout-dialog" role="dialog" aria-modal="true" aria-labelledby="dgLayoutTitle">
  <div class="dg-layout-head"><div><h2 id="dgLayoutTitle">Dashboard Layouts</h2><p>Choose the workspace that fits your SOC workflow. All layouts use your live DecoyGuard data.</p></div><button class="dg-layout-x" type="button" id="dgLayoutClose" aria-label="Close layout selector">×</button></div>
  <div class="dg-layout-content">
   <div class="dg-layout-gallery"><h3>Predefined layouts</h3><div class="dg-layout-cards">
    <button type="button" class="dg-layout-card" data-layout-choice="modern" data-reading-choice="standard"><strong>Modern (Default)</strong><div class="dg-layout-thumb"><div class="thumb-top"></div><div class="thumb-metrics"><i></i><i></i><i></i><i></i></div><div class="thumb-panels"><i></i><i></i><i></i></div></div><p>Global overview, website comparisons and incident investigation.</p><small>✓ Modern SOC workspace</small></button>
    <button type="button" class="dg-layout-card" data-layout-choice="classic" data-reading-choice="standard"><strong>Classic (Original UI)</strong><div class="dg-layout-thumb classic"><div class="thumb-top"></div><div class="thumb-metrics"><i></i><i></i><i></i><i></i></div><div class="thumb-panels"><i></i><i></i><i></i></div></div><p>The original threat intelligence, behaviour and honeypot layout.</p><small>✓ Familiar monitoring interface</small></button>
    <button type="button" class="dg-layout-card" data-layout-choice="modern" data-reading-choice="compact"><strong>Compact</strong><div class="dg-layout-thumb compact"><div class="thumb-top"></div><div class="thumb-metrics"><i></i><i></i><i></i><i></i></div><div class="thumb-panels"><i></i><i></i><i></i></div></div><p>More information on screen with tighter spacing.</p><small>✓ Dense monitoring</small></button>
    <button type="button" class="dg-layout-card" data-layout-choice="modern" data-reading-choice="comfortable"><strong>Comfortable</strong><div class="dg-layout-thumb comfortable"><div class="thumb-top"></div><div class="thumb-metrics"><i></i><i></i><i></i><i></i></div><div class="thumb-panels"><i></i><i></i><i></i></div></div><p>Larger text and roomier cards for long sessions.</p><small>✓ Easier reading</small></button>
    <button type="button" class="dg-layout-card" data-layout-choice="modern" data-reading-choice="focus"><strong>Focus Mode</strong><div class="dg-layout-thumb focus"><div class="thumb-top"></div><div class="thumb-metrics"><i></i><i></i><i></i><i></i></div><div class="thumb-panels"><i></i><i></i><i></i></div></div><p>Reduce distractions during investigation.</p><small>✓ Concentrated analysis</small></button>
    <button type="button" class="dg-layout-card" data-layout-choice="modern" data-reading-choice="contrast"><strong>High Contrast</strong><div class="dg-layout-thumb contrast"><div class="thumb-top"></div><div class="thumb-metrics"><i></i><i></i><i></i><i></i></div><div class="thumb-panels"><i></i><i></i><i></i></div></div><p>Stronger borders and text contrast for readability.</p><small>✓ Accessibility option</small></button>
   </div><section class="dg-saved-section"><h3>Custom layouts</h3><div class="dg-custom-save"><label for="dgCustomName">Layout name<input id="dgCustomName" maxlength="60" placeholder="Analyst workspace"></label><button type="button" id="dgCustomSave">Save current workspace</button></div><p id="dgCustomStatus" role="status"></p><div id="dgSavedLayouts" class="dg-saved-layouts"></div></section><div class="dg-layout-note">Classic and Modern are different dashboard interfaces. Compact, Comfortable, Focus and High Contrast apply to the Modern interface as reading presets. Your existing widget visibility settings are retained.</div></div>
   <aside class="dg-layout-side"><h3>Display &amp; Reading Options</h3><p>Fine-tune your selected workspace. These preferences affect appearance only.</p>
    <label for="dgLayoutReading">Reading mode</label><select id="dgLayoutReading"><option value="standard">Standard</option><option value="compact">Compact</option><option value="comfortable">Comfortable</option><option value="focus">Focus Mode</option><option value="contrast">High Contrast</option></select>
    <label for="dgLayoutSize">Text size <output id="dgLayoutSizeLabel">100%</output></label><input id="dgLayoutSize" type="range" min="90" max="150" step="5" value="100">
    <label for="dgLayoutFont">Font style</label><select id="dgLayoutFont"><option value="jakarta">Plus Jakarta Sans</option><option value="system">System sans serif</option><option value="mono">Monospace</option></select><div class="dg-layout-check"><input id="dgLayoutIcons" type="checkbox" checked><label for="dgLayoutIcons">Show icons</label></div><div class="dg-layout-check"><input id="dgLayoutDescriptions" type="checkbox" checked><label for="dgLayoutDescriptions">Show descriptions</label></div><div class="dg-layout-check"><input id="dgLayoutColorFriendly" type="checkbox"><label for="dgLayoutColorFriendly">Color-blind-friendly presentation</label></div><label for="dgLayoutLine">Line spacing</label><select id="dgLayoutLine"><option value="1.3">Tight</option><option value="1.5">Normal</option><option value="1.85">Spacious</option></select>
    <label for="dgLayoutDensity">Card density</label><select id="dgLayoutDensity"><option value="normal">Normal</option><option value="compact">Compact</option><option value="spacious">Spacious</option></select>
    <div class="dg-layout-check"><input type="checkbox" id="dgLayoutCharts" checked><label for="dgLayoutCharts">Show charts</label></div>
    <div class="dg-layout-check"><input type="checkbox" id="dgLayoutMotion"><label for="dgLayoutMotion">Reduce motion</label></div>
   </aside>
  </div>
  <div class="dg-layout-footer"><label><input type="checkbox" id="dgLayoutRemember" checked> Remember my last layout on this browser</label><div style="display:flex;gap:8px"><button type="button" id="dgLayoutCancel">Cancel</button><button type="button" class="dg-layout-apply" id="dgLayoutApply">Apply Layout</button></div></div>
 </section>
</div>
<script>
(function(){
 const pageLayout = <?php echo json_encode($dgCurrentLayout); ?>;
 const layoutKey='dg_soc_layout',readingKey='decoyguard-reading-v1';
 const $=id=>document.getElementById(id);
 let selected=pageLayout, opener=null;
 const defaults={mode:'standard',size:100,line:'1.5',density:'normal',charts:true,motion:false,font:'jakarta',icons:true,descriptions:true,colorFriendly:false};
 function storedReading(){try{return {...defaults,...JSON.parse(localStorage.getItem(readingKey)||'{}')}}catch(e){return {...defaults}}}
 function show(){renderSaved();opener=document.activeElement;const settings=document.getElementById('dashboardSettingsBackdrop');if(settings)settings.hidden=true;selected=pageLayout;const r=storedReading();$('dgLayoutReading').value=r.mode;$('dgLayoutSize').value=r.size;$('dgLayoutLine').value=r.line;$('dgLayoutDensity').value=r.density;$('dgLayoutFont').value=r.font;$('dgLayoutIcons').checked=r.icons;$('dgLayoutDescriptions').checked=r.descriptions;$('dgLayoutColorFriendly').checked=r.colorFriendly;$('dgLayoutCharts').checked=r.charts;$('dgLayoutMotion').checked=r.motion;$('dgLayoutRemember').checked=localStorage.getItem('dg_layout_remember')!=='false';refresh();$('dgLayoutOverlay').hidden=false;document.body.style.overflow='hidden';$('dgLayoutClose').focus()}
 function hide(){$('dgLayoutOverlay').hidden=true;document.body.style.overflow='';if(opener?.closest('.settings-window')){const settings=document.getElementById('dashboardSettingsBackdrop');if(settings)settings.hidden=false;}if(opener&&opener.focus)opener.focus()}
 function refresh(){$('dgLayoutSizeLabel').textContent=$('dgLayoutSize').value+'%';document.querySelectorAll('[data-layout-choice]').forEach(b=>{let active=b.dataset.layoutChoice===selected&&b.dataset.readingChoice===$('dgLayoutReading').value;b.classList.toggle('is-selected',active);b.setAttribute('aria-pressed',String(active))})}
 function apply(){
  const r={mode:$('dgLayoutReading').value,size:Number($('dgLayoutSize').value),line:$('dgLayoutLine').value,density:$('dgLayoutDensity').value,charts:$('dgLayoutCharts').checked,motion:$('dgLayoutMotion').checked,font:$('dgLayoutFont').value,icons:$('dgLayoutIcons').checked,descriptions:$('dgLayoutDescriptions').checked,colorFriendly:$('dgLayoutColorFriendly').checked};
  try{localStorage.setItem(readingKey,JSON.stringify(r));localStorage.setItem('dg_layout_remember',String($('dgLayoutRemember').checked));if($('dgLayoutRemember').checked)localStorage.setItem(layoutKey,selected);else localStorage.removeItem(layoutKey)}catch(e){}
  const next=selected==='classic'?'dashboard_classic.php':'dashboard.php';
  const current=location.pathname.split('/').pop();
  if(current!==next){location.assign(next+location.search+location.hash)}else{location.reload()}
 }

 const customKey='dg-saved-workspaces-v1';
 function readSaved(){try{const values=JSON.parse(localStorage.getItem(customKey)||'[]');return Array.isArray(values)?values.filter(x=>x&&typeof x.name==='string'&&['modern','classic'].includes(x.layout)&&x.reading&&typeof x.reading==='object').slice(0,12):[];}catch(e){return [];}}
 function renderSaved(){const root=$('dgSavedLayouts');root.replaceChildren();for(const item of readSaved()){const article=document.createElement('article');article.className='dg-saved-layout';const open=document.createElement('button');open.type='button';open.className='dg-saved-open';const title=document.createElement('strong');title.textContent=item.name;const meta=document.createElement('small');meta.textContent=item.layout+' · Saved '+new Date(item.saved).toLocaleDateString();open.append(title,meta);open.addEventListener('click',()=>{try{localStorage.setItem(readingKey,JSON.stringify({...defaults,...item.reading}));localStorage.setItem('decoyguard-dashboard-panels',JSON.stringify(item.panels||{}));if(item.slots)localStorage.setItem('decoyguard-panel-slots-v1',JSON.stringify(item.slots));localStorage.setItem(layoutKey,item.layout);location.assign(item.layout==='classic'?'dashboard_classic.php':'dashboard.php');}catch(e){$('dgCustomStatus').textContent='Could not load the saved workspace.';}});const remove=document.createElement('button');remove.type='button';remove.textContent='Delete';remove.setAttribute('aria-label','Delete saved layout '+item.name);remove.addEventListener('click',()=>{try{localStorage.setItem(customKey,JSON.stringify(readSaved().filter(x=>x.name!==item.name)));renderSaved();}catch(e){$('dgCustomStatus').textContent='Could not delete the saved layout.';}});article.append(open,remove);root.append(article);}if(!root.children.length)root.textContent='No custom layouts saved in this browser.';}
 document.addEventListener('DOMContentLoaded',()=>{$('dgCustomSave').addEventListener('click',()=>{const name=$('dgCustomName').value.trim();if(!name){$('dgCustomStatus').textContent='Enter a name for your workspace.';return;}try{const panels=Object.fromEntries(Array.from(document.querySelectorAll('[data-dashboard-toggle]'),x=>[x.dataset.dashboardToggle,x.checked]));const entries=readSaved().filter(x=>x.name!==name);if(entries.length>=12){$('dgCustomStatus').textContent='Delete a saved layout before adding another (limit 12).';return;}entries.unshift({name,layout:pageLayout,reading:storedReading(),panels,slots:JSON.parse(localStorage.getItem('decoyguard-panel-slots-v1')||'null'),saved:new Date().toISOString()});localStorage.setItem(customKey,JSON.stringify(entries));$('dgCustomStatus').textContent='Current panel choices and reading preferences saved.';renderSaved();}catch(e){$('dgCustomStatus').textContent='Browser storage unavailable; workspace was not saved.';}});});
 function applyExtras(p){const body=document.body;body.classList.add('dg-reading');body.classList.toggle('dg-compact',p.mode==='compact'||p.density==='compact');body.classList.toggle('dg-spacious',p.mode==='comfortable'||p.density==='spacious');body.classList.toggle('dg-focus',p.mode==='focus');body.classList.toggle('dg-contrast',p.mode==='contrast');body.classList.toggle('dg-no-charts',p.charts===false);body.classList.toggle('dg-reduce-motion',p.motion===true);body.style.setProperty('--dg-reading-scale',String(Math.max(90,Math.min(150,Number(p.size)||100))/100));body.style.setProperty('--dg-reading-leading',['1.3','1.5','1.85'].includes(p.line)?p.line:'1.5');body.dataset.dgFont=['jakarta','system','mono'].includes(p.font)?p.font:'jakarta';body.classList.toggle('dg-hide-icons',p.icons===false);body.classList.toggle('dg-hide-descriptions',p.descriptions===false);body.classList.toggle('dg-color-friendly',p.colorFriendly===true);}
 document.addEventListener('dg-reading-updated',event=>applyExtras(event.detail));applyExtras(storedReading());

 document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-open-layouts]').forEach(b=>b.addEventListener('click',show));
  document.querySelectorAll('[data-layout-choice]').forEach(b=>b.addEventListener('click',()=>{selected=b.dataset.layoutChoice;$('dgLayoutReading').value=b.dataset.readingChoice;refresh()}));
  ['dgLayoutReading','dgLayoutSize'].forEach(id=>$(id).addEventListener('input',refresh));
  $('dgLayoutApply').addEventListener('click',apply);
  $('dgLayoutClose').addEventListener('click',hide);$('dgLayoutCancel').addEventListener('click',hide);
  $('dgLayoutOverlay').addEventListener('click',e=>{if(e.target===$('dgLayoutOverlay'))hide()});
  document.addEventListener('keydown',e=>{if(!$('dgLayoutOverlay').hidden&&e.key==='Escape')hide()});
  // When returning via the sidebar, restore the selected layout, unless the user disabled remembering.
  try{const saved=localStorage.getItem(layoutKey);if(localStorage.getItem('dg_layout_remember')!=='false'&&['classic','modern'].includes(saved)&&saved!==pageLayout){location.replace((saved==='classic'?'dashboard_classic.php':'dashboard.php')+location.search+location.hash)}}catch(e){}
 });
})();
</script>
