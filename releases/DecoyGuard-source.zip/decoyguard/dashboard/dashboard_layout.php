<section id="dgWorkspaceModal" class="dg-ws-overlay" hidden aria-label="Dashboard layout editor">
 <div class="dg-ws-dialog" role="dialog" aria-modal="true" aria-labelledby="dgWsTitle">
  <header class="dg-ws-head"><div><span class="dg-ws-eyebrow">DECOYGUARD / SOC WORKSPACE</span><h2 id="dgWsTitle">Customize your dashboard</h2><p>Choose a layout, adjust its widgets, then apply your changes.</p></div><button type="button" id="dgWsClose" class="dg-ws-icon" aria-label="Close editor">✕</button></header>
  <nav class="dg-ws-nav" role="tablist" aria-label="Dashboard settings sections"><button type="button" role="tab" aria-selected="true" data-ws-section="layouts">1. Layouts</button><button type="button" role="tab" aria-selected="false" data-ws-section="widgets">2. Widgets</button><button type="button" role="tab" aria-selected="false" data-ws-section="appearance">3. Appearance &amp; reading</button></nav>
  <div class="dg-ws-body"><div class="dg-ws-main">
   <section data-ws-content="layouts"><h3>Prepared workspaces</h3><div id="dgWsPresets" class="dg-ws-presets"></div>
   </section><section data-ws-content="widgets" hidden><div class="dg-ws-section-title"><h3>Widget library</h3><span>Choose what appears in your workspace</span></div><div id="dgWsWidgets" class="dg-ws-widgets"></div>
   <p class="dg-ws-help">Custom mode: drag widget headers to reorder. Use the size control on each widget to change its width. Changes are stored locally in this browser.</p></section>
  </div><aside class="dg-ws-side" data-ws-content="appearance" hidden><h3>Appearance</h3><p>Theme and reading preferences do not change your security data.</p>
   <label for="dgWsTheme">Theme</label><div id="dgWsThemes" class="dg-ws-themes"></div>
   <label for="dgWsReading">Reading mode</label><select id="dgWsReading"><option value="standard">Standard</option><option value="compact">Compact</option><option value="comfortable">Comfortable</option><option value="focus">Focus</option><option value="contrast">High Contrast</option></select>
   <label for="dgWsScale">Text size <output id="dgWsScaleValue">100%</output></label><input id="dgWsScale" type="range" min="90" max="150" step="5" value="100">
   <label for="dgWsDensity">Card spacing</label><select id="dgWsDensity"><option value="normal">Balanced</option><option value="compact">Compact</option><option value="spacious">Spacious</option></select>
   <label class="dg-ws-check"><input type="checkbox" id="dgWsCharts" checked> Show charts</label>
   <label class="dg-ws-check"><input type="checkbox" id="dgWsMotion"> Reduce motion</label>
   <button type="button" id="dgWsReset" class="dg-ws-reset">Restore original DecoyGuard layout</button>
  </aside></div>
  <footer class="dg-ws-footer"><span id="dgWsStatus" role="status">Choose a preset or customize individual widgets.</span><div><button type="button" id="dgWsCancel">Discard changes</button><button type="button" id="dgWsApply">Save &amp; apply</button></div></footer>
 </div>
</section>