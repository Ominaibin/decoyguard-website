DecoyGuard v4.0 — fresh-install source distribution

This package starts without saved websites, visitor accounts, credentials,
logs, captured artifacts, SQLite databases or deployment history. Downloading
it does not connect your installation to the public demonstration server.

Requirements: Docker Desktop running on Windows, or Docker Engine + Compose on
Linux; Python; internet access for browser/images/dependencies. Run commands
from the extracted decoyguard directory.

WINDOWS POWERSHELL
py -3.14 -m pip install -r requirements.txt
py -3.14 -m playwright install chromium
py -3.14 decoyguard.py --dashboard-only

LINUX
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m playwright install --with-deps chromium
.venv/bin/python decoyguard.py --dashboard-only
Ubuntu may require python3-venv before creating the environment.

After startup, use the local URL printed by the program. Configure credentials
through the application and change the initial password before public access.
Use Website Handler to add a website you own or have permission to test.
For Juice Shop, obtain its official Docker image separately and start the
source application before adding it to Website Handler. Banking application
source is not bundled with this fresh-install source release.

Subsequent startup: use decoyguard.py --saved with the same Python interpreter.
Keep the engine process running during testing. Public demo testing and local
installation are separate workflows.

LIMITS
Frontend capture cannot recover arbitrary backend business logic. Some sites
need an application-specific adapter. Source and configuration checks passed;
this fresh distribution has not been run through a full Docker installation
in this environment. Third-party dependencies/images retain their own licenses.
