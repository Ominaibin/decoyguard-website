import os
import sys
import shutil
import subprocess
import json
import time
from pathlib import Path

class DeploymentManager:
    NGINX_PREFIX = 'worker_processes 1;\n\nevents {\n    worker_connections 1024;\n}\n\nhttp {\n    include       /etc/nginx/mime.types;\n    default_type  application/octet-stream;\n\n    # Hardening / Banner Cloaking\n    server_tokens off;\n\n    # =========================================================\n    # DECOYGUARD JSON LOG FORMAT\n    # =========================================================\n    log_format decoyguard_json escape=json \'{\'\n        \'"timestamp":"$time_iso8601",\'\n        \'"event_id":"DG-WEB-$request_id",\'\n        \'"remote_addr":"$remote_addr",\'\n        \'"method":"$request_method",\'\n        \'"uri":"$uri",\'\n        \'"args":"$args",\'\n        \'"request":"$request",\'\n        \'"status":"$status",\'\n        \'"bytes_sent":"$body_bytes_sent",\'\n        \'"referer":"$http_referer",\'\n        \'"user_agent":"$http_user_agent",\'\n        \'"request_time":"$request_time",\'\n        \'"site_id":"$site_id",\'\n        \'"target_type":"$target_type"\'\n    \'}\';\n\n    # Suppress routine failed polling retries while retaining other requests.\n    map "$request_method:$uri:$args:$status" $decoyguard_log_request {\n        default 1;\n        ~^GET:/socket\\.io/:EIO=4&transport=polling&t=[A-Za-z0-9_-]+:503$ 0;\n    }\n\n    # =========================================================================\n    # ON-DEMAND DECOY WEBSITE (ATTACKER ENTRY PORT 8080)\n    # =========================================================================\n'
    DASHBOARD_SERVER = '   server {\n        listen 80;\n        server_name localhost;\n\n        # Default value so every log entry has target_type\n        set $target_type "dashboard";\n        set $site_id "dashboard";\n\n        # =====================================================\n        # PRODUCTION TEST SITE\n        # =====================================================\n        location /production-test/ {\n            set $target_type "production";\n            set $site_id "production-test";\n\n            proxy_pass http://production/;\n            proxy_set_header Host $host;\n            proxy_set_header X-Real-IP $remote_addr;\n            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n        }\n\n        # Write to central DecoyGuard access log\n        access_log /var/log/decoyguard/access.json decoyguard_json if=$decoyguard_log_request;\n        error_log  /var/log/decoyguard/error.log warn;\n\n        # Web Root\n        root /var/www/dashboard;\n        index dashboard.php index.php index.html index.htm;\n\n        # =====================================================\n        # HONEYPOT / BAIT ENDPOINTS (PORT 80)\n        # =====================================================\n        location = /.env {\n            set $target_type "honeypot";\n            default_type application/json;\n            return 403 \'{"error":"Unauthorised access attempt logged. Threat score updated."}\';\n        }\n\n        location ~* \\.(sql|bak|ini|log|config|env)$ {\n            set $target_type "honeypot";\n            default_type application/json;\n            return 403 \'{"error":"Access denied by DecoyGuard Security Engine."}\';\n        }\n\n        location ~* ^/(wp-admin|phpmyadmin|admin|backup)(/|$) {\n            set $target_type "honeypot";\n            default_type application/json;\n            return 403 \'{"error":"Restricted endpoint. Incident recorded."}\';\n        }\n\n        location ~* ^/api/v1/debug(/|$) {\n            set $target_type "honeypot";\n            default_type application/json;\n            return 403 \'{"error":"Debug endpoint restricted. Incident recorded."}\';\n        }\n\n        location ~* ^/\\.git(/|$) {\n            set $target_type "honeypot";\n            default_type application/json;\n            return 403 \'{"error":"Repository access attempt logged."}\';\n        }\n\n        # =====================================================\n        # DASHBOARD API — INTERNAL / EXCLUDE FROM LOGGING\n        # =====================================================\n        location = /api.php {\n            access_log off;\n\n            try_files $uri =404;\n            fastcgi_pass php:9000;\n            include fastcgi_params;\n            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;\n        }\n\n        # =====================================================\n        # PHP-FPM (DASHBOARD)\n        # =====================================================\n        location ~ \\.php$ {\n            try_files $uri =404;\n            fastcgi_split_path_info ^(.+\\.php)(/.+)$;\n            fastcgi_pass php:9000;\n            fastcgi_index dashboard.php;\n            include fastcgi_params;\n            fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;\n        }\n\n        # =====================================================\n        # NORMAL DASHBOARD TRAFFIC\n        # =====================================================\n        location / {\n            set $target_type "dashboard";\n            try_files $uri $uri/ /dashboard.php?$args;\n        }\n    }'

    def __init__(self, compose_file="docker-compose.yaml"):
        self.compose_file = compose_file
        self.behaviour_process = None
        self.mirror_process = None
        self._mirror_run_id = None
        self.mirror_workers = {}
        self.public_roots = ["decoy-website/public"]

    def _registry_path(self):
        return Path('logs/website_registry.json')

    @staticmethod
    def _write_json(path, data):
        import uuid
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
        temporary.write_text(json.dumps(data, indent=2), encoding='utf-8')
        try:
            for attempt in range(10):
                try:
                    os.replace(temporary, path); break
                except PermissionError:
                    if attempt == 9: raise
                    time.sleep(0.05)
            try: path.chmod(0o666)
            except OSError: pass
        finally:
            temporary.unlink(missing_ok=True)

    def load_site_registry(self):
        """Adopt existing mirrors once; preserve them when new websites are added."""
        import uuid
        path = self._registry_path()
        if path.exists():
            registry = json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(registry.get('sites'), dict) or len(registry['sites']) > 8:
                raise ValueError('Invalid website registry or more than eight sites')
            return registry
        config_path = Path('decoy-website/private/gateway_sites.json')
        config = json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {}
        registry = {'deployment_id':config.get('deployment_id') or uuid.uuid4().hex,
                    'sites':{}, 'retired_ids':[]}
        from urllib.parse import urlsplit, urlunsplit
        for site_id, old in config.get('sites', {}).items():
            root = 'decoy-website' if site_id == 'juiceshop' else ('decoy-website/banking' if site_id == 'banking' else 'decoy-website/sites/' + site_id)
            worker = Path(root) / 'private/mirror_worker.json'
            source = json.loads(worker.read_text(encoding='utf-8')).get('target_url') if worker.exists() else None
            if not source:
                parsed = urlsplit(old['production']); host = parsed.hostname
                if host == 'host.docker.internal': host = 'localhost'
                if host == 'banking-website': source = 'http://localhost:8000'
                else: source = urlunsplit((parsed.scheme, ('['+host+']' if ':' in host else host) + (':'+str(parsed.port) if parsed.port else ''), '/', '', ''))
            entry = self.validate_site({'site_id':site_id,'name':site_id.title(),'source_url':source}, registry)
            entry.update(status='ready', capture_ready=True, public_status='Local only')
            registry['sites'][site_id] = entry
        self._write_json(path, registry)
        return registry

    def validate_site(self, payload, registry):
        import re
        from urllib.parse import urlsplit
        site_id = str(payload.get('site_id', '')).strip().lower()
        if not re.fullmatch(r'[a-z][a-z0-9-]{0,30}', site_id):
            raise ValueError('Website ID must start with a letter and use letters, numbers or hyphens (31 characters maximum)')
        old = registry['sites'].get(site_id)
        if not old and len(registry['sites']) >= 8: raise ValueError('At most eight website pairs are supported')
        if not old and site_id in registry.get('retired_ids', []): raise ValueError('This ID has retained decoy data; use a new ID')
        name = str(payload.get('name') or site_id).strip()
        if not name or len(name) > 80 or any(ord(c)<32 for c in name): raise ValueError('Invalid display name')
        source = str(payload.get('source_url', '')).strip()
        if len(source)>2048 or any(ord(c)<33 for c in source): raise ValueError('Invalid source URL')
        url = urlsplit(source)
        if url.scheme not in ('http','https') or not url.hostname or url.username or url.password or url.fragment:
            raise ValueError('Use an HTTP(S) source URL without embedded credentials or a fragment')
        _ = url.port  # Reject invalid ports.
        if url.path in ('','/') and not url.query: source=source.rstrip('/')
        reserved = {80,443,2222}
        for entry in registry['sites'].values(): reserved.update((entry['gateway_port'],entry['decoy_port']))
        if url.hostname in ('localhost','127.0.0.1','::1','host.docker.internal') and (url.port or (443 if url.scheme=='https' else 80)) in reserved:
            raise ValueError('Use the original application URL, not a DecoyGuard gateway, dashboard or decoy')
        if old and old['source_url'] != source: raise ValueError('Use a new website ID for a different source; existing mirrors are preserved')
        domain = str(payload.get('domain', '')).strip().lower()
        if domain:
            if len(domain)>253 or not re.fullmatch(r'(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}',domain):
                raise ValueError('Enter a domain name without scheme, path, wildcard or port')
            if domain.endswith(('.localhost','.local','.internal','.test','.example','.invalid')): raise ValueError('Public domain configuration requires a real domain')
            if any(s.get('domain') == domain for key,s in registry['sites'].items() if key != site_id): raise ValueError('Domain is already assigned')
        if domain and domain==url.hostname: raise ValueError('Use a separate origin address for the real server, so DNS changes do not create a gateway loop')
        if any(other.get('domain')==url.hostname for other in registry['sites'].values() if other.get('domain')): raise ValueError('The source URL points to a configured public gateway domain')
        https = payload.get('https') is True
        if https and not domain: raise ValueError('HTTPS requires a public domain')
        profile = payload.get('backend_profile') or None
        if profile not in (None,'generic','banking','healthcare','industrial','ecommerce','education','corporate'):
            raise ValueError('Unsupported backend profile')
        used = {80,443,2222,3000,8000}
        for key,s in registry['sites'].items():
            if key != site_id: used.update((s['gateway_port'],s['decoy_port']))
        if url.hostname in ('localhost','127.0.0.1','::1'): used.add(url.port or 80)
        def port(field, preferred):
            value = payload.get(field) or (old or {}).get(field)
            if value:
                if isinstance(value,bool): raise ValueError('Invalid port')
                if not (isinstance(value,int) or (isinstance(value,str) and value.isdigit())): raise ValueError('Ports must be integers')
                value = int(value)
                if not 1024<=value<=65535 or value in used: raise ValueError('Gateway and decoy ports must be unique, unused ports from 1024 to 65535')
            else:
                value = preferred
                while value in used: value += 1
            used.add(value); return value
        slot = len(registry['sites']) + 1
        gateway = port('gateway_port',8081 if site_id=='juiceshop' else (8082 if site_id=='banking' else 8100+slot))
        decoy = port('decoy_port',8088 if site_id=='juiceshop' else (8089 if site_id=='banking' else 8180+slot))
        root = 'decoy-website' if site_id=='juiceshop' else ('decoy-website/banking' if site_id=='banking' else 'decoy-website/sites/'+site_id)
        return {'site_id':site_id,'name':name,'source_url':source,'gateway_port':gateway,'decoy_port':decoy,
                'domain':domain,'https':https,'backend_profile':profile,'root':root,
                'static':payload.get('static') is True, 'status':(old or {}).get('status','queued'),'capture_ready':(old or {}).get('capture_ready',False)}

    def render_site_configuration(self, registry):
        """Generate existing Nginx/Compose files and private routing data from one registry."""
        import copy, ipaddress
        from urllib.parse import urlsplit, urlunsplit
        active = {k:s for k,s in registry['sites'].items() if s.get('capture_ready')}
        if len(registry['sites'])>8: raise ValueError('At most eight website pairs are supported')
        config = json.loads(Path(self.compose_file).read_text(encoding='utf-8'))
        services = config['services']; networks = config.setdefault('networks', {})
        # Reconcile only managed decoy services; retain SSH, source and other services.
        for key in list(services):
            if key.startswith('decoy-site-') or key in ('decoy-web','decoy-bank','tls'): services.pop(key)
        for key in list(networks):
            if key.startswith('decoy_site_') or key in ('decoy_juiceshop','decoy_banking','decoyguard_tls'): networks.pop(key)
        gateway = services['gateway']; php = services['php']
        gateway['ports'] = ['127.0.0.1:80:80']
        gateway['networks'] = ['decoyguard_isolated']; php['networks'] = ['decoyguard_isolated']
        php['extra_hosts'] = ['host.docker.internal:host-gateway']
        gateway['depends_on'] = ['php','production']
        if 'banking-website' in services:
            services['banking-website']['profiles']=['bank-source']
            if any(k=='banking' and urlsplit(s['source_url']).hostname in ('localhost','127.0.0.1') and urlsplit(s['source_url']).port==8000 for k,s in active.items()):
                services['banking-website'].pop('profiles',None)
        nginx = self.NGINX_PREFIX + '\n    map "$status:$upstream_status" $dg_gateway_rejected { default 0; ~^[45][0-9][0-9]:$ 1; }\n' 
        routing = {'deployment_id':registry['deployment_id'],'sites':{}}
        tls_sites = []; public = any(s.get('domain') for s in active.values())
        if public: gateway['ports'][0] = '80:80'
        for site_id,s in active.items():
            service = 'decoy-web' if site_id=='juiceshop' else ('decoy-bank' if site_id=='banking' else 'decoy-site-'+site_id)
            network = 'decoy_'+site_id if site_id in ('juiceshop','banking') else 'decoy_site_'+site_id.replace('-','_')
            networks[network] = {'driver':'bridge','internal':True}
            gateway['networks'].append(network); php['networks'].append(network); gateway['depends_on'].append(service)
            root = s['root']
            for folder in ('public','private/backend-state','private/mirror-queue','decoy-database'): Path(root,folder).mkdir(parents=True,exist_ok=True)
            services[service] = {'build':{'context':'.','dockerfile':'docker/Dockerfile'},'restart':'unless-stopped',
                'volumes':['./'+root+'/public:/var/www/html','./'+root+'/private:/var/www/decoyguard-private:ro',
                           './'+root+'/private/backend-state:/var/www/decoyguard-private/backend-state',
                           './'+root+'/private/mirror-queue:/var/www/decoyguard-private/mirror-queue',
                           './tools/guard_middleware.php:/var/www/guard_middleware.php:ro',
                           './'+root+'/decoy-database:/var/www/decoy-database','./logs/events.jsonl:/var/log/decoyguard/events.jsonl'],
                'environment':['DECOYGUARD_ACTIVE=1','DECOY_TRUST_PROXY=1','DECOY_DB_PATH=/var/www/decoy-database/decoy_website.db',
                               'TELEMETRY_LOG_PATH=/var/log/decoyguard/events.jsonl','DECOY_SITE_ID='+site_id,'DECOYGUARD_PRESENTATION='+('1' if os.getenv('DECOYGUARD_PRESENTATION')=='1' else '0')], 'networks':[network]}
            if site_id in ('juiceshop','banking'): services[service]['container_name']='decoyguard_web' if site_id=='juiceshop' else 'decoyguard_bank_decoy'
            source = urlsplit(s['source_url']); host = source.hostname
            if host in ('localhost','127.0.0.1','::1'): host='host.docker.internal'
            netloc = ('['+host+']' if ':' in host else host) + (':'+str(source.port) if source.port else '')
            production = urlunsplit((source.scheme,netloc,'','',''))
            if site_id=='banking' and source.hostname in ('localhost','127.0.0.1') and source.port==8000: production='http://banking-website:80'
            routing['sites'][site_id]={'production':production,'decoy':'http://'+service+':80',
                                     'private':'/var/www/'+root+'/private','gateway_port':s['gateway_port'],'decoy_port':s['decoy_port']}
            # Local test ports stay loopback-only; a configured domain is the public entry point.
            for port in (s['gateway_port'],s['decoy_port']): gateway['ports'].append(f'127.0.0.1:{port}:{port}')
            nginx += self._gateway_server(site_id, str(s['gateway_port']), 'localhost')
            nginx += f'''\n    server {{
        listen {s['decoy_port']}; server_name localhost;
        set $site_id "{site_id}"; set $target_type "decoy";
        access_log /var/log/decoyguard/access.json decoyguard_json if=$decoyguard_log_request;
        location / {{
            proxy_pass http://{service}:80;
            proxy_set_header Host $http_host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $remote_addr;
            proxy_set_header X-Decoy-Request-ID $request_id;
            proxy_set_header X-Decoy-Entry-Point direct-decoy;
            proxy_read_timeout 100s;
        }}
    }}\n'''
            if s.get('domain'):
                if s.get('https'):
                    tls_sites.append(s)
                    nginx += f'''\n    server {{
        listen 80; server_name {s['domain']};
        set $site_id "{site_id}"; set $target_type "production";
        location /.well-known/acme-challenge/ {{
            resolver 127.0.0.11 valid=5s;
            set $acme_backend http://tls:80;
            proxy_pass $acme_backend; proxy_set_header Host $host;
        }}
        location / {{ return 308 https://{s['domain']}$request_uri; }}
    }}\n'''
                else: nginx += self._gateway_server(site_id,'80',s['domain'])
        if tls_sites:
            subnet = str(ipaddress.ip_network(os.getenv('DECOYGUARD_TLS_SUBNET','172.30.255.0/29')))
            networks['decoyguard_tls']={'driver':'bridge','ipam':{'config':[{'subnet':subnet}]}}
            gateway['networks'].append('decoyguard_tls')
            nginx = nginx.replace('    server_tokens off;', '    server_tokens off;\n    set_real_ip_from '+subnet+';\n    real_ip_header X-Forwarded-For;\n    real_ip_recursive on;\n    geo $realip_remote_addr $dg_edge_proxy { default 0; '+subnet+' 1; }\n    map \"$dg_edge_proxy:$http_x_forwarded_proto\" $dg_https { default \"\"; \"1:https\" on; }')
            nginx = nginx.replace('fastcgi_param HTTPS $https if_not_empty;', 'fastcgi_param HTTPS $dg_https if_not_empty;')
            services['tls']={'image':'caddy:2','restart':'unless-stopped','ports':['443:443'],
                'volumes':['./logs/Caddyfile:/etc/caddy/Caddyfile:ro','decoyguard_tls_data:/data','decoyguard_tls_config:/config'],
                'networks':['decoyguard_tls'],'depends_on':['gateway']}
            config.setdefault('volumes',{}).update({'decoyguard_tls_data':{},'decoyguard_tls_config':{}})
            Path('logs/Caddyfile').write_text('\n'.join(s['domain']+' {\n    reverse_proxy gateway:'+str(s['gateway_port'])+'\n}\n' for s in tls_sites),encoding='utf-8')
        nginx += self.DASHBOARD_SERVER + '\n}\n'
        Path('nginx/nginx.conf').write_text(nginx,encoding='utf-8')
        self._write_json(self.compose_file,config)
        self._write_json('decoy-website/private/gateway_sites.json',routing)
        self.public_roots=[s['root']+'/public' for s in active.values()]
        return routing

    @staticmethod
    def _gateway_server(site_id, port, domain):
        log_name = 'dg_rejected_' + site_id.replace('-', '_') + '_' + str(port)
        log_format = ("\n    log_format " + log_name + " escape=json '{" +
            '"timestamp":"$time_iso8601","event_id":"DG-WEB-$request_id",' +
            '"remote_addr":"$remote_addr","method":"$request_method","request":"$request",' +
            '"uri":"$request_uri","status":"$status","user_agent":"$http_user_agent",' +
            '"site_id":"' + site_id + '","target_type":"production","source":"nginx-rejection"}' + "';\n")
        return log_format + f'''\n    server {{
        listen {port}; server_name {domain};
        client_max_body_size 1m;
        set $site_id "{site_id}"; set $target_type "production";
        access_log /var/log/decoyguard/access.json {log_name} if=$dg_gateway_rejected;
        error_log /var/log/decoyguard/{site_id}_gateway_error.log warn;
        location / {{
            include fastcgi_params; fastcgi_pass php:9000;
            fastcgi_param SCRIPT_FILENAME /var/www/guard_middleware.php;
            fastcgi_param DG_GATEWAY_MODE 1;
            fastcgi_param DG_PRESENTATION_MODE {1 if os.getenv("DECOYGUARD_PRESENTATION")=="1" else 0};
            fastcgi_param DG_SITE_ID {site_id};
            fastcgi_param DG_REQUEST_ID $request_id;
            fastcgi_param HTTP_HOST $http_host;
            fastcgi_param HTTPS $https if_not_empty;
            fastcgi_pass_request_body on;
            fastcgi_read_timeout 110s; fastcgi_buffering off;
        }}
    }}\n'''

    def deploy_registered_site(self, payload, *, recapture=False):
        from tools.mirror_engine import DecoyDuplicator
        from tools.data_generator import generate_decoy_database_from_manifest
        registry=self.load_site_registry(); entry=self.validate_site(payload,registry); site_id=entry['site_id']
        old=registry['sites'].get(site_id)
        if old and old.get('capture_ready') and not recapture:
            return old
        if recapture and old and old.get('capture_ready'): raise ValueError('Use a new ID to preserve an active mirror')
        entry.update(status='deploying',error='',capture_ready=False)
        registry['sites'][site_id]=entry; self._write_json(self._registry_path(),registry)
        snapshots={str(p):p.read_bytes() if p.exists() else None for p in map(Path,[self.compose_file,'nginx/nginx.conf','decoy-website/private/gateway_sites.json','logs/Caddyfile'])}
        try:
            if site_id=='banking' and entry['source_url'].rstrip('/')=='http://localhost:8000':
                if not self.start_banking_source(): raise RuntimeError('Banking source failed to start')
            public=Path(entry['root'])/'public'
            if recapture and old and old.get('capture_ready'):
                raise ValueError('Remove the route and add a new website ID to rebuild without overwriting an active mirror')
            duplicator=DecoyDuplicator(entry['source_url'],output_dir=str(public),backend_profile=entry['backend_profile'],static_decoy=entry.get('static',False))
            duplicator.clone()
            if not (public/'site_manifest.json').exists(): raise RuntimeError('Capture did not produce a website manifest')
            if not generate_decoy_database_from_manifest(manifest_path=str(public/'site_manifest.json'),db_path=str(public.parent/'decoy-database/decoy_website.db')):
                raise RuntimeError('Synthetic data generation failed')
            entry['capture_ready']=True; entry['status']='ready'; registry['sites'][site_id]=entry
            self.render_site_configuration(registry)
            if not self.launch_stack(): raise RuntimeError('Container or mirror worker health checks failed')
            entry['status']='live'; entry['public_status']='HTTPS configured; awaiting DNS/certificate verification' if entry['https'] else ('HTTP domain configured; awaiting DNS verification' if entry['domain'] else 'Local only')
            registry['sites'][site_id]=entry; self._write_json(self._registry_path(),registry)
            return entry
        except Exception as error:
            self.stop_mirror_worker(entry['root']+'/public')
            for name,contents in snapshots.items():
                path=Path(name)
                if contents is not None: path.write_bytes(contents)
                elif path.exists(): path.unlink()
            entry.update(status='failed',error=str(error),capture_ready=False); registry['sites'][site_id]=entry
            self._write_json(self._registry_path(),registry)
            # Reconcile the previous running configuration after a failed addition.
            try:
                self.public_roots=[s['root']+'/public' for s in registry['sites'].values() if s.get('capture_ready')]
                self.launch_stack()
            except Exception: pass
            raise

    def remove_registered_site(self, site_id):
        registry=self.load_site_registry()
        if site_id not in registry['sites']: raise ValueError('Unknown website ID')
        previous_roots=[s['root']+'/public' for s in registry['sites'].values() if s.get('capture_ready')]
        entry=registry['sites'].pop(site_id)
        registry.setdefault('retired_ids',[]).append(site_id)
        snapshots={str(p):p.read_bytes() if p.exists() else None for p in map(Path,[self.compose_file,'nginx/nginx.conf','decoy-website/private/gateway_sites.json','logs/Caddyfile'])}
        self.stop_mirror_worker(entry['root']+'/public')
        try:
            self.render_site_configuration(registry)
            if not self.launch_stack(): raise RuntimeError('Could not apply route removal')
            self._write_json(self._registry_path(),registry)
        except Exception:
            for name,contents in snapshots.items():
                path=Path(name)
                if contents is not None: path.write_bytes(contents)
                elif path.exists(): path.unlink()
            self.public_roots=previous_roots
            try: self.launch_stack()
            except Exception: pass
            raise
        return {'site_id':site_id,'status':'removed','data_retained':True}

    def start_site_controller(self):
        """Consume authenticated dashboard requests on the host; PHP never runs Docker."""
        import threading
        self._controller_stop=threading.Event()
        registry=self.load_site_registry()
        for entry in registry['sites'].values():
            if entry.get('status')=='deploying': entry.update(status='failed',capture_ready=False,error='Deployment was interrupted. Retry this website.')
        self._write_json(self._registry_path(),registry)
        requests=Path('logs/site_requests'); requests.mkdir(parents=True,exist_ok=True)
        try: requests.chmod(0o777)
        except OSError: pass
        for stale in requests.glob('*.running'):
            try: job=json.loads(stale.read_text(encoding='utf-8'))
            except (ValueError,OSError): job={'job_id':stale.stem}
            job.update(status='failed',error='Controller stopped during deployment. Retry the website.')
            self._write_json(stale.with_suffix('.done'),job); stale.unlink()
        def heartbeat():
            while not self._controller_stop.is_set():
                self._write_json('logs/site_controller.json',{'timestamp':time.time(),'status':'ready' if self._controller_thread.is_alive() else 'stopped'})
                self._controller_stop.wait(2)
        def loop():
            while not self._controller_stop.is_set():
                for path in sorted(requests.glob('*.json')):
                    if self._controller_stop.is_set(): break
                    claimed=path.with_suffix('.running')
                    try: os.replace(path,claimed)
                    except FileNotFoundError: continue
                    job={'job_id':claimed.stem}
                    try:
                        parsed=json.loads(claimed.read_text(encoding='utf-8'))
                        if not isinstance(parsed,dict): raise ValueError('Invalid deployment request')
                        job=parsed; job.update(status='deploying',started=time.time()); self._write_json(claimed,job)
                        if job['action']=='add': result=self.deploy_registered_site(job['site'])
                        elif job['action']=='retry': result=self.deploy_registered_site(job['site'],recapture=True)
                        elif job['action']=='remove': result=self.remove_registered_site(job['site']['site_id'])
                        else: raise ValueError('Unsupported website operation')
                        job.update(status='complete',result=result)
                    except Exception as error: job.update(status='failed',error=str(error)); print('[SITES] '+str(error),flush=True)
                    job['finished']=time.time(); self._write_json(claimed.with_suffix('.done'),job); claimed.unlink(missing_ok=True)
                    completed=sorted(requests.glob('*.done'),key=lambda p:p.stat().st_mtime)
                    for expired in completed[:-50]: expired.unlink(missing_ok=True)
                self._controller_stop.wait(1)
        self._controller_thread=threading.Thread(target=loop,name='website-deployment',daemon=True)
        self._controller_thread.start()
        threading.Thread(target=heartbeat,name='website-heartbeat',daemon=True).start()

    def verify_docker(self):
        """Checks if Docker daemon and Docker Compose plugin are available."""
        if not shutil.which("docker"):
            print("[!] Docker binary not found in system PATH.")
            return False

        try:
            # 1. Daemon check
            res_info = subprocess.run(["docker", "info"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if res_info.returncode != 0:
                print("[!] Docker daemon is not active. Please start Docker Desktop.")
                return False

            # 2. Compose plugin check
            res_compose = subprocess.run(["docker", "compose", "version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if res_compose.returncode != 0:
                print("[!] 'docker compose' is not available or outdated.")
                return False
        except Exception as e:
            print(f"[!] Docker verification error: {e}")
            return False

        return True

    def prepare_environment(self):
        """Create runtime mounts before Compose starts PHP and the decoy containers."""
        os.makedirs("decoy-website/public", exist_ok=True)
        os.makedirs("decoy-website/decoy-database", exist_ok=True)
        os.makedirs("logs", exist_ok=True)
        for name in ('events.jsonl', 'access.json', 'behaviour_events.jsonl',
                     'gateway_routes.json', 'routing_decisions.jsonl'):
            path = Path('logs') / name
            path.touch(exist_ok=True)
            # Host Python and container uid 33 both append; decoys mount only events.jsonl.
            try:
                path.chmod(0o666)
            except OSError:
                pass
        requests=Path('logs/site_requests'); requests.mkdir(parents=True,exist_ok=True)
        try: requests.chmod(0o777)
        except OSError: pass
        return True


    def start_banking_source(self):
        if not Path('banking-website/index.php').is_file():
            print('[!] banking-website/index.php is missing. Extract your banking website first.')
            return False
        result = subprocess.run(['docker', 'compose', '-f', self.compose_file,
                                 'up', '-d', '--build', 'banking-website'], check=False)
        if result.returncode:
            return False
        import requests
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            try:
                response = requests.get('http://127.0.0.1:8000/', timeout=2)
                if response.status_code == 200 and 'database connection failed' not in response.text.lower():
                    return True
            except requests.RequestException:
                pass
            time.sleep(0.25)
        print('[!] Banking source is not ready at localhost:8000; inspect its Docker logs.')
        return False

    def install_banking_source_backend(self):
        """Optional supplied-source banking adapter; never infer PHP from a URL."""
        if os.getenv('DECOY_BANKING_SOURCE_BACKEND', '0') != '1':
            return
        import sqlite3
        from contextlib import closing
        import hashlib
        import secrets
        import tempfile
        source = Path('banking-website')
        public = Path('decoy-website/banking/public')
        private = public.parent / 'private'
        required = ('index.php', 'mainpage.php', 'includes/db.php', 'includes/guard.php')
        if not all((source / name).is_file() for name in required):
            raise RuntimeError('Supplied banking PHP source is incomplete')
        if not (private / 'backend_catalog.json').is_file():
            raise RuntimeError('Mirror and configure banking before installing its source backend')
        state = private / 'backend-state'
        state.mkdir(parents=True, exist_ok=True)
        state.chmod(0o777)
        database = state / 'bank-training.db'
        if not database.exists():
            schemas = ["CREATE TABLE users (\r\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n    username TEXT UNIQUE NOT NULL,\r\n    full_name TEXT NOT NULL,\r\n    password_hash TEXT NOT NULL,\r\n    salt TEXT NOT NULL,\r\n    account_status TEXT DEFAULT 'active' CHECK(account_status IN ('active', 'locked', 'suspended')),\r\n    failed_attempts INTEGER DEFAULT 0,\r\n    locked_until DATETIME DEFAULT NULL,\r\n    created_at DATETIME DEFAULT CURRENT_TIMESTAMP\r\n)", "CREATE TABLE accounts (\r\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n    user_id INTEGER NOT NULL,\r\n    account_number TEXT UNIQUE NOT NULL,\r\n    account_type TEXT NOT NULL,\r\n    balance REAL NOT NULL DEFAULT 0.00 CHECK(balance >= 0.00),\r\n    currency TEXT DEFAULT 'RM',\r\n    status TEXT DEFAULT 'active',\r\n    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE\r\n)", 'CREATE TABLE auth_logs (\r\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n    username TEXT,\r\n    source_ip TEXT,\r\n    status TEXT NOT NULL,\r\n    attempt_time DATETIME DEFAULT CURRENT_TIMESTAMP\r\n)', "CREATE TABLE security_events (\r\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n    event_type TEXT NOT NULL,\r\n    severity TEXT NOT NULL,\r\n    source_ip TEXT,\r\n    username TEXT,\r\n    description TEXT,\r\n    status TEXT DEFAULT 'Detected',\r\n    created_at DATETIME DEFAULT CURRENT_TIMESTAMP\r\n)", 'CREATE TABLE transactions (\r\n    id INTEGER PRIMARY KEY AUTOINCREMENT,\r\n    user_id INTEGER NOT NULL,\r\n    transaction_type TEXT NOT NULL,\r\n    amount REAL NOT NULL,\r\n    description TEXT,\r\n    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,\r\n    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE\r\n)']
            fd, staging = tempfile.mkstemp(prefix='bank-', suffix='.db', dir=state)
            os.close(fd)
            try:
                with closing(sqlite3.connect(staging)) as db:
                    for schema in schemas:
                        db.execute(schema)
                    for uid, username, display in ((1, 'demo', 'Demo Customer'),
                            (2, 'recipient', 'Training Recipient'), (3, 'canary', 'Canary Customer')):
                        salt = secrets.token_hex(16)
                        digest = hashlib.sha256(('DemoBank2026!' + salt).encode()).hexdigest()
                        db.execute('INSERT INTO users(id,username,full_name,password_hash,salt) VALUES(?,?,?,?,?)',
                                   (uid, username, display, digest, salt))
                    for uid, number, balance in ((1,'5912',24180.50),(2,'2222',1000),(3,'9999',5000)):
                        db.execute('INSERT INTO accounts(user_id,account_number,account_type,balance) VALUES(?,?,?,?)',
                                   (uid, number, 'Training account', balance))
                    db.commit()
                os.replace(staging, database)
            finally:
                Path(staging).unlink(missing_ok=True)
        database.chmod(0o666)
        # Only locally supplied PHP source is trusted; no production records copied.
        for file in source.rglob('*.php'):
            if file.is_symlink():
                raise RuntimeError('Symlinks are not supported in supplied banking source')
            destination = public / file.relative_to(source)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, destination)
        print('[✓] Banking source backend enabled with an isolated synthetic database.')

    def prepare_container_telemetry(self):
        """Nginx and PHP use different UIDs; Windows bind mounts need container-side chmod."""
        paths=['/var/log/decoyguard/'+name for name in
               ('access.json','events.jsonl','gateway_routes.json','routing_decisions.jsonl')]
        encoded=json.dumps(paths,separators=(',',':'))
        repair='$files='+encoded+'; foreach ($files as $f) { if (!is_file($f) && file_put_contents($f,"",FILE_APPEND)===false) exit(1); if (!chmod($f,0666)) { fwrite(STDERR,"Cannot set shared log permissions: ".$f); exit(1); } }'
        probe='$files='+encoded+'; foreach ($files as $f) { clearstatcache(true,$f); if (!is_writable($f) || file_put_contents($f,"",FILE_APPEND|LOCK_EX)===false) { fwrite(STDERR,"PHP worker cannot write shared log: ".$f); exit(1); } }'
        for user,code in (('root',repair),('www-data',probe)):
            result=subprocess.run(['docker','compose','-f',self.compose_file,'exec','-T','--user',user,'php','php','-r',code],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=15)
            if result.returncode:
                raise RuntimeError('Gateway telemetry permission check failed: '+result.stderr.strip())

    def refresh_saved_backends(self):
        """Upgrade only generated API code; retain captured pages, catalog and state."""
        from tools.mirror_engine import DecoyDuplicator
        root = Path.cwd().resolve()
        for site in self.load_site_registry().get('sites', {}).values():
            if not site.get('capture_ready'):
                continue
            public = (root / site['root'] / 'public').resolve()
            if root not in public.parents:
                raise ValueError('Saved mirror root is outside this project')
            runtime = public / 'decoy_api.php'
            catalog = public.parent / 'private' / 'backend_catalog.json'
            if not runtime.is_file() or not catalog.is_file():
                print('[!] Backend refresh skipped for '+site['site_id']+': generated runtime/catalog missing')
                continue
            current = runtime.read_text(encoding='utf-8')
            if '// DG_RUNTIME_REV=20261028_MIRROR4' in current:
                continue
            if 'function dg_load_state(' not in current:
                print('[!] Backend refresh skipped for '+site['site_id']+': custom runtime retained')
                continue
            backup = public.parent / 'private' / 'decoy_api.before-20261028-mirror4.php'
            if not backup.exists():
                backup.write_text(current,encoding='utf-8')
                try: backup.chmod(0o600)
                except OSError: pass
            engine = DecoyDuplicator(site['source_url'],output_dir=str(public),
                backend_profile=site.get('backend_profile'),static_decoy=site.get('static',False))
            engine.generate_runtime_handlers(preserve_catalog=True)
            print('[OK] Local API runtime updated for '+site['site_id']+'; saved pages and data retained.')

    def launch_stack(self):
        if getattr(self,"_controller_stop",None) and self._controller_stop.is_set(): return False
        """Builds if needed and boots the container stack quietly."""
        if not os.path.exists(self.compose_file):
            print(f"[!] Compose configuration not found: {self.compose_file}")
            return False

        try:
            self.refresh_saved_backends()
            self.install_banking_source_backend()
            cmd = [
                "docker",
                "compose",
                "-f",
                self.compose_file,
                "up",
                "-d",
                "--build", "--remove-orphans"
            ]

            res = subprocess.run(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.PIPE,
                text=True, encoding="utf-8", errors="replace"
            )

            if res.returncode != 0:
                print("[!] Container boot failed.")
                if res.stderr:
                    print(res.stderr.strip())
                return False

            self.prepare_container_telemetry()

            # Provision private persistent dashboard credentials for the PHP worker.
            auth_code = "$p='/var/log/decoyguard/dashboard-auth'; if (!is_dir($p) && !mkdir($p,0700,true)) exit(1); if (!chown($p,33) || !chmod($p,0700)) exit(1); $f=$p.'/credentials.json'; if (is_file($f) && (!chown($f,33) || !chmod($f,0600))) exit(1);"
            auth_ready = subprocess.run(['docker','compose','-f',self.compose_file,'exec','-T','--user','root','php','php','-r',auth_code],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=15)
            if auth_ready.returncode:
                print('[!] Dashboard credential storage cannot be prepared: '+auth_ready.stderr.strip())
                return False

            # Bind-mounted Nginx edits do not force Compose to recreate a container.
            for arguments in (['nginx', '-t'], ['nginx', '-s', 'reload']):
                checked = subprocess.run(['docker', 'exec', 'decoyguard_nginx'] + arguments,
                                         capture_output=True, text=True, encoding='utf-8',
                                         errors='replace', timeout=15, check=False)
                if checked.returncode:
                    print('[!] Gateway configuration failed: ' + checked.stderr.strip())
                    return False
            routing_config = Path('decoy-website/private/gateway_sites.json')
            if routing_config.exists():
                import requests
                sites = json.loads(routing_config.read_text(encoding='utf-8')).get('sites', {})
                for site_id, site in sites.items():
                    port = site.get('gateway_port', 8081 if site_id == 'juiceshop' else 8082)

                    if site_id not in sites:
                        continue
                    ready = False
                    deadline = time.monotonic() + 20
                    while time.monotonic() < deadline:
                        try:
                            response = requests.get(f'http://127.0.0.1:{port}/', timeout=3,
                                                    headers={'User-Agent':'DecoyGuard-Startup'},
                                                    allow_redirects=False)
                            ready = (response.status_code < 500 and
                                     response.headers.get('X-DecoyGuard-Site') == site_id and
                                     response.headers.get('X-DecoyGuard-Target') in ('production','decoy'))
                            if ready:
                                break
                        except requests.RequestException:
                            pass
                        time.sleep(0.25)
                    if not ready:
                        print(f'[!] {site_id} gateway is not ready on localhost:{port}; inspect docker compose logs gateway php.')
                        return False

            compose = json.loads(Path(self.compose_file).read_text(encoding='utf-8'))
            if 'tls' in compose['services']:
                checked = subprocess.run(['docker','compose','-f',self.compose_file,'exec','-T','tls','caddy','reload','--config','/etc/caddy/Caddyfile'],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=30)
                if checked.returncode: raise RuntimeError('HTTPS configuration reload failed: '+checked.stderr.strip())
            for public_root in self.public_roots:
                config = Path(public_root).parent / "private" / "mirror_worker.json"
                if config.exists() and not self.start_mirror_worker(public_root):
                    print(f"[!] Mirror worker failed for {public_root}; inspect logs/mirror_worker*.log.")
                    return False
            return True

        except Exception as e:
            print(f"[!] Container boot failed: {e}")
            return False

    def manage_application_lab(self, action, directory='decoy-lab', *, confirm_reset=False):
        """Manage independent replicas without changing the ordinary mirror stack."""
        root = Path(directory).resolve()
        compose = root / 'compose.yaml'
        if not compose.is_file():
            print('[!] Prepare the application lab first; compose.yaml is missing.')
            return False
        if action == 'reset' and not confirm_reset:
            print('[!] Reset removes synthetic banking data and container state. Add --confirm-reset.')
            return False
        if action not in {'up', 'down', 'status', 'reset'}:
            raise ValueError('Unknown application lab action')
        base = ['docker', 'compose', '-p', 'decoyguard-application-lab', '-f', str(compose)]
        operations = {
            'up': ['up', '-d', '--build', '--wait', '--wait-timeout', '180'],
            'down': ['down'], 'status': ['ps'], 'reset': ['down', '--volumes'],
        }
        try:
            result = subprocess.run(base + operations[action], cwd=str(root), check=False)
        except OSError as error:
            print('[!] Docker is unavailable: ' + str(error))
            return False
        if result.returncode:
            print('[!] Lab operation failed. Inspect: docker compose -p decoyguard-application-lab -f ' + str(compose) + ' logs')
            return False
        if action == 'up':
            print('[OK] Juice Shop: http://localhost:8090')
            print('[OK] Banking: http://localhost:8091 (demo / DemoBank2026!)')
            print('[OK] Lab logs: ' + str(root / 'logs'))
        elif action == 'reset':
            print('[OK] Runtime data removed. Run lab up to recreate the seeded replicas.')
        return True

    def start_mirror_worker(self, public_root="decoy-website/public"):
        """Each mirrored site owns its browser process and capture queue."""
        public = Path(public_root).resolve()
        key = str(public)
        private = public.parent / 'private'
        config_path = private / 'mirror_worker.json'
        if not config_path.exists():
            return False
        config = json.loads(config_path.read_text(encoding='utf-8'))
        if not config.get('active'):
            return False
        run_id = config['run_id']
        heartbeat_path = private / 'mirror-queue' / run_id / 'heartbeat.json'
        previous = self.mirror_workers.get(key)
        if previous and previous[0].poll() is None:
            if previous[1] == run_id:
                return True
            self.stop_mirror_worker(public_root)
        def ready():
            try:
                heartbeat = json.loads(heartbeat_path.read_text(encoding='utf-8'))
                return heartbeat.get('run_id') == run_id and time.time() - heartbeat.get('timestamp', 0) < 10
            except (OSError, ValueError):
                return False
        if ready():
            return True
        folders = [Path(__file__).resolve().parent, Path.cwd() / 'tools', Path.cwd()]
        worker = next((folder / 'mirror_worker.py' for folder in folders if (folder / 'mirror_worker.py').is_file()), None)
        engine = next((folder / 'mirror_engine.py' for folder in folders if (folder / 'mirror_engine.py').is_file()), None)
        if not worker or not engine:
            print('[!] mirror_worker.py and mirror_engine.py must be in tools/.')
            return False
        Path('logs').mkdir(exist_ok=True)
        name = 'mirror_worker.log' if public.parent.name == 'decoy-website' else f'mirror_worker_{public.parent.name}.log'
        with open(Path('logs') / name, 'a', encoding='utf-8') as log:
            process = subprocess.Popen(
                [sys.executable, str(worker), '--root', str(public), '--engine', str(engine)],
                stdout=log, stderr=subprocess.STDOUT,
                env={**os.environ, 'PYTHONIOENCODING':'utf-8', 'PYTHONUTF8':'1', 'PYTHONUNBUFFERED':'1'},
            )
        self.mirror_workers[key] = (process, run_id)
        self.mirror_process = process
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if process.poll() is not None:
                self.stop_mirror_worker(public_root)
                return False
            if ready():
                return True
            time.sleep(0.1)
        self.stop_mirror_worker(public_root)
        return False


    def stop_mirror_worker(self, public_root=None):
        keys = [str(Path(public_root).resolve())] if public_root else list(self.mirror_workers)
        for key in keys:
            item = self.mirror_workers.pop(key, None)
            if not item:
                continue
            process = item[0]
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=5)
        self.mirror_process = None
        self._mirror_run_id = None


    def start_behaviour_engine(self, engine_script="behavioural_detection.py"):
        """Launches the Behaviour Engine as a background process."""

        if not os.path.exists(engine_script):
            if os.path.exists("behaviour_engine.py"):
                engine_script = "behaviour_engine.py"
            else:
                print(
                    f"[-] Behaviour Engine script '{engine_script}' not found. "
                    "Telemetry logged to disk only."
                )
                return False

        try:
            self.behaviour_process = subprocess.Popen(
                [sys.executable, engine_script],
                env={**os.environ, "PYTHONIOENCODING":"utf-8", "PYTHONUTF8":"1", "PYTHONUNBUFFERED":"1"},
                cwd=str(Path(__file__).resolve().parent.parent),
            )
            return True

        except Exception as e:
            print(f"[!] Failed to spawn Behaviour Engine process: {e}")
            return False

    def teardown_stack(self):
        """Stops the Behaviour Engine and container stack."""

        if self.behaviour_process and self.behaviour_process.poll() is None:
            self.behaviour_process.terminate()
            self.behaviour_process.wait()

        if getattr(self,'_controller_stop',None):
            self._controller_stop.set()
            self._controller_thread.join(timeout=3)
            self._write_json('logs/site_controller.json',{'timestamp':time.time(),'status':'stopped'})
        self.stop_mirror_worker()

        # Keep containers available for debugging by using stop instead of down
        if os.path.exists(self.compose_file):
            subprocess.run(
                ["docker", "compose", "-f", self.compose_file, "stop"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False
            )