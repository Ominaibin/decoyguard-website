import base64
import contextlib
import hashlib
import json
import os
import re
import shutil
import stat
import time
import unicodedata
import urllib.parse
import uuid
import requests
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
try:
    from tools.adaptive_analyzer import AdaptiveSemanticAnalyzer
except ImportError:
    from adaptive_analyzer import AdaptiveSemanticAnalyzer

# Capture waits are centralized so tuning requires no patch scripts.
ON_DEMAND_NETWORK_IDLE_SECONDS = 2.0
STARTUP_NETWORK_IDLE_SECONDS = 1.5
APPEARANCE_WAIT_SECONDS = 2.0

NAVIGATION_GUARD_JS = ""
INTERACTION_RUNTIME_JS = r"""
/* Local interactions for captured documents. No production scripts or requests. */
(() => {
  'use strict';
  if (window.__mirrorInteractions) return;
  window.__mirrorInteractions = true;
  const init = () => {
    const label = e => (e.getAttribute('aria-label') || e.textContent || '').trim().toLowerCase();
    const visible = (e, show) => {
      // Move focus off descendants before hiding them from accessibility APIs.
      if (!show && e.contains(document.activeElement)) document.activeElement.blur();
      e.hidden = !show;
      e.inert = !show;
      if (show) e.removeAttribute('inert');
      // Hidden/inert panels already leave the accessibility tree.
      // Avoid aria-hidden=true while browser focus restoration is in progress.
      if (show) e.setAttribute('aria-hidden', 'false');
      else e.removeAttribute('aria-hidden');
      e.style.setProperty('display', show ? (e.dataset.mirrorDisplay || 'block') : 'none', 'important');
      if (show) { e.style.setProperty('visibility', 'visible', 'important'); e.style.setProperty('opacity', '1', 'important'); }
    };

    // Restore close actions for static dialogs, including Angular Material overlays.
    const dismissDialog = control => {
      const dialog = control.closest('[role="dialog"], dialog, [aria-modal="true"]');
      if (!dialog) return;
      const overlay = dialog.closest('.cdk-overlay-container');
      const wrapper = dialog.closest('.cdk-global-overlay-wrapper');
      visible(dialog, false);
      if (dialog.tagName === 'DIALOG' && dialog.open && typeof dialog.close === 'function') dialog.close();
      if (wrapper) {
        if (typeof wrapper.hidePopover === 'function') { try { wrapper.hidePopover(); } catch (_) {} }
        visible(wrapper, false);
      }
      const remaining = overlay && [...overlay.querySelectorAll('[role="dialog"], [aria-modal="true"]')].some(d => !d.hidden && getComputedStyle(d).display !== 'none');
      if (overlay && !remaining) {
        overlay.querySelectorAll('.cdk-overlay-backdrop').forEach(b => visible(b, false));
        for (const root of document.querySelectorAll('body > app-root, body > main, body > [inert]')) {
          if (root === overlay || root.contains(overlay) || root.matches('[role="dialog"], dialog')) continue;
          root.removeAttribute('aria-hidden'); root.removeAttribute('inert'); root.inert = false;
        }
        document.documentElement.classList.remove('cdk-global-scrollblock');
        for (const root of [document.body, document.documentElement]) if (root.style.overflow === 'hidden') root.style.removeProperty('overflow');
      }
      const focusTarget = document.querySelector('main button:not([disabled]), app-root button:not([disabled]), main a[href]');
      if (focusTarget && !focusTarget.closest('[hidden], [inert]')) focusTarget.focus({preventScroll:true});
    };
    document.addEventListener('click', e => {
      const control = e.target.closest('button, [role="button"]');
      if (!control || !control.closest('[role="dialog"], dialog, [aria-modal="true"]')) return;
      const name = label(control);
      const dismiss = /^(close|dismiss)(\b|$)/.test(name) || /^(close|dismiss)$/.test((control.textContent || '').trim().toLowerCase());
      if (!dismiss) return;
      e.preventDefault(); dismissDialog(control);
    });
    document.addEventListener('keydown', e => {
      if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role="button"]:not(button)') && /^(close|dismiss)(\b|$)/.test(label(e.target))) {
        e.preventDefault(); e.target.click();
      }
    });

    const closers = [];
    for (const b of document.querySelectorAll('button[aria-expanded]')) {
      let panel = document.getElementById(b.getAttribute('aria-controls'));
      const template = [...document.querySelectorAll('template[data-mirror-for]')].find(t => t.dataset.mirrorFor === b.id);
      if (!panel && template && template.content.firstElementChild) {
        const existingId = template.content.firstElementChild.id;
        if (existingId) panel = document.getElementById(existingId);
      }
      if (!panel && template) {
        const fragment = template.content.cloneNode(true);
        panel = fragment.firstElementChild;
        if (panel) { document.body.append(fragment); panel.hidden = true; }
      }
      if (!panel) continue;
      const popup = b.hasAttribute('aria-haspopup') || /\bmenu\b/.test(label(b));
      const wasOpen = b.getAttribute('aria-expanded') === 'true';
      panel.dataset.mirrorDisplay = getComputedStyle(panel).display === 'none' ? 'block' : getComputedStyle(panel).display;
      const set = open => { b.setAttribute('aria-expanded', String(open)); visible(panel, open); if (open && !popup) { panel.style.setProperty('height','auto','important'); panel.style.setProperty('max-height','none','important'); panel.style.setProperty('overflow','visible','important'); } };
      set(wasOpen);
      b.addEventListener('click', e => { e.preventDefault(); const open = b.getAttribute('aria-expanded') !== 'true'; if (popup) closers.forEach(fn => fn()); set(open); });
      if (popup) {
        const close = () => set(false); closers.push(close);
        document.addEventListener('click', e => { if (!b.contains(e.target) && !panel.contains(e.target)) close(); });
        panel.addEventListener('click', e => { if (e.target.closest('a[href]')) close(); });
      }
    }

    // A contents toggle may omit aria-controls: use a captured, named contents nav.
    for (const b of document.querySelectorAll('button[aria-expanded]:not([aria-controls])')) {
      if (label(b) !== 'in this article') continue;
      const original = [...document.querySelectorAll('nav')].find(n => (n.getAttribute('aria-label') || '').toLowerCase() === 'in this article');
      if (!original) continue;
      const panel = original.cloneNode(true);
      panel.removeAttribute('id'); panel.querySelectorAll('[id]').forEach(e => e.removeAttribute('id'));
      panel.style.cssText = 'position:absolute;z-index:1000;background:Canvas;color:CanvasText;border:1px solid;padding:16px;max-height:65vh;overflow:auto;min-width:220px';
      b.parentElement.append(panel); visible(panel,false);
      const close = () => { visible(panel,false); b.setAttribute('aria-expanded','false'); }; closers.push(close);
      b.addEventListener('click', () => { const open=b.getAttribute('aria-expanded')!=='true'; b.setAttribute('aria-expanded',String(open)); visible(panel,open); });
      panel.addEventListener('click', e => { if(e.target.closest('a')) close(); });
      document.addEventListener('click', e => { if(!b.contains(e.target) && !panel.contains(e.target)) close(); });
    }
    const markdown = () => {
      const article = document.querySelector('article') || document.querySelector('[data-container="article"]') || document.querySelector('main') || document.body;
      const text = node => {
        if(node.nodeType === Node.TEXT_NODE) return node.textContent;
        if(node.nodeType !== Node.ELEMENT_NODE) return '';
        if(node.matches('button,nav,script,style,template,form,aside')) return '';
        const tag=node.tagName.toLowerCase(), children=()=>[...node.childNodes].map(text).join('');
        if(/^h[1-6]$/.test(tag)) return '\n\n'+'#'.repeat(Number(tag[1]))+' '+children().trim()+'\n\n';
        if(tag==='pre') return '\n\n```\n'+node.textContent.trim()+'\n```\n\n';
        if(tag==='code') return '`'+node.textContent+'`';
        if(tag==='a') { const url=new URL(node.getAttribute('href') || '#',location.href); return '['+children().trim()+']('+url.href+')'; }
        if(tag==='li') return '\n- '+children().trim();
        if(tag==='strong'||tag==='b') return '**'+children()+'**';
        if(tag==='em'||tag==='i') return '*'+children()+'*';
        if(tag==='br') return '\n';
        const value=children(); return /^(p|div|section|ul|ol|blockquote)$/.test(tag) ? '\n'+value+'\n' : value;
      };
      let result=text(article).replace(/\n{3,}/g,'\n\n').trim();
      const h1=document.querySelector('h1'); if(h1 && !result.includes('# '+h1.textContent.trim())) result='# '+h1.textContent.trim()+'\n\n'+result;
      return result;
    };
    const showMarkdown = () => {
      const dialog=document.createElement('dialog'); dialog.style.cssText='width:min(90vw,900px);max-height:85vh;background:Canvas;color:CanvasText';
      const close=document.createElement('button');close.textContent='Close';close.type='button';close.onclick=()=>{dialog.close();dialog.remove();};
      const pre=document.createElement('pre');pre.style.cssText='white-space:pre-wrap;overflow:auto';pre.textContent=markdown();dialog.append(close,pre);document.body.append(dialog);dialog.showModal();dialog.addEventListener('close',()=>dialog.remove(),{once:true});
    };
    const copyMarkdown = async () => {
      const value=markdown();
      if(navigator.clipboard && window.isSecureContext) { try { await navigator.clipboard.writeText(value); return true; } catch (_) {} }
      const area=document.createElement('textarea');area.value=value;area.style.cssText='position:fixed;left:-10000px';document.body.append(area);area.select();
      let copied=false;try { copied=document.execCommand('copy'); } catch (_) {} area.remove();if(!copied) showMarkdown();return copied;
    };
    for(const b of document.querySelectorAll('button')) {
      if(label(b)==='copy markdown') b.addEventListener('click',async e=>{e.preventDefault();const copied=await copyMarkdown();let status=b.parentElement.querySelector('[data-mirror-copy-status]');if(!status){status=document.createElement('span');status.dataset.mirrorCopyStatus='';status.setAttribute('role','status');b.parentElement.append(status);}status.textContent=copied?' Copied':' Select the Markdown to copy';});
      if(!/more markdown options/i.test(label(b))) continue;
      // Replace application-only actions with honest local copy/view actions.
      const panel=document.createElement('div');panel.setAttribute('role','menu');panel.style.cssText='position:absolute;z-index:1001;padding:12px;background:Canvas;color:CanvasText;border:1px solid;border-radius:8px';
      for(const [title,action] of [['Copy markdown',copyMarkdown],['View as Markdown',showMarkdown]]) { const item=document.createElement('button');item.type='button';item.textContent=title;item.setAttribute('role','menuitem');item.style.cssText='display:block;padding:8px;background:transparent;color:inherit;border:0;cursor:pointer';item.onclick=()=>{action();close();};panel.append(item); }
      b.parentElement.append(panel);visible(panel,false);
      const close=()=>{visible(panel,false);b.setAttribute('aria-expanded','false');};closers.push(close);
      // Capture prevents the earlier generic popup handler opening an extra panel.
      b.addEventListener('click',e=>{e.preventDefault();e.stopImmediatePropagation();const open=b.getAttribute('aria-expanded')!=='true';closers.forEach(fn=>fn());b.setAttribute('aria-expanded',String(open));visible(panel,open);},true);
      document.addEventListener('click',e=>{if(!b.contains(e.target)&&!panel.contains(e.target))close();});
    }

    document.addEventListener('keydown', e => { if (e.key === 'Escape') closers.forEach(fn => fn()); });
    for (const b of document.querySelectorAll('button, [role="button"]')) {
      if (/^(back to top|scroll to top|top)$/.test(label(b))) b.addEventListener('click', e => { e.preventDefault(); window.scrollTo({top: 0, behavior: 'smooth'}); });
    }
    // Pair previous/next controls only with a nearby repeated group of linked cards.
    for (const next of document.querySelectorAll('button[aria-label]')) {
      if (!/^next (articles|slides|items)$/.test(label(next))) continue;
      let root = next.parentElement, group, previous;
      for (let depth = 0; root && depth < 5; depth++, root = root.parentElement) {
        previous = [...root.querySelectorAll('button[aria-label]')].find(b => /^previous (articles|slides|items)$/.test(label(b)));
        group = [...root.children].find(e => e.children.length > 1 && [...e.children].every(c => c.querySelector('a[href]')));
        if (previous && group) break;
      }
      if (!group || !previous) continue;
      const cards = [...group.children]; let index = 0;
      const paint = () => { cards.forEach((c,i) => visible(c, i === index)); previous.disabled = index === 0; next.disabled = index === cards.length - 1; };
      previous.addEventListener('click', e => { e.preventDefault(); index = Math.max(0,index-1); paint(); });
      next.addEventListener('click', e => { e.preventDefault(); index = Math.min(cards.length-1,index+1); paint(); }); paint();
    }
    for (const input of document.querySelectorAll('input')) {
      if (!/^search (articles|items)$/.test(label(input) || (input.placeholder || '').toLowerCase())) continue;
      let root = input.parentElement, group;
      for (let depth = 0; root && depth < 8; depth++, root = root.parentElement) {
        group = [...root.children].find(e => e.children.length > 1 && [...e.children].every(c => c.querySelector('h3 a[href], h4 a[href], article a[href]')));
        if (group) break;
      }
      if (!group) continue;
      const cards = [...group.children];
      input.addEventListener('input', () => { const q = input.value.trim().toLowerCase(); cards.forEach(c => visible(c, c.textContent.toLowerCase().includes(q))); });
      input.addEventListener('keydown', e => { if (e.key === 'Enter') e.preventDefault(); });
      const form = input.closest('form'); if (form) form.addEventListener('submit', e => { e.preventDefault(); e.stopImmediatePropagation(); }, true);
    }
    for (const form of document.querySelectorAll('form')) {
      const radios = [...form.querySelectorAll('input[type="radio"]')];
      if (radios.length !== 2 || !/helpful/i.test(form.textContent) || !radios.some(r => label(r) === 'yes') || !radios.some(r => label(r) === 'no')) continue;
      const status = document.createElement('p'); status.setAttribute('role', 'status'); form.append(status);
      radios.forEach(r => r.addEventListener('change', () => {
        radios.forEach(x => { const l = [...form.querySelectorAll('label')].find(l => l.htmlFor === x.id); if (l) { l.style.outline = x.checked ? '2px solid currentColor' : ''; } });
        status.textContent = 'Thank you for your feedback.';
      }));
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true}); else init();
})();
"""

CAPTURE_INTERACTION_PANELS_JS = r"""async () => {
  const snapshots = [];
  const buttons = [...document.querySelectorAll('button[aria-expanded="false"]')]
    .filter(b => b.id && (b.hasAttribute('aria-haspopup') || /\bmenu\b/i.test(b.getAttribute('aria-label') || '')) && b.getBoundingClientRect().width > 0).slice(0, 12);
  for (const b of buttons) {
    const before = new Set(document.querySelectorAll('[role="menu"], [role="dialog"], [role="listbox"]'));
    b.click(); await new Promise(r => setTimeout(r, 180));
    if (b.getAttribute('aria-expanded') !== 'true') continue;
    let panel = document.getElementById(b.getAttribute('aria-controls'));
    if (!panel) panel = [...document.querySelectorAll('[role="menu"], [role="dialog"], [role="listbox"]')].find(p => !before.has(p));
    if (panel && panel !== b && !panel.contains(b)) snapshots.push([b.id, panel.outerHTML]);
    b.click(); await new Promise(r => setTimeout(r, 100));
  }
  for (const [id, html] of snapshots) {
    const t = document.createElement('template'); t.dataset.mirrorFor = id; t.innerHTML = html; document.body.append(t);
  }
}
"""

def atomic_json(path, value):
    """Publish complete metadata so concurrent PHP readers never see partial JSON."""
    temporary = str(path) + '.' + uuid.uuid4().hex + '.tmp'
    with open(temporary, 'w', encoding='utf-8') as handle:
        json.dump(value, handle, ensure_ascii=False)
    os.replace(temporary, path)

@contextlib.contextmanager
def mirror_file_lock(path, blocking=True):
    """Cross-platform process lock for publication and worker leadership."""
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, 'a+b') as handle:
        handle.seek(0, os.SEEK_END)
        if not handle.tell():
            handle.write(b'0'); handle.flush()
        handle.seek(0)
        if os.name == 'nt':
            import msvcrt
            # LK_LOCK retries only ten times; explicitly wait when blocking.
            while True:
                try:
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if not blocking:
                        raise
                    time.sleep(0.1)
        else:
            import fcntl
            fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == 'nt':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle, fcntl.LOCK_UN)

def normalize_document_path(raw):
    """Only a document path is copied. Visitor query strings are never upstream input."""
    parsed = urllib.parse.urlsplit(raw)
    if parsed.scheme or parsed.netloc or not parsed.path.startswith('/') or raw.startswith('//'):
        raise ValueError('Expected a local document path')
    path = urllib.parse.unquote(parsed.path, errors='strict')
    if len(path.encode('utf-8')) > 2048 or '//' in path:
        raise ValueError('Invalid document path')
    for part in path.split('/'):
        if part in ('.', '..') or part.startswith('.'):
            raise ValueError('Invalid document path')
        if any(not (char.isalnum() or unicodedata.category(char).startswith('M') or char in '-_.~:@+(),! ') for char in part):
            raise ValueError('Invalid document path')
    return path.rstrip('/') or '/'

class MirrorCaptureError(RuntimeError):
    def __init__(self, message, status=502):
        super().__init__(message)
        self.status = status

class DecoyDuplicator:
    """Capture a quick landing page, then mirror actual requested pages on demand.

    A local mirror_worker.py process captures uncached public HTML routes and
    stores their rendered documents privately. PHP waits for that capture and
    reads the cached HTML; no unrelated template or article content is substituted.
    Original application scripts are stripped from public snapshots, so navigation
    and local forms work while original backend interactions are not reproduced.
    """
    API_PATTERNS = ['fetch\\(\\s*[\\"\\\']([^\\"\\\']+)[\\"\\\']', 'axios\\.(?:get|post|put|delete|patch)\\(\\s*[\\"\\\']([^\\"\\\']+)[\\"\\\']', '\\$\\.(?:get|post|ajax)\\(\\s*[\\"\\\']([^\\"\\\']+)[\\"\\\']', 'url\\s*:\\s*[\\"\\\']([^\\"\\\']+)[\\"\\\']', '[`\\"\\\'](/(?:api|rest|graphql)/[^`\\"\\\']+)[`\\"\\\']', '[`\\"\\\'](/socket\\.io[^`\\"\\\']*)[`\\"\\\']']

    def __init__(self, target_url, output_dir='decoy-website/public', *, max_pages=1, max_seconds=60, static_decoy=False, color_scheme=None, viewport=None, seed_routes=None, backend_profile=None):
        if max_pages < 1 or max_seconds <= 0:
            raise ValueError('max_pages and max_seconds must be positive')
        self.color_scheme = color_scheme or os.getenv('DECOY_COLOR_SCHEME', 'dark')
        if self.color_scheme not in ('light', 'dark'):
            raise ValueError('color_scheme must be light or dark')
        self.viewport = dict(viewport or {'width': 1440, 'height': 900})
        if any(not isinstance(self.viewport.get(k), int) or self.viewport[k] <= 0 for k in ('width', 'height')):
            raise ValueError('viewport must have positive integer width and height')
        self.max_pages = int(max_pages)
        self.max_seconds = float(max_seconds)
        self.static_decoy = bool(static_decoy)
        if backend_profile not in (None, 'generic', 'banking', 'healthcare', 'industrial', 'ecommerce', 'education', 'corporate'):
            raise ValueError('Unsupported backend profile')
        self.backend_profile = backend_profile
        self.attempted = set()
        self.discovered_routes = set()
        self.capture_failures = {}
        self.stop_reason = 'queue_exhausted'
        self._deadline = None
        self._assets_in_progress = set()
        self._on_demand_read_only = False
        self.target_url, self.output_dir = (target_url.rstrip('/'), output_dir); self.assets_dir = os.path.join(output_dir, 'assets'); self.session = requests.Session()
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'})
        self.visited, self.routes, self.forms, self.api_routes, self.api_responses = (set(), [], [], set(), []); self.downloaded_assets, self.runtime_asset_map = ({}, {}); self._archived_runtime_urls = set(); self._api_capture_keys = set()
        self._pw = self._browser = self._browser_context = None; self._mirror_started_at = None; self._runtime_bytes = 0; self._runtime_files = 0; self._runtime_skip_counts = {'route_like': 0, 'body_unavailable': 0, 'other': 0}
        self.asset_stats = {'css': 0, 'javascript': 0, 'images': 0, 'fonts': 0, 'misc': 0}; self.adaptive_analyzer = AdaptiveSemanticAnalyzer(); self.page_semantics = {}; self.template_candidates = {}; parsed_target = urllib.parse.urlparse(self.target_url)
        self.target_scheme = parsed_target.scheme or 'https'; self.target_host = (parsed_target.hostname or '').lower(); self.target_netloc = (parsed_target.netloc or '').lower()
        self.seed_urls = []
        for route in seed_routes or []:
            seed = self.canonicalize_url(urllib.parse.urljoin(self.target_url + '/', route))
            parsed_seed = urllib.parse.urlparse(seed)
            if parsed_seed.netloc.lower() != self.target_netloc or parsed_seed.scheme != self.target_scheme or parsed_seed.username or parsed_seed.password:
                raise ValueError('seed_routes must stay on the target origin')
            self.get_local_page_path(seed)
            if seed not in self.seed_urls:
                self.seed_urls.append(seed)


    def _route_section(self, url):
        """Group by topic beneath an optional language prefix, not by language."""
        parts = [part for part in urllib.parse.urlparse(url).path.split('/') if part]
        if not parts:
            return '/'
        languages = {'en', 'fr', 'de', 'es', 'pt', 'it', 'ja', 'ko', 'zh', 'ru',
                     'ar', 'nl', 'pl', 'tr', 'sv', 'da', 'no', 'fi', 'cs', 'uk',
                     'id', 'ms', 'th', 'vi', 'hi', 'he', 'ro', 'hu', 'el', 'bg'}
        first = parts[0].lower().replace('_', '-')
        is_language = first.split('-')[0] in languages and re.fullmatch(r'[a-z]{2}(?:-[a-z0-9]{2,8})*', first)
        depth = 2 if is_language else 1
        return '/' + '/'.join(parts[:depth])

    def _route_pattern(self, url):
        section = self._route_section(url)
        # Site and language landing pages must not match every topic beneath them.
        single_segment = len(section.strip('/').split('/')) == 1
        language_landing = single_segment and self._route_section(section + '/__dg_probe__') != section
        if section == '/' or language_landing:
            return section
        return section + '/*'

    def _budget_expired(self):
        return self._deadline is not None and time.perf_counter() >= self._deadline

    def _request_timeout(self, maximum=8):
        if self._deadline is None:
            return maximum
        return max(0.1, min(maximum, self._deadline - time.perf_counter()))

    def fetch(self, url):
        try:
            res = self.session.get(url, timeout=self._request_timeout(10), allow_redirects=True); res.raise_for_status()
            return res
        except Exception as e:
            print(f'[!] Failed to fetch {url}: {e}')
            return None

    def is_same_domain(self, url):
        return self.is_target_family(url)

    def is_target_family(self, url):
        try:
            host = (urllib.parse.urlparse(url).hostname or '').lower().rstrip('.'); target = (self.target_host or '').lower().rstrip('.')
            if not host or not target:
                return False
            h = host[4:] if host.startswith('www.') else host; t = target[4:] if target.startswith('www.') else target
            return h == t or h.endswith('.' + t) or t.endswith('.' + h)
        except Exception:
            return False

    def _runtime_response_is_route_like(self, response):
        """; Return True for framework/data responses whose URL path represents a; page route rather than a real static file.; """
        try:
            req = response.request; parsed = urllib.parse.urlparse(response.url); path = urllib.parse.unquote(parsed.path or ''); content_type = (response.headers.get('content-type', '') or '').lower()
            if req.resource_type == 'document':
                return True
            query_keys = {k.lower() for k, _ in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)}
            if '_rsc' in query_keys:
                return True
            if 'text/html' in content_type or 'application/xhtml+xml' in content_type:
                return True
            basename = os.path.basename(path.rstrip('/')); ext = os.path.splitext(basename)[1].lower(); static_prefixes = ('/_next/', '/assets/', '/static/')
            if path and (not ext) and (not path.startswith(static_prefixes)):
                return True
            return False
        except Exception:
            return False

    def _safe_runtime_path(self, url):
        parsed = urllib.parse.urlparse(url); raw = urllib.parse.unquote(parsed.path or '')
        if not raw or raw.endswith('/'):
            return None
        if os.path.splitext(raw)[1].lower() in ('.php', '.phtml', '.phar', '.cgi', '.pl', '.py', '.sh') or os.path.basename(raw).startswith('.'):
            return None
        normalized = os.path.normpath(raw.lstrip('/\\'))
        if normalized in ('', '.') or normalized.startswith('..') or os.path.isabs(normalized):
            return None
        dest = os.path.abspath(os.path.join(self.output_dir, normalized)); root = os.path.abspath(self.output_dir)
        if os.path.commonpath([root, dest]) != root:
            return None
        if os.path.isdir(dest):
            return None
        parent = os.path.dirname(dest); probe = parent
        while probe and probe != root:
            if os.path.isfile(probe):
                return None
            new_probe = os.path.dirname(probe)
            if new_probe == probe:
                break
            probe = new_probe
        return dest

    def archive_runtime_response(self, response):
        try:
            req = response.request
            if req.method.upper() != 'GET' or not self.is_target_family(response.url):
                return None
            if self._runtime_response_is_route_like(response):
                self._runtime_skip_counts['route_like'] += 1
                return None
            clean = urllib.parse.urldefrag(response.url)[0]
            if clean in self._archived_runtime_urls:
                return self.downloaded_assets.get(clean)
            parsed = urllib.parse.urlparse(response.url); dest = self._safe_runtime_path(response.url)
            if not dest:
                self._runtime_skip_counts['route_like'] += 1
                return None
            try:
                body = response.body()
            except Exception:
                self._runtime_skip_counts['body_unavailable'] += 1
                return None
            if body is None:
                self._runtime_skip_counts['body_unavailable'] += 1
                return None
            parent = os.path.dirname(dest)
            if os.path.isfile(parent):
                self._runtime_skip_counts['route_like'] += 1
                return None
            os.makedirs(parent, exist_ok=True)
            if os.path.isdir(dest):
                self._runtime_skip_counts['route_like'] += 1
                return None
            if 'text/css' in response.headers.get('content-type', '').lower():
                body = self.rewrite_css_assets(body.decode('utf-8', errors='replace'), response.url).encode('utf-8')
            with open(dest, 'wb') as f:
                f.write(body)
            self._archived_runtime_urls.add(clean); local_url = parsed.path or '/'; self.downloaded_assets[clean] = local_url; self.runtime_asset_map[clean] = local_url; self.runtime_asset_map[parsed.path] = local_url; self._runtime_bytes += len(body)
            self._runtime_files += 1
            if not self.static_decoy and os.path.splitext(parsed.path)[1].lower() in ('.js', '.mjs'):
                self.discover_and_fetch_chunks(body.decode('utf-8', errors='replace'), response.url)
            return local_url
        except Exception:
            self._runtime_skip_counts['other'] += 1
            return None

    def is_framework_document(self, html):
        text = html or ''; markers = ('id="__next"', "id='__next'", '__NEXT_DATA__', '/_next/static/', 'webpackChunk', 'data-reactroot', 'data-react-helmet')
        return any((m in text for m in markers))

    def native_document(self, html, url):
        """Keep original bootstrap/SSR HTML; never rehydrate a rendered snapshot."""
        soup = BeautifulSoup(html, 'html.parser')
        for tag in soup.find_all(['iframe', 'object', 'embed']): tag.decompose()
        for meta in soup.find_all('meta'):
            if str(meta.get('http-equiv', '')).lower() in ('refresh', 'content-security-policy'): meta.decompose()
        for base in soup.find_all('base'): base['href'] = '/'
        self.localize_all_assets(soup, url)
        for tag in soup.find_all(['script', 'link']):
            tag.attrs.pop('integrity', None)
            tag.attrs.pop('crossorigin', None)
        for form in soup.find_all('form'):
            action = urllib.parse.urljoin(url, form.get('action') or url)
            parsed = urllib.parse.urlparse(action)
            if self._same_origin(action): form['action'] = (parsed.path or '/') + ('?' + parsed.query if parsed.query else '')
            else: form['action'] = '/trap_handler.php'
        self.rewrite_links(soup, url)
        guard = soup.new_tag('script', src='/assets/decoyguard-navigation.js')
        (soup.head or soup).insert(0, guard)
        return str(soup)

    def save_framework_page(self, html, url):
        document = self.native_document(html, url)
        full_path = os.path.join(self.output_dir, self.get_local_page_path(url))
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        policy = "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; form-action 'self'; frame-src 'none'; object-src 'none'; base-uri 'self'; worker-src 'self' blob:"
        # JSON encoding provides a valid PHP double-quoted string after escaping $.
        wrapper = '<?php header(' + json.dumps('Content-Security-Policy: ' + policy).replace('$', '\\$') + '); ?>\n'
        from pathlib import Path
        Path(full_path).write_text(wrapper + "<?php echo base64_decode('" + base64.b64encode(document.encode()).decode() + "'); ?>", encoding='utf-8')
        print('[OK] Original frontend saved: ' + self.get_local_page_path(url))

    def canonicalize_url(self, url):
        parsed = urllib.parse.urlparse(url); ignored = {'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid', 'msclkid', 'ref'}
        filtered = [(k, v) for k, v in urllib.parse.parse_qsl(parsed.query, keep_blank_values=True) if k.lower() not in ignored]; path = parsed.path or '/'
        if path != '/':
            path = path.rstrip('/')
        return urllib.parse.urlunparse((parsed.scheme.lower(), parsed.netloc.lower(), path, '', urllib.parse.urlencode(sorted(filtered), doseq=True), ''))

    def get_local_page_path(self, url):
        path = urllib.parse.unquote(urllib.parse.urlparse(url).path).strip('/')
        if '\\' in path or any(part in ('.', '..') for part in path.split('/')):
            raise ValueError('Unsafe page path')
        if not path:
            return 'index.php'
        if path.endswith('/'):
            path += 'index'
        if path.endswith('.php'):
            return os.path.normpath(path)
        if path.endswith('.html'):
            return os.path.normpath(path[:-5] + '.php')
        return os.path.normpath(path + '.php')

    def rewrite_css_assets(self, css_text, css_base_url):

        def replace(match):
            ref = match.group(1).strip()
            if ref.startswith(('data:', '#', 'about:')):
                return match.group(0)
            full_url = urllib.parse.urljoin(css_base_url, ref); ext = os.path.splitext(urllib.parse.urlparse(full_url).path)[1].lower()
            return f'''url("{self.download_and_localize_asset(full_url, 'css' if ext == '.css' else 'fonts' if ext in ['.woff', '.woff2', '.ttf', '.eot', '.otf'] else 'images')}")'''
        css_text = re.sub(r'''(@import\s+)["']([^"']+)["']''',
            lambda m: m[1] + '"' + self.download_and_localize_asset(urllib.parse.urljoin(css_base_url, m[2]), 'css') + '"',
            css_text, flags=re.IGNORECASE)
        return re.sub('url\\(\\s*["\\\']?([^)"\\\']+)["\\\']?\\s*\\)', replace, css_text)

    def mirror_favicon(self):
        try:
            res = self.session.get(urllib.parse.urljoin(self.target_url + '/', 'favicon.ico'), timeout=self._request_timeout(8))
            if res.status_code == 200:
                with open(os.path.join(self.output_dir, 'favicon.ico'), 'wb') as f:
                    f.write(res.content)
                print('[✓] Favicon mirrored: /favicon.ico')
        except Exception as e:
            print(f'[-] Favicon download failed: {e}')

    def sanitize_javascript_content(self, js_text):
        js_text = re.sub(re.escape(self.target_url), '', js_text)
        for orig_url, local_path in sorted(getattr(self, 'runtime_asset_map', {}).items(), key=lambda item: len(item[0]), reverse=True):
            if not orig_url:
                continue
            js_text = js_text.replace(orig_url, local_path); orig_path = urllib.parse.urlparse(orig_url).path
            if orig_path:
                js_text = js_text.replace(orig_path, local_path); fn = os.path.basename(orig_path)
                if fn:
                    js_text = re.sub(f'(?<![A-Za-z0-9_.-])\\./{re.escape(fn)}', local_path, js_text); js_text = re.sub(f'(?<![A-Za-z0-9_./-]){re.escape(fn)}', local_path, js_text)
        return js_text

    def rewrite_captured_javascript(self):
        js_dir = os.path.join(self.assets_dir, 'js')
        if not self.runtime_asset_map or not os.path.isdir(js_dir):
            return
        valid_map = {o: l for o, l in self.runtime_asset_map.items() if l}
        if not valid_map:
            return
        rewritten_count = 0
        for fn in os.listdir(js_dir):
            if not fn.lower().endswith('.js'):
                continue
            fp = os.path.join(js_dir, fn)
            try:
                with open(fp, 'r', encoding='utf-8', errors='ignore') as f:
                    js_text = f.read()
                orig_text = js_text
                for orig_url, local_path in sorted(valid_map.items(), key=lambda item: len(item[0]), reverse=True):
                    if not orig_url or not local_path:
                        continue
                    orig_path = urllib.parse.urlparse(orig_url).path; js_text = js_text.replace(orig_url, local_path)
                    if orig_path:
                        js_text = js_text.replace(orig_path, local_path); bn = os.path.basename(orig_path)
                        if bn:
                            js_text = re.sub(f'(?<![A-Za-z0-9_.-])\\./{re.escape(bn)}', local_path, js_text); js_text = re.sub(f'(?<![A-Za-z0-9_./-]){re.escape(bn)}', local_path, js_text)
                if js_text != orig_text:
                    with open(fp, 'w', encoding='utf-8', errors='ignore') as f:
                        f.write(js_text)
                    rewritten_count += 1
            except Exception as e:
                print(f'[-] Failed to rewrite JS {fn}: {e}')
        print(f'[✓] Rewrote captured JavaScript references in {rewritten_count} files.')

    def _ensure_browser(self):
        if self._browser_context is not None:
            return
        self._pw = sync_playwright().start(); self._browser = self._pw.chromium.launch(headless=True, **({'executable_path': os.environ['PLAYWRIGHT_CHROMIUM_EXECUTABLE']} if os.getenv('PLAYWRIGHT_CHROMIUM_EXECUTABLE') else {})); self._browser_context = self._browser.new_context(service_workers='block', ignore_https_errors=True, color_scheme=self.color_scheme, viewport=self.viewport)
        if self._on_demand_read_only:
            self._browser_context.route('**/*', self._read_only_browser_route)
        print('[✓] Shared Chromium mirror session started.')

    def _close_browser(self):
        try:
            if self._browser_context:
                self._browser_context.close()
        except Exception:
            pass
        try:
            if self._browser:
                self._browser.close()
        except Exception:
            pass
        try:
            if self._pw:
                self._pw.stop()
        except Exception:
            pass
        self._browser_context = self._browser = self._pw = None

    def _capture_appearance(self, page):
        """Wait briefly for fonts/CSS and serialize styles created through CSSOM.

        Keep rendered theme classes/data attributes. Pin computed root variables
        and root/body typography so stripping application scripts does not lose
        their initialized appearance. Cross-origin sheets remain normal links
        and are downloaded/localized by the Python asset path.
        """
        wait_ms = int(self._request_timeout(APPEARANCE_WAIT_SECONDS) * 1000)
        try:
            page.evaluate("""async (timeout) => {
                await Promise.race([
                    Promise.all([
                        document.fonts ? document.fonts.ready : Promise.resolve(),
                        new Promise(resolve => {
                            const pending = [...document.querySelectorAll('link[rel~="stylesheet"]')]
                                .filter(link => !link.sheet && !link.disabled);
                            if (!pending.length) return resolve();
                            let remaining = pending.length;
                            const done = () => { if (--remaining === 0) resolve(); };
                            pending.forEach(link => {
                                link.addEventListener('load', done, {once: true});
                                link.addEventListener('error', done, {once: true});
                            });
                        })
                    ]),
                    new Promise(resolve => setTimeout(resolve, timeout))
                ]);
            }""", wait_ms)
            page.evaluate(r"""() => {
                for (const style of [...document.querySelectorAll('style')]) {
                    try {
                        const rules = [...style.sheet.cssRules].map(rule => rule.cssText).join('\n');
                        if (rules) style.textContent = rules;
                    } catch (_) {}
                }
                for (const sheet of document.adoptedStyleSheets || []) {
                    try {
                        const style = document.createElement('style');
                        style.textContent = [...sheet.cssRules].map(rule => rule.cssText).join('\n');
                        document.head.appendChild(style);
                    } catch (_) {}
                }
                const root = document.documentElement;
                const computed = getComputedStyle(root);
                const variables = [...computed].filter(name => name.startsWith('--'))
                    .map(name => [name, computed.getPropertyValue(name)]);
                for (const [name, value] of variables) root.style.setProperty(name, value);
                for (const node of [root, document.body].filter(Boolean)) {
                    const css = getComputedStyle(node);
                    const values = ['font-family', 'font-size', 'font-weight', 'line-height',
                                    'color', 'background-color', 'color-scheme']
                        .map(name => [name, css.getPropertyValue(name)]);
                    for (const [name, value] of values) node.style.setProperty(name, value);
                }
            }""")
        except Exception as exc:
            print(f'[-] Appearance snapshot incomplete: {exc}')

    def _capture_spa_routes(self, page, base_url, capture_limit=24):
        """
        Safely explore same-origin SPA routes exposed by the application.

        Newly visited routes may expose additional client-side routes, so
        discovery continues breadth-first until the bounded capture limit
        is reached. No submit/delete/purchase controls are exercised.
        """

        parsed_base = urllib.parse.urlparse(base_url)
        origin = f'{parsed_base.scheme}://{parsed_base.netloc}'

        def discover_routes():
            try:
                return page.evaluate(r"""
                    () => {
                        const found = new Set();

                        const add = value => {
                            if (!value) return;

                            value = String(value).trim();

                            if (
                                value.startsWith('#/') ||
                                value.startsWith('/#/') ||
                                value.startsWith('./#/')
                            ) {
                                found.add(value);
                            }
                        };

                        document.querySelectorAll('a[href]').forEach(el => {
                            add(el.getAttribute('href'));
                        });

                        document.querySelectorAll(
                            '[routerlink], [routerLink], [data-route], [data-href]'
                        ).forEach(el => {
                            add(el.getAttribute('routerlink'));
                            add(el.getAttribute('routerLink'));
                            add(el.getAttribute('data-route'));
                            add(el.getAttribute('data-href'));
                        });

                        const html = document.documentElement.outerHTML;

                        for (const match of html.matchAll(
                            /(?:href|routerlink|routerLink|data-route|data-href)=["']([^"']+)["']/g
                        )) {
                            add(match[1]);
                        }

                        return [...found];
                    }
                """)
            except Exception as exc:
                print(f'[-] SPA route discovery failed: {exc}')
                return []

        queue = list(discover_routes())
        queued = set(queue)
        seen = set()

        while queue and len(seen) < capture_limit:
            if self._budget_expired():
                break

            raw = queue.pop(0)

            try:
                if raw.startswith('./#/'):
                    raw = raw[1:]

                if raw.startswith('#/'):
                    target = origin + '/' + raw
                elif raw.startswith('/#/'):
                    target = origin + raw
                else:
                    continue

                fragment = urllib.parse.urlparse(target).fragment

                if not fragment.startswith('/'):
                    continue

                route_key = '#' + fragment

                if route_key in seen:
                    continue

                seen.add(route_key)
                self.discovered_routes.add(route_key)

                page.goto(
                    target,
                    wait_until='domcontentloaded',
                    timeout=int(self._request_timeout(8) * 1000)
                )

                try:
                    page.wait_for_load_state(
                        'networkidle',
                        timeout=int(self._request_timeout(1.5) * 1000)
                    )
                except Exception:
                    pass

                try:
                    page.wait_for_timeout(350)
                except Exception:
                    pass

                try:
                    page.evaluate(
                        'window.scrollTo(0, Math.min(document.body.scrollHeight, 1800))'
                    )
                    page.wait_for_timeout(150)
                    page.evaluate('window.scrollTo(0, 0)')
                except Exception:
                    pass

                print(f'[✓] SPA route exercised: {route_key}')

            # Newly rendered SPA pages may expose routes that were not
            # present on the landing page.
                for discovered in discover_routes():
                    if discovered not in queued:
                        queued.add(discovered)
                        queue.append(discovered)

            except Exception as exc:
                print(f'[-] SPA route capture skipped: {raw}: {exc}')

    def render_page(self, url):
        page = None
        captured_api_responses = []
        started = time.perf_counter()

        try:
            self._ensure_browser()
            page = self._browser_context.new_page()

            def capture_response(response):
                try:
                    req = response.request
                    res_url = response.url
                    parsed = urllib.parse.urlparse(res_url)
                    content_type = response.headers.get(
                        'content-type', ''
                    ).lower()

                    # Archive normal runtime files such as JS/CSS/images/fonts.
                    self.archive_runtime_response(response)

                    is_data = req.resource_type in ('xhr', 'fetch')
                    is_json = (
                        'json' in content_type
                        and parsed.path.lower().endswith('.json')
                    )

                    if not (is_data or is_json):
                        return

                    if not self.is_target_family(res_url):
                        return

                    # Initial learning catalog is read-only.
                    # Writes are handled later by the contained synthetic backend.
                    if req.method.upper() not in ('GET', 'HEAD'):
                        return

                    canonical = self.canonicalize_url(res_url)

                    key = (
                        canonical,
                        req.method.upper(),
                        req.post_data or ''
                    )

                    if key in self._api_capture_keys:
                        return

                    self._api_capture_keys.add(key)

                    if not any(
                        t in content_type
                        for t in (
                            'json',
                            'text/',
                            'xml',
                            'javascript'
                        )
                    ):
                        return

                    try:
                        body = response.text()
                    except Exception:
                        return

                    # API responses can contain image/resource paths that
                    # never appeared in the initial document. Discover them
                    # while the upstream capture session still exists.
                    try:
                        self.discover_assets_from_response(
                            body,
                            res_url
                        )
                    except Exception as exc:
                        print(
                            f'[-] API asset discovery failed '
                            f'for {res_url}: {exc}'
                        )

                    captured_api_responses.append({
                        'url': canonical,
                        'path': parsed.path,
                        'method': req.method.upper(),

                        'request_headers': {
                            k: v
                            for k, v in req.headers.items()
                            if k.lower() in {
                                'accept',
                                'content-type'
                            }
                        },

                        'post_data': req.post_data,
                        'status': response.status,

                        'response_headers': {
                            k: v
                            for k, v in response.headers.items()
                            if k.lower() == 'content-type'
                        },

                        'content_type': content_type,
                        'body': body[:100000],
                        'body_truncated': len(body) > 100000
                    })

                except Exception as exc:
                    print(
                        f'[-] Runtime response capture failed: {exc}'
                    )

            # IMPORTANT:
            # The current broken method is missing everything from here down.
            page.on('response', capture_response)

            page.goto(
                url,
                wait_until='domcontentloaded',
                timeout=int(
                    self._request_timeout(15) * 1000
                )
            )

            try:
                page.wait_for_load_state(
                    'networkidle',
                    timeout=int(
                        self._request_timeout(
                            ON_DEMAND_NETWORK_IDLE_SECONDS
                            if self._on_demand_read_only
                            else STARTUP_NETWORK_IDLE_SECONDS
                        ) * 1000
                    )
                )
            except Exception:
                pass

            # Walk a bounded number of viewports so intersection observers can
            # load lower-page media; keep the existing capture deadline.
            try:
                height = page.evaluate('Math.min(document.documentElement.scrollHeight, 12000)')
                step = max(400, self.viewport['height'])
                for offset in range(step, int(height), step):
                    if self._budget_expired():
                        break
                    page.evaluate('(y) => window.scrollTo(0, y)', offset)
                    page.wait_for_timeout(100)
                page.evaluate('window.scrollTo(0, 0)')
            except Exception:
                pass

            # Record links from the original rendered landing page.
            try:
                rendered_links = list(set(
                    page.locator('a[href]').evaluate_all(
                        '''
                        els => els
                            .map(a => a.href)
                            .filter(Boolean)
                        '''
                    )
                ))
            except Exception:
                rendered_links = []

            # Explore same-origin SPA routes while capture_response is still
            # attached. This is what learns route-specific APIs such as
            # registration dropdown data.
            if not self._on_demand_read_only:
                self._capture_spa_routes(
                    page,
                    url
                )

                # SPA exploration changes the browser's current route.
                # Return to the requested document before taking the final
                # appearance/document snapshot.
                try:
                    page.goto(
                        url,
                        wait_until='domcontentloaded',
                        timeout=int(
                            self._request_timeout(8) * 1000
                        )
                    )

                    try:
                        page.wait_for_load_state(
                            'networkidle',
                            timeout=int(
                                self._request_timeout(1.5)
                                * 1000
                            )
                        )
                    except Exception:
                        pass

                except Exception as exc:
                    print(
                        f'[-] Could not restore capture page '
                        f'{url}: {exc}'
                    )

            # Preserve the final visual state.
            self._capture_appearance(page)
            self._capture_interaction_panels(page)

            # Temporary notifications generated during capture should not
            # become part of the mirrored document.
            try:
                page.evaluate(r"""() => {
                    document.querySelectorAll(
                        'mat-snack-bar-container, ' +
                        '.cdk-live-announcer-element'
                    ).forEach(node => {
                        const wrapper = node.closest(
                            '.cdk-global-overlay-wrapper'
                        );

                        if (
                            wrapper &&
                            !wrapper.querySelector(
                                '[role="dialog"], [role="menu"]'
                            )
                        ) {
                            wrapper.remove();
                        } else {
                            node.remove();
                        }
                    });
                }""")
            except Exception:
                pass

            html = page.content()

            # Publish API routes learned during this page capture.
            for response_data in captured_api_responses:
                try:
                    self.api_routes.add(
                        urllib.parse.urlparse(
                            response_data['url']
                        ).path
                    )
                except Exception:
                    pass

            self.api_responses.extend(
                captured_api_responses
            )

            elapsed = time.perf_counter() - started

            print(
                f'[✓] Rendered in {elapsed:.2f}s | '
                f'links={len(rendered_links)} | '
                f'unique runtime={self._runtime_files} | '
                f'{self._runtime_bytes / 1048576:.1f} MB'
            )

            return (
                html,
                rendered_links
            )

        except Exception as exc:
            print(
                f'[!] Browser rendering failed for {url}: {exc}'
            )
            return (None, [])

        finally:
            if page:
                try:
                    page.close()
                except Exception:
                    pass

    def discover_api_routes(self, js_text):
        for pattern in self.API_PATTERNS:
            try:
                matches = re.findall(pattern, js_text, flags=re.IGNORECASE)
            except re.error:
                continue
            for match in matches:
                if not match:
                    continue
                route = match.strip()
                if route.startswith(('http://', 'https://', '//')):
                    parsed = urllib.parse.urlparse(route)
                    if parsed.netloc != urllib.parse.urlparse(self.target_url).netloc:
                        continue
                    route = parsed.path
                if route.startswith('/'):
                    clean_route = route
                elif route.startswith('api/') or route.startswith('rest/'):
                    clean_route = '/' + route
                else:
                    continue
                self.api_routes.add(clean_route); print(f'[✓] API route discovered: {clean_route}')

    def discover_runtime_assets(self, js_text, current_js_url):
        patterns = ['["\\\']([^"\\\']*?/assets/[^"\\\']+)["\\\']', '["\\\'](assets/[^"\\\']+)["\\\']', '["\\\'](/assets/[^"\\\']+)["\\\']', '["\\\']([^"\\\']+\\.json)["\\\']', '["\\\']([^"\\\']+\\.(?:png|jpg|jpeg|gif|svg|webp|woff|woff2|ttf|eot|otf))["\\\']']
        matches = set()
        for pattern in patterns:
            try:
                for match in re.findall(pattern, js_text, flags=re.IGNORECASE):
                    matches.add(match[0] if isinstance(match, tuple) else match)
            except re.error:
                continue
        for asset in matches:
            asset = asset.strip()
            if asset.startswith(('data:', 'blob:', '#')) or ('://' in asset and (not asset.startswith(('http://', 'https://', '//')))):
                continue
            full_asset_url = urllib.parse.urljoin(current_js_url, asset); parsed = urllib.parse.urlparse(full_asset_url)
            if parsed.scheme not in ('http', 'https') or not parsed.path:
                continue
            extension = os.path.splitext(parsed.path)[1].lower()
            if extension not in {'.json', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp', '.woff', '.woff2', '.ttf', '.eot', '.otf'}:
                continue
            clean_url = urllib.parse.urldefrag(full_asset_url)[0]
            if clean_url in self.downloaded_assets:
                continue
            asset_path = parsed.path.lstrip('/')
            if not asset_path.startswith('assets/'):
                if extension == '.json':
                    possible_url = urllib.parse.urljoin(self.target_url + '/', 'assets/' + os.path.basename(asset_path))
                    try:
                        if self.session.get(possible_url, timeout=self._request_timeout(5)).status_code == 200:
                            clean_url = possible_url; asset_path = urllib.parse.urlparse(possible_url).path.lstrip('/')
                        else:
                            continue
                    except Exception:
                        continue
                else:
                    continue
            local_path = os.path.join(self.output_dir, asset_path); os.makedirs(os.path.dirname(local_path), exist_ok=True)
            try:
                res = self.session.get(clean_url, timeout=self._request_timeout(8))
                if res.status_code != 200:
                    continue
                with open(local_path, 'wb') as f:
                    f.write(res.content)
                self.downloaded_assets[clean_url] = '/' + asset_path.replace('\\', '/'); asset_type = 'misc' if extension == '.json' else 'fonts' if extension in {'.woff', '.woff2', '.ttf', '.eot', '.otf'} else 'images'
                self.asset_stats[asset_type] = self.asset_stats.get(asset_type, 0) + 1; print(f'[✓] Runtime asset: /{asset_path}')
            except Exception:
                pass

    def discover_assets_from_response(self, response_text, response_url):
        """
        Discover image references embedded in API/JSON responses.

        API payloads often contain only a filename rather than the actual
        browser URL. Do not assume that a bare filename lives beside the
        API endpoint. Probe a small set of generic static locations and
        preserve whichever real target resource exists.
        """
        patterns = [
            r'["\']([^"\']+\.(?:png|jpg|jpeg|gif|svg|webp))["\']',
            r'["\']([^"\']*?/assets/[^"\']+)["\']',
            r'["\'](assets/[^"\']+)["\']',
            r'["\'](/assets/[^"\']+)["\']',
        ]

        discovered = set()

        for pattern in patterns:
            try:
                for match in re.findall(
                    pattern,
                    response_text,
                    flags=re.IGNORECASE
                ):
                    discovered.add(
                        match[0]
                        if isinstance(match, tuple)
                        else match
                    )
            except re.error:
                continue

        target_root = self.target_url.rstrip('/') + '/'

        for asset in discovered:
            asset = asset.strip()

            if asset.startswith(
                ('data:', 'blob:', '#', 'javascript:')
            ):
                continue

            parsed_asset = urllib.parse.urlparse(asset)

            candidates = []

            # Absolute URL.
            if parsed_asset.scheme in ('http', 'https'):
                candidates.append(asset)

            # Root-relative URL: /assets/...
            elif asset.startswith('/'):
                candidates.append(
                    urllib.parse.urljoin(
                        target_root,
                        asset.lstrip('/')
                    )
                )

            # Explicit relative path containing directories.
            elif '/' in asset:
                candidates.append(
                    urllib.parse.urljoin(
                        response_url,
                        asset
                    )
                )

                candidates.append(
                    urllib.parse.urljoin(
                        target_root,
                        asset
                    )
                )

            else:
                # Bare filename from structured API data.
                #
                # First keep ordinary relative resolution available.
                candidates.append(
                    urllib.parse.urljoin(
                        response_url,
                        asset
                    )
                )

                # Common public/static image roots. These are generic
                # candidates, not application-specific filenames.
                for prefix in (
                    'assets/public/images/products/',
                    'assets/public/images/',
                    'assets/images/',
                    'images/',
                    'img/',
                    'static/images/',
                    'public/images/',
                ):
                    candidates.append(
                        urllib.parse.urljoin(
                            target_root,
                            prefix + asset
                        )
                    )

            seen = set()

            for candidate in candidates:
                candidate = urllib.parse.urldefrag(
                    candidate
                )[0]

                if candidate in seen:
                    continue

                seen.add(candidate)

                parsed = urllib.parse.urlparse(candidate)

                if (
                    parsed.scheme not in ('http', 'https')
                    or not self.is_target_family(candidate)
                ):
                    continue

                extension = os.path.splitext(
                    parsed.path
                )[1].lower()

                if extension not in {
                    '.png',
                    '.jpg',
                    '.jpeg',
                    '.gif',
                    '.svg',
                    '.webp'
                }:
                    continue

                # Already successfully archived.
                existing = self.downloaded_assets.get(
                    candidate
                )

                if existing and not existing.startswith('/_missing/'):
                    break

                try:
                    local = self.download_and_localize_asset(
                        candidate,
                        'images'
                    )
                except Exception as exc:
                    print(
                        f'[-] Failed to mirror API image '
                        f'{candidate}: {exc}'
                    )
                    continue

                if (
                    local
                    and not str(local).startswith('/_missing/')
                ):
                    print(
                        f'[✓] API image preserved: '
                        f'{candidate} -> {local}'
                    )
                    break

    def rewrite_response_asset_urls(self, response_text):
        if not response_text:
            return response_text
        rewritten = response_text
        for orig, loc in sorted(self.downloaded_assets.items(), key=lambda item: len(item[0]), reverse=True):
            if not orig or not loc:
                continue
            rewritten = rewritten.replace(orig, loc).replace(urllib.parse.urldefrag(orig)[0], loc); orig_path = urllib.parse.urlparse(orig).path
            if orig_path:
                rewritten = rewritten.replace(orig_path, loc)
        return rewritten

    def _asset_fallback(self, asset_url):
        if not self._on_demand_read_only and self.static_decoy:
            return asset_url
        extension = os.path.splitext(urllib.parse.urlparse(asset_url).path)[1].lower()
        if not re.fullmatch(r'\.[a-z0-9]{1,10}', extension):
            extension = '.bin'
        return '/_missing/' + hashlib.sha256(asset_url.encode()).hexdigest()[:20] + extension

    def download_and_localize_asset(self, asset_url, asset_type):
        if not asset_url or asset_url.startswith(('data:', 'blob:', '#')):
            return asset_url
        clean_target_url = urllib.parse.urldefrag(asset_url)[0]
        if clean_target_url in self.downloaded_assets:
            return self.downloaded_assets[clean_target_url]
        if self._budget_expired() or clean_target_url in self._assets_in_progress:
            return self._asset_fallback(asset_url)
        self._assets_in_progress.add(clean_target_url)
        try:
            res = self.session.get(clean_target_url, timeout=self._request_timeout(8))
            if res.status_code != 200:
                return self._asset_fallback(asset_url)
            orig_path = urllib.parse.urlparse(clean_target_url).path or '/'
            if not self.static_decoy:
                local_file = self._safe_runtime_path(clean_target_url)
                if local_file:
                    if not self._same_origin(clean_target_url):
                        namespace = hashlib.sha256(urllib.parse.urlparse(clean_target_url).netloc.encode()).hexdigest()[:12]
                        local_file = os.path.join(self.output_dir, '_external', namespace, orig_path.lstrip('/'))
                                        # Extensionless stylesheets must be published as CSS.
                    content_type = res.headers.get(
                        'Content-Type', ''
                    ).split(';', 1)[0].strip().lower()

                    if (
                        not os.path.splitext(local_file)[1]
                        and asset_type == 'css'
                        and content_type == 'text/css'
                    ):
                        local_file += '.css'
                    os.makedirs(os.path.dirname(local_file), exist_ok=True)
                    local_url = '/' + os.path.relpath(local_file, self.output_dir).replace('\\', '/')
                    self.downloaded_assets[clean_target_url] = local_url
                    data = self.rewrite_css_assets(res.text, clean_target_url).encode() if asset_type == 'css' else res.content
                    with open(local_file, 'wb') as handle: handle.write(data)
                    if asset_type == 'javascript':
                        self.discover_and_fetch_chunks(res.text, clean_target_url)
                        self.discover_runtime_assets(res.text, clean_target_url)
                    return local_url

            if asset_type == 'images' and orig_path.startswith('/assets/') and self._safe_runtime_path(clean_target_url):
                local_file = self._safe_runtime_path(clean_target_url); rel_path = os.path.relpath(local_file, self.output_dir); os.makedirs(os.path.dirname(local_file), exist_ok=True)
                with open(local_file, 'wb') as f:
                    f.write(res.content)
                local_rel = '/' + rel_path.replace('\\', '/'); self.downloaded_assets[clean_target_url] = local_rel; self.asset_stats['images'] += 1; print(f'[✓] Preserved runtime image: {local_rel}')
                return local_rel
            orig_filename = os.path.basename(orig_path); ext = os.path.splitext(orig_filename)[1].lower()
            if ext in ('.php', '.phtml', '.phar', '.cgi', '.pl', '.py', '.sh') or not ext:
                ext = {'css': '.css', 'javascript': '.js', 'images': '.png', 'fonts': '.woff2'}.get(asset_type, '.bin')
                orig_filename = (os.path.splitext(orig_filename)[0] or 'asset') + ext
            url_hash = hashlib.md5(clean_target_url.encode('utf-8')).hexdigest()[:10]
            subfolder = {'images': 'img', 'css': 'css', 'javascript': 'js', 'fonts': 'fonts'}.get(asset_type, 'misc'); save_dir = os.path.join(self.assets_dir, subfolder); os.makedirs(save_dir, exist_ok=True)
            clean_name = f"{url_hash}_{(re.sub('[^a-zA-Z0-9._-]', '', orig_filename) or f'asset{ext}' if orig_filename else ext or '.bin')}"; file_path = os.path.join(save_dir, clean_name)
            if asset_type == 'css':
                with open(file_path, 'w', encoding='utf-8', errors='ignore') as f:
                    f.write(self.rewrite_css_assets(res.text, clean_target_url))
            elif asset_type == 'javascript':
                sanitized_text = self.sanitize_javascript_content(res.text)
                with open(file_path, 'w', encoding='utf-8', errors='ignore') as f:
                    f.write(sanitized_text)
                try:
                    self.discover_runtime_assets(sanitized_text, clean_target_url); self.discover_and_fetch_chunks(sanitized_text, clean_target_url)
                except Exception:
                    pass
            else:
                with open(file_path, 'wb') as f:
                    f.write(res.content)
            local_rel_path = f'/assets/{subfolder}/{clean_name}'; self.downloaded_assets[clean_target_url] = local_rel_path
            return local_rel_path
        except Exception as e:
            print(f'[-] Failed to download asset {asset_url}: {e}')
            return self._asset_fallback(asset_url)
        finally:
            self._assets_in_progress.discard(clean_target_url)

    def localize_all_assets(self, soup, current_url):
        for style in soup.find_all('style'):
            style.string = self.rewrite_css_assets(style.get_text(), current_url)
        for tag in soup.find_all(style=True):
            tag['style'] = self.rewrite_css_assets(str(tag['style']), current_url)
        for tag in soup.find_all('link', href=True):
            full_url = urllib.parse.urljoin(current_url, tag['href']); rel = [r.lower() for r in tag.get('rel', [])]
            if 'stylesheet' in rel or tag['href'].lower().endswith('.css'):
                tag['href'] = self.download_and_localize_asset(full_url, 'css')
                if str(tag['href']).startswith('/'):
                    tag.attrs.pop('integrity', None)
                    tag.attrs.pop('crossorigin', None)
            elif any((r in rel for r in ['icon', 'shortcut', 'apple-touch-icon'])):
                tag['href'] = self.download_and_localize_asset(full_url, 'images')
        for tag in soup.find_all('script'):
            if tag.get('src'):
                tag['src'] = self.download_and_localize_asset(urllib.parse.urljoin(current_url, tag['src']), 'javascript')
                if str(tag['src']).startswith('/'):
                    tag.attrs.pop('integrity', None)
                    tag.attrs.pop('crossorigin', None)
        for tag in soup.find_all('img', src=True):
            tag['src'] = self.download_and_localize_asset(urllib.parse.urljoin(current_url, tag['src']), 'images')
        for tag in soup.find_all(srcset=True):
            if not tag.get('srcset') or 'data:' in tag['srcset']:
                continue
            tag['srcset'] = ', '.join((f"{self.download_and_localize_asset(urllib.parse.urljoin(current_url, p[0]), 'images')} {' '.join(p[1:])}".strip() for p in [i.strip().split() for i in tag['srcset'].split(',') if i.strip()] if p))
        # Responsive/lazy media and preloads may never be requested in the first viewport.
        for tag in soup.find_all(['img', 'source', 'video', 'audio', 'track']):
            for attr in ('data-src', 'data-original', 'data-lazy-src', 'poster', 'src'):
                value = tag.get(attr)
                if not value or (attr == 'src' and tag.name == 'img'):
                    continue
                kind = 'images' if tag.name == 'img' or attr == 'poster' else 'misc'
                localized = self.download_and_localize_asset(urllib.parse.urljoin(current_url, value), kind)
                tag[attr] = localized
                if attr in ('data-src', 'data-original', 'data-lazy-src') and tag.name == 'img':
                    tag['src'] = localized
        for tag in soup.find_all('link', href=True):
            rel = {str(value).lower() for value in tag.get('rel', [])}
            if not rel.intersection({'preload', 'modulepreload'}):
                continue
            kind = {'style': 'css', 'script': 'javascript', 'font': 'fonts', 'image': 'images'}.get(tag.get('as'),
                    'javascript' if 'modulepreload' in rel else 'misc')
            tag['href'] = self.download_and_localize_asset(urllib.parse.urljoin(current_url, tag['href']), kind)
            if str(tag['href']).startswith('/'):
                tag.attrs.pop('integrity', None)
                tag.attrs.pop('crossorigin', None)
        for tag in soup.find_all('meta', property='og:image', content=True):
            tag['content'] = self.download_and_localize_asset(urllib.parse.urljoin(current_url, tag['content']), 'images')

    def discover_links(self, soup, current_url):
        links = []
        for tag in soup.find_all('a', href=True):
            href = tag['href'].strip()
            if href.startswith(('#', 'mailto:', 'javascript:', 'tel:')):
                continue
            full_url = urllib.parse.urljoin(current_url, href); parsed = urllib.parse.urlparse(full_url)
            if parsed.path == '/redirect' and 'to=' in parsed.query or not self.is_crawl_host(full_url):
                continue
            links.append(self.canonicalize_url(full_url))
        return list(set(links))

    def discover_and_fetch_chunks(self, js_text, current_js_url):
        matches = set()
        for pattern in ['["\\\'](\\.?\\.?/[^"\\\']+\\.js)["\\\']', '["\\\']([a-zA-Z0-9_\\-]+\\.js)["\\\']', '["\\\'](/[^"\\\']+\\.js)["\\\']']:
            try:
                matches.update(re.findall(pattern, js_text, flags=re.IGNORECASE))
            except re.error:
                continue
        for chunk in matches:
            if chunk.startswith(('data:', 'javascript:')):
                continue
            if not os.path.basename(urllib.parse.urlparse(chunk).path).lower().endswith('.js'):
                continue
            full_chunk_url = urllib.parse.urljoin(current_js_url, chunk)
            if urllib.parse.urlparse(full_chunk_url).scheme in ('http', 'https'):
                self.download_and_localize_asset(full_chunk_url, 'javascript')

    def rewrite_links(self, soup, current_url):
        for tag in soup.find_all('a', href=True):
            href = tag['href'].strip()
            if href.startswith(('#', 'mailto:', 'javascript:', 'tel:')):
                continue
            full_url = urllib.parse.urljoin(current_url, href)
            if self.is_same_domain(full_url):
                parsed = urllib.parse.urlparse(full_url)
                tag['href'] = (parsed.path or '/') + ('?' + parsed.query if parsed.query else '') + ('#' + parsed.fragment if parsed.fragment else '')

    def inspect_and_rewrite_forms(self, soup, route):
        for form in soup.find_all('form'):
            form_fields = [re.sub('[^a-zA-Z0-9_]', '', name.lower()) for name in [field.get('name') or field.get('id') for field in form.find_all(['input', 'select', 'textarea'])] if name]
            self.forms.append({'route': route, 'method': (form.get('method') or 'POST').upper(), 'fields': list(set(form_fields))}); form['action'], form['method'] = ('/trap_handler.php', 'POST'); hidden = soup.new_tag('input')
            hidden['type'], hidden['name'], hidden['value'] = ('hidden', 'decoy_source', route); form.append(hidden)

    def analyze_page_structure(self, soup, url):
        """Extract bounded structural evidence from a rendered/live page."""; title = soup.title.get_text(' ', strip=True) if soup.title else ''; headings = []
        for heading in soup.select('h1, h2, h3')[:30]:
            text = heading.get_text(' ', strip=True)
            if text:
                headings.append(text[:200])
        forms = []
        for form_index, form in enumerate(soup.find_all('form')[:15]):
            form_info = {'region_id': f'form_{form_index}', 'method': str(form.get('method', 'GET')).upper(), 'action': str(form.get('action', ''))[:500], 'fields': []}
            for field in form.select('input, select, textarea, button')[:40]:
                field_type = field.get('type') or field.name or ''; form_info['fields'].append({'name': str(field.get('name', ''))[:100], 'type': str(field_type)[:50], 'placeholder': str(field.get('placeholder', ''))[:120]})
            forms.append(form_info)
        landmarks = []
        landmark_selectors = [('header', 'header'), ('nav', 'nav'), ('main', 'main'), ('aside', 'aside'), ('footer', 'footer'), ('[role="banner"]', 'banner'), ('[role="navigation"]', 'navigation'), ('[role="main"]', 'main'), ('[role="complementary"]', 'complementary'), ('[role="contentinfo"]', 'contentinfo'), ('[role="search"]', 'search')]
        seen_landmark_nodes = set()
        for selector, semantic_hint in landmark_selectors:
            try:
                nodes = soup.select(selector)
            except Exception:
                continue
            for node in nodes[:10]:
                node_identity = id(node)
                if node_identity in seen_landmark_nodes:
                    continue
                seen_landmark_nodes.add(node_identity); region_id = node.get('id') or f'{semantic_hint}_{len(landmarks)}'; classes = node.get('class', [])
                if isinstance(classes, str):
                    classes = classes.split()
                text = node.get_text(' ', strip=True)
                landmarks.append({'region_id': str(region_id)[:100], 'tag': str(node.name or '')[:30], 'role': str(node.get('role', ''))[:50], 'semantic_hint': semantic_hint, 'classes': [str(item)[:80] for item in classes[:8]], 'text_sample': text[:300], 'link_count': len(node.find_all('a', href=True))})
                if len(landmarks) >= 30:
                    break
            if len(landmarks) >= 30:
                break
        breadcrumb_found = False; breadcrumb_selectors = ['[aria-label*="breadcrumb" i]', '[class*="breadcrumb" i]', '[id*="breadcrumb" i]']
        for selector in breadcrumb_selectors:
            try:
                if soup.select_one(selector):
                    breadcrumb_found = True
                    break
            except Exception:
                continue
        internal_links = []; path_prefix_counts = {}
        for anchor in soup.find_all('a', href=True)[:1000]:
            href = str(anchor.get('href', '')).strip()
            if not href or href.startswith(('#', 'mailto:', 'tel:', 'javascript:', 'data:')):
                continue
            try:
                absolute = urllib.parse.urljoin(url, href); parsed_link = urllib.parse.urlparse(absolute)
                if not self.is_target_family(absolute):
                    continue
                path = parsed_link.path or '/'; internal_links.append(path); segments = [segment for segment in path.split('/') if segment]; prefix = '/' + segments[0] + '/*' if segments else '/*'
                path_prefix_counts[prefix] = path_prefix_counts.get(prefix, 0) + 1
            except Exception:
                continue
        common_prefixes = sorted(path_prefix_counts.items(), key=lambda item: item[1], reverse=True)[:15]
        link_patterns = {'internal_link_count': len(internal_links), 'common_prefixes': [{'pattern': pattern, 'count': count} for pattern, count in common_prefixes], 'sample_paths': list(dict.fromkeys(internal_links))[:30]}; signature_counts = {}
        signature_examples = {}; candidate_nodes = soup.select('article, section, li, main > div, [class]')
        for node in candidate_nodes[:1500]:
            classes = node.get('class', [])
            if isinstance(classes, str):
                classes = classes.split()
            classes = [str(c)[:80] for c in classes[:6] if c]
            if classes:
                signature = (str(node.name), tuple(sorted(classes)))
            elif node.name in ('article', 'section', 'li'):
                signature = (str(node.name), ())
            else:
                continue
            text = node.get_text(' ', strip=True)
            if len(text) < 20:
                continue
            signature_counts[signature] = signature_counts.get(signature, 0) + 1
            if signature not in signature_examples:
                signature_examples[signature] = text[:250]
        repeated_regions = []; repeated = sorted(signature_counts.items(), key=lambda item: item[1], reverse=True)
        for index, (signature, count) in enumerate(repeated):
            if count < 2:
                continue
            tag_name, classes = signature; repeated_regions.append({'region_id': f'repeat_{index}', 'tag': tag_name, 'classes': list(classes), 'count': count, 'text_sample': signature_examples.get(signature, '')})
            if len(repeated_regions) >= 20:
                break
        tables = soup.find_all('table'); lists = soup.find_all(['ul', 'ol']); code_blocks = soup.select('pre, code'); articles = soup.find_all('article'); images = soup.find_all('img')
        paragraphs = [p.get_text(' ', strip=True) for p in soup.find_all('p') if p.get_text(' ', strip=True)]; paragraph_chars = sum((len(text) for text in paragraphs)); body_text = soup.body.get_text(' ', strip=True) if soup.body else ''
        content_signals = {'paragraph_count': len(paragraphs), 'paragraph_chars': paragraph_chars, 'table_count': len(tables), 'list_count': len(lists), 'code_block_count': len(code_blocks), 'article_count': len(articles), 'image_count': len(images), 'breadcrumb': breadcrumb_found, 'body_text_length': len(body_text), 'has_h1': bool(soup.find('h1')), 'visible_text_sample': body_text[:800]}
        document_text = str(soup); framework = 'unknown'
        if '__NEXT_DATA__' in document_text or '/_next/' in document_text or soup.find(id='__next'):
            framework = 'nextjs'
        elif soup.find(id='root') and ('react' in document_text.lower() or 'webpack' in document_text.lower()):
            framework = 'react'
        elif 'data-v-' in document_text or '__NUXT__' in document_text or soup.find(id='__nuxt'):
            framework = 'vue_or_nuxt'
        elif 'ng-version' in document_text or soup.find(attrs={'ng-version': True}):
            framework = 'angular'
        context = {'url': url, 'title': title[:300], 'headings': headings, 'forms': forms, 'landmarks': landmarks, 'link_patterns': link_patterns, 'repeated_regions': repeated_regions, 'content_signals': content_signals, 'framework': framework}
        result = self.adaptive_analyzer.analyze_page_semantics(context); self.page_semantics[url] = result; print(f"[*] Page semantics: {result['page_type']} / {result['interaction_type']} ({result['source']}, {result['confidence']:.2f})")
        return result

    def capture_template_candidate(self, soup, url):
        """; Keep a static rendered-DOM candidate for adaptive reconstruction.

        This is not served directly during the crawl. It is sanitized and; exported later after the Site Profile has selected representative; pages.; """
        try:
            analysis = self.page_semantics.get(url, {})
            if not isinstance(analysis, dict):
                return
            page_type = str(analysis.get('page_type', 'GENERIC')).upper(); page_family = str(analysis.get('page_family', page_type.lower())).strip().lower() or 'generic'
            template_affinity = str(analysis.get('template_affinity', page_family)).strip().lower() or page_family; snapshot = BeautifulSoup(str(soup), 'html.parser')
            for script in snapshot.find_all('script'):
                script.decompose()
            for tag in snapshot.find_all(True):
                for attribute in list(tag.attrs):
                    if str(attribute).lower().startswith('on'):
                        del tag.attrs[attribute]
            for tag in snapshot.find_all(True):
                for attribute in ('href', 'src', 'action'):
                    value = tag.get(attribute)
                    if not value or str(value).startswith(('#', 'data:', 'blob:', 'javascript:', 'mailto:', 'tel:')):
                        continue
                    absolute = urllib.parse.urljoin(url, str(value))
                    if self.is_target_family(absolute):
                        parsed_value = urllib.parse.urlparse(absolute); tag[attribute] = (parsed_value.path or '/') + ('?' + parsed_value.query if parsed_value.query else '') + ('#' + parsed_value.fragment if parsed_value.fragment else '')
                if tag.get('srcset'):
                    rewritten = []
                    for item in str(tag.get('srcset')).split(','):
                        parts = item.strip().split()
                        if not parts:
                            continue
                        absolute = urllib.parse.urljoin(url, parts[0])
                        if self.is_target_family(absolute):
                            parsed_value = urllib.parse.urlparse(absolute); parts[0] = parsed_value.path or '/'
                        rewritten.append(' '.join(parts))
                    tag['srcset'] = ', '.join(rewritten)
            route = urllib.parse.urlparse(url).path or '/'
            for form in snapshot.find_all('form'):
                for old in form.find_all('input', attrs={'name': 'decoy_source'}):
                    old.decompose()
                form['action'] = '/trap_handler.php'; form['method'] = 'POST'; hidden = snapshot.new_tag('input'); hidden['type'] = 'hidden'; hidden['name'] = 'decoy_source'; hidden['value'] = route; form.append(hidden)
            guard = snapshot.new_tag('script', src='/assets/decoyguard-navigation.js')
            if snapshot.head:
                snapshot.head.insert(0, guard)
            elif snapshot.body:
                snapshot.body.append(guard)
            else:
                snapshot.append(guard)
            self.template_candidates[url] = {'url': url, 'route': route, 'page_type': page_type, 'page_family': page_family, 'template_affinity': template_affinity, 'confidence': float(analysis.get('confidence', 0.0) or 0.0), 'html': str(snapshot)}
        except Exception as e:
            print(f'[!] Template candidate capture failed: {url}: {e}')

    def save_page(self, soup, url):
        local_path = self.get_local_page_path(url); full_path = os.path.join(self.output_dir, local_path); os.makedirs(os.path.dirname(full_path), exist_ok=True)
        if not soup.find('script', src='/assets/decoyguard-navigation.js'):
            guard = soup.new_tag('script', src='/assets/decoyguard-navigation.js')
            if soup.body:
                soup.body.append(guard)
            else:
                soup.append(guard)
        php_guard = "<?php @include_once $_SERVER['DOCUMENT_ROOT'] . '/guard_middleware.php'; ?>\n"
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(php_guard + "<?php echo base64_decode('" + base64.b64encode(str(soup).encode('utf-8')).decode('ascii') + "'); ?>")
        print(f'[✓] Saved isolated view: {local_path}')

    def is_crawl_host(self, url):
        """Only crawl HTML pages from the exact starting hostname."""
        try:
            host = (urllib.parse.urlparse(url).hostname or '').lower().rstrip('.'); target = (urllib.parse.urlparse(self.target_url).hostname or '').lower().rstrip('.')
            return bool(host and target and (host == target))
        except Exception:
            return False

    def crawl(self, url, max_pages=None):
        max_pages = self.max_pages if max_pages is None else int(max_pages)
        if max_pages < 1:
            raise ValueError('max_pages must be positive')
        self._deadline = time.perf_counter() + self.max_seconds
        start_url = self.canonicalize_url(url)
        queue = list(dict.fromkeys([start_url] + self.seed_urls)); queued = set(queue); last_progress = 0
        priority = {item: i for i, item in enumerate(queue)}
        while queue and len(self.visited) < max_pages and len(self.attempted) < max_pages * 3:
            if self._budget_expired():
                self.stop_reason = 'time_budget'
                break
            # Prefer a new first-level section before another page in a learned section.
            covered = {self._route_section(u) for u in self.visited}
            queue.sort(key=lambda u: (priority.get(u, len(priority)), self._route_section(u) in covered, len(urllib.parse.urlparse(u).path.split('/')), u))
            current = queue.pop(0)
            if current in self.attempted or not self.is_crawl_host(current):
                continue
            self.attempted.add(current); self.discovered_routes.add(urllib.parse.urlparse(current).path or '/'); res = self.fetch(current)
            if res is None:
                self.capture_failures[current] = 'fetch_failed'
                continue
            if not self.is_crawl_host(res.url):
                self.capture_failures[current] = 'redirect_outside_target'
                continue
            rendered_html, rendered_links = self.render_page(current)
            if not rendered_html:
                rendered_html = res.text if 'text/html' in res.headers.get('Content-Type', '').lower() else None
            if not rendered_html:
                self.capture_failures[current] = 'no_html'
                continue
            original_html = res.text if 'text/html' in res.headers.get('Content-Type', '').lower() else ''; framework = self.is_framework_document(original_html); save_source = original_html if original_html and not self.static_decoy else rendered_html
            analysis_source = rendered_html or original_html
            if not save_source or not analysis_source:
                continue
            soup = BeautifulSoup(save_source, 'html.parser'); analysis_soup = BeautifulSoup(analysis_source, 'html.parser'); route = urllib.parse.urlparse(current).path or '/'; self.routes.append(route)
            try:
                self.analyze_page_structure(analysis_soup, current)
            except Exception as e:
                print(f'[!] Semantic analysis failed: {current}: {e}')
            links = set(self.discover_links(analysis_soup, current))
            for link in rendered_links:
                try:
                    canonical = self.canonicalize_url(link)
                    if self.is_crawl_host(canonical):
                        links.add(canonical)
                except Exception:
                    pass
            if not self.static_decoy:
                self.save_framework_page(original_html, current)
            else:
                if self.static_decoy:
                    for script in soup.find_all('script'):
                        script.decompose()
                    for tag in soup.find_all(True):
                        for attr in list(tag.attrs):
                            if attr.lower().startswith('on'):
                                del tag.attrs[attr]
                self.localize_all_assets(soup, current); self.inspect_and_rewrite_forms(soup, route); self.rewrite_links(soup, current); self.save_page(soup, current)
            # Templates must use the same localized assets as the saved page.
            self.capture_template_candidate(soup, current)
            self.visited.add(current)
            n = len(self.visited)
            for link in sorted(links):
                self.discovered_routes.add(urllib.parse.urlparse(link).path or '/')
                if link not in self.attempted and link not in queued and self.is_crawl_host(link):
                    queued.add(link); queue.append(link)
            if n == 1 or n - last_progress >= 50:
                total = max(0.0, time.perf_counter() - (self._mirror_started_at or time.perf_counter())); print(f'[→] {n} pages | {self._runtime_files} resources | {self._runtime_bytes / 1048576:.1f} MB | queue {len(queue)} | {total:.1f}s'); last_progress = n
        self._deadline = None
        if len(self.visited) >= max_pages:
            self.stop_reason = 'page_budget'
            print(f'[✓] Learning budget reached: {len(self.visited)} pages captured | {len(queue)} discovered routes left for adaptive reconstruction.')

        elif len(self.attempted) >= max_pages * 3:
            self.stop_reason = 'attempt_budget'
        for seed in self.seed_urls:
            if seed not in self.visited:
                print(f'[!] Priority page was not captured within the budget: {seed}')
        if not self.visited:
            raise RuntimeError('No pages captured; decoy deployment cannot proceed.')

    def _fallback_shell(self, html):
        """Keep site chrome, but do not relabel another topic's article as a copy."""
        soup = BeautifulSoup(html, 'html.parser')
        main = soup.find('main') or soup.find(attrs={'role': 'main'}) or soup.find(id='main-content') or soup.find('article')
        if main:
            main.clear()
        else:
            body = soup.body or soup
            # With no content landmark, retain only identifiable global chrome.
            for child in list(body.contents):
                if getattr(child, 'name', None) not in ('header', 'footer', 'style', 'link', 'script'):
                    child.extract()
            main = soup.new_tag('main')
            body.append(main)
        main['style'] = str(main.get('style', '')) + ';padding:2rem;min-width:0'
        for sidebar in list(soup.find_all('aside')) + list(soup.find_all(attrs={'role': 'complementary'})):
            if sidebar.parent:
                sidebar.decompose()
        for sidebar in soup.select('[id*="sidebar" i], [aria-label="Sidebar" i]'):
            if sidebar.parent and not sidebar.find_parent(['header', 'footer']):
                sidebar.decompose()
        for nav in soup.find_all('nav'):
            label = str(nav.get('aria-label', '')).lower()
            if 'breadcrumb' in label:
                nav.clear()
                nav.append('__DG_BREADCRUMBS__')
            elif not nav.find_parent(['header', 'footer']):
                nav.decompose()
        main.append('__DG_ROUTE_CONTENT__')
        return str(soup)

    def generate_adaptive_templates(self):
        """; Export representative static rendered templates learned from; captured pages.

        One representative is kept for each page family and each route; family selected by site_profile.json.; """; profile_path = os.path.join(self.output_dir, 'site_profile.json')
        if not os.path.exists(profile_path):
            print('[!] Adaptive templates skipped: site_profile.json not found.'); return
        try:
            with open(profile_path, 'r', encoding='utf-8') as f:
                profile = json.load(f)
        except Exception as e:
            print(f'[!] Could not load site profile: {e}'); return
        templates_dir = os.path.join(self.output_dir, 'templates'); os.makedirs(templates_dir, exist_ok=True); manifest = {'version': 3, 'page_families': {}, 'route_families': {}, 'exact_routes': {}, 'home_route': urllib.parse.urlparse(self.target_url).path or '/', 'discovered_routes': sorted(self.discovered_routes), 'default_template': None, 'fallback_template': None}

        def safe_name(value):
            value = str(value or 'generic').lower(); value = re.sub('[^a-z0-9_-]+', '_', value)
            return value.strip('_') or 'generic'

        def write_template(candidate, filename):
            if not candidate:
                return None
            path = os.path.join(templates_dir, filename)
            with open(path, 'w', encoding='utf-8') as f:
                f.write(candidate['html'])
            return '/templates/' + filename
        if self.template_candidates:
            best_default = next((item for item in self.template_candidates.values() if item['route'] == '/'), next(iter(self.template_candidates.values()))); manifest['default_template'] = write_template(best_default, 'default.html')
            shell = dict(best_default, html=self._fallback_shell(best_default['html']))
            manifest['fallback_template'] = write_template(shell, 'fallback.html')
        for index, candidate in enumerate(self.template_candidates.values()):
            manifest['exact_routes'][candidate['route'].rstrip('/') or '/'] = {'template': write_template(candidate, f'exact_{index:04d}.html')}
        for family_name, family in profile.get('page_families', {}).items():
            representative_url = family.get('representative_url'); candidate = self.template_candidates.get(representative_url)
            if not candidate:
                continue
            filename = 'page_' + safe_name(family_name) + '.html'; template_path = write_template(candidate, filename)
            if template_path:
                manifest['page_families'][family_name] = {'template': template_path, 'representative_url': representative_url, 'representative_route': candidate['route'], 'page_type': candidate['page_type']}
        route_index = 0
        for route_pattern, family in profile.get('route_families', {}).items():
            representative_url = family.get('representative_url'); candidate = self.template_candidates.get(representative_url)
            if not candidate:
                continue
            route_index += 1; filename = f'route_{route_index:04d}.html'; template_path = write_template(candidate, filename)
            if template_path:
                manifest['route_families'][route_pattern] = {'template': template_path, 'representative_url': representative_url, 'representative_route': candidate['route'], 'page_family': candidate['page_family'], 'page_type': candidate['page_type'], 'shell_template': write_template(dict(candidate, html=self._fallback_shell(candidate['html'])), f'shell_{route_index:04d}.html')}
        manifest_path = os.path.join(self.output_dir, 'template_manifest.json')
        with open(manifest_path, 'w', encoding='utf-8') as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)
        print(f"[✓] Adaptive templates generated: {len(manifest['page_families'])} page families | {len(manifest['route_families'])} route families.")

    def generate_synthetic_config(self):
        config = {'target_url': self.target_url, 'target_host': urllib.parse.urlparse(self.target_url).netloc, 'routes': sorted(list(self.routes)), 'pages_mirrored': len(self.visited), 'generator': 'on_demand_capture', 'synthetic_enabled': False, 'on_demand_enabled': True}
        output_path = os.path.join(self.output_dir, 'synthetic_config.json')
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            print('[✓] Synthetic environment configuration generated.')
        except Exception as e:
            print(f'[!] Synthetic configuration error: {e}')

    def capture_profile_assets(self):
        """Discover assets from captured API data without site-specific paths.

        Industry profiles are metadata for the isolated backend, not a reason
        to assume any particular website's API schema or asset directory.
        """
        self._deadline = time.perf_counter() + 20
        try:
            for response in self.api_responses:
                if not isinstance(response, dict):
                    continue
                body = response.get('body')
                url = response.get('url')
                if not isinstance(body, str) or not isinstance(url, str):
                    continue
                self.discover_assets_from_response(body, url)
        finally:
            self._deadline = None

    def generate_site_profile(self):
        """Aggregate learned page semantics into a deterministic site profile."""; page_families, route_families, frameworks, pages = ({}, {}, {}, [])

        for url, analysis in self.page_semantics.items():
            if not isinstance(analysis, dict):
                continue
            route = urllib.parse.urlparse(url).path or '/'; page_type = str(analysis.get('page_type', 'GENERIC')).upper(); page_family = str(analysis.get('page_family', page_type.lower())).strip().lower() or 'generic'
            affinity = str(analysis.get('template_affinity', page_family)).strip().lower() or page_family; confidence = float(analysis.get('confidence', 0.0) or 0.0); framework = str(analysis.get('framework', '')).strip().lower()
            if framework and framework != 'unknown':
                frameworks[framework] = frameworks.get(framework, 0) + 1
            pattern = self._route_pattern(url)
            pages.append({'url': url, 'route': route, 'page_type': page_type, 'page_family': page_family, 'template_affinity': affinity, 'route_pattern': pattern, 'confidence': confidence, 'source': str(analysis.get('source', 'rules')), 'regions': analysis.get('regions', []), 'content_schema': analysis.get('content_schema', {}), 'interaction_model': analysis.get('interaction_model', [])})
            fam = page_families.setdefault(page_family, {'page_types': {}, 'template_affinities': {}, 'routes': [], 'representative_route': None, 'representative_url': None, 'best_confidence': -1.0, 'count': 0}); fam['count'] += 1; fam['routes'].append(route)
            fam['page_types'][page_type] = fam['page_types'].get(page_type, 0) + 1; fam['template_affinities'][affinity] = fam['template_affinities'].get(affinity, 0) + 1
            if confidence > fam['best_confidence']:
                fam['best_confidence'], fam['representative_route'], fam['representative_url'] = (confidence, route, url)
            rf = route_families.setdefault(pattern, {'page_families': {}, 'page_types': {}, 'template_affinities': {}, 'sample_routes': [], 'representative_route': None, 'representative_url': None, 'best_confidence': -1.0, 'count': 0}); rf['count'] += 1
            rf['page_families'][page_family] = rf['page_families'].get(page_family, 0) + 1; rf['page_types'][page_type] = rf['page_types'].get(page_type, 0) + 1; rf['template_affinities'][affinity] = rf['template_affinities'].get(affinity, 0) + 1
            if route not in rf['sample_routes'] and len(rf['sample_routes']) < 12:
                rf['sample_routes'].append(route)
            if confidence > rf['best_confidence']:
                rf['best_confidence'], rf['representative_route'], rf['representative_url'] = (confidence, route, url)
        for fam in page_families.values():
            fam.pop('best_confidence', None); fam['routes'] = list(dict.fromkeys(fam['routes']))[:50]
        for fam in route_families.values():
            fam.pop('best_confidence', None)
        profile = {'version': 2, 'site': {'target_url': self.target_url, 'target_host': self.target_host, 'framework': max(frameworks, key=frameworks.get) if frameworks else 'unknown', 'pages_analyzed': len(pages), 'routes_captured': len(set(self.routes))}, 'page_families': page_families, 'route_families': route_families, 'framework_observations': frameworks, 'pages': pages}
        path = os.path.join(self.output_dir, 'site_profile.json')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(profile, f, indent=2, ensure_ascii=False)
        print(f'[✓] Site profile generated: {len(page_families)} page families | {len(route_families)} route families | {len(pages)} analyzed pages.')
        return profile

    def generate_synthetic_runtime(self):
        """Generate the local request-and-wait handler for actual document capture."""
        self.generate_on_demand_config()
        # Every mirrored form posts to this maintained local handler.
        from pathlib import Path
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)
        handler = Path(__file__).with_name('trap_handler.php')
        Path(self.output_dir, 'trap_handler.php').write_bytes(handler.read_bytes())

        synthetic_php = '<?php\n@include_once $_SERVER[\'DOCUMENT_ROOT\'] . \'/guard_middleware.php\';\nheader(\'Content-Type: text/html; charset=UTF-8\');\nheader(\'Cache-Control: no-store\');\n@set_time_limit(100);\nfunction dg_unavailable($status, $pending = false) {\n    http_response_code($status);\n    if ($pending) header(\'Retry-After: 2\');\n    echo \'<!doctype html><html><head><meta charset="utf-8"><title>\' . ($pending ? \'Loading page\' : \'Page unavailable\') . \'</title>\';\n    if ($pending) echo \'<meta http-equiv="refresh" content="2">\';\n    echo \'</head><body><main><h1>\' . ($pending ? \'Loading page\' : \'Page unavailable\') . \'</h1><p>\' . ($pending ? \'Please wait while this page loads.\' : \'This page could not be loaded.\') . \'</p></main></body></html>\';\n    exit;\n}\n$method = strtoupper($_SERVER[\'REQUEST_METHOD\'] ?? \'GET\');\nif (!in_array($method, [\'GET\', \'HEAD\'], true)) { header(\'Allow: GET, HEAD\'); dg_unavailable(405); }\n$raw = parse_url($_SERVER[\'REQUEST_URI\'] ?? \'/\', PHP_URL_PATH);\nif (!is_string($raw) || substr($raw, 0, 1) !== \'/\' || substr($raw, 0, 2) === \'//\') dg_unavailable(400);\n$path = rawurldecode($raw);\nif (strlen($path) > 2048 || strpos($path, \'//\') !== false || !preg_match(\'~^/[\\pL\\pN\\pM/_.\\~:@+(),! -]*$~u\', $path)) dg_unavailable(400);\nforeach (explode(\'/\', $path) as $part) if ($part === \'.\' || $part === \'..\' || (strlen($part) && $part[0] === \'.\')) dg_unavailable(400);\n$path = rtrim($path, \'/\') ?: \'/\';\n// This queue is outside the public root and shared only with the local worker.\n$private = getenv(\'DECOY_PRIVATE_DIR\') ?: (is_dir(\'/var/www/decoyguard-private\') ? \'/var/www/decoyguard-private\' : dirname(__DIR__) . \'/private\');\n$configFile = $private . \'/mirror_worker.json\';\n$config = is_file($configFile) ? json_decode(file_get_contents($configFile), true) : null;\n$run = $config[\'run_id\'] ?? \'\';\nif (!$config || empty($config[\'active\']) || !preg_match(\'/^[a-f0-9]{32}$/\', $run)) dg_unavailable(503);\n$queue = $private . \'/mirror-queue/\' . $run;\n$key = hash(\'sha256\', $path);\n$cache = $queue . \'/cache/\' . $key . \'.html\';\n$statusFile = $queue . \'/status/\' . $key . \'.json\';\n$status = is_file($statusFile) ? json_decode(file_get_contents($statusFile), true) : [];\nif (($status[\'state\'] ?? \'\') === \'ready\' && is_file($cache)) {\n    http_response_code($status[\'http_status\'] ?? 200);\n    if ($method !== \'HEAD\') readfile($cache);\n    exit;\n}\n$heartbeatFile = $queue . \'/heartbeat.json\';\n$heartbeat = is_file($heartbeatFile) ? json_decode(file_get_contents($heartbeatFile), true) : [];\nif (($heartbeat[\'run_id\'] ?? \'\') !== $run || time() - ($heartbeat[\'timestamp\'] ?? 0) > 10) dg_unavailable(503);\nif (($status[\'state\'] ?? \'\') === \'failed\' && time() - ($status[\'timestamp\'] ?? 0) < 15) dg_unavailable($status[\'http_status\'] ?? 502);\n$lock = @fopen($queue . \'/enqueue.lock\', \'c\');\nif (!$lock || !flock($lock, LOCK_EX)) dg_unavailable(503);\n$job = $queue . \'/jobs/\' . $key . \'.json\';\n$working = $queue . \'/working/\' . $key . \'.json\';\nif (!is_file($job) && !is_file($working) && !is_file($cache)) {\n    if (count(glob($queue . \'/jobs/*.json\') ?: []) >= 64) { flock($lock, LOCK_UN); fclose($lock); dg_unavailable(503); }\n    $tmp = $job . \'.\' . bin2hex(random_bytes(6)) . \'.tmp\';\n    $written = @file_put_contents($tmp, json_encode([\'run_id\' => $run, \'path\' => $path]));\n    if ($written === false || !@rename($tmp, $job)) { @unlink($tmp); flock($lock, LOCK_UN); fclose($lock); dg_unavailable(503); }\n}\nflock($lock, LOCK_UN); fclose($lock);\n$deadline = microtime(true) + min(75, max(1, (int)($config[\'wait_seconds\'] ?? 45)));\nwhile (microtime(true) < $deadline) {\n    clearstatcache(true, $statusFile); clearstatcache(true, $cache);\n    $status = is_file($statusFile) ? json_decode(file_get_contents($statusFile), true) : [];\n    if (($status[\'state\'] ?? \'\') === \'ready\' && is_file($cache)) {\n        http_response_code($status[\'http_status\'] ?? 200);\n        if ($method !== \'HEAD\') readfile($cache);\n        exit;\n    }\n    if (($status[\'state\'] ?? \'\') === \'failed\') dg_unavailable($status[\'http_status\'] ?? 502);\n    $latest = is_file($configFile) ? json_decode(file_get_contents($configFile), true) : [];\n    if (($latest[\'run_id\'] ?? \'\') !== $run || empty($latest[\'active\'])) dg_unavailable(503);\n    usleep(200000);\n}\ndg_unavailable(503, true);\n'
        if not self.static_decoy:
            policy = "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; style-src 'self' 'unsafe-inline'; connect-src 'self'; form-action 'self'; object-src 'none'; frame-src 'none'; base-uri 'self'"
            synthetic_php = '<?php header(' + json.dumps('Content-Security-Policy: ' + policy) + '); ?>\n' + synthetic_php
        with open(os.path.join(self.output_dir, 'synthetic.php'), 'w', encoding='utf-8') as handle:
            handle.write(synthetic_php)

    def generate_runtime_handlers(self, *, preserve_catalog=False):
        """Generate a local replay handler for captured read-only API responses."""
        from pathlib import Path

        private = Path(self.output_dir).resolve().parent / "private"
        private.mkdir(parents=True, exist_ok=True)

        state = private / "backend-state"
        state.mkdir(exist_ok=True)

        try:
            os.chmod(state, 0o777)
        except OSError:
            pass

        state_db = state / "state.json"

        if not state_db.exists():
            atomic_json(state_db, {
                "version": 1,
                "next_id": 1000,
                "sessions": {},
                "resources": {},
                "relations": {},
            })

        try:
            os.chmod(state_db, 0o666)
        except OSError:
            pass

        # Captured bodies remain outside the public web root.
        catalog = {
            "version": 1,
            "profile": self.backend_profile,
            "demo_sqli": os.getenv("DECOY_DEMO_SQLI", "0") == "1",
            "responses": self.api_responses,
        }

        # Retain generator output when on-demand capture refreshes the catalog.
        old_catalog_path = private / "backend_catalog.json"
        if preserve_catalog:
            previous = json.loads(old_catalog_path.read_text(encoding="utf-8"))
            if not isinstance(previous, dict) or not isinstance(previous.get("responses"), list):
                raise ValueError("Cannot refresh invalid captured API catalog")
            catalog = previous
            self.api_responses = previous["responses"]
        if old_catalog_path.exists():
            try:
                previous = json.loads(old_catalog_path.read_text(encoding="utf-8"))
                for key in ("generated_users", "generated_data_source"):
                    if key in previous:
                        catalog[key] = previous[key]
            except (OSError, ValueError):
                pass
        observed_paths = {urllib.parse.urlparse(r.get("url", "")).path.rstrip("/").lower()
                          for r in self.api_responses if isinstance(r, dict)}
        compatibility = catalog.get("compatibility")
        if not isinstance(compatibility, dict): compatibility = {}
        compatibility["juice_shop"] = {
            "/rest/admin/application-configuration", "/rest/products/search"
        }.issubset(observed_paths)
        catalog["compatibility"] = compatibility
        atomic_json(private / "backend_catalog.json", catalog)
        report = AdaptiveSemanticAnalyzer.analyze_api_contracts(self.api_responses, getattr(self, 'api_routes', ()))
        report['application_adapters'] = ['juice_shop'] if compatibility['juice_shop'] else []
        atomic_json(private / "api_compatibility.json", report)

        api_php = r'''<?php
// DG_RUNTIME_REV=20261028_MIRROR4
declare(strict_types=1);

$privateRoot = rtrim(getenv('DECOY_PRIVATE_DIR') ?: '/var/www/decoyguard-private', '/');
$catalogFile = $privateRoot . '/backend_catalog.json';
$stateFile = $privateRoot . '/backend-state/state.json';
$runtimeCatalog=is_file($catalogFile)?json_decode(file_get_contents($catalogFile),true):[];
$juiceShop=($runtimeCatalog['compatibility']['juice_shop']??false)===true;


// Receive client-only interactions for the existing middleware to inspect.
// This observes an attempted payload; it does not claim server-side exploitation.
if (($_GET['__dg_client_event'] ?? '') === '1' && (parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) === '/decoy_api.php')) {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { http_response_code(405); exit; }
    $clientEvent = json_decode(file_get_contents('php://input', false, null, 0, 65536), true);
    if (!is_array($clientEvent) || ($clientEvent['interaction'] ?? '') !== 'hash-query' || !is_array($clientEvent['fields'] ?? null)) {
        http_response_code(400); exit;
    }
    header('Cache-Control: no-store');
    header('X-DecoyGuard-Observation: client-interaction');
    http_response_code(204); exit;
}

function dg_fail(int $status, string $message): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode([
        'error' => $message,
        'errors' => [['message'=>$message]],
        'decoy' => true
    ]);
    exit;
}

function dg_public_value($value) {
    if (!is_array($value)) return $value;
    $out=[];
    foreach ($value as $key=>$item) $out[$key]=preg_match('/pass|secret|token|authorization|cookie|security.?answer|^answer$/i',(string)$key)
        ? '[REDACTED]' : dg_public_value($item);
    return $out;
}
function dg_auth_fail(int $status,string $message): never {
    global $juiceShop;
    if (!$juiceShop) dg_fail($status,$message);
    http_response_code($status); header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store'); echo json_encode($message); exit;
}
function dg_active_session(array $state): ?array {
    $key=dg_session_key(); $session=$key!==null?($state['sessions'][$key]??null):null;
    return is_array($session) && ($session['expires_at']??0)>=time() ? $session : null;
}
function dg_product_rows(array $catalog,array $state): array {
    $products=[];
    foreach (($catalog['responses']??[]) as $response) {
        if (!is_array($response) || (int)($response['status']??200)!==200 || !empty($response['body_truncated'])) continue;
        $path=strtolower(parse_url($response['url']??'',PHP_URL_PATH)?:'');
        if (!in_array(rtrim($path,'/'),['/rest/products/search','/api/products'],true)) continue;
        $decoded=json_decode($response['body']??'',true);$rows=$decoded['data']??null;
        if (is_array($rows)) foreach ($rows as $row) if (is_array($row) && isset($row['id'])) $products[(string)$row['id']]=$row;
    }
    foreach (($state['resources']??[]) as $path=>$bucket) if (strtolower($path)==='/api/products') {
        $products=[];
        foreach (($bucket['records']??[]) as $row) if (is_array($row) && isset($row['id'])) $products[(string)$row['id']]=$row;
    }
    return $products;
}

function dg_normalize_query(string $query): string {
    if ($query === '') {
        return '';
    }

    parse_str($query, $values);

    if (!is_array($values)) {
        return $query;
    }

    ksort($values);

    return http_build_query(
        $values,
        '',
        '&',
        PHP_QUERY_RFC3986
    );
}

function dg_load_state(string $file): array {
    if (!is_file($file)) {
        return [
            'version' => 1,
            'next_id' => 1000,
            'sessions' => [],
            'resources' => [],
            'relations' => []
        ];
    }

    $state = json_decode(
        (string) file_get_contents($file),
        true
    );

    if (!is_array($state) || !is_array($state['resources'] ?? null)) dg_fail(503, 'Local state invalid; restore its backup before retrying');
    return $state;
}

function dg_save_state(string $file, array $state): bool {
    $json = json_encode($state, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false || strlen($json)>8388608) dg_fail(507, 'Local state storage limit reached');
    $tmp = $file . '.' . bin2hex(random_bytes(8)) . '.tmp';
    $stream = @fopen($tmp, 'xb');
    if (!$stream) dg_fail(503, 'Cannot write local state');
    @chmod($tmp, 0600);
    $written=fwrite($stream,$json); $flushed=fflush($stream); fclose($stream);
    if ($written!==strlen($json) || !$flushed || !@rename($tmp,$file)) {
        @unlink($tmp); dg_fail(503, 'Cannot persist local state');
    }
    return true;
}

// Only writes lock; readers observe either the old or new atomic snapshot.
function dg_lock_state(string $file): void {
    $lock=@fopen($file.'.lock','c');
    if (!$lock) dg_fail(503,'Local state lock unavailable');
    $deadline=microtime(true)+3;
    while (!flock($lock,LOCK_EX|LOCK_NB)) {
        if (microtime(true)>$deadline) { fclose($lock); dg_fail(503,'Local state is busy; retry'); }
        usleep(10000);
    }
    register_shutdown_function(static function() use ($lock) { flock($lock,LOCK_UN); fclose($lock); });
}

// Cookies are separate per decoy store; ports alone do not isolate browser cookies.
function dg_cookie_name(): string {
    global $privateRoot;
    $site=getenv('DECOY_SITE_ID',true)?:$privateRoot;
    return 'DG_DECOY_'.substr(hash('sha256',$site),0,12);
}
function dg_session_key(): ?string {
    $authorization=$_SERVER['HTTP_AUTHORIZATION']??'';
    if (preg_match('/^Bearer\s+(\S+)$/i',$authorization,$match)) $token=$match[1];
    else $token=$_COOKIE[dg_cookie_name()]??'';
    return is_string($token) && $token!=='' && strlen($token)<=4096 ? hash('sha256',$token) : null;
}
function dg_session_cookie(string $token,int $expires): void {
    setcookie(dg_cookie_name(),$token,['expires'=>$expires,'path'=>'/',
        'httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
}
function dg_captured_records(string $catalogFile,string $resourceKey): array {
    $catalog=is_file($catalogFile)?json_decode(file_get_contents($catalogFile),true):[];
    foreach (($catalog['responses']??[]) as $response) {
        if (!is_array($response) || strtoupper($response['method']??'GET')!=='GET' ||
            (int)($response['status']??200)!==200 || !empty($response['body_truncated'])) continue;
        $url=$response['url']??'';
        if ((rtrim(parse_url($url,PHP_URL_PATH)?:'/','/')?:'/')!==$resourceKey || parse_url($url,PHP_URL_QUERY)) continue;
        $decoded=json_decode($response['body']??'',true);
        if (!is_array($decoded)) continue;
        $rows=is_array($decoded['data']??null) && array_is_list($decoded['data']) ? $decoded['data'] :
            (array_is_list($decoded)?$decoded:null);
        if ($rows!==null) return array_slice(array_values(array_filter($rows,'is_array')),0,2000);
    }
    return [];
}

function dg_resource_key(string $path): string {
    $path = '/' . trim($path, '/');

    if ($path === '/') {
        return '/';
    }

    /*
     * Remove a final identifier so collection/member URLs can
     * share state:
     *
     * /api/users/42 -> /api/users
     * /orders/abc   -> /orders
     */
    $parts = explode('/', trim($path, '/'));

    if (count($parts) > 1) {
        $last = end($parts);

        if (
            preg_match('/^[0-9]+$/', $last) ||
            preg_match('/^[a-f0-9-]{8,}$/i', $last)
        ) {
            array_pop($parts);
        }
    }

    return '/' . implode('/', $parts);
}

$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if (in_array($method, ['POST', 'PUT', 'PATCH', 'DELETE'], true)) {
    $rawBody = (string) file_get_contents('php://input',false,null,0,1048577);
    if (strlen($rawBody)>1048576) dg_fail(413,'Local request exceeds 1 MiB');
    if (stripos($_SERVER['CONTENT_TYPE']??'','application/json')!==false && !($method==='DELETE' && trim($rawBody)==='')) {
        $input=json_decode($rawBody,true);
        if (!is_array($input) || json_last_error()!==JSON_ERROR_NONE || !str_starts_with(ltrim($rawBody),'{'))
            dg_fail(400,'Expected a JSON object');
    } else $input=is_array($_POST)?$_POST:[];

    /*
     * Recursively sanitize sensitive values before anything reaches
     * the synthetic state database.
     */
    $sanitize = function ($value) use (&$sanitize) {
        if (!is_array($value)) {
            return $value;
        }

        $sensitive = [
            'password', 'passwd', 'pass',
            'token', 'access_token', 'refresh_token',
            'authorization', 'secret',
            'creditcard', 'credit_card',
            'cvv', 'cvc', 'answer', 'securityanswer', 'passwordrepeat', 'password_confirmation'
        ];

        $clean = [];

        foreach ($value as $key => $item) {
            $name = strtolower((string) $key);

            if (in_array($name, $sensitive, true) || preg_match('/pass|secret|token|authorization|cookie|security.?answer/i',$name)) {
                $clean[$key] = '[REDACTED]';
            } else {
                $clean[$key] = $sanitize($item);
            }
        }

        return $clean;
    };

    $authenticationInput = $input; // Validate before redaction; never persist plaintext passwords.
    $input = $sanitize($input);

    $requestPath = parse_url(
        $_SERVER['REQUEST_URI'] ?? '/',
        PHP_URL_PATH
    );

    $requestPath = is_string($requestPath)
        ? $requestPath
        : '/';

    if ($requestPath !== '/') {
        $requestPath = rtrim($requestPath, '/');
    }

    $resourceKey = dg_resource_key($requestPath);
    dg_lock_state($stateFile);
    $state = dg_load_state($stateFile);
    foreach (($state['sessions']??[]) as $key=>$session) {
        if (!is_array($session) || ($session['expires_at']??0)<time()) unset($state['sessions'][$key]);
    }
    if ($method==='POST' && preg_match('#/(?:logout|signout|sign-out)(?:/|$)#i',$requestPath)) {
        $sessionKey=dg_session_key();
        if ($sessionKey!==null) unset($state['sessions'][$sessionKey]);
        dg_session_cookie('',time()-3600); dg_save_state($stateFile,$state);
        header('Content-Type: application/json'); header('Cache-Control: no-store');
        echo json_encode(['status'=>'success','data'=>null]); exit;
    }

    if (!isset($state['resources']) ||
        !is_array($state['resources'])) {
        $state['resources'] = [];
    }

    if (!isset($state['next_id']) ||
        !is_numeric($state['next_id'])) {
        $state['next_id'] = 1000;
    }

    if (!isset($state['resources'][$resourceKey]) ||
        !is_array($state['resources'][$resourceKey])) {

        $state['resources'][$resourceKey] = [
            'records' => dg_captured_records($catalogFile,$resourceKey),
            'latest' => null
        ];
    }

    if ($juiceShop && strtolower($resourceKey)==='/api/products' &&
        $state['resources'][$resourceKey]['records']===[] &&
        ($state['resources'][$resourceKey]['latest']??null)===null) {
        $state['resources'][$resourceKey]['records']=array_values(dg_product_rows($runtimeCatalog,[]));
    }

    $bucket =& $state['resources'][$resourceKey];
    if (!is_array($bucket['records']??null)) dg_fail(503,'Invalid local resource state');
    $urlIdentifier=$resourceKey!==$requestPath ? basename($requestPath) : null;

    if ($juiceShop && strtolower($resourceKey)==='/api/basketitems') {
        $session=dg_active_session($state);
        if ($session===null) dg_auth_fail(401,'Sign in before changing a basket');
        if ($method==='POST') {
            $basket=$input['BasketId']??$session['basket_id'];
            if (!is_scalar($basket) || (string)$basket!==(string)$session['basket_id']) dg_fail(403,'Basket does not belong to this local session');
            $products=dg_product_rows($runtimeCatalog,$state);
            if (!is_scalar($input['ProductId']??null) || !isset($products[(string)$input['ProductId']])) dg_fail(404,'Local product not found');
            $quantity=filter_var($input['quantity']??1,FILTER_VALIDATE_INT);
            if ($quantity===false || $quantity<1 || $quantity>1000) dg_fail(400,'Quantity must be between 1 and 1000');
            $input['BasketId']=$session['basket_id']; $input['quantity']=$quantity;
        } elseif ($urlIdentifier!==null) {
            foreach ($bucket['records'] as $row) if ((string)($row['id']??'')===(string)$urlIdentifier &&
                (string)($row['BasketId']??'')!==(string)$session['basket_id']) dg_fail(403,'Basket item does not belong to this local session');
            if (isset($input['BasketId']) && (string)$input['BasketId']!==(string)$session['basket_id']) dg_fail(403,'Cannot move another basket item');
            if (isset($input['quantity'])) {
                $quantity=filter_var($input['quantity'],FILTER_VALIDATE_INT);
                if ($quantity===false || $quantity<1 || $quantity>1000) dg_fail(400,'Quantity must be between 1 and 1000');
                $input['quantity']=$quantity;
            }
        }
    }

    if ($method === 'POST') {
    $record = $input;

    if (count($bucket['records'])>=2000) dg_fail(507,'Local collection limit reached');
    $knownIds=array_map(static fn($row)=>(string)($row['id']??''),$bucket['records']);
    if (!array_key_exists('id',$record)) {
        while (in_array((string)$state['next_id'],$knownIds,true)) $state['next_id']++;
        $record['id']=(int)$state['next_id']++;
    } elseif (!is_scalar($record['id']) || in_array((string)$record['id'],$knownIds,true)) {
        dg_fail(409,'Record ID already exists or is invalid');
    }

    $record['_decoy'] = true;
    $record['_resource'] = $resourceKey;

    /*
     * Generic local authentication: accept only explicitly configured
     * synthetic credentials. Never authenticate arbitrary submitted values.
     */
    $pathLower = strtolower($requestPath);

    $looksLikeAuth =
        str_contains($pathLower, 'login') ||
        str_contains($pathLower, 'signin') ||
        str_contains($pathLower, 'sign-in') ||
        str_contains($pathLower, 'authenticate') ||
        str_contains($pathLower, 'session');

    $identityValue =
        $input['email'] ??
        $input['username'] ??
        $input['user'] ??
        $input['login'] ??
        null;

    $looksLikeRegistration=!$looksLikeAuth && preg_match('#/(?:users?|register|signup|sign-up)$#i',$requestPath) &&
        (isset($authenticationInput['password']) || isset($authenticationInput['pass']));
    if ($looksLikeRegistration) {
        $email=is_scalar($identityValue)?trim((string)$identityValue):'';
        $password=$authenticationInput['password']??$authenticationInput['pass']??null;
        if ($email==='' || strlen($email)>254 || !is_string($password) || $password==='' || strlen($password)>72)
            dg_fail(400,'Provide an identity and a password of 1 to 72 bytes');
        if (isset($authenticationInput['passwordRepeat']) && $authenticationInput['passwordRepeat']!==$password)
            dg_fail(400,'Passwords do not match');
        $username=is_scalar($input['username']??null)?trim((string)$input['username']):$email;
        $allUsers=array_merge(array_values($state['auth_users']??[]),$runtimeCatalog['generated_users']??[]);
        foreach ($allUsers as $user) {
            if (!is_array($user)) continue;
            foreach (['email','username'] as $field) {
                $stored=(string)($user[$field]??'');
                if ($stored!=='' && (strcasecmp($stored,$email)===0 || strcasecmp($stored,$username)===0))
                    dg_fail(409,'This local account already exists');
            }
        }
        foreach ($bucket['records'] as $existing) if (is_array($existing) &&
            strcasecmp((string)($existing['email']??$existing['username']??''),$email)===0)
            dg_fail(409,'Account exists without recoverable credentials; register a new test identity');
        if (count($state['auth_users']??[])>=1000) dg_fail(507,'Local account limit reached');
        $state['auth_users'][hash('sha256',strtolower($email))]=[
            'id'=>$record['id'],'email'=>$email,'username'=>$username,
            'password_hash'=>password_hash($password,PASSWORD_DEFAULT),'created_at'=>gmdate('c')
        ];
        $record['email']=$email;$record['username']=$username;
    }

    if ($looksLikeAuth) {
        $identityText = is_scalar($identityValue) ? trim((string) $identityValue) : '';
        $passwordValue = $authenticationInput['password'] ?? $authenticationInput['pass'] ?? null;
        $passwordText = is_scalar($passwordValue) ? (string) $passwordValue : '';

        $settings = is_file($catalogFile) ? json_decode(file_get_contents($catalogFile), true) : [];
        $users = $settings['generated_users'] ?? [];
        $demoSql = ($settings['demo_sqli'] ?? false) === true;
        if (!is_array($users)) dg_auth_fail(503,'Local account configuration unavailable');
        $normalAccount=null;$account=null;$knownRegistered=false;
        // Older generic registration redacted password but could retain its repeat
        // field. Adopt that account only when the submitted password matches it;
        // hash it privately and remove the repeat from the public resource state.
        foreach ($state['resources'] as $path=>&$resource) {
            if (!preg_match('#/(?:users?|register|signup|sign-up)$#i',$path) || !is_array($resource)) continue;
            foreach (($resource['records']??[]) as $index=>$legacy) {
                if (!is_array($legacy) || !isset($legacy['id'])) continue;
                $legacyEmail=(string)($legacy['email']??$legacy['username']??'');
                $legacyUsername=(string)($legacy['username']??$legacyEmail);
                if (strcasecmp($legacyEmail,$identityText)!==0 && strcasecmp($legacyUsername,$identityText)!==0) continue;
                $repeat=$legacy['passwordRepeat']??null;
                $legacyKey=hash('sha256',strtolower($legacyEmail));
                if (!isset($state['auth_users'][$legacyKey]) && is_string($repeat) && $repeat!=='[REDACTED]' &&
                    $repeat!=='' && strlen($repeat)<=72 && hash_equals($repeat,$passwordText)) {
                    $state['auth_users'][$legacyKey]=['id'=>$legacy['id'],'email'=>$legacyEmail,'username'=>$legacyUsername,
                        'password_hash'=>password_hash($passwordText,PASSWORD_DEFAULT),'created_at'=>gmdate('c')];
                    $resource['records'][$index]=$sanitize($legacy);
                    if (is_array($resource['latest']??null) && (string)($resource['latest']['id']??'')===(string)$legacy['id'])
                        $resource['latest']=$sanitize($resource['latest']);
                }
            }
        }
        unset($resource);
        foreach (($state['auth_users']??[]) as $user) {
            if (!is_array($user)) continue;
            if (strcasecmp((string)($user['email']??''),$identityText)!==0 &&
                strcasecmp((string)($user['username']??''),$identityText)!==0) continue;
            $knownRegistered=true;
            if (is_string($user['password_hash']??null) && password_verify($passwordText,$user['password_hash'])) {
                $normalAccount=['id'=>$user['id'],'email'=>$user['email'],'username'=>$user['username']];
                $account=$normalAccount;
            }
            break;
        }
        if ($knownRegistered && !$account) dg_auth_fail(401,'Invalid local decoy credentials');
        if (!$knownRegistered) {
            try {
                $authDb=new PDO('sqlite::memory:',null,null,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
                $authDb->exec('CREATE TABLE users(id INTEGER PRIMARY KEY,email TEXT,username TEXT,password TEXT)');
                $insert=$authDb->prepare('INSERT OR IGNORE INTO users VALUES(?,?,?,?)');
                foreach (array_slice($users,0,1000) as $user) {
                    if (!is_array($user) || empty($user['password'])) continue;
                    $insert->execute([(int)$user['id'],(string)($user['email']??''),(string)($user['username']??''),(string)$user['password']]);
                }
                $configuredEmail=getenv('DECOY_AUTH_EMAIL')?:'';$configuredPass=getenv('DECOY_AUTH_PASSWORD')?:'';
                if ($configuredEmail!=='' && $configuredPass!=='') $insert->execute([2147483647,$configuredEmail,$configuredEmail,$configuredPass]);
                $authDb->exec('PRAGMA query_only=ON');
                $name=substr($identityText,0,2048);$pass=substr($passwordText,0,2048);
                $safe=$authDb->prepare('SELECT id,email,username FROM users WHERE (email=? OR username=?) AND password=? LIMIT 1');
                $safe->execute([$name,$name,$pass]);$normalAccount=$safe->fetch(PDO::FETCH_ASSOC);
                $account=$demoSql ? $authDb->query("SELECT id,email,username FROM users WHERE email='$name' AND password='$pass' OR username='$name' AND password='$pass' LIMIT 1")->fetch(PDO::FETCH_ASSOC) : $normalAccount;
            } catch (PDOException $error) { dg_auth_fail(400,'Local authentication query rejected'); }
        }
        if (!$account || $identityText==='' || $passwordText==='') dg_auth_fail(401,'Invalid local decoy credentials');
        $GLOBALS['DG_EXPLOIT_RESULT']=$normalAccount?'normal_login':'sql_authentication_bypass';
        header('X-DecoyGuard-Exploit-Result: '.$GLOBALS['DG_EXPLOIT_RESULT']);
        $record['id']=(int)$account['id'];$identityValue=$account['email'];
        $input['email']=$account['email'];$input['username']=$account['username'];
        $identity = [
            'id' => $record['id'],
            'email' => isset($input['email'])
                ? (string) $input['email']
                : (string) $identityValue,
            'username' => isset($input['username'])
                ? (string) $input['username']
                : (string) $identityValue,
            'authenticated' => true
        ];

        if (!isset($state['sessions']) ||
            !is_array($state['sessions'])) {
            $state['sessions'] = [];
        }

        /*
         * Give framework clients an opaque LOCAL token-shaped value.
         * It has no relationship to a real account or upstream token.
         */
        $encodePart = static function (array $part): string {
            return rtrim(strtr(base64_encode(json_encode($part)), '+/', '-_'), '=');
        };
        $jwtHeader = $encodePart(['alg' => 'HS256', 'typ' => 'JWT']);
        $jwtBody = $encodePart([
            'id' => $identity['id'],
            'email' => $identity['email'],
            'data' => ['id' => $identity['id'], 'email' => $identity['email']],
            'iat' => time(), 'exp' => time() + 3600,
            'iss' => 'DecoyGuard-Local', 'jti'=>bin2hex(random_bytes(16))
        ]);
        $jwtUnsigned = $jwtHeader . '.' . $jwtBody;
        $sessionToken = $jwtUnsigned . '.' . rtrim(strtr(base64_encode(
            hash_hmac('sha256', $jwtUnsigned, 'decoyguard-local-only', true)
        ), '+/', '-_'), '=');

        $basketId = (int) $identity['id'];
        if (count($state['sessions'])>=512) dg_fail(503,'Local session limit reached');
        $state['sessions'][hash('sha256',$sessionToken)] = [
            'identity'=>$identity,'created_at'=>gmdate('c'),'expires_at'=>time()+3600,'basket_id'=>$basketId
        ];
        dg_session_cookie($sessionToken,time()+3600);
        // Never keep submitted credentials or login records in resource collections.
        $record=$identity;
        $bucket['records'][] = $record;
        $bucket['latest'] = $record;

        dg_save_state($stateFile, $state);

        http_response_code(200);
        header(
            'Content-Type: application/json; charset=utf-8'
        );
        header('Cache-Control: no-store');
        header(
            'X-DecoyGuard-Replay: synthetic-session'
        );

        echo json_encode([
            'status' => 'success',
            'decoy' => true,

            /*
             * Common auth response shapes are supplied together.
             * Unknown frontend clients can consume whichever field
             * they normally inspect.
             */
            'authentication' => [
            'token' => $sessionToken,
            'bid' => $basketId,
            'umail' => $identity['email'],
            'identity' => $identity
        ],

            'token' => $sessionToken,
            'user' => $identity,

            'data' => [
                'token' => $sessionToken,
                'id' => $identity['id'],
                'email' => $identity['email'],
                'username' => $identity['username'],
                'authenticated' => true
            ]
        ], JSON_UNESCAPED_SLASHES);

        exit;
    }

    /*
     * Ordinary synthetic resource creation.
     */
    $bucket['records'][] = $record;
    $bucket['latest'] = $record;

    /*
     * Record simple foreign-key relationships. This is useful for
     * cart/basket/order-item style APIs without naming one specific
     * application.
     */
    if (!isset($state['relations']) ||
        !is_array($state['relations'])) {
        $state['relations'] = [];
    }

    $relations = [];

    foreach ($record as $key => $value) {
        $keyString = (string) $key;

        if (
            preg_match('/(?:Id|_id)$/i', $keyString) &&
            is_scalar($value)
        ) {
            $relations[$keyString] = $value;
        }
    }

    if (!empty($relations)) {
        $state['relations'][$resourceKey][] = [
            'record_id' => $record['id'],
            'links' => $relations
        ];
    }

    dg_save_state($stateFile, $state);

    http_response_code(201);
    header(
        'Content-Type: application/json; charset=utf-8'
    );
    header('Cache-Control: no-store');
    header(
    'X-DecoyGuard-Replay: synthetic-write'
);

echo json_encode([
    'status' => 'success',
    'decoy' => true,
    'data' => $record
], JSON_UNESCAPED_SLASHES);

exit;
}
    if ($method === 'PUT' || $method === 'PATCH') {
        $identifier=$urlIdentifier ?? ($input['id']??null);
        if (!is_scalar($identifier)) dg_fail(400,'Update requires a record ID');
        $existing=null;
        foreach ($bucket['records'] as $row) if (is_array($row) && isset($row['id']) && (string)$row['id']===(string)$identifier) { $existing=$row; break; }
        if ($existing===null) dg_fail(404,'Local record not found');
        if (isset($input['id']) && (string)$input['id']!==(string)$identifier) dg_fail(409,'Body ID does not match the requested record');
        $record=array_replace_recursive($existing,$input);
        $record['id']=$existing['id'];

        $record['_decoy'] = true;
        $record['_resource'] = $resourceKey;

        $bucket['latest'] = $record;

        $updated = false;

        foreach ($bucket['records'] as $index => $stored) {
            if (
                isset($stored['id'], $record['id']) &&
                (string) $stored['id'] ===
                (string) $record['id']
            ) {
                $bucket['records'][$index] = $record;
                $updated = true;
                break;
            }
        }

        if (!$updated) {
            $bucket['records'][] = $record;
        }

        dg_save_state($stateFile, $state);

        http_response_code(200);
        header(
            'Content-Type: application/json; charset=utf-8'
        );
        header('Cache-Control: no-store');
        header('X-DecoyGuard-Replay: synthetic-write');

        echo json_encode([
            'status' => 'success',
            'decoy' => true,
            'data' => $record
        ]);

        exit;
    }

    /*
     * DELETE remains local. If the URL identifies a record,
     * remove the matching synthetic record when possible.
     */
    if ($method === 'DELETE') {
        $identifier=$urlIdentifier;
        if ($identifier===null) dg_fail(400,'Delete requires a member URL');
        $found=false;
        foreach ($bucket['records'] as $row) if (is_array($row) && isset($row['id']) && (string)$row['id']===(string)$identifier) { $found=true; break; }
        if (!$found) dg_fail(404,'Local record not found');

        if (is_array($bucket['records'])) {
            $bucket['records'] = array_values(
                array_filter(
                    $bucket['records'],
                    function ($record) use ($identifier) {
                        if (!is_array($record)) {
                            return true;
                        }

                        if (!array_key_exists('id', $record)) {
                            return true;
                        }

                        return (string) $record['id'] !==
                            (string) $identifier;
                    }
                )
            );
        }

        $bucket['latest'] =
            !empty($bucket['records'])
                ? end($bucket['records'])
                : null;

        dg_save_state($stateFile, $state);

        http_response_code(200);
        header(
            'Content-Type: application/json; charset=utf-8'
        );
        header('Cache-Control: no-store');
        header('X-DecoyGuard-Replay: synthetic-write');

        echo json_encode([
            'status' => 'success',
            'decoy' => true,
            'data' => null
        ]);

        exit;
    }
}

if (!is_file($catalogFile)) {
    dg_fail(503, 'Captured API catalog unavailable');
}

$catalog = json_decode(
    (string) file_get_contents($catalogFile),
    true
);

if (!is_array($catalog)) {
    dg_fail(503, 'Captured API catalog invalid');
}

$requestUri = $_SERVER['REQUEST_URI'] ?? '/';

$requestPath = parse_url($requestUri, PHP_URL_PATH);
$requestQuery = parse_url($requestUri, PHP_URL_QUERY);

$requestPath = is_string($requestPath) ? $requestPath : '/';

if ($requestPath !== '/') {
    $requestPath = rtrim($requestPath, '/');
}

$requestQuery = dg_normalize_query(
    is_string($requestQuery) ? $requestQuery : ''
);

// Optional captured-contract compatibility; no original server is contacted.
if ($juiceShop && in_array($method,['GET','HEAD'],true)) {
    $state=dg_load_state($stateFile); $session=dg_active_session($state);
    $lowerPath=strtolower($requestPath);
    if ($lowerPath==='/rest/saveloginip') {
        if ($session===null) dg_auth_fail(401,'No active local session');
        dg_lock_state($stateFile);$state=dg_load_state($stateFile);$key=dg_session_key();
        if (dg_active_session($state)===null) dg_auth_fail(401,'No active local session');
        $state['sessions'][$key]['identity']['lastLoginIp']=$_SERVER['REMOTE_ADDR']??'Not recorded';
        dg_save_state($stateFile,$state);header('Content-Type: application/json');header('Cache-Control: no-store');
        if ($method!=='HEAD') echo json_encode(['status'=>'success']);exit;
    }
    if (preg_match('#^/rest/basket/([0-9]+)$#',$lowerPath,$basketMatch)) {
        if ($session===null) dg_auth_fail(401,'Sign in to view your local basket');
        if ((string)$session['basket_id']!==$basketMatch[1]) dg_fail(403,'Basket does not belong to this local session');
        $products=dg_product_rows($catalog,$state);$items=[];
        foreach (($state['resources']??[]) as $path=>$bucket) {
            if (strtolower($path)!=='/api/basketitems') continue;
            foreach (($bucket['records']??[]) as $item) {
                if (!is_array($item) || (string)($item['BasketId']??'')!==$basketMatch[1]) continue;
                $product=$products[(string)($item['ProductId']??'')]??null;
                if (!is_array($product)) continue;
                $product['BasketItem']=$item;$items[]=$product;
            }
        }
        header('Content-Type: application/json');header('Cache-Control: no-store');
        if ($method!=='HEAD') echo json_encode(['status'=>'success','data'=>['id'=>$session['basket_id'],'Products'=>$items]]);
        exit;
    }
}

// Juice Shop requests individual products separately from its captured search list.
// Ignore only the frontend's date cache-buster; use real local product IDs.
if ($juiceShop && ($method==='GET' || $method==='HEAD') &&
    preg_match('#^/api/products(?:/([0-9]+))?/?$#i',$requestPath,$productMatch)) {
    $products=dg_product_rows($catalog,dg_load_state($stateFile));
    if (isset($productMatch[1])) {
        if (!isset($products[$productMatch[1]])) dg_fail(404,'Local product not found');
        $answer=$products[$productMatch[1]];
    } else {
        $answer=array_values($products);
    }
    header('Content-Type: application/json');header('Cache-Control: no-store');
    header('X-DecoyGuard-Replay: local-product-catalog');
    if ($method!=='HEAD') echo json_encode(['status'=>'success','data'=>$answer],JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
// Missing captures are not evidence of real reviews. Keep an explicit local-only
// review collection so a product dialog can render without inventing source reviews.
if ($juiceShop && ($method==='GET' || $method==='HEAD') &&
    preg_match('#^/rest/products/([0-9]+)/reviews/?$#i',$requestPath,$reviewMatch)) {
    $localState=dg_load_state($stateFile);$products=dg_product_rows($catalog,$localState);
    if (!isset($products[$reviewMatch[1]])) dg_fail(404,'Local product not found');
    $rows=$localState['resources'][rtrim($requestPath,'/')]['records']??[];
    // Prefer supplied captured reviews when no local collection has been written.
    if (!isset($localState['resources'][rtrim($requestPath,'/')]))
        $rows=dg_captured_records($catalogFile,rtrim($requestPath,'/'));
    header('Content-Type: application/json');header('Cache-Control: no-store');
    header('X-DecoyGuard-Replay: local-review-collection');
    if ($method!=='HEAD') echo json_encode(['status'=>'success','data'=>array_values($rows)],JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

// Model a captured collection's search contract without a website-specific UI handler.
if ($method === 'GET' || $method === 'HEAD') {
    parse_str($requestQuery, $searchParams);
    $searchKey = null;
    foreach (['q', 'search', 'query', 'term'] as $key) {
        if (isset($searchParams[$key]) && is_scalar($searchParams[$key])) { $searchKey = $key; break; }
    }
    if ($searchKey !== null) {
        $best = null; $records = []; $wrapped = false;
        foreach ($catalog['responses'] ?? [] as $response) {
            if (!is_array($response) || !empty($response['body_truncated']) ||
                strtoupper($response['method'] ?? 'GET') !== 'GET' ||
                (int)($response['status'] ?? 200) !== 200 ||
                rtrim(parse_url($response['url'] ?? '', PHP_URL_PATH) ?: '/', '/') !== rtrim($requestPath, '/')) continue;
            parse_str(parse_url($response['url'] ?? '', PHP_URL_QUERY) ?: '', $capturedParams);
            $other = $searchParams; unset($other[$searchKey]); unset($capturedParams[$searchKey]);
            if ($other != $capturedParams) continue;
            $decoded = json_decode($response['body'] ?? '', true);
            if (!is_array($decoded)) continue;
            $isWrapped = isset($decoded['data']) && is_array($decoded['data']) && array_is_list($decoded['data']);
            $collection = $isWrapped ? $decoded['data'] : (array_is_list($decoded) ? $decoded : null);
            if ($collection === null || ($best !== null && count($collection) <= count($records))) continue;
            $best = $decoded; $records = $collection; $wrapped = $isWrapped;
        }
        if ($best !== null) {
            $searchState=dg_load_state($stateFile);
            $searchBucket=$searchState['resources'][dg_resource_key($requestPath)]??null;
            if (is_array($searchBucket) && is_array($searchBucket['records']??null)) $records=$searchBucket['records'];
            $term = substr((string)$searchParams[$searchKey], 0, 2048);
            try {
                // Fresh dummy DB per request; no persistent/source database is opened.
                $searchDb = new PDO('sqlite::memory:', null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
                $searchDb->exec('CREATE TABLE items(label TEXT, payload TEXT)');
                $insert = $searchDb->prepare('INSERT INTO items VALUES (?, ?)');
                foreach ($records as $item) {
                    if (!is_array($item)) continue;
                    $text = [];
                    foreach (['name', 'title', 'description', 'label', 'summary'] as $field) {
                        if (isset($item[$field]) && is_scalar($item[$field])) $text[] = (string)$item[$field];
                    }
                    if (!$text) foreach ($item as $value) if (is_string($value)) $text[] = $value;
                    $insert->execute([implode(' ', $text), json_encode($item, JSON_INVALID_UTF8_SUBSTITUTE)]);
                }
                $searchDb->exec('PRAGMA query_only=ON');
                $baseline = $searchDb->prepare("SELECT payload FROM items WHERE label LIKE ? ESCAPE '\\'");
                $literal = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $term);
                $baseline->execute(['%' . $literal . '%']);
                $normal = $baseline->fetchAll(PDO::FETCH_COLUMN);
                if (($catalog['demo_sqli'] ?? false) === true) {
                    // Explicit demo mode: intentional SQL injection, only over the dummy table.
                    $rows = $searchDb->query("SELECT payload FROM items WHERE label LIKE '%$term%'")->fetchAll(PDO::FETCH_COLUMN);
                    $GLOBALS['DG_EXPLOIT_RESULT'] = count($rows) > count($normal) ? 'search_results_expanded' : 'search_completed';
                    header('X-DecoyGuard-Exploit-Result: ' . $GLOBALS['DG_EXPLOIT_RESULT']);
                } else {
                    $rows = $normal;
                }
                $result = [];
                foreach ($rows as $row) {
                    $item = json_decode((string)$row, true);
                    if (is_array($item)) $result[] = $item;
                }
                $answer = $best;
                if ($wrapped) $answer['data'] = $result; else $answer = $result;
                header('Content-Type: application/json; charset=utf-8');
                header('Cache-Control: no-store');
                header('X-DecoyGuard-Replay: local-collection-search');
                header('X-DecoyGuard-Demo-SQLi: ' . (!empty($catalog['demo_sqli']) ? 'enabled' : 'disabled'));
                if ($method !== 'HEAD') echo json_encode($answer, JSON_INVALID_UTF8_SUBSTITUTE);
                exit;
            } catch (PDOException $error) {
                $GLOBALS['DG_EXPLOIT_RESULT'] = 'query_rejected';
                dg_fail(400, 'Local search query rejected');
            }
        }
    }
}

/* Resolve uncaptured members only from an observed exact collection URL.
 * Never guess a collection, ignore filters, or replay an old row after a local
 * collection has been written. Returned records remain decoy-local evidence. */
if ($method==='GET' || $method==='HEAD') {
    $memberKey=dg_resource_key($requestPath);
    $memberId=$memberKey!==$requestPath ? basename($requestPath) : null;
    $localState=dg_load_state($stateFile);
    if ($memberId!==null && !isset($localState['resources'][$memberKey]) &&
        !preg_match('#/(?:users?|accounts?|sessions?|tokens?|payments?|cards?)(?:/|$)#i',$memberKey)) {
        $rows=dg_captured_records($catalogFile,$memberKey);
        if ($rows) {
            $found=null;
            foreach ($rows as $row) if ((string)($row['id']??'')===(string)$memberId) { $found=$row;break; }
            if ($found===null) dg_fail(404,'Record not found in captured local collection');
            header('Content-Type: application/json');header('Cache-Control: no-store');
            header('X-DecoyGuard-Replay: captured-collection-member');
            if ($method!=='HEAD') echo json_encode(['status'=>'success','decoy'=>true,'data'=>dg_public_value($found)],JSON_INVALID_UTF8_SUBSTITUTE);
            exit;
        }
    }
}

/*
 * Synthetic identity/session reads.
 *
 * Authentication-like writes establish token-indexed local sessions.
 * Identity reads require the matching bearer token or per-site cookie.
 */
if ($method === 'GET' || $method === 'HEAD') {
    $state = dg_load_state($stateFile);

    $pathLower = strtolower($requestPath);

    $looksLikeIdentity =
        str_contains($pathLower, 'whoami') ||
        str_contains($pathLower, 'who-am-i') ||
        str_contains($pathLower, 'current-user') ||
        str_contains($pathLower, 'current_user') ||
        str_contains($pathLower, 'currentuser') ||
        preg_match('#/(?:me)(?:/|$)#', $pathLower) === 1 ||
        str_contains($pathLower, 'profile') ||
        str_contains($pathLower, 'identity') ||
        str_contains($pathLower, 'session');

    $sessionKey=dg_session_key();
    $session=$sessionKey!==null ? ($state['sessions'][$sessionKey]??null) : null;
    if (!is_array($session) || ($session['expires_at']??0)<time()) $session=null;
    if ($looksLikeIdentity && $session===null) {
        if ($juiceShop) {
            header('Content-Type: application/json');header('Cache-Control: no-store');
            if ($method!=='HEAD') echo json_encode(['user'=>(object)[],'data'=>(object)[]]);
            exit;
        }
        dg_fail(401,'No active local session');
    }

    if ($looksLikeIdentity && $session !== null) {
        $identity = (
            isset($session['identity']) &&
            is_array($session['identity'])
        )
            ? $session['identity']
            : [];

        http_response_code(200);
        header(
            'Content-Type: application/json; charset=utf-8'
        );
        header('Cache-Control: no-store');
        header(
            'X-DecoyGuard-Replay: synthetic-session'
        );

        if ($method !== 'HEAD') {
            echo json_encode([
                'status' => 'success',
                'decoy' => true,

                /*
                 * Return both conventional representations.
                 */
                'user' => $identity,
                'data' => $identity
            ], JSON_UNESCAPED_SLASHES);
        }

        exit;
    }
}

/*
 * Synthetic state overlay.
 *
 * A resource created or modified inside the decoy should be visible
 * to later GET requests without contacting the original application.
 */
 
if ($method === 'GET' || $method === 'HEAD') {
    $state = dg_load_state($stateFile);
    $resourceKey = dg_resource_key($requestPath);

    $bucket = (
        isset($state['resources'][$resourceKey]) &&
        is_array($state['resources'][$resourceKey])
    )
        ? $state['resources'][$resourceKey]
        : null;

    if ($bucket !== null) {
        $records = (
            isset($bucket['records']) &&
            is_array($bucket['records'])
        )
            ? $bucket['records']
            : [];

        /*
         * If this looks like a member URL:
         *
         *     /api/items/1001
         *
         * return that individual synthetic record.
         */
        $parts = explode(
            '/',
            trim($requestPath, '/')
        );

        $identifier = end($parts);
        $baseKey = dg_resource_key($requestPath);
        $isMemberRequest = ($baseKey !== $requestPath);

        if ($isMemberRequest) {
            foreach ($records as $record) {
                if (
                    is_array($record) &&
                    array_key_exists('id', $record) &&
                    (string) $record['id'] ===
                        (string) $identifier
                ) {
                    http_response_code(200);
                    header(
                        'Content-Type: application/json; charset=utf-8'
                    );
                    header('Cache-Control: no-store');
                    header(
                        'X-DecoyGuard-Replay: synthetic-state'
                    );

                    if ($method !== 'HEAD') {
                        echo json_encode(
                            [
                                'status' => 'success',
                                'decoy' => true,
                                'data' => dg_public_value($record)
                            ],
                            JSON_UNESCAPED_SLASHES |
                            JSON_UNESCAPED_UNICODE
                        );
                    }

                    exit;
                }
            }
        }

        if ($isMemberRequest) dg_fail(404,'Local record not found');

        /*
         * Collection read.
         *
         * Preserve a conventional { data: [...] } representation so
         * frontend code can consume locally-created resources.
         */
        if (is_array($records)) {
            http_response_code(200);
            header(
                'Content-Type: application/json; charset=utf-8'
            );
            header('Cache-Control: no-store');
            header(
                'X-DecoyGuard-Replay: synthetic-state'
            );

            if ($method !== 'HEAD') {
                echo json_encode(
                    [
                        'status' => 'success',
                        'decoy' => true,
                        'data' => dg_public_value(array_values($records))
                    ],
                    JSON_UNESCAPED_SLASHES |
                    JSON_UNESCAPED_UNICODE
                );
            }

            exit;
        }
    }
}

foreach (($catalog['responses'] ?? []) as $response) {
    if (!is_array($response)) {
        continue;
    }

    $storedMethod = strtoupper(
        (string) ($response['method'] ?? 'GET')
    );

    if ($storedMethod !== 'GET' && $storedMethod !== 'HEAD') {
        continue;
    }

    $storedUrl = (string) ($response['url'] ?? '');

    $storedPath = parse_url($storedUrl, PHP_URL_PATH);
    $storedQuery = parse_url($storedUrl, PHP_URL_QUERY);

    $storedPath = is_string($storedPath) ? $storedPath : '/';

    if ($storedPath !== '/') {
        $storedPath = rtrim($storedPath, '/');
    }

    $storedQuery = dg_normalize_query(
        is_string($storedQuery) ? $storedQuery : ''
    );

    if (
        $storedPath !== $requestPath ||
        $storedQuery !== $requestQuery
    ) {
        continue;
    }

    $status = (int) ($response['status'] ?? 200);

    if ($status < 100 || $status > 599) {
        $status = 200;
    }

    http_response_code($status);

    $headers = $response['response_headers']
        ?? $response['headers']
        ?? [];

    $contentType = '';

    if (is_array($headers)) {
        foreach ($headers as $name => $value) {
            if (strtolower((string) $name) === 'content-type') {
                $contentType = (string) $value;
                break;
            }
        }
    }

    if ($contentType === '') {
        $contentType = (string) (
            $response['content_type']
            ?? 'application/json; charset=utf-8'
        );
    }

    # Only replay the useful representation header.
    # Do not replay upstream cookies, CORS or transport headers.
    header('Content-Type: ' . $contentType);
    header('Cache-Control: no-store');
    header('X-DecoyGuard-Replay: captured');

    if ($method !== 'HEAD') {
        echo (string) ($response['body'] ?? '');
    }

    exit;
}

/* Generic basket/cart collection fallback, entirely local. */
if ($method === 'GET' || $method === 'HEAD') {
    $lowerPath = strtolower($requestPath);
    if (preg_match('#/(?:basketitems|cartitems|basket|cart)(?:/|$)#', $lowerPath)) {
        $state = dg_load_state($stateFile);
        $items = [];
        foreach (($state['resources'] ?? []) as $key => $bucket) {
            if (preg_match('#/(?:basketitems|cartitems)$#i', (string) $key)) {
                foreach (($bucket['records'] ?? []) as $record) {
                    if (is_array($record)) $items[] = $record;
                }
            }
        }
        http_response_code(200);
        header('Content-Type: application/json; charset=utf-8');
        header('X-DecoyGuard-Replay: synthetic-cart');
        if ($method !== 'HEAD') {
            echo json_encode(['status' => 'success', 'data' => $items], JSON_UNESCAPED_SLASHES);
        }
        exit;
    }
}
dg_fail(404, 'No captured response for this request');
'''

        runtime_path = Path(self.output_dir, "decoy_api.php")
        runtime_tmp = runtime_path.with_name(runtime_path.name + "." + uuid.uuid4().hex + ".tmp")
        try:
            runtime_tmp.write_text(api_php, encoding="utf-8")
            os.replace(runtime_tmp, runtime_path)
        finally:
            runtime_tmp.unlink(missing_ok=True)

        Path(self.output_dir, "decoy_socket.php").write_text(
            r'''<?php
// Minimal Engine.IO 4 / Socket.IO default-namespace polling. No upstream requests.
declare(strict_types=1);
header('Cache-Control: no-store');
header('Content-Type: text/plain; charset=UTF-8');
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
if (($_GET['EIO'] ?? '') !== '4' || ($_GET['transport'] ?? '') !== 'polling' || !in_array($method, ['GET', 'POST'], true)) {
    http_response_code(400); echo 'Unsupported local socket transport'; exit;
}
$sid = $_GET['sid'] ?? '';
$opening = $sid === '' && $method === 'GET';
if ($opening) $sid = bin2hex(random_bytes(16));
if (!is_string($sid) || !preg_match('/^[a-f0-9]{32}$/', $sid)) { http_response_code(400); exit; }
ini_set('session.use_cookies', '0');
ini_set('session.use_only_cookies', '0');
session_name('DGSOCKET');
session_id('dg-socket-' . $sid);
if (!session_start()) { http_response_code(503); exit; }
if ($opening) {
    $_SESSION = ['opened'=>time(), 'announced'=>false, 'pending_connect'=>false];
    session_write_close();
    echo '0' . json_encode(['sid'=>$sid, 'upgrades'=>[], 'pingInterval'=>25000, 'pingTimeout'=>20000, 'maxPayload'=>65536]);
    exit;
}
if (!isset($_SESSION['opened'])) { session_write_close(); http_response_code(400); echo 'Unknown local socket'; exit; }
if ($method === 'POST') {
    $packet = file_get_contents('php://input', false, null, 0, 65536);
    if ($packet === '40' || str_starts_with($packet, '40{')) $_SESSION['pending_connect'] = true;
    elseif ($packet === '1') $_SESSION = [];
    elseif ($packet !== '3' && !str_starts_with($packet, '42[')) { session_write_close(); http_response_code(501); echo 'Realtime application events are not simulated'; exit; }
    // Application event packets are observed by middleware only; no challenge completion is emitted.
    session_write_close(); echo 'ok'; exit;
}
if (!empty($_SESSION['pending_connect']) && empty($_SESSION['announced'])) {
    $_SESSION['announced'] = true; session_write_close();
    echo '40' . json_encode(['sid'=>$sid]); exit;
}
session_write_close();
// Long-poll instead of an immediate error/reconnect loop. Apache handles other requests concurrently.
usleep(10000000);
echo '2';
''',
            encoding="utf-8"
        )

        print(
            "[OK] Captured read-only API replay generated "
            f"({len(self.api_responses)} responses)."
        )

    def _capture_interaction_panels(self, page):
        """Retain discoverable popup content before source scripts are removed."""
        try:
            page.evaluate(CAPTURE_INTERACTION_PANELS_JS)
        except Exception as error:
            print("[!] Optional menu capture: " + ascii(str(error)))

    def generate_navigation_guard(self):
        """Contain the mirrored frontend while preserving its own UI behavior."""
        target = json.dumps(self.target_url)
        host = json.dumps(self.target_host)

        runtime = r"""
    (() => {
        "use strict";

        const TARGET_URL = __TARGET_URL__;
        const TARGET_HOST = __TARGET_HOST__;
        const LOCAL = location.origin;

        const norm = h => String(h || "")
            .toLowerCase()
            .replace(/^www\./, "");

        const belongs = h => {
            const a = norm(h), b = norm(TARGET_HOST);
            return a === b || a.endsWith("." + b) || b.endsWith("." + a);
        };

        function localURL(value) {
            if (!value) return value;

            const raw = String(value).trim();

            if (
                raw.startsWith("#") ||
                raw.startsWith("data:") ||
                raw.startsWith("blob:") ||
                raw.startsWith("javascript:")
            ) return value;

            if (raw.startsWith("mailto:") || raw.startsWith("tel:"))
                return "#";

            try {
                const u = new URL(raw, TARGET_URL);

                if (u.origin === LOCAL)
                    return u.pathname + u.search + u.hash;

                if (belongs(u.hostname))
                    return u.pathname + u.search + u.hash;

                if (u.protocol === "http:" || u.protocol === "https:")
                    return "/_external/" +
                        encodeURIComponent(u.hostname) +
                        u.pathname + u.search + u.hash;

            } catch (_) {}

            return value;
        }

        /* -------------------------------------------------------
        NETWORK CONTAINMENT
        Keep application JS alive, but redirect its requests
        into the local decoy.
        ------------------------------------------------------- */

        // A stale source service worker must not bypass the local request boundary.
        if (navigator.serviceWorker) {
            navigator.serviceWorker.getRegistrations().then(items => items.forEach(item => item.unregister())).catch(() => {});
            navigator.serviceWorker.register = () => Promise.reject(new Error("Service workers are disabled in the decoy"));
        }

        const realFetch = window.fetch.bind(window);

        window.fetch = function(input, init) {
            try {
                const original =
                    input instanceof Request ? input.url : input;

                const mapped = localURL(original);

                if (input instanceof Request)
                    input = new Request(mapped, input);
                else
                    input = mapped;
            } catch (_) {}

            return realFetch(input, init);
        };

        const realOpen = XMLHttpRequest.prototype.open;

        XMLHttpRequest.prototype.open = function(
            method, url, ...rest
        ) {
            return realOpen.call(
                this,
                method,
                localURL(url),
                ...rest
            );
        };

        // Hash-router queries never reach HTTP automatically. Observe them without
        // replacing the application's controls, filtering, or rendering behavior.
        let queryTimer = null;
        let lastClientQuery = '';
        function reportClientQuery() {
            const fragment = location.hash.slice(1);
            const split = fragment.indexOf('?');
            if (split < 0) return;
            const params = new URLSearchParams(fragment.slice(split + 1));
            const fields = {};
            for (const key of ['q', 'search', 'query', 'term']) {
                const value = params.get(key);
                if (value) fields[key] = value.slice(0, 2048);
            }
            if (!Object.keys(fields).length) { lastClientQuery = ''; return; }
            const payload = { interaction: 'hash-query', client_route: fragment.slice(0, 4096), fields };
            const signature = JSON.stringify(payload);
            if (signature === lastClientQuery) return;
            lastClientQuery = signature;
            realFetch('/decoy_api.php?__dg_client_event=1', {
                method: 'POST', headers: {'Content-Type': 'application/json'},
                body: signature, credentials: 'same-origin'
            }).then(response => {
                if (!response.ok) console.warn('DecoyGuard: client interaction capture returned HTTP ' + response.status);
            }).catch(error => console.warn('DecoyGuard: client interaction capture failed', error));
        }
        function scheduleClientQuery() {
            clearTimeout(queryTimer);
            queryTimer = setTimeout(reportClientQuery, 250);
        }
        for (const name of ['pushState', 'replaceState']) {
            const original = history[name];
            history[name] = function(...args) {
                const result = original.apply(this, args);
                scheduleClientQuery();
                return result;
            };
        }
        addEventListener('hashchange', scheduleClientQuery);
        addEventListener('popstate', scheduleClientQuery);
        scheduleClientQuery();

        const NativeWebSocket = window.WebSocket;

        window.WebSocket = function(url, protocols) {
            try {
                const u = new URL(url, TARGET_URL);

                /*
                * Do not reconnect to the real application's
                * WebSocket backend from the deployed decoy.
                */
                if (belongs(u.hostname)) {
                    const local =
                        (location.protocol === "https:" ? "wss://" : "ws://") +
                        location.host +
                        "/__decoy_ws" +
                        u.pathname +
                        u.search;

                    return protocols
                        ? new NativeWebSocket(local, protocols)
                        : new NativeWebSocket(local);
                }
            } catch (_) {}

            return protocols
                ? new NativeWebSocket(url, protocols)
                : new NativeWebSocket(url);
        };

        window.WebSocket.prototype = NativeWebSocket.prototype;

        if (navigator.sendBeacon) {
            const beacon = navigator.sendBeacon.bind(navigator);

            navigator.sendBeacon = function(url, data) {
                return beacon(localURL(url), data);
            };
        }

        /* -------------------------------------------------------
        NAVIGATION CONTAINMENT
        ------------------------------------------------------- */

        document.addEventListener("click", e => {
            const a = e.target.closest("a[href]");
            if (!a) return;

            const old = a.getAttribute("href");
            const next = localURL(old);

            if (next && next !== old)
                a.setAttribute("href", next);
        }, true);

       document.addEventListener("submit", e => {
        const form = e.target;
        if (!(form instanceof HTMLFormElement)) return;

        const method = String(
            form.getAttribute("method") || "GET"
        ).toUpperCase();

        /*
        * GET forms may navigate, so keep their destination local.
        */
        if (method === "GET") {
            const action = localURL(
                form.getAttribute("action") ||
                location.pathname
            );

            form.setAttribute("action", action);
            return;
        }

        /*
        * Do not cancel framework-controlled submissions here.
        *
        * Angular/React/Vue handlers need to receive the submit event
        * so they can issue their own fetch/XHR. DecoyGuard contains
        * those network calls separately.
        *
        * Native non-GET form containment is handled by the request
        * boundary rather than blocking the framework's event.
        */
    }, false);

        /* -------------------------------------------------------
        DYNAMIC DOM
        Rewrite links inserted later by React/Angular/etc.
        ------------------------------------------------------- */

        function rewrite(root) {
            if (!root || !root.querySelectorAll) return;

            const nodes = [];

            if (root.matches?.("[href],[action]"))
                nodes.push(root);

            nodes.push(
                ...root.querySelectorAll("[href],[action]")
            );

            for (const el of nodes) {
                for (const attr of ["href", "action"]) {
                    if (!el.hasAttribute(attr)) continue;

                    const old = el.getAttribute(attr);
                    const next = localURL(old);

                    if (next && next !== old)
                        el.setAttribute(attr, next);
                }
            }
        }

        if (document.documentElement)
            rewrite(document.documentElement);

        new MutationObserver(records => {
            for (const record of records)
                for (const node of record.addedNodes)
                    if (node.nodeType === 1)
                        rewrite(node);
        }).observe(document.documentElement, {
            childList: true,
            subtree: true
        });

    })();
    """

        runtime = (
            runtime
            .replace("__TARGET_URL__", target)
            .replace("__TARGET_HOST__", host)
        )

        os.makedirs(self.assets_dir, exist_ok=True)

        path = os.path.join(
            self.assets_dir,
            "decoyguard-navigation.js"
        )

        with open(path, "w", encoding="utf-8") as f:
            f.write(runtime)

        print(
            "[OK] Frontend containment runtime generated."
        )
    def _fresh_output_directory(self):
        """Create a genuinely empty mirror root for every new target."""; target = os.path.abspath(self.output_dir)

        def _force_remove(func, path, exc_info):
            try:
                os.chmod(path, stat.S_IWRITE); func(path)
            except Exception:
                pass
        self._close_browser()
        if os.path.lexists(target):
            print('[*] Clearing previous mirrored website...'); last_error = None
            for attempt in range(1, 6):
                try:
                    shutil.rmtree(target, onerror=_force_remove); last_error = None
                    break
                except FileNotFoundError:
                    last_error = None
                    break
                except OSError as exc:
                    last_error = exc; time.sleep(0.25 * attempt)
            if os.path.lexists(target):
                raise RuntimeError(f'Could not completely clear the previous mirror at {target!r}. Refusing to mix two websites. Last cleanup error: {last_error}')
        os.makedirs(target, exist_ok=False); os.makedirs(self.assets_dir, exist_ok=True); print('[✓] Previous mirror cleared; fresh output directory created.')

    def _same_origin(self, url):
        parsed = urllib.parse.urlparse(url)
        return parsed.scheme == self.target_scheme and parsed.netloc.lower() == self.target_netloc and not parsed.username and not parsed.password

    def _read_only_browser_route(self, route):
        request = route.request
        if request.method not in ('GET', 'HEAD'):
            route.abort(); return
        if request.resource_type == 'document' and not self._same_origin(request.url):
            route.abort(); return
        route.continue_()

    def capture_document(self, raw_path, capture_seconds=45):
        """Copy one actual public document into the worker's staging directory."""
        path = normalize_document_path(raw_path)
        encoded = urllib.parse.quote(path, safe='/-_.~')
        url = urllib.parse.urlunparse((self.target_scheme, self.target_netloc, encoded, '', '', ''))
        self._deadline = time.perf_counter() + capture_seconds
        self._on_demand_read_only = True
        try:
            for _ in range(6):
                if not self._same_origin(url):
                    raise MirrorCaptureError('Source redirect left the configured origin', 502)
                response = self.session.get(url, timeout=self._request_timeout(10), allow_redirects=False)
                if response.status_code not in (301, 302, 303, 307, 308):
                    break
                url = urllib.parse.urljoin(url, response.headers.get('Location', ''))
            else:
                raise MirrorCaptureError('Too many source redirects', 502)
            if response.status_code >= 400:
                status = response.status_code if response.status_code in (403, 404, 410) else 502
                raise MirrorCaptureError('Source document unavailable', status)
            if not 200 <= response.status_code < 300:
                raise MirrorCaptureError('Source document unavailable', 502)
            content_type = response.headers.get('Content-Type', '').lower()
            if not any(value in content_type for value in ('text/html', 'application/xhtml+xml')):
                raise MirrorCaptureError('Requested resource is not an HTML document', 404)
            rendered, links = self.render_page(url)
            if not rendered:
                if self.is_framework_document(response.text):
                    raise MirrorCaptureError('Browser rendering required for this document', 503)
                rendered = response.text
            if not self.static_decoy:
                return self.native_document(response.text, url)
            soup = BeautifulSoup(rendered, 'html.parser')
            for tag in list(soup.find_all(['script', 'base', 'iframe', 'object', 'embed'])):
                tag.decompose()
            for tag in soup.find_all(True):
                for attribute in list(tag.attrs):
                    if attribute.lower().startswith('on'):
                        del tag.attrs[attribute]
            for meta in soup.find_all('meta'):
                if str(meta.get('http-equiv', '')).lower() == 'refresh':
                    meta.decompose()
            self.discovered_routes.update(urllib.parse.urlparse(link).path or '/' for link in self.discover_links(soup, url))
            self.localize_all_assets(soup, url)
            self.inspect_and_rewrite_forms(soup, path)
            self.rewrite_links(soup, url)
            guard = soup.new_tag('script', src='/assets/decoyguard-navigation.js')
            (soup.head or soup.body or soup).insert(0, guard)
            return str(soup)
        finally:
            self._deadline = None

    def generate_htaccess(self):
        """Route captured APIs locally and preserve MIME-safe asset failures."""
        content = r"""Options -Indexes

DirectoryIndex index.php index.html

RewriteEngine On

# Existing local files/directories always win.
RewriteCond %{REQUEST_FILENAME} -f [OR]
RewriteCond %{REQUEST_FILENAME} -d
RewriteRule ^ - [L]

# Captured read-only application APIs.
RewriteRule ^(?:api|rest)(?:/.*)?$ decoy_api.php [L,QSA,NC]

# Socket.IO must never escape to the original target.
RewriteRule ^socket\.io(?:/.*)?$ decoy_socket.php [L,QSA,NC]

# Never substitute HTML for a missing runtime/static resource.
RewriteRule \.(?:js|mjs|css|json|map|wasm|woff2?|ttf|otf|eot|png|jpe?g|gif|svg|webp|avif|ico|webmanifest|mp4|webm|mp3|ogg|pdf|bin)$ - [R=404,L,NC]

# Remaining document-like routes use the local on-demand mirror.
RewriteRule ^ synthetic.php [L,QSA]
"""

        path = os.path.join(self.output_dir, ".htaccess")

        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(content)

        print("[OK] Local API and document routing generated.")
    
    def generate_manifest(self):
        """Write public metadata for the completed local mirror."""
        manifest = {
            "version": 2,
            "target_url": self.target_url,
            "target_host": self.target_host,
            "pages_mirrored": len(self.visited),
            "routes": sorted(set(self.routes)),
            "discovered_routes": sorted(self.discovered_routes),
            "forms": self.forms,
            "api_routes": sorted(self.api_routes),
            # Captured response bodies stay private.
            "api_responses": [],
            "assets": {
                "total": sum(self.asset_stats.values()),
                "by_type": dict(self.asset_stats),
            },
            "backend": {
                "profile": self.backend_profile,
                "catalog": "private",
                "captured_read_responses": len(self.api_responses),
            },
            "on_demand": not self.static_decoy,
        }

        atomic_json(
            os.path.join(self.output_dir, "site_manifest.json"),
            manifest
        )

        print("[OK] Site manifest generated.")

    def generate_on_demand_config(self):
        private = os.path.join(os.path.dirname(os.path.abspath(self.output_dir)), 'private')
        os.makedirs(private, exist_ok=True)
        run_id = uuid.uuid4().hex
        root = os.path.join(private, 'mirror-queue', run_id)
        for name in ('', 'jobs', 'working', 'cache', 'status'):
            directory = os.path.join(root, name)
            os.makedirs(directory, exist_ok=True)
            os.chmod(directory, 0o777)
        config = {'version': 1, 'run_id': run_id, 'active': True,
                  'target_url': self.target_url, 'capture_seconds': 45, 'wait_seconds': 45,
                  'color_scheme': self.color_scheme, 'viewport': self.viewport,
                  'asset_map': self.downloaded_assets, 'static_decoy': self.static_decoy, 'backend_profile': self.backend_profile,
                  'captured_files': {(urllib.parse.unquote(urllib.parse.urlparse(url).path).rstrip('/') or '/'): self.get_local_page_path(url) for url in self.visited}}
        atomic_json(os.path.join(private, 'mirror_worker.json'), config)
        print('[✓] Actual on-demand capture configured; uncaptured routes wait for the local worker.')

    def clone(self):
        if self.attempted:
            raise RuntimeError('Create a new DecoyDuplicator for each clone run.')
        private = os.path.join(os.path.dirname(os.path.abspath(self.output_dir)), 'private')
        os.makedirs(private, exist_ok=True)
        with mirror_file_lock(os.path.join(private, 'publication.lock')):
            config_path = os.path.join(private, 'mirror_worker.json')
            if os.path.isfile(config_path):
                atomic_json(config_path, {'active': False})
            self._mirror_started_at = time.perf_counter()
            self._fresh_output_directory()
            try:
                self.generate_navigation_guard(); self.mirror_favicon(); self.crawl(self.target_url)
            finally:
                self._close_browser()
            self.capture_profile_assets(); self.generate_navigation_guard(); self.generate_site_profile(); self.generate_runtime_handlers(); self.generate_synthetic_config()
            self.generate_synthetic_runtime(); self.generate_htaccess(); self.generate_manifest()
            elapsed = time.perf_counter() - self._mirror_started_at
            print(f'[✓] Landing capture ready: {len(self.visited)} pages in {elapsed:.1f}s. Other documents will be copied on demand.')
        return self.output_dir


# Application replicas preserve application code and local server-side behavior.
# A URL snapshot cannot infer an arbitrary application's backend implementation.
def prepare_application_lab(banking_source, output_dir='decoy-lab'):
    """Build a local Juice Shop + Northstar banking lab from an owned ZIP/directory.

    Only schema is read from the supplied banking DB. A fresh synthetic DB is
    created. Existing lab data is never replaced by a prepare operation.
    """
    import pathlib
    import sqlite3
    import tempfile
    import zipfile

    source = pathlib.Path(banking_source).resolve()
    destination = pathlib.Path(output_dir).resolve()
    if destination.exists():
        raise FileExistsError('Lab already exists. Use a new --directory or lab reset for runtime data.')
    if not source.exists():
        raise FileNotFoundError(source)
    with tempfile.TemporaryDirectory() as temporary:
        workspace = pathlib.Path(temporary)
        extracted = workspace / 'source'
        if source.is_file():
            extracted.mkdir()
            with zipfile.ZipFile(source) as archive:
                if sum(info.file_size for info in archive.infolist()) > 100 * 1024 * 1024:
                    raise ValueError('Banking archive is too large')
                for info in archive.infolist():
                    name = info.filename.replace('\\', '/')
                    parts = pathlib.PurePosixPath(name).parts
                    if name.startswith('/') or any(part in ('.', '..') or ':' in part for part in parts):
                        raise ValueError('Unsafe archive path')
                    if stat.S_ISLNK(info.external_attr >> 16):
                        raise ValueError('Archive symlinks are not supported')
                    path = extracted.joinpath(*parts)
                    if info.is_dir(): path.mkdir(parents=True, exist_ok=True)
                    else:
                        path.parent.mkdir(parents=True, exist_ok=True)
                        path.write_bytes(archive.read(info))
        else:
            extracted = source
        candidates = [p.parent for p in extracted.rglob('index.php')
                      if (p.parent / 'includes/db.php').is_file()
                      and (p.parent / 'banking-database/website-data.db').is_file()]
        if len(candidates) != 1:
            raise ValueError('Expected one Northstar banking app with includes/db.php and banking-database/website-data.db')
        bank_source = candidates[0]
        staged = workspace / 'lab'
        bank = staged / 'banking'
        bank.mkdir(parents=True)
        for item in bank_source.rglob('*'):
            if item.is_symlink(): raise ValueError('Source symlinks are not supported')
            if item.is_file() and item.suffix.lower() in {'.php', '.css', '.js', '.png', '.svg', '.jpg', '.jpeg', '.woff', '.woff2', '.ico'}:
                relative = item.relative_to(bank_source)
                if relative.parts[0] == 'banking-database': continue
                target = bank / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(item, target)
        index = (bank / 'index.php').read_text(encoding='utf-8')
        # The replica logs probes locally instead of sending users to old ports.
        old = 'header("Location: http://localhost:8080/index.php?shunted=1");\n        exit;'
        if old not in index: raise ValueError('Banking login guard differs from the supplied Northstar version')
        index = index.replace(old, "$error = 'Invalid username or password.';")
        index, count = re.subn(r'header\(\s*"Location: http://"\s*\.\s*\(\$_SERVER\[\x27SERVER_NAME\x27\] \?\? \x27localhost\x27\)\s*\.\s*":8080/index.php\?bot_trap=1"\s*\);', "header('Location: index.php?bot_trap=1');", index)
        if count != 1: raise ValueError('Banking bot-trap redirect hook differs from the supplied version')
        (bank / 'index.php').write_text(index, encoding='utf-8')
        (bank / 'includes/guard.php').write_text("<?php\n// Replica telemetry runs via auto_prepend_file; never proxy to production.\n", encoding='utf-8')
        (bank / 'includes/db.php').write_text("""<?php
$dbPath = getenv('DECOY_BANK_DB') ?: '/var/lib/decoyguard/website-data.db';
$pdo = new PDO('sqlite:' . $dbPath);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
$pdo->exec('PRAGMA foreign_keys = ON');
$pdo->exec('PRAGMA busy_timeout = 5000');
""", encoding='utf-8')
        (bank / '.htaccess').write_text('RedirectMatch 404 "^/(includes|banking-database)(/|$)"\n', encoding='utf-8')
        seed_path = staged / 'bank-seed.db'
        original_db = sqlite3.connect((bank_source / 'banking-database/website-data.db').as_uri() + '?mode=ro', uri=True)
        seed = sqlite3.connect(seed_path)
        try:
            for name, sql in original_db.execute("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"):
                if sql: seed.execute(sql)
            salt = uuid.uuid4().hex
            password_hash = hashlib.sha256(('DemoBank2026!' + salt).encode()).hexdigest()
            seed.execute('INSERT INTO users(username,full_name,password_hash,salt) VALUES(?,?,?,?)', ('demo', 'Demo Customer', password_hash, salt))
            uid = seed.execute('SELECT id FROM users WHERE username=?', ('demo',)).fetchone()[0]
            seed.execute('INSERT INTO accounts(user_id,account_number,account_type,balance) VALUES(?,?,?,?)', (uid, '5912', 'Everyday', 24180.50))
            seed.execute('INSERT INTO transactions(user_id,transaction_type,amount,description) VALUES(?,?,?,?)', (uid, 'credit', 24180.50, 'Synthetic opening balance'))
            seed.commit()
        finally:
            original_db.close(); seed.close()
        (staged / 'Dockerfile.banking').write_text("""FROM php:8.3-apache
RUN apt-get update && apt-get install -y --no-install-recommends libsqlite3-dev && docker-php-ext-install pdo_sqlite && rm -rf /var/lib/apt/lists/*
COPY banking/ /var/www/html/
COPY bank-seed.db /opt/decoyguard/bank-seed.db
COPY telemetry.php /opt/decoyguard/telemetry.php
COPY banking.ini /usr/local/etc/php/conf.d/decoyguard.ini
COPY bank-entrypoint.sh /usr/local/bin/bank-entrypoint
RUN chmod +x /usr/local/bin/bank-entrypoint
ENTRYPOINT ["bank-entrypoint"]
CMD ["apache2-foreground"]
""", encoding='utf-8')
        (staged / 'bank-entrypoint.sh').write_text("""#!/bin/sh
set -eu
mkdir -p /var/lib/decoyguard /var/log/decoyguard
if [ ! -f /var/lib/decoyguard/website-data.db ]; then
    cp /opt/decoyguard/bank-seed.db /var/lib/decoyguard/website-data.db
fi
chown -R www-data:www-data /var/lib/decoyguard /var/log/decoyguard
exec docker-php-entrypoint "$@"
""", encoding='utf-8')
        (staged / 'banking.ini').write_text('auto_prepend_file=/opt/decoyguard/telemetry.php\ndisplay_errors=Off\nlog_errors=On\nsession.cookie_httponly=1\nsession.cookie_samesite=Lax\n', encoding='utf-8')
        (staged / 'telemetry.php').write_text(LAB_TELEMETRY_PHP, encoding='utf-8')
        (staged / 'telemetry_server.py').write_text(LAB_TELEMETRY_SERVER, encoding='utf-8')
        (staged / 'nginx.conf').write_text(LAB_NGINX_CONFIG, encoding='utf-8')
        (staged / 'compose.yaml').write_text(LAB_COMPOSE_CONFIG, encoding='utf-8')
        (staged / 'logs').mkdir()
        atomic_json(staged / 'lab_manifest.json', {
            'mode': 'application-replica', 'banking_database': 'synthetic',
            'source_database_copied': False,
            'juice_shop_url': 'http://localhost:8090', 'banking_url': 'http://localhost:8091',
            'demo_username': 'demo', 'demo_password': 'DemoBank2026!',
        })
        shutil.copytree(staged, destination)
    return str(destination)


LAB_COMPOSE_CONFIG = '''services:
  juice-shop:
    image: bkimminich/juice-shop:latest
    restart: unless-stopped
    networks: [lab]
    healthcheck:
      test: ["CMD", "/nodejs/bin/node", "-e", "fetch('http://127.0.0.1:3000/').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"]
      interval: 5s
      timeout: 3s
      start_period: 45s
      retries: 12
  banking:
    build:
      context: .
      dockerfile: Dockerfile.banking
    restart: unless-stopped
    volumes:
      - bank-state:/var/lib/decoyguard
      - ./logs:/var/log/decoyguard
    networks: [lab]
    healthcheck:
      test: ["CMD", "php", "-r", "exit(@file_get_contents('http://127.0.0.1/index.php') === false ? 1 : 0);"]
      interval: 5s
      timeout: 3s
      retries: 12
  telemetry:
    image: python:3.14-slim
    command: ["python", "/opt/telemetry_server.py"]
    volumes:
      - ./telemetry_server.py:/opt/telemetry_server.py:ro
      - ./logs:/logs
    networks: [lab]
  gateway:
    image: nginx:alpine
    restart: unless-stopped
    ports:
      - "127.0.0.1:8090:8090"
      - "127.0.0.1:8091:8091"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./logs:/var/log/decoyguard
    depends_on:
      juice-shop: {condition: service_healthy}
      banking: {condition: service_healthy}
      telemetry: {condition: service_started}
    networks: [lab, ingress]
networks:
  lab: {internal: true}
  ingress: {}
volumes:
  bank-state: {}
'''

LAB_NGINX_CONFIG = r'''events {}
http {
    map $http_upgrade $connection_upgrade { default upgrade; '' close; }
    log_format lab_json escape=json '{"timestamp":"$time_iso8601","source_ip":"$remote_addr","method":"$request_method","uri":"$request_uri","status":$status,"application":"$application","request_time":$request_time}';
    access_log /var/log/decoyguard/access.jsonl lab_json;
    error_log /var/log/decoyguard/nginx-error.log warn;
    server {
        listen 8090;
        set $application juice-shop;
        location = /_record {
            internal;
            proxy_pass http://telemetry:9000;
            proxy_set_header X-Original-URI $request_uri;
            proxy_set_header X-Original-Method $request_method;
            proxy_set_header X-Application $application;
            proxy_set_header X-Real-IP $remote_addr;
        }
        location / {
            mirror /_record;
            mirror_request_body on;
            proxy_pass http://juice-shop:3000;
            proxy_http_version 1.1;
            proxy_set_header Host $http_host;
            proxy_set_header X-Forwarded-For $remote_addr;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection $connection_upgrade;
            proxy_read_timeout 60s;
        }
    }
    server {
        listen 8091;
        set $application banking;
        location / {
            proxy_pass http://banking:80;
            proxy_set_header Host $http_host;
            proxy_set_header X-Forwarded-For $remote_addr;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
}
'''

LAB_TELEMETRY_PHP = r'''<?php
// Passive lab telemetry: do not intercept business logic or redirect users.
$uri = $_SERVER['REQUEST_URI'] ?? '/';
$body = file_get_contents('php://input');
$haystack = urldecode($uri) . ' ' . $body . ' ' . json_encode($_POST);
$suspicious = preg_match('/union\s+select|or\s+[\x27\x22]?1[\x27\x22]?\s*=\s*[\x27\x22]?1|<script|\.\.\/|sleep\s*\(/i', $haystack) === 1;
$fields = [];
foreach ($_POST as $key => $value) {
    $fields[$key] = preg_match('/password|secret|token|authorization/i', $key) ? '[redacted]' : (is_scalar($value) ? substr((string)$value, 0, 500) : '[array]');
}
$event = [
    'timestamp' => date('c'),
    'incident_id' => 'DG-LAB-' . bin2hex(random_bytes(6)),
    'source_ip' => $_SERVER['HTTP_X_FORWARDED_FOR'] ?? ($_SERVER['REMOTE_ADDR'] ?? ''),
    'method' => $_SERVER['REQUEST_METHOD'] ?? 'GET',
    'path' => parse_url($uri, PHP_URL_PATH),
    'fields' => $fields,
    'attack' => $suspicious ? 'Suspicious input in banking replica' : 'Banking replica interaction',
    'severity' => $suspicious ? 'HIGH' : 'INFO',
    'risk_score' => $suspicious ? 80 : 0,
    'decision' => 'OBSERVE', 'route' => 'LAB', 'engine' => 'Application replica',
];
@file_put_contents('/var/log/decoyguard/banking-events.jsonl', json_encode($event) . "\n", FILE_APPEND | LOCK_EX);
'''


LAB_TELEMETRY_SERVER = r'''"""Passive request observation for local application replicas."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit, parse_qs, unquote_plus
import hashlib
import json
import os
import re
import threading
import uuid

LOG = Path(os.environ.get('DECOY_LAB_LOG', '/logs/application-events.jsonl'))
LOCK = threading.Lock()
SECRET = re.compile(r'password|secret|token|authorization|cookie', re.I)
PROBE = re.compile(r"union\s+select|or\s+['\"]?1['\"]?\s*=\s*['\"]?1|['\"]\s+or\b|<script|\.\./|sleep\s*\(", re.I)

def redact(value):
    if isinstance(value, dict):
        return {str(k): '[redacted]' if SECRET.search(str(k)) else redact(v) for k,v in value.items()}
    if isinstance(value, list): return [redact(v) for v in value[:30]]
    if isinstance(value, str): return value[:500]
    return value

class Observer(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def observe(self):
        try:
            length = max(0, int(self.headers.get('Content-Length', '0')))
        except ValueError:
            self.send_error(400); return
        # Nginx mirrors a request, not a business operation. No upstream forwarding.
        body = self.rfile.read(min(length, 65536))
        remaining = length - len(body)
        while remaining:
            chunk = self.rfile.read(min(remaining, 65536))
            if not chunk: break
            remaining -= len(chunk)
        text = body.decode('utf-8', errors='replace')
        uri = self.headers.get('X-Original-URI', '/')
        content_type = self.headers.get('Content-Type', '')
        fields = {}
        if 'application/json' in content_type:
            try: fields = redact(json.loads(text))
            except ValueError: fields = {'body': '[unparseable JSON]'}
        elif 'application/x-www-form-urlencoded' in content_type:
            fields = redact(parse_qs(text, keep_blank_values=True))
        elif body: fields = {'body': '[binary or unsupported content omitted]'}
        suspect = bool(PROBE.search(unquote_plus(text + ' ' + uri)))
        event = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'incident_id': 'DG-LAB-' + uuid.uuid4().hex[:12],
            'source_ip': self.headers.get('X-Real-IP', ''),
            'application': self.headers.get('X-Application', ''),
            'method': self.headers.get('X-Original-Method', self.command),
            'path': urlsplit(uri).path, 'fields': fields,
            'attack': 'Suspicious application input' if suspect else 'Application interaction',
            'severity': 'HIGH' if suspect else 'INFO', 'risk_score': 80 if suspect else 0,
            'decision': 'OBSERVE', 'route': 'LAB', 'engine': 'Application replica',
        }
        try:
            LOG.parent.mkdir(parents=True, exist_ok=True)
            with LOCK:
                with LOG.open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps(event) + '\n')
        except OSError:
            self.send_error(503); return
        self.send_response(204); self.end_headers()
    do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = do_HEAD = do_OPTIONS = observe

if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', 9000), Observer).serve_forever()
'''

def verify_application_lab():
    """Check local replica APIs and banking session/form behavior after lab up."""
    local = requests.Session()
    local.trust_env = False  # Local checks must bypass environment HTTP proxies.
    juice = local.get('http://127.0.0.1:8090/', timeout=15)
    juice.raise_for_status()
    if '<script' not in juice.text:
        raise RuntimeError('Juice Shop application scripts are absent')
    products = local.get('http://127.0.0.1:8090/rest/products/search?q=apple', timeout=15)
    products.raise_for_status()
    if not isinstance(products.json().get('data'), list):
        raise RuntimeError('Juice Shop product API did not return a product list')
    with requests.Session() as session:
        session.trust_env = False
        login = session.post('http://127.0.0.1:8091/index.php', data={'username': 'demo', 'password': 'DemoBank2026!'}, timeout=15)
        login.raise_for_status()
        if not login.url.endswith('/mainpage.php'):
            raise RuntimeError('Banking demo login did not reach the dashboard')
        transfer = session.post('http://127.0.0.1:8091/transfer.php', data={'amount': '20', 'recipient': '12345', 'reference': 'Replica smoke check'}, timeout=15)
        transfer.raise_for_status()
        if 'Transaction completed.' not in transfer.text:
            raise RuntimeError('Banking transfer form failed')
        session.get('http://127.0.0.1:8091/logout.php', timeout=15).raise_for_status()
        protected = session.get('http://127.0.0.1:8091/mainpage.php', timeout=15)
        if not protected.url.endswith('/index.php'):
            raise RuntimeError('Banking logout did not clear the session')
    print('[OK] Juice Shop scripts/product API and banking login/transfer/logout passed.')
    return True


def mirror_engine_main():
    """Maintained CLI for static captures and native local application replicas."""
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description='DecoyGuard mirror engine')
    commands = parser.add_subparsers(dest='mode', required=True)
    capture = commands.add_parser('mirror', help='Capture a public website with on-demand pages')
    capture.add_argument('url')
    capture.add_argument('--output', default='decoy-website/public')
    capture.add_argument('--static', action='store_true')
    capture.add_argument('--max-pages', type=int, default=1)
    capture.add_argument('--max-seconds', type=float, default=60)
    capture.add_argument('--seed-route', action='append', default=[], help='Same-origin route to prioritize; repeat for multiple routes')
    capture.add_argument('--backend-profile', choices=['generic', 'banking', 'healthcare', 'industrial', 'ecommerce', 'education', 'corporate'])
    analyze = commands.add_parser('analyze', help='Inspect a saved mirror API catalog without network requests')
    analyze.add_argument('--output', default='decoy-website/public', help='Existing saved mirror public directory')
    lab = commands.add_parser('lab', help='Manage fully running local application replicas')
    lab.add_argument('action', choices=['prepare', 'up', 'down', 'status', 'reset', 'verify'])
    lab.add_argument('--directory', default='decoy-lab')
    lab.add_argument('--banking-source')
    lab.add_argument('--confirm-reset', action='store_true')
    args = parser.parse_args()
    if args.mode == 'analyze':
        private = Path(args.output).resolve().parent / 'private'
        catalog = json.loads((private / 'backend_catalog.json').read_text(encoding='utf-8'))
        report = AdaptiveSemanticAnalyzer.analyze_api_contracts(catalog.get('responses', []))
        report['application_adapters'] = [k for k, v in catalog.get('compatibility', {}).items() if v is True]
        atomic_json(private / 'api_compatibility.json', report)
        print('[OK] API compatibility report: ' + str(private / 'api_compatibility.json'))
        print('Captured contracts: ' + str(len(report['endpoints'])) + '; collection/member candidates: ' + str(len(report['collection_member_candidates'])))
        return 0
    if args.mode == 'mirror':
        DecoyDuplicator(args.url, output_dir=args.output, static_decoy=args.static, backend_profile=args.backend_profile, max_pages=args.max_pages, max_seconds=args.max_seconds, seed_routes=args.seed_route).clone()
        return 0
    if args.action == 'verify':
        try:
            return 0 if verify_application_lab() else 1
        except (requests.RequestException, ValueError, RuntimeError) as error:
            print('[FAIL] Local application verification: ' + str(error))
            print('[INFO] Check lab status and container logs; the gateway must be running on ports 8090/8091.')
            return 1
    if args.action == 'prepare':
        if not args.banking_source: parser.error('lab prepare requires --banking-source')
        result = prepare_application_lab(args.banking_source, args.directory)
        print('[OK] Prepared application replicas: ' + result)
        return 0
    try:
        from tools.deployment_manager import DeploymentManager
    except ImportError:
        from deployment_manager import DeploymentManager
    manager = DeploymentManager()
    return 0 if manager.manage_application_lab(args.action, args.directory, confirm_reset=args.confirm_reset) else 1


if __name__ == '__main__':
    raise SystemExit(mirror_engine_main())
