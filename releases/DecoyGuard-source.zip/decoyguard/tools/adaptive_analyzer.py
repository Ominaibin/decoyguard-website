import hashlib
import json
import os
import random
import re
import urllib.parse
import urllib.request

CACHE_FILE = ".ai_cache.json"
SYNTHETIC_CACHE_FILE = ".synthetic_cache.json"

ALLOWED_TYPES = {
    "EMAIL", "USERNAME", "NAME", "FIRST_NAME", "LAST_NAME", "PASSWORD",
    "MONEY", "PRICE", "CURRENCY", "INTEGER",
    "ID", "USER_ID", "ACCOUNT_ID", "PRODUCT_ID", "ORDER_ID",
    "PHONE", "ADDRESS", "CITY", "STATE", "COUNTRY", "ZIPCODE",
    "TITLE", "TEXT", "STATUS", "DATE", "DATETIME", "URL", "RATING"
}

PAGE_TYPES = {
    "HOME",
    "SEARCH",
    "LISTING",
    "DETAIL",
    "ARTICLE",
    "CATALOG",
    "PROFILE",
    "DOCUMENTATION",
    "DASHBOARD",
    "LOGIN",
    "FORM",
    "GENERIC",
}

INTERACTION_TYPES = {
    "SEARCH",
    "FILTER",
    "PAGINATION",
    "SORT",
    "NAVIGATION",
    "LOOKUP",
    "FORM_SUBMISSION",
    "UNKNOWN",
}


class AdaptiveSemanticAnalyzer:
    def __init__(self, api_endpoint=None, api_key=None):
        self.ai_enabled = os.getenv("AI_ENABLED", "false").lower() == "true"
        self.api_endpoint = api_endpoint if api_endpoint is not None else os.getenv("AI_ENDPOINT", "")
        self.api_key = api_key if api_key is not None else os.getenv("AI_API_KEY", "")
        self.model = os.getenv("AI_MODEL", "")
        self.confidence_threshold = float(os.getenv("AI_CONFIDENCE_THRESHOLD", "0.60"))

        self.cache = self._load_cache()
        self.page_analysis_cache = {}
        self.synthetic_cache = self._load_synthetic_cache()

    # =========================================================
    # EXISTING AI CACHE
    # =========================================================

    @staticmethod
    def analyze_api_contracts(responses, discovered_routes=()):
        """Describe observed JSON contracts locally, without retaining response values.

        Collection/member and foreign-key matches are structural candidates, not
        claims that business rules, authorization or server code were recovered.
        """
        endpoints = []
        collections = []
        seen = set()
        for response in list(responses or [])[:2000]:
            if not isinstance(response, dict):
                continue
            parsed = urllib.parse.urlsplit(str(response.get("url", "")))
            path = parsed.path or "/"
            method = str(response.get("method", "GET")).upper()
            try:
                status = int(response.get("status", 0) or 0)
            except (TypeError, ValueError):
                status = 0
            key = (path, method, status, tuple(sorted(urllib.parse.parse_qs(parsed.query, keep_blank_values=True))))
            if key in seen:
                continue
            seen.add(key)
            entry = {"path": path, "method": method, "status": status,
                     "query_parameters": list(key[3]), "coverage": "captured_replay",
                     "shape": "unparsed", "fields": [], "required_adapter": False}
            if response.get("body_truncated"):
                entry.update(coverage="incomplete_capture", shape="truncated")
            else:
                try:
                    body = json.loads(response.get("body", ""))
                    rows = body if isinstance(body, list) else None
                    wrapper = None
                    if isinstance(body, dict):
                        for name in ("data", "results", "items", "records"):
                            if isinstance(body.get(name), list):
                                rows, wrapper = body[name], name
                                break
                    if rows is not None:
                        objects = [row for row in rows[:100] if isinstance(row, dict)]
                        fields = sorted({str(k) for row in objects for k in row})
                        id_fields = [field for field in ("id", "_id", "uuid")
                                     if objects and all(isinstance(row.get(field), (str, int)) and not isinstance(row.get(field), bool) for row in objects)]
                        entry.update(shape="collection", wrapper=wrapper, fields=fields,
                                     identifier_fields=id_fields, captured_count=len(rows))
                        if method == "GET" and status == 200 and objects:
                            collections.append(entry)
                    elif isinstance(body, dict):
                        value = body.get("data", body)
                        entry.update(shape="object", fields=sorted(value) if isinstance(value, dict) else [])
                    else:
                        entry["shape"] = type(body).__name__
                except (ValueError, TypeError):
                    pass
            if method not in ("GET", "HEAD"):
                entry.update(coverage="observed_write_contract", required_adapter=True)
            endpoints.append(entry)
        known_paths = {e["path"].rstrip("/") for e in endpoints}
        unresolved = sorted({urllib.parse.urlsplit(str(route)).path for route in discovered_routes or []
                             if str(route).startswith("/")} - known_paths)
        relationships = []
        for collection in collections:
            for field in collection["fields"]:
                if not field.lower().endswith("id") or field.lower() in ("id", "_id"):
                    continue
                stem = field[:-2].rstrip("_").lower()
                for target in collections:
                    target_name = target["path"].rstrip("/").split("/")[-1].lower()
                    if stem and target_name in (stem, stem + "s", stem + "es"):
                        relationships.append({"from": collection["path"], "field": field,
                                              "to": target["path"], "confidence": "schema_candidate"})
        return {"version": 1, "analysis": "observed_contracts_only", "endpoints": endpoints,
                "collection_member_candidates": [{"collection": e["path"], "identifier_fields": e["identifier_fields"],
                    "coverage": "local_member_lookup_candidate"} for e in collections if e["identifier_fields"]],
                "relationships": relationships, "uncaptured_routes": unresolved,
                "limitations": ["No source backend or business rules recovered.",
                                "Authentication and nested workflows may require an application adapter.",
                                "Schema relationships are candidates, not verified access or ownership rules."]}

    def _load_cache(self):
        if not os.path.exists(CACHE_FILE):
            return {}
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[-] Failed to load AI cache: {e}")
            return {}

    def _save_cache(self):
        try:
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.cache, f, indent=2)
        except Exception as e:
            print(f"[-] Failed to write AI cache: {e}")

    def _make_cache_key(self, field, context):
        return f"{context.strip().lower()}::{field.strip().lower()}"

    # =========================================================
    # EXISTING SEMANTIC CLASSIFICATION
    # =========================================================

    def classify_unknown_fields(self, unknown_fields, context="Web application"):
        results = {}
        to_query = []

        for field in unknown_fields:
            cache_key = self._make_cache_key(field, context)
            if cache_key in self.cache:
                results[field] = self.cache[cache_key]["type"]
            else:
                to_query.append(field)

        if not to_query:
            return results

        if not self.ai_enabled or not self.api_endpoint:
            for field in to_query:
                results[field] = "TEXT"
            return results

        allowed = sorted(list(ALLOWED_TYPES))
        prompt = (
            "You are a semantic field classifier for a cybersecurity deception system.\n"
            f"Context: {context}\n"
            "Classify each unknown web application field into exactly ONE of these allowed types:\n"
            f"{allowed}\n\n"
            f"Fields: {to_query}\n\n"
            "Return JSON only in this required format:\n"
            '{"fields": {"field_name": {"type": "TYPE", "confidence": 0.0}}}\n\n'
            "Rules:\n"
            "1. TYPE must be one of the allowed types.\n"
            "2. confidence must be between 0.0 and 1.0.\n"
            "3. Do not invent new types or return explanations.\n"
            "4. If uncertain, use TEXT."
        )

        try:
            payload = {
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.0
            }
            req_data = json.dumps(payload).encode("utf-8")
            headers = {"Content-Type": "application/json"}
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            req = urllib.request.Request(
                self.api_endpoint,
                data=req_data,
                headers=headers,
                method="POST"
            )

            with urllib.request.urlopen(req, timeout=5) as response:
                raw_response = response.read().decode("utf-8")

            response_json = json.loads(raw_response)
            content = response_json["choices"][0]["message"]["content"]
            parsed = json.loads(content)
            field_map = parsed.get("fields", {})

            for field in to_query:
                item = field_map.get(field, {})
                assigned_type = str(item.get("type", "TEXT")).upper()

                try:
                    confidence = float(item.get("confidence", 0.0))
                except (ValueError, TypeError):
                    confidence = 0.0

                confidence = max(0.0, min(1.0, confidence))

                if assigned_type not in ALLOWED_TYPES or confidence < self.confidence_threshold:
                    assigned_type = "TEXT"

                results[field] = assigned_type
                cache_key = self._make_cache_key(field, context)
                self.cache[cache_key] = {
                    "type": assigned_type,
                    "confidence": confidence
                }

            self._save_cache()
            return results

        except Exception as e:
            print(f"[!] Semantic fallback failed: {e}")
            for field in to_query:
                results[field] = "TEXT"
            return results

    def _classify_page_rules(self, page_context):
        """Fast deterministic first-pass classifier. AI is only consulted when these rules are uncertain."""
        url = str(page_context.get("url", ""))
        title = str(page_context.get("title", "")).lower()
        headings = " ".join(page_context.get("headings", [])).lower()
        forms = page_context.get("forms", [])

        parsed = urllib.parse.urlparse(url)
        path = (parsed.path or "/").lower()
        params = urllib.parse.parse_qs(parsed.query)
        text = f"{title} {headings} {path}"

        if path in ("", "/"):
            return {
                "page_type": "HOME",
                "interaction_type": "NAVIGATION",
                "confidence": 0.95,
                "source": "rules",
            }

        # ---------------------------------------------------------
        # SEARCH PAGE DETECTION
        # ---------------------------------------------------------
        # Do not classify a page as SEARCH merely because words
        # such as "search" or "find" appear in documentation text.
        #
        # Require structural/search-route evidence instead.

        search_param_names = {
            "q",
            "query",
            "search",
            "keyword",
            "term",
        }

        parameter_names = {
            str(key).lower()
            for key in params
        }

        search_route_segments = {
            "search",
            "find",
            "lookup",
        }

        path_segments = {
            segment.lower()
            for segment in path.split("/")
            if segment
        }

        has_search_parameter = bool(
            parameter_names & search_param_names
        )

        has_search_route = bool(
            path_segments & search_route_segments
        )

        has_search_form = False

        for form in forms:
            fields = form.get("fields", [])

            for field in fields:
                field_name = str(
                    field.get("name", "")
                ).lower()

                field_type = str(
                    field.get("type", "")
                ).lower()

                placeholder = str(
                    field.get("placeholder", "")
                ).lower()

                if (
                    field_name in search_param_names
                    or field_type == "search"
                    or "search" in placeholder
                ):
                    has_search_form = True
                    break

            if has_search_form:
                break

        if (
            has_search_parameter
            or has_search_route
            or has_search_form
        ):
            return {
                "page_type": "SEARCH",
                "interaction_type": "SEARCH",
                "confidence": 0.92,
                "source": "rules",
            }

        if params:
            interaction = "FILTER"
            parameter_names = {key.lower() for key in params}

            if parameter_names & {"page", "offset", "limit"}:
                interaction = "PAGINATION"
            elif parameter_names & {"sort", "order", "orderby"}:
                interaction = "SORT"
            elif parameter_names & {"q", "query", "search", "keyword", "term"}:
                interaction = "SEARCH"

            return {
                "page_type": "LISTING",
                "interaction_type": interaction,
                "confidence": 0.82,
                "source": "rules",
            }

        has_password = False
        for form in forms:
            for field in form.get("fields", []):
                if str(field.get("type", "")).lower() == "password":
                    has_password = True

        if has_password:
            return {
                "page_type": "LOGIN",
                "interaction_type": "FORM_SUBMISSION",
                "confidence": 0.95,
                "source": "rules",
            }

        content_signals = page_context.get("content_signals", {})
        paragraph_count = int(content_signals.get("paragraph_count", 0) or 0)
        code_count = int(content_signals.get("code_count", 0) or 0)
        article_count = int(content_signals.get("article_count", 0) or 0)
        has_h1 = bool(content_signals.get("has_h1", False))
        breadcrumb = bool(content_signals.get("breadcrumb", False))

        body_text_length = int(content_signals.get("body_text_length", 0) or 0)

        documentation_words = (
            "documentation", "docs", "reference", "guide", "tutorial", "api",)

        looks_documentary = (
            has_h1
            and body_text_length >= 500
            and (
                paragraph_count >= 3
                or code_count >= 1
                or article_count >= 1
                or breadcrumb
                or any(word in text for word in documentation_words)
            )
        )

        if looks_documentary:
            return {
                "page_type": "DOCUMENTATION",
                "interaction_type": "NAVIGATION",
                "confidence": 0.88,
                "source": "rules",
            }

        # A form only defines the whole page when the page is
        # actually dominated by that form.
        if forms and body_text_length < 500:
            return {
                "page_type": "FORM",
                "interaction_type": "FORM_SUBMISSION",
                "confidence": 0.72,
                "source": "rules",
            }

        segments = [segment for segment in path.split("/") if segment]
        if len(segments) >= 2:
            return {
                "page_type": "DETAIL",
                "interaction_type": "NAVIGATION",
                "confidence": 0.68,
                "source": "rules",
            }

        return {
            "page_type": "GENERIC",
            "interaction_type": "NAVIGATION",
            "confidence": 0.45,
            "source": "rules",
        }

    def _classify_page_with_ai(self, page_context):
        """
        AI hole-filler for page semantics.

        Rules establish observable facts first. AI is only allowed to
        interpret those facts. It does not return HTML, JavaScript,
        arbitrary URLs, or executable behavior.
        """
        compact_context = {
            "url": str(page_context.get("url", ""))[:500],
            "title": str(page_context.get("title", ""))[:300],
            "headings": [str(item)[:200] for item in page_context.get("headings", [])[:30]],
            "landmarks": page_context.get("landmarks", [])[:30],
            "forms": page_context.get("forms", [])[:15],
            "link_patterns": page_context.get("link_patterns", {}),
            "repeated_regions": page_context.get("repeated_regions", [])[:20],
            "content_signals": page_context.get("content_signals", {}),
            "framework": str(page_context.get("framework", ""))[:50],
        }

        prompt = (
            "You analyze the semantic structure of a live web page "
            "for an isolated cybersecurity deception environment.\n\n"
            "The supplied observations were collected locally from the "
            "page DOM. Treat them as authoritative facts.\n\n"
            "Infer only semantic meaning that is reasonably supported "
            "by those observations.\n\n"
            f"Allowed PAGE_TYPE values:\n{sorted(PAGE_TYPES)}\n\n"
            f"Allowed INTERACTION_TYPE values:\n{sorted(INTERACTION_TYPES)}\n\n"
            "Return JSON with this exact top-level structure:\n"
            "{\n"
            '  "page_type": "TYPE",\n'
            '  "interaction_type": "TYPE",\n'
            '  "page_family": "short_semantic_family",\n'
            '  "template_affinity": "short_template_name",\n'
            '  "regions": [\n'
            "    {\n"
            '      "region_id": "observed_region_id",\n'
            '      "semantic_role": "role",\n'
            '      "content_kind": "kind",\n'
            '      "repeatable": false\n'
            "    }\n"
            "  ],\n"
            '  "content_schema": {\n'
            '      "primary": "kind",\n'
            '      "secondary": "kind"\n'
            "  },\n"
            '  "interaction_model": [\n'
            "    {\n"
            '      "kind": "INTERACTION_TYPE",\n'
            '      "region_id": "observed_region_id"\n'
            "    }\n"
            "  ],\n"
            '  "route_family": {\n'
            '      "pattern": "observed_route_pattern",\n'
            '      "semantic_type": "short_type"\n'
            "  },\n"
            '  "confidence": 0.0\n'
            "}\n\n"
            "Rules:\n"
            "1. Do not invent routes that are not supported by the observed URL or link patterns.\n"
            "2. Do not return HTML, JavaScript, CSS, executable code, credentials, or instructions.\n"
            "3. region_id must refer to an observed landmark or region when possible.\n"
            "4. interaction_model.kind must use an allowed INTERACTION_TYPE.\n"
            "5. Keep page_family, template_affinity and semantic labels short and generic.\n"
            "6. If evidence is weak, use GENERIC and lower confidence.\n"
            "7. Do not identify a specific website merely from branding.\n\n"
            "Observed page information:\n"
            f"{json.dumps(compact_context, ensure_ascii=False)}"
        )

        payload = {
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.0,
        }

        req_data = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        request = urllib.request.Request(
            self.api_endpoint,
            data=req_data,
            headers=headers,
            method="POST",
        )

        with urllib.request.urlopen(request, timeout=8) as response:
            raw = response.read().decode("utf-8")

        response_json = json.loads(raw)
        content = response_json["choices"][0]["message"]["content"]
        return json.loads(content)

    def _validate_page_analysis(self, result, fallback):
        """
        Validate AI semantic output.

        AI may describe meaning, but it cannot introduce executable
        behavior or override DecoyGuard containment.
        """
        if not isinstance(result, dict):
            return fallback

        page_type = str(result.get("page_type", "")).upper()
        interaction_type = str(result.get("interaction_type", "")).upper()

        try:
            confidence = float(result.get("confidence", 0.0))
        except (TypeError, ValueError):
            return fallback

        confidence = max(0.0, min(1.0, confidence))

        if page_type not in PAGE_TYPES:
            return fallback
        if interaction_type not in INTERACTION_TYPES:
            return fallback
        if confidence < self.confidence_threshold:
            return fallback

        def clean_label(value, default="generic"):
            value = str(value or default)
            value = re.sub(r"[^a-zA-Z0-9_\-\s]", "", value)
            value = re.sub(r"\s+", "_", value.strip().lower())
            return value[:80] or default

        regions = []
        raw_regions = result.get("regions", [])
        if isinstance(raw_regions, list):
            for item in raw_regions[:30]:
                if not isinstance(item, dict):
                    continue
                regions.append({
                    "region_id": clean_label(item.get("region_id"), "region"),
                    "semantic_role": clean_label(item.get("semantic_role"), "content"),
                    "content_kind": clean_label(item.get("content_kind"), "generic"),
                    "repeatable": bool(item.get("repeatable", False)),
                })

        interactions = []
        raw_interactions = result.get("interaction_model", [])
        if isinstance(raw_interactions, list):
            for item in raw_interactions[:20]:
                if not isinstance(item, dict):
                    continue
                kind = str(item.get("kind", "")).upper()
                if kind not in INTERACTION_TYPES:
                    continue
                interactions.append({
                    "kind": kind,
                    "region_id": clean_label(item.get("region_id"), "page"),
                })

        raw_schema = result.get("content_schema", {})
        content_schema = {}
        if isinstance(raw_schema, dict):
            for key, value in list(raw_schema.items())[:20]:
                safe_key = clean_label(key, "content")
                content_schema[safe_key] = clean_label(value, "generic")

        route_family = result.get("route_family", {})
        if not isinstance(route_family, dict):
            route_family = {}

        pattern = str(route_family.get("pattern", ""))[:200]
        if not pattern.startswith("/") or "://" in pattern or pattern.startswith("//"):
            pattern = ""

        return {
            "page_type": page_type,
            "interaction_type": interaction_type,
            "page_family": clean_label(result.get("page_family"), page_type.lower()),
            "template_affinity": clean_label(result.get("template_affinity"), page_type.lower()),
            "regions": regions,
            "content_schema": content_schema,
            "interaction_model": interactions,
            "route_family": {
                "pattern": pattern,
                "semantic_type": clean_label(route_family.get("semantic_type"), page_type.lower()),
            },
            "confidence": confidence,
            "source": "ai",
        }

    def analyze_page_semantics(self, page_context):
        """
        Hybrid semantic analysis.

        Rules establish high-confidence facts.
        AI fills semantic holes when useful.
        Containment and routing authority remain deterministic.
        """
        rule_result = self._classify_page_rules(page_context)
        base = dict(rule_result)

        base.setdefault("page_family", str(base.get("page_type", "GENERIC")).lower())
        base.setdefault("template_affinity", base["page_family"])
        base.setdefault("regions", [])
        base.setdefault("content_schema", {})
        base.setdefault("interaction_model", [])
        base.setdefault("route_family", {
            "pattern": "",
            "semantic_type": base["page_family"],
        })

        if not self.ai_enabled or not self.api_endpoint:
            return base

        cache_material = json.dumps(page_context, sort_keys=True, default=str, ensure_ascii=False)
        cache_key = hashlib.sha256(cache_material.encode("utf-8", errors="ignore")).hexdigest()

        if cache_key in self.page_analysis_cache:
            return self.page_analysis_cache[cache_key]

        has_rich_structure = bool(
            page_context.get("landmarks")
            or page_context.get("repeated_regions")
            or page_context.get("link_patterns")
            or page_context.get("content_signals")
        )

        if rule_result.get("confidence", 0.0) >= 0.95 and not has_rich_structure:
            return base

        try:
            ai_result = self._classify_page_with_ai(page_context)
            result = self._validate_page_analysis(ai_result, fallback=base)
        except Exception as e:
            print(f"[!] Adaptive page analysis failed: {e}")
            result = base

        self.page_analysis_cache[cache_key] = result
        return result

    # =========================================================
    # SYNTHETIC ADAPTIVE ENVIRONMENT
    # =========================================================

    def _load_synthetic_cache(self):
        """Loads persistent generated routes."""
        if not os.path.exists(SYNTHETIC_CACHE_FILE):
            return {}
        try:
            with open(SYNTHETIC_CACHE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except Exception as e:
            print(f"[-] Failed to load synthetic cache: {e}")
        return {}

    def _save_synthetic_cache(self):
        try:
            with open(SYNTHETIC_CACHE_FILE, "w", encoding="utf-8") as f:
                json.dump(self.synthetic_cache, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[-] Failed to write synthetic cache: {e}")

    # ---------------------------------------------------------
    # DETERMINISTIC SEEDING
    # ---------------------------------------------------------

    def _route_seed(self, value):
        """Same route -> same seed -> same generated data."""
        value = str(value or "/").lower()
        digest = hashlib.sha256(value.encode("utf-8", errors="ignore")).hexdigest()
        return int(digest[:16], 16)

    def _synthetic_cache_key(self, route, query_string=""):
        route = route or "/"
        return route + ("?" + query_string if query_string else "")

    # ---------------------------------------------------------
    # NORMALIZATION
    # ---------------------------------------------------------

    def _clean_title(self, value):
        value = urllib.parse.unquote(str(value or ""))
        value = value.replace("_", " ")
        value = re.sub(r"\s+", " ", value).strip()
        return value[:120] if value else "Untitled"

    def _slug(self, value):
        value = self._clean_title(value)
        value = re.sub(r"[^a-zA-Z0-9\s_-]", "", value)
        value = re.sub(r"\s+", "_", value.strip())
        return value or "Untitled"

    # ---------------------------------------------------------
    # ROUTE CLASSIFICATION
    # ---------------------------------------------------------

    def classify_decoy_route(self, route, query_string=""):
        route = route or "/"
        try:
            params = urllib.parse.parse_qs(query_string)
        except Exception:
            params = {}

        path = route.lower().rstrip("/")
        if params:
            return "listing"

        segments = [segment for segment in path.split("/") if segment]
        if not segments:
            return "home"
        if len(segments) >= 2:
            return "detail"
        return "section"

    # ---------------------------------------------------------
    # SEARCH EXTRACTION
    # ---------------------------------------------------------

    def _extract_search_query(self, route, query_string):
        try:
            params = urllib.parse.parse_qs(query_string)
        except Exception:
            params = {}

        for key in ("search", "q", "query", "term", "keyword"):
            values = params.get(key)
            if values and values[0]:
                return self._clean_title(values[0])

        lower_route = route.lower()
        if "/search/" in lower_route:
            return self._clean_title(route.rsplit("/", 1)[-1])

        return "Search"

    # ---------------------------------------------------------
    # RELATED ROUTES
    # ---------------------------------------------------------

    def _generate_related_topics(self, title, count=8):
        """Creates stable links which themselves can be fed back into this generator."""
        rng = random.Random(self._route_seed(title))
        prefixes = [
            "History of", "Overview of", "Development of", "Research on",
            "Introduction to", "Background of", "Classification of",
            "Studies of", "Modern", "Early"
        ]
        suffixes = [
            "research", "history", "theory", "applications", "development",
            "studies", "overview", "classification", "analysis", "methods"
        ]

        topics = []
        attempts = 0
        while len(topics) < count and attempts < 100:
            attempts += 1
            if attempts % 2:
                candidate = f"{rng.choice(prefixes)} {title}"
            else:
                candidate = f"{title} {rng.choice(suffixes)}"

            if candidate != title and candidate not in topics:
                topics.append(candidate)

        return topics

    # ---------------------------------------------------------
    # ARTICLE GENERATOR
    # ---------------------------------------------------------

    def _generate_article_state(self, route):
        raw_title = route
        if route.lower().startswith("/wiki/"):
            raw_title = route[len("/wiki/"):]

        title = self._clean_title(raw_title)
        rng = random.Random(self._route_seed(route))
        years = [1874, 1892, 1907, 1921, 1948, 1963, 1977, 1989, 1998, 2006, 2014, 2021]
        year = rng.choice(years)

        related_topics = self._generate_related_topics(title, count=8)
        related = [{"title": topic, "route": "/wiki/" + self._slug(topic)} for topic in related_topics]

        return {
            "type": "article",
            "synthetic": True,
            "title": title,
            "route": route,
            "metadata": {
                "reference_year": year,
                "seed": self._route_seed(route)
            },
            "sections": [
                {
                    "heading": "Overview",
                    "text": (
                        f"{title} is represented within this synthetic reference environment. "
                        "The subject is connected with several related areas in the local archive."
                    )
                },
                {
                    "heading": "Background",
                    "text": (
                        f"Archived material associated with {title} includes references dating "
                        f"to approximately {year}. Terminology and classification vary between sources."
                    )
                },
                {
                    "heading": "Development",
                    "text": (
                        f"Later material concerning {title} expanded into related areas of study, "
                        "analysis and classification."
                    )
                }
            ],
            "related": related
        }

    # ---------------------------------------------------------
    # SEARCH GENERATOR
    # ---------------------------------------------------------

    def _generate_search_state(self, route, query_string):
        query = self._extract_search_query(route, query_string)
        related = self._generate_related_topics(query, count=10)
        titles = [query, f"{query} (disambiguation)", f"History of {query}", *related]

        results = []
        seen = set()

        for title in titles:
            if title in seen:
                continue
            seen.add(title)
            results.append({
                "title": title,
                "route": "/wiki/" + self._slug(title),
                "snippet": (
                    f"Information concerning {title}, including background, "
                    "related subjects and archived references."
                )
            })

        return {
            "type": "search",
            "synthetic": True,
            "title": f"Search results for “{query}”",
            "query": query,
            "route": route,
            "results": results[:10]
        }

    # ---------------------------------------------------------
    # CATEGORY GENERATOR
    # ---------------------------------------------------------

    def _generate_category_state(self, route):
        raw_title = route.rstrip("/").rsplit("/", 1)[-1]
        title = self._clean_title(raw_title)
        topics = self._generate_related_topics(title, count=12)
        entries = [{"title": topic, "route": "/wiki/" + self._slug(topic)} for topic in topics]

        return {
            "type": "category",
            "synthetic": True,
            "title": title,
            "route": route,
            "entries": entries
        }

    # ---------------------------------------------------------
    # GENERIC GENERATOR
    # ---------------------------------------------------------

    def _generate_generic_state(self, route):
        title = self._clean_title(route.rstrip("/").rsplit("/", 1)[-1] or "Main page")
        related_topics = self._generate_related_topics(title, count=6)
        related = [{"title": topic, "route": "/wiki/" + self._slug(topic)} for topic in related_topics]

        return {
            "type": "generic",
            "synthetic": True,
            "title": title,
            "route": route,
            "related": related
        }

    # ---------------------------------------------------------
    # PUBLIC SYNTHETIC API
    # ---------------------------------------------------------

    def generate_decoy_route(self, route, query_string="", session=None):
        """Main entry point for synthetic environments."""
        route = route or "/"
        cache_key = self._synthetic_cache_key(route, query_string)

        if cache_key in self.synthetic_cache:
            return self.synthetic_cache[cache_key]

        page_type = self.classify_decoy_route(route, query_string)

        if page_type == "search":
            state = self._generate_search_state(route, query_string)
        elif page_type == "article":
            state = self._generate_article_state(route)
        elif page_type == "category":
            state = self._generate_category_state(route)
        else:
            state = self._generate_generic_state(route)

        if session:
            state["session_observed"] = True

        self.synthetic_cache[cache_key] = state
        self._save_synthetic_cache()
        return state