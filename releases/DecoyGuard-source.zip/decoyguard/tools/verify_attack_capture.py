"""Verify local direct/gateway capture, detection, redaction and artifact bytes.

Run after `python decoyguard.py --saved` reaches ACTIVE. Sends harmless test
probes only to loopback listeners. Writes genuine test events/artifacts to logs;
SQLi probes may contain later requests from this local source. No external URLs,
dashboard credentials or original production applications are used intentionally.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parents[1]


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def read_new(path, offset):
    if not path.exists():
        return []
    records = []
    with path.open('rb') as stream:
        stream.seek(offset if path.stat().st_size >= offset else 0)
        for line in stream:
            if not line.endswith(b'\n'):
                continue
            try:
                record = json.loads(line)
                if isinstance(record, dict):
                    records.append(record)
            except (ValueError, UnicodeDecodeError):
                continue
    return records


def site_configs():
    registry = ROOT / 'logs/website_registry.json'
    if registry.exists():
        data = json.loads(registry.read_text(encoding='utf-8'))
        sites = data.get('sites', {})
        if not isinstance(sites, dict):
            raise ValueError('Invalid site registry')
        result = []
        for site_id in ('juiceshop', 'banking'):
            site = sites.get(site_id)
            if not isinstance(site, dict):
                raise ValueError(f'Saved site {site_id!r} not found; configure it before testing')
            result.append(dict(site, site_id=site_id))
        return result
    return [dict(site_id='juiceshop', name='Juice Shop', decoy_port=8088, gateway_port=8081, root='decoy-website'),
            dict(site_id='banking', name='Banking', decoy_port=8089, gateway_port=8082, root='decoy-website/banking')]


def multipart(marker, payload):
    boundary = 'DGCheck' + uuid.uuid4().hex
    body = (f'--{boundary}\r\nContent-Disposition: form-data; name="username"\r\n\r\n{marker}\r\n'
            f'--{boundary}\r\nContent-Disposition: form-data; name="password"\r\n\r\ncheck-only-not-a-real-password\r\n'
            f'--{boundary}\r\nContent-Disposition: form-data; name="evidence"; filename="artifact-check.txt"\r\n'
            'Content-Type: text/plain\r\n\r\n').encode()
    return body + payload + f'\r\n--{boundary}--\r\n'.encode(), f'multipart/form-data; boundary={boundary}'


def check(site, mode, timeout):
    site_id = site['site_id']
    gateway = mode == 'gateway-upload'
    port = site['gateway_port'] if gateway else site['decoy_port']
    if not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError(f'Invalid local listener port for {site_id}')
    marker = 'dg-check-' + uuid.uuid4().hex
    files = [ROOT / 'logs/events.jsonl', ROOT / 'logs/access.json', ROOT / 'logs/alerts.jsonl']
    offsets = {p: p.stat().st_size if p.exists() else 0 for p in files}
    uploaded = mode.endswith('upload')
    payload = ('DecoyGuard harmless evidence ' + marker + '\n').encode()
    if uploaded:
        body, content_type = multipart(marker, payload)
        path = '/trap_handler.php?q=or%201%3D1'
    elif mode == 'json-xss':
        body = json.dumps({'username': marker, 'password': 'check-only', 'comment': '<script>alert(1)</script>'}).encode()
        content_type = 'application/json'
        path = '/trap_handler.php'
    else:
        body = urllib.parse.urlencode({'username': marker, 'password': "' OR 1=1--"}).encode()
        content_type = 'application/x-www-form-urlencoded'
        path = '/trap_handler.php'
    request = urllib.request.Request(f'http://127.0.0.1:{port}{path}', data=body,
                                    headers={'Content-Type': content_type, 'User-Agent': 'DecoyGuard-Local-Check'})
    print(f'\n{site_id} / {mode} / localhost:{port}', flush=True)
    try:
        response = urllib.request.build_opener(NoRedirect()).open(request, timeout=15)
        status = response.status
        response.close()
    except urllib.error.HTTPError as error:
        status = error.code
        error.close()
    except (OSError, urllib.error.URLError) as error:
        print(f'  FAIL HTTP: {error}')
        return False
    print(f'  HTTP {status}; checking actual telemetry, not treating the response as proof')
    event = alert = None
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        candidates = [e for p in files[:2] for e in read_new(p, offsets[p])
                      if e.get('site_id') == site_id and isinstance(e.get('fields'), dict)
                      and e['fields'].get('username') == marker and e.get('event_id')]
        # Gateway event is authoritative there; direct events cover body-aware capture.
        candidates.sort(key=lambda e: (gateway and e.get('source') == 'gateway-decision'), reverse=True)
        alerts = read_new(files[2], offsets[files[2]])
        for candidate in candidates:
            matched = next((a for a in alerts if a.get('incident_id') == candidate['event_id'] and a.get('site_id') == site_id), None)
            if matched:
                event, alert = candidate, matched
                break
        if alert:
            break
        if candidates:
            event = candidates[0]
        time.sleep(.2)
    if event is None:
        print('  FAIL CAPTURE: no new body-aware event for this site and unique test marker')
        return False
    if gateway and event.get('source') != 'gateway-decision':
        print('  FAIL GATEWAY: direct capture exists but no matching gateway decision was verified')
        return False
    if event['fields'].get('password') != '[REDACTED]':
        print('  FAIL REDACTION: test password is not marked redacted')
        return False
    if event.get('target_type') != 'decoy':
        print('  FAIL ROUTING: request was not recorded as targeting the decoy')
        return False
    print('  PASS capture, site attribution, decoy target and password redaction')
    if alert is None:
        print('  FAIL DETECTION: capture found, but no corresponding alert; keep DecoyGuard running')
        return False
    attack = str(alert.get('attack_type', '')).lower()
    if not (('xss' in attack or 'cross' in attack) if mode == 'json-xss' else 'sql' in attack):
        print(f'  FAIL CLASSIFICATION: {alert.get("attack_type")!r}')
        return False
    print('  PASS matching classified alert:', alert['incident_id'])
    if uploaded:
        expected = hashlib.sha256(payload).hexdigest()
        artifacts = (event.get('forensics') or {}).get('artifacts', [])
        artifact = next((a for a in artifacts if isinstance(a, dict) and a.get('sha256', a.get('hash')) == expected), None)
        if not artifact or artifact.get('size_bytes') != len(payload):
            print('  FAIL ARTIFACT: expected size/hash missing; check storage permissions and artifact_capture_errors')
            return False
        stored = artifact.get('storage_name', '')
        if not re.fullmatch(r'[a-f0-9]{32}\.bin', stored):
            print('  FAIL ARTIFACT: invalid private storage object name')
            return False
        folder = (ROOT / site['root'] / 'private/backend-state/artifacts').resolve()
        if ROOT.resolve() not in folder.parents:
            raise ValueError('Artifact directory is outside this project')
        actual = folder / stored
        if not actual.is_file() or actual.stat().st_size != len(payload) or hashlib.sha256(actual.read_bytes()).hexdigest() != expected:
            print('  FAIL STORAGE: metadata did not match a persisted host file (custom storage paths need manual verification)')
            return False
        alert_artifacts = (alert.get('forensics') or {}).get('artifacts', [])
        if not any(isinstance(a, dict) and a.get('sha256', a.get('hash')) == expected for a in alert_artifacts):
            print('  FAIL ALERT EVIDENCE: stored artifact metadata did not survive into the alert')
            return False
        print('  PASS stored bytes, SHA-256, size and artifact metadata in the alert')
    return True



def check_backend(site):
    """Use a unique local resource, never an existing application's records."""
    site_id = site['site_id']
    port = site['decoy_port']
    if not isinstance(port, int) or not 1 <= port <= 65535:
        raise ValueError('Invalid local decoy port')
    path = '/api/dg-verification-' + uuid.uuid4().hex
    opener = urllib.request.build_opener(NoRedirect())

    def request(method, target, body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(f'http://127.0.0.1:{port}' + target, data=data, method=method,
            headers={'Content-Type': 'application/json', 'User-Agent': 'DecoyGuard-Backend-Check'})
        try:
            with opener.open(req, timeout=15) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as error:
            status = error.code
            error.close()
            return status, {}

    print(f'\n{site_id} / local backend consistency / localhost:{port}', flush=True)
    try:
        first_status, first = request('POST', path, {'name': 'verification-first'})
        second_status, second = request('POST', path, {'name': 'verification-second'})
        if first_status != 201 or second_status != 201:
            raise ValueError('Local creation did not return HTTP 201')
        first_id, second_id = first['data']['id'], second['data']['id']
        for identifier in (first_id, second_id):
            if not isinstance(identifier, int):
                raise ValueError('Expected a local numeric record ID')
        if request('PATCH', f'{path}/{first_id}', {'name': 'verification-updated'})[0] != 200:
            raise ValueError('Update of first record failed')
        if request('GET', f'{path}/{first_id}')[1]['data']['name'] != 'verification-updated':
            raise ValueError('Update did not change the requested record')
        if request('GET', f'{path}/{second_id}')[1]['data']['name'] != 'verification-second':
            raise ValueError('Updating first record unexpectedly changed the second')
        for identifier in (first_id, second_id):
            if request('DELETE', f'{path}/{identifier}')[0] != 200:
                raise ValueError('Delete failed')
            if request('GET', f'{path}/{identifier}')[0] != 404:
                raise ValueError('Deleted member was still returned')
        if request('GET', path)[1].get('data') != []:
            raise ValueError('Deleted collection was not empty')
        print('  PASS create, read, update by ID, delete and empty collection')
        return True
    except (KeyError, TypeError, ValueError, OSError, urllib.error.URLError) as error:
        print('  FAIL BACKEND:', error)
        print('  This check uses its own resource namespace:', path)
        return False


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--timeout', type=float, default=20, help='Seconds to await each detection (1 to 120)')
    cli.add_argument('--direct-only', action='store_true', help='Skip protected gateway upload checks')
    cli.add_argument('--skip-backend', action='store_true', help='Skip local CRUD consistency checks')
    options = cli.parse_args()
    if not 1 <= options.timeout <= 120:
        cli.error('--timeout must be between 1 and 120')
    print('Local verification writes real test events and small evidence files; it does not clear history.')
    print('Gateway probes can route later requests from this local source to its decoy.')
    try:
        results = []
        for site in site_configs():
            modes = ['form-sqli', 'json-xss', 'direct-upload']
            if not options.direct_only:
                modes.append('gateway-upload')
            for mode in modes:
                results.append(check(site, mode, options.timeout))
            if not options.skip_backend:
                results.append(check_backend(site))
        print(f'\n{sum(results)}/{len(results)} checks passed. Dashboard display and Docker health are separate checks.')
        return 0 if results and all(results) else 1
    except (ValueError, OSError) as error:
        print('FAIL CONFIGURATION:', error)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
