<?php
// Generic local form/API sink. Never send submitted attacks to the source site.
require_once '/var/www/guard_middleware.php';
header('Cache-Control: no-store');
if (stripos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false ||
    stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(401);
    echo json_encode(['success'=>false, 'message'=>'Invalid credentials or request.']);
} else {
    header('Content-Type: text/html; charset=utf-8');
    http_response_code(401);
    echo '<!doctype html><html><head><meta charset="utf-8"><title>Request unsuccessful</title></head><body><main><h1>Request unsuccessful</h1><p>Check your details and try again.</p><a href="/">Return to the website</a></main></body></html>';
}
