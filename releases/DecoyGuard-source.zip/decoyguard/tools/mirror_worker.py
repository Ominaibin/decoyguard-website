"""Local, serial Playwright worker for actual on-demand website mirroring."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import tempfile
import threading
import time


def load_engine(engine_path):
    engine_path = Path(engine_path).resolve()
    sys.path.insert(0, str(engine_path.parent))
    sys.path.insert(0, str(engine_path.parent.parent))
    if not importlib.util.find_spec('adaptive_analyzer'):
        for name in ('adaptive_analyzer.py', 'adaptive_analyzer(2).py'):
            candidate = engine_path.parent / name
            if candidate.exists():
                spec = importlib.util.spec_from_file_location('adaptive_analyzer', candidate)
                analyzer = importlib.util.module_from_spec(spec)
                sys.modules['adaptive_analyzer'] = analyzer
                spec.loader.exec_module(analyzer)
                break
    spec = importlib.util.spec_from_file_location('decoyguard_live_mirror', engine_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class MirrorWorker:
    def __init__(self, public_root, engine_module, engine=None):
        self.public = Path(public_root).resolve()
        self.private = self.public.parent / 'private'
        self.config_path = self.private / 'mirror_worker.json'
        self.config = json.loads(self.config_path.read_text(encoding='utf-8'))
        if not self.config.get('active'):
            raise RuntimeError('Mirror configuration is inactive; run mirroring first')
        self.run_id = self.config['run_id']
        if len(self.run_id) != 32 or any(c not in '0123456789abcdef' for c in self.run_id):
            raise ValueError('Invalid mirror generation')
        self.queue = self.private / 'mirror-queue' / self.run_id
        self.module = engine_module
        self.engine = engine or engine_module.DecoyDuplicator(
            self.config['target_url'], str(self.public),
            color_scheme=self.config.get('color_scheme', 'dark'),
            viewport=self.config.get('viewport'),
            static_decoy=self.config.get('static_decoy', False),
            backend_profile=self.config.get('backend_profile'))
        self.engine._on_demand_read_only = True
        self.engine.downloaded_assets.update(self.config.get('asset_map', {}))
        self.engine._archived_runtime_urls.update(self.engine.downloaded_assets)
        self.stop = threading.Event()
        for name in ('jobs', 'working', 'cache', 'status'):
            directory = self.queue / name
            directory.mkdir(parents=True, exist_ok=True)
            os.chmod(directory, 0o777)

    def current(self):
        try:
            latest = json.loads(self.config_path.read_text(encoding='utf-8'))
            return latest.get('active') and latest.get('run_id') == self.run_id
        except (OSError, ValueError):
            return False

    def heartbeat(self):
        self.module.atomic_json(self.queue / 'heartbeat.json', {
            'run_id': self.run_id, 'timestamp': int(time.time()), 'pid': os.getpid()})

    def _heartbeat_loop(self):
        while not self.stop.is_set() and self.current():
            self.heartbeat()
            self.stop.wait(1)

    def _status(self, key, state, status=200):
        self.module.atomic_json(self.queue / 'status' / (key + '.json'), {
            'state': state, 'http_status': status, 'timestamp': int(time.time())})

    def _publish_assets(self, staging):
        # Never promote source-provided executable files into the PHP web root.
        safe = {'.css', '.js', '.mjs', '.json', '.map', '.woff', '.woff2', '.ttf',
                '.otf', '.eot', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp',
                '.ico', '.avif', '.wasm', '.webmanifest', '.mp4', '.webm', '.mp3',
                '.ogg', '.pdf', '.bin'}
        for source in Path(staging).rglob('*'):
            if not source.is_file() or source.is_symlink():
                continue
            if source.suffix.lower() not in safe:
                raise RuntimeError(
                    f"Unsupported captured asset: {source.relative_to(staging)} "
                    f"(extension={source.suffix!r})"
                )
            destination = self.public / source.relative_to(staging)
            parent = destination.parent
            parent.mkdir(parents=True, exist_ok=True)
            if self.public not in destination.resolve().parents:
                raise RuntimeError('Asset publication escaped the web root')
            temporary = parent / (destination.name + '.' + self.run_id + '.tmp')
            shutil.copyfile(source, temporary)
            os.replace(temporary, destination)

    def _merge_manifest(self, path):
        manifest_path = self.public / 'site_manifest.json'
        try:
            manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        except (OSError, ValueError):
            manifest = {'target_url': self.config['target_url']}
        routes = set(manifest.get('on_demand_routes', []))
        routes.add(path)
        manifest['on_demand_routes'] = sorted(routes)
        manifest['discovered_routes'] = sorted(set(manifest.get('discovered_routes', [])) | self.engine.discovered_routes)
        manifest['routes'] = sorted(set(manifest.get('routes', [])) | {path})
        manifest['pages_mirrored'] = len(manifest['routes'])
        manifest['on_demand_count'] = len(routes)
        forms = manifest.get('forms', []) + self.engine.forms
        unique = {json.dumps(form, sort_keys=True): form for form in forms}
        manifest['forms'] = list(unique.values())
        private_catalog = self.private / 'backend_catalog.json'
        catalog = json.loads(private_catalog.read_text()) if private_catalog.exists() else {'profile': self.config.get('backend_profile'), 'responses': []}
        catalog['responses'] = list({json.dumps(item, sort_keys=True): item for item in catalog['responses'] + self.engine.api_responses}.values())
        self.module.atomic_json(private_catalog, catalog)
        manifest['api_responses'] = []
        manifest['api_routes'] = sorted(set(manifest.get('api_routes', [])) | self.engine.api_routes)
        self.module.atomic_json(manifest_path, manifest)
        # Retain only published mappings, reducing downloads after a worker restart.
        self.config['asset_map'] = self.engine.downloaded_assets
        self.module.atomic_json(self.config_path, self.config)

    def process_job(self, job_file):
        job_file = Path(job_file)
        key = job_file.stem
        if len(key) != 64 or any(c not in '0123456789abcdef' for c in key):
            job_file.unlink(missing_ok=True)
            return
        working = self.queue / 'working' / job_file.name
        try:
            os.replace(job_file, working)
        except OSError:
            return
        saved_fields = ('downloaded_assets', 'runtime_asset_map', '_archived_runtime_urls',
                        '_api_capture_keys', 'forms', 'api_routes', 'api_responses')
        snapshot = {name: copy.deepcopy(getattr(self.engine, name)) for name in saved_fields}
        old_output, old_assets = self.engine.output_dir, self.engine.assets_dir
        committed = False
        try:
            job = json.loads(working.read_text(encoding='utf-8'))
            path = self.module.normalize_document_path(job['path'])
            if job.get('run_id') != self.run_id or hashlib.sha256(path.encode()).hexdigest() != key:
                raise self.module.MirrorCaptureError('Invalid capture job', 400)
            cache_file = self.queue / 'cache' / (key + '.html')
            if cache_file.exists():
                self._status(key, 'ready'); return
            if not self.current():
                raise self.module.MirrorCaptureError('Capture generation replaced', 503)
            with tempfile.TemporaryDirectory(prefix='capture-', dir=self.queue) as staging:
                self.engine.output_dir = staging
                self.engine.assets_dir = str(Path(staging) / 'assets')
                Path(self.engine.assets_dir).mkdir()
                html = self.engine.capture_document(path, self.config.get('capture_seconds', 45))
                # Keep document out of the static asset promotion tree.
                html_bytes = html.encode('utf-8')
                with self.module.mirror_file_lock(self.private / 'publication.lock'):
                    if not self.current():
                        raise self.module.MirrorCaptureError('Capture generation replaced', 503)
                    self._publish_assets(staging)
                    temporary = cache_file.with_suffix('.tmp')
                    temporary.write_bytes(html_bytes)
                    os.replace(temporary, cache_file)
                    committed = True
                    self._merge_manifest(path)
                    self._status(key, 'ready')
                print(f'[✓] Captured actual document: {path}', flush=True)
        except Exception as exc:
            if committed:
                # The document is usable even if nonessential metadata failed.
                self._status(key, 'ready')
            else:
                for name, value in snapshot.items():
                    setattr(self.engine, name, value)
                self._status(key, 'failed', getattr(exc, 'status', 502))
            print(f'[!] Capture failed: {exc}', flush=True)
        finally:
            self.engine.output_dir, self.engine.assets_dir = old_output, old_assets
            working.unlink(missing_ok=True)

    def run(self):
        with self.module.mirror_file_lock(self.queue / 'worker.lock', blocking=False):
            # Resume jobs whose owner exited before publishing a result.
            for orphan in (self.queue / 'working').glob('*.json'):
                os.replace(orphan, self.queue / 'jobs' / orphan.name)
            self.heartbeat()
            heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
            heartbeat_thread.start()
            try:
                while not self.stop.is_set() and self.current():
                    pending = sorted((self.queue / 'jobs').glob('*.json'), key=lambda file: file.stat().st_mtime)
                    if pending:
                        self.process_job(pending[0])
                    else:
                        self.stop.wait(0.2)
            finally:
                self.stop.set()
                heartbeat_thread.join(timeout=2)
                self.engine._close_browser()
                (self.queue / 'heartbeat.json').unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default='decoy-website/public')
    parser.add_argument('--engine', required=True)
    args = parser.parse_args()
    module = load_engine(args.engine)
    worker = MirrorWorker(args.root, module)
    for name in ('SIGINT', 'SIGTERM'):
        if hasattr(signal, name):
            signal.signal(getattr(signal, name), lambda *_: worker.stop.set())
    worker.run()


if __name__ == '__main__':
    main()
