<?php

// Best-effort RFC5424 UDP delivery; existing JSONL remains authoritative fallback.
function dg_emit_syslog(array $event): void {
    if (getenv('DECOY_SYSLOG_ENABLED', true)==='0') return;
    $host=getenv('DECOY_SYSLOG_HOST', true) ?: 'host.docker.internal';
    $port=(int)(getenv('DECOY_SYSLOG_PORT', true) ?: 5514);
    if (!preg_match('/^[a-zA-Z0-9.:-]+$/D',$host) || $port<1 || $port>65535) return;
    $message='<134>1 '.gmdate('Y-m-d\TH:i:s\Z').' decoyguard web - - - '.json_encode($event,JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES);
    if (strlen($message)>60000) { error_log('DecoyGuard: syslog message exceeds datagram limit'); return; }
    $socket=@stream_socket_client('udp://'.$host.':'.$port,$errno,$error,0.05);
    if ($socket) { stream_set_timeout($socket,0,50000); @fwrite($socket,$message); fclose($socket); }
}

$dgPresentation = (($_SERVER['DG_PRESENTATION_MODE'] ?? '')==='1') || getenv('DECOYGUARD_PRESENTATION', true)==='1';
function dg_valid_application_finding($finding): bool {
    return is_array($finding)
        && ($finding['kind'] ?? '') === 'object_ownership_violation'
        && ($finding['verified'] ?? false) === true
        && ($finding['outcome'] ?? '') === 'rejected'
        && is_string($finding['object_type'] ?? null)
        && preg_match('/^[a-z_]{1,40}$/', $finding['object_type']);
}
// Rebuild PHP-parsed multipart data locally; never forward an empty raw body.
// PHP's parsed field semantics apply (duplicate scalar fields collapse).
function dg_gateway_multipart(int $limit): array {
    $boundary='DGUpload'.bin2hex(random_bytes(18)); $body=''; $parts=0;
    $quote=static function(string $value): string {
        if (strlen($value)>512 || preg_match('/[\x00-\x1f\x7f]/',$value))
            dg_gate_fail(400,'Invalid multipart field or filename');
        return str_replace(['\\','"'],['\\\\','\\"'],$value);
    };
    $append=function(string $name,string $value,?string $filename=null,string $mime='application/octet-stream') use (&$body,&$parts,$limit,$boundary,$quote) {
        if (++$parts>256) dg_gate_fail(413,'Too many multipart parts');
        $header='--'.$boundary."\r\nContent-Disposition: form-data; name=\"".$quote($name).'"';
        if ($filename!==null) $header.='; filename="'.$quote($filename).'"';
        $header.="\r\n";
        if ($filename!==null) {
            if (!preg_match('~^[a-zA-Z0-9!#$&^_.+-]+/[a-zA-Z0-9!#$&^_.+-]+$~D',$mime)) $mime='application/octet-stream';
            $header.='Content-Type: '.$mime."\r\n";
        }
        if (strlen($body)+strlen($header)+strlen($value)+4>$limit)
            dg_gate_fail(413,'Multipart request exceeds gateway limit');
        $body.=$header."\r\n".$value."\r\n";
    };
    $fields=function($value,string $name,int $depth=0) use (&$fields,$append) {
        if ($depth>12) dg_gate_fail(400,'Multipart nesting exceeds limit');
        if (is_array($value)) foreach ($value as $key=>$item) $fields($item,$name.'['.$key.']',$depth+1);
        elseif (is_scalar($value)) $append($name,(string)$value);
    };
    foreach ($_POST as $name=>$value) $fields($value,(string)$name);
    $files=function($names,$temps,$errors,$types,string $field,int $depth=0) use (&$files,$append,$limit) {
        if ($depth>12) dg_gate_fail(400,'Multipart nesting exceeds limit');
        if (is_array($names)) {
            foreach ($names as $key=>$name) $files($name,is_array($temps)?($temps[$key]??null):null,
                is_array($errors)?($errors[$key]??null):null,is_array($types)?($types[$key]??null):null,$field.'['.$key.']',$depth+1);
            return;
        }
        if ($errors===UPLOAD_ERR_NO_FILE) return;
        if ($errors!==UPLOAD_ERR_OK || !is_string($temps) || !is_uploaded_file($temps))
            dg_gate_fail(400,'Multipart upload was incomplete or rejected by PHP');
        $size=filesize($temps);
        if ($size===false || $size>$limit) dg_gate_fail(413,'Upload exceeds gateway limit');
        $data=file_get_contents($temps,false,null,0,$limit+1);
        if ($data===false || strlen($data)!==$size) dg_gate_fail(400,'Cannot read received upload');
        $filename=basename(str_replace('\\','/',is_string($names)?$names:'upload'));
        $append($field,$data,$filename,is_string($types)?$types:'application/octet-stream');
    };
    foreach ($_FILES as $name=>$file) {
        if (!is_array($file)) dg_gate_fail(400,'Malformed multipart upload');
        $files($file['name']??null,$file['tmp_name']??null,$file['error']??null,$file['type']??null,(string)$name);
    }
    if (!$parts && (int)($_SERVER['CONTENT_LENGTH']??0)>0)
        dg_gate_fail(400,'No multipart fields received; check PHP upload limits and boundary');
    $body.='--'.$boundary."--\r\n";
    if (strlen($body)>$limit) dg_gate_fail(413,'Multipart request exceeds gateway limit');
    return [$body,'multipart/form-data; boundary='.$boundary];
}

// Gateway mode is a FastCGI parameter set by Nginx, never an HTTP header.
if (($_SERVER['DG_GATEWAY_MODE'] ?? '') === '1') {
    function dg_gate_fail(int $status, string $message): void {
        http_response_code($status); header('Content-Type: application/json');
        header('Cache-Control: no-store'); echo json_encode(['error'=>$message]); exit;
    }
    function dg_gate_redact($value) {
        if (!is_array($value)) return is_string($value) ? substr($value, 0, 4096) : $value;
        $result=[];
        foreach ($value as $key=>$item) $result[$key]=preg_match('/pass|secret|token|authorization|cookie|security.?answer|^answer$/i',(string)$key) ? '[REDACTED]' : dg_gate_redact($item);
        return $result;
    }
    $configPath = getenv('DG_GATEWAY_CONFIG', true) ?: '/var/www/decoy-website/private/gateway_sites.json';
    $config = is_file($configPath) ? json_decode(file_get_contents($configPath), true) : null;
    $siteId = $_SERVER['DG_SITE_ID'] ?? '';
    $site = $config['sites'][$siteId] ?? null;
    if (!is_array($site) || empty($config['deployment_id']) || count($config['sites']) > 8) dg_gate_fail(503, 'Website routing is not configured');
    foreach (['production','decoy'] as $destination) {
        $url=parse_url($site[$destination] ?? '');
        if (!is_array($url) || !in_array($url['scheme'] ?? '', ['http','https'], true) || empty($url['host']) || isset($url['user']) || isset($url['query']) || isset($url['fragment'])) dg_gate_fail(503,'Invalid configured upstream');
    }
    $method=strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (!in_array($method,['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'],true)) dg_gate_fail(405,'Unsupported method');
    if (strtolower($_SERVER['HTTP_UPGRADE'] ?? '') === 'websocket') dg_gate_fail(426,'This gateway currently supports HTTP and Socket.IO polling');
    $uri=$_SERVER['REQUEST_URI'] ?? '/';
    if (!str_starts_with($uri,'/') || str_starts_with($uri,'//') || preg_match('/[\r\n\x00]/',$uri)) dg_gate_fail(400,'Invalid request target');
    $maxBody=1048576;
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0)>$maxBody) dg_gate_fail(413,'Request body exceeds gateway inspection limit');
    $body=file_get_contents('php://input',false,null,0,$maxBody+1);
    if ($body===false || strlen($body)>$maxBody) dg_gate_fail(413,'Request body exceeds gateway inspection limit');
    $multipartType=null;
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'multipart/form-data') !== false) {
        if ($method!=='POST') dg_gate_fail(415,'Multipart forwarding currently supports POST only');
        [$body,$multipartType]=dg_gateway_multipart($maxBody);
    }
    $fields=array_merge($_GET,$_POST);
    if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')!==false) {
        $json=json_decode($body,true); if (is_array($json)) $fields=array_merge($fields,$json);
    } elseif (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/x-www-form-urlencoded')!==false) {
        parse_str($body,$formFields); $fields=array_merge($fields,$formFields);
    }
    $inspection=$uri.' '.$body.' '.json_encode($fields).' '.($_SERVER['HTTP_USER_AGENT'] ?? '');
    // Inspect decoded variants without changing the bytes sent to the application.
    for ($decode=0;$decode<2;$decode++) $inspection=rawurldecode($inspection);
    $patterns=[
        'SQL Injection'=>'/union\s+(?:all\s+)?select|drop\s+table|[\x27\x22]\s*(?:--|#)|[\x27\x22]\s*or\b|\bor\s+[\x27\x22]?\d+[\x27\x22]?\s*=\s*[\x27\x22]?\d+|sleep\s*\(|information_schema/i',
        'Cross-Site Scripting'=>'/<script\b|onerror\s*=|javascript:/i',
        'Directory Traversal'=>'~\.\.[/\\\\]|/etc/passwd|/etc/shadow~i',
        'Command Injection'=>'/shell_exec|system\s*\(|\/bin\/sh|;\s*(?:ls|whoami)\b|&&\s*whoami\b/i',
        'Scanner Probe'=>'/\b(?:sqlmap|nikto|nmap|masscan|gobuster|dirbuster|ffuf|metasploit)\b/i'
    ];
    $matches=[]; foreach ($patterns as $name=>$pattern) if (preg_match($pattern,$inspection)) $matches[]=$name;
    if ($dgPresentation && preg_match('/\bnmap\b/i',$inspection)) $matches=array_values(array_diff($matches,['Scanner Probe']));
    $canaryHit=false;
    $privatePath=$site['private'] ?? '';
    $canaries=$privatePath && is_file($privatePath.'/canaries.json') ? json_decode(file_get_contents($privatePath.'/canaries.json'),true) : [];
    if (is_array($canaries)) array_walk_recursive($fields,function($value) use ($canaries,&$canaryHit) {
        foreach ($canaries as $canary) if (is_scalar($value) && is_scalar($canary) && (string)$value===(string)$canary) $canaryHit=true;
    });
    if ($canaryHit) $matches[]='Canary Parameter Tampering';
    $ip=$_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!filter_var($ip,FILTER_VALIDATE_IP)) dg_gate_fail(400,'Invalid gateway client address');
    $logDir=getenv('DG_GATEWAY_LOG_DIR',true) ?: '/var/log/decoyguard';
    $routeFile=$logDir.'/gateway_routes.json';
    $lock=@fopen($routeFile,'c+');
    if (!$lock || !flock($lock,LOCK_EX)) dg_gate_fail(503,'Routing state is unavailable');
    $rawState=stream_get_contents($lock);
    $state=json_decode($rawState,true);
    if (trim($rawState)!=='' && (!is_array($state) || !is_array($state['routes'] ?? null))) {
        flock($lock,LOCK_UN);fclose($lock);dg_gate_fail(503,'Routing state is corrupt; refusing to forward');
    }
    if (!is_array($state) || !is_array($state['routes'] ?? null) || ($state['deployment_id'] ?? '') !== $config['deployment_id']) $state=['deployment_id'=>$config['deployment_id'],'routes'=>[]];
    $now=time();
    foreach ($state['routes'] as $key=>$value) if (($value['expires'] ?? 0)<$now) unset($state['routes'][$key]);
    // The host core writes BE / accumulated-risk decisions to a separate append-only feed.
    $decisions=$logDir.'/routing_decisions.jsonl';
    if (is_file($decisions)) {
        $feed=fopen($decisions,'rb'); $size=filesize($decisions);
        if ($size>1048576) { fseek($feed,$size-1048576); fgets($feed); }
        while (($line=fgets($feed))!==false) {
            $decision=json_decode($line,true);
            if (!is_array($decision) || ($decision['deployment_id'] ?? '')!==$config['deployment_id'] || ($decision['expires'] ?? 0)<$now) continue;
            if (!isset($config['sites'][$decision['site_id'] ?? '']) || !filter_var($decision['ip'] ?? '',FILTER_VALIDATE_IP)) continue;
            $decisionKey=$decision['site_id'].'|'.$decision['ip'];
            if (($state['routes'][$decisionKey]['expires'] ?? 0)<$decision['expires'])
                $state['routes'][$decisionKey]=['expires'=>$decision['expires'],'reason'=>'Detection engine decision'];
        }
        fclose($feed);
    }
    $key=$siteId.'|'.$ip;
    if ($matches) $state['routes'][$key]=['expires'=>$now+7200,'reason'=>implode(', ',$matches)];
    $contained=isset($state['routes'][$key]);
    $reason=$contained ? $state['routes'][$key]['reason'] : 'Normal request';
    $stateJson=json_encode($state);
    rewind($lock);
    if (!ftruncate($lock,0) || fwrite($lock,$stateJson)!==strlen($stateJson)) { flock($lock,LOCK_UN);fclose($lock);dg_gate_fail(503,'Routing state write failed'); }
    fflush($lock);flock($lock,LOCK_UN);fclose($lock);
    $destination=$contained?'decoy':'production';
    $base=rtrim($site[$destination],'/');
    $target=$base.$uri;
    $requestId=$_SERVER['DG_REQUEST_ID'] ?? '';
    if (!preg_match('/^[a-f0-9]{32}$/',$requestId)) $requestId=bin2hex(random_bytes(16));
    $outHeaders=[];
    $hop=['host','connection','content-length','transfer-encoding','expect','upgrade','proxy-authorization','proxy-connection','keep-alive','te','trailer'];
    foreach (explode(',',$_SERVER['HTTP_CONNECTION'] ?? '') as $connectionHeader) {
        $headerName=strtolower(trim($connectionHeader));
        if ($headerName!=='') $hop[]=$headerName;
    }
    foreach (getallheaders() as $name=>$value) {
        $lower=strtolower($name);
        if ($multipartType!==null && $lower==='content-type') continue;
        if (in_array($lower,$hop,true) || str_starts_with($lower,'x-decoy') || str_starts_with($lower,'x-forwarded') || $lower==='x-real-ip') continue;
        if (preg_match('/[\r\n]/',(string)$value)) continue;
        $outHeaders[]=$name.': '.$value;
    }
    if ($multipartType!==null) $outHeaders[]='Content-Type: '.$multipartType;
    $outHeaders[]='Connection: close';
    $outHeaders[]='X-Real-IP: '.$ip;
    $outHeaders[]='X-Forwarded-For: '.$ip;
    $outHeaders[]='X-Forwarded-Proto: '.((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off')?'https':'http');
    $outHeaders[]='X-Decoy-Request-ID: '.$requestId;
    $outHeaders[]='X-Decoy-Site-ID: '.$siteId;
    $outHeaders[]='X-Decoy-Entry-Point: protected-gateway';
    if (strlen($body)>0 || in_array($method,['POST','PUT','PATCH'],true)) $outHeaders[]='Content-Length: '.strlen($body);
    $context=stream_context_create(['http'=>['method'=>$method,'header'=>implode("\r\n",$outHeaders),'content'=>$body,'ignore_errors'=>true,'follow_location'=>0,'max_redirects'=>0,'timeout'=>95,'protocol_version'=>1.1]]);
    $stream=@fopen($target,'rb',false,$context);
    $responseHeaders=$http_response_header ?? [];
    $status=502; $exploit=null; $applicationFinding=null; $upstreamArtifacts=[];
    $responseHop=['connection','transfer-encoding','upgrade','proxy-authenticate','proxy-authorization','proxy-connection','keep-alive','te','trailer'];
    foreach ($responseHeaders as $line) if (stripos($line,'Connection:')===0) {
        foreach (explode(',',substr($line,11)) as $name) $responseHop[]=strtolower(trim($name));
    }
    if ($stream!==false) {
        foreach ($responseHeaders as $line) {
            if (preg_match('~^HTTP/\S+\s+(\d{3})~',$line,$m)) { $status=(int)$m[1]; continue; }
            $colon=strpos($line,':'); if ($colon===false) continue;
            $name=substr($line,0,$colon);$value=trim(substr($line,$colon+1));$lower=strtolower($name);
            if ($lower==='x-decoyguard-artifact-evidence') {
                if ($destination==='decoy' && strlen($value)<=6000) {
                    $bytes=base64_decode($value,true); $items=$bytes===false?null:json_decode($bytes,true);
                    if (is_array($items)) foreach (array_slice($items,0,8) as $item) {
                        if (is_array($item) && ($item['site_id']??'')===$siteId &&
                            is_string($item['sha256']??null) && is_string($item['storage_name']??null) &&
                            is_string($item['name']??null) && is_int($item['size_bytes']??null) &&
                            $item['size_bytes']>=0 && $item['size_bytes']<=1048576 &&
                            preg_match('/^[a-f0-9]{64}$/D',$item['sha256']??'') &&
                            preg_match('/^[a-f0-9]{32}\.bin$/D',$item['storage_name']??'')) $upstreamArtifacts[]=$item;
                    }
                }
                continue; // Private evidence header is not a public download mechanism.
            }
            if ($lower==='x-decoyguard-exploit-result') $exploit=$value;
            // Trust configured upstream response headers, never client parameters.
            if ($lower==='x-decoyguard-app-finding' && strlen($value)<=2048) {
                $decoded=base64_decode($value,true);
                $candidate=$decoded===false ? null : json_decode($decoded,true);
                if (dg_valid_application_finding($candidate)) $applicationFinding=$candidate;
            }
            if (in_array($lower,array_merge($responseHop,['x-decoyguard-target','x-decoyguard-site','x-decoyguard-routing-reason','x-accel-redirect']),true)) continue;
            if ($lower==='location' && str_starts_with($value,$base.'/')) $value=substr($value,strlen($base));
            header($name.': '.$value,false);
        }
    }
    http_response_code($status);
    header('X-DecoyGuard-Target: '.$destination);
    header('X-DecoyGuard-Site: '.$siteId);
    header('X-DecoyGuard-Routing-Reason: '.$reason);
    $evidence=json_encode(dg_gate_redact($fields));
    $canonical=['SQL Injection'=>'or 1=1','Cross-Site Scripting'=>'<script','Directory Traversal'=>'../','Command Injection'=>'shell_exec','Scanner Probe'=>'nmap'];
    foreach ($matches as $match) if (isset($canonical[$match])) $evidence.=' '.$canonical[$match];
    $event=['event_id'=>'DG-WEB-'.$requestId,'timestamp'=>gmdate('c'),'source'=>'gateway-decision','site_id'=>$siteId,
        'remote_addr'=>$ip,'source_ip'=>$ip,'target_type'=>$destination==='production'?'production':'decoy',
        'entry_point'=>'protected-gateway','entry_target_type'=>'production','upstream_target_type'=>$destination,
        'gateway_port'=>(int)($_SERVER['SERVER_PORT'] ?? 0),
        'method'=>$method,'uri'=>parse_url($uri,PHP_URL_PATH),'args'=>parse_url($uri,PHP_URL_QUERY) ?? '',
        'request'=>$method.' '.$uri.' HTTP/1.1','status'=>$status,'user_agent'=>$_SERVER['HTTP_USER_AGENT'] ?? '',
        'fields'=>dg_gate_redact($fields),'detection_text'=>$evidence,'attack_type'=>$matches?implode(', ',$matches):'Normal Traffic',
        'canary_hit'=>$canaryHit,'risk_score'=>$canaryHit?95:($matches?85:0),'severity'=>$matches?'HIGH':'INFO','route'=>$contained?'HONEYPOT':'REAL_SERVER',
        'decision'=>$contained?'CONTAINED':'ALLOW','routing_reason'=>$reason,'exploit_result'=>$exploit];
    if ($status===403 && dg_valid_application_finding($applicationFinding)) {
        $event['security_finding']=$applicationFinding;
        $event['attack_type']='Account Parameter Tampering';
        $event['risk_score']=max(95,$event['risk_score']);
        $event['severity']='HIGH';
    }
    $event['forensics']=['artifacts'=>$upstreamArtifacts];
    $event['peer_ip']=$_SERVER['REMOTE_ADDR'] ?? '';
    $event['client_ip_origin']='gateway-transport-peer';
    dg_emit_syslog($event);
    if (@file_put_contents($logDir.'/access.json',json_encode($event,JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE)."\n",FILE_APPEND|LOCK_EX)===false) error_log('DecoyGuard: gateway telemetry write failed');
    if ($stream===false) { header('Content-Type: application/json');echo json_encode(['error'=>'Configured '.$destination.' upstream is unavailable','site_id'=>$siteId]);exit; }
    if ($method!=='HEAD') fpassthru($stream);
    fclose($stream);exit;
}

// Store only bytes actually received by PHP. A request path or shell command
// is never evidence of a captured file. Files are inert private .bin objects.
function dg_capture_uploads(array $context): array {
    $result=['artifacts'=>[], 'errors'=>[]];
    if (!$_FILES) return $result;
    if (getenv('DECOY_ARTIFACT_CAPTURE', true)==='0') {
        $result['errors'][]='capture_disabled'; return $result;
    }
    $entries=[]; $truncated=false;
    $walk=function($names,$temps,$errors,$field,$depth=0) use (&$walk,&$entries,&$truncated) {
        if ($depth>12 || count($entries)>=8) { $truncated=true; return; }
        if (is_array($names)) {
            foreach ($names as $key=>$name) {
                if (count($entries)>=8) { $truncated=true; break; }
                $walk($name,is_array($temps)?($temps[$key]??null):null,
                    is_array($errors)?($errors[$key]??null):null,$field,$depth+1);
            }
        } else $entries[]=['name'=>$names,'tmp'=>$temps,'error'=>$errors,'field'=>$field];
    };
    foreach ($_FILES as $field=>$upload) {
        if (!is_array($upload)) continue;
        $walk($upload['name']??null,$upload['tmp_name']??null,$upload['error']??null,(string)$field);
    }
    if ($truncated) $result['errors'][]='capture_file_limit_8';
    $private=getenv('DECOY_PRIVATE_DIR') ?: '/var/www/decoyguard-private';
    $store=getenv('DECOY_ARTIFACT_DIR') ?: $private.'/backend-state/artifacts';
    if (!is_dir($store) && !@mkdir($store,0700,true)) {
        $result['errors'][]='storage_unavailable'; return $result;
    }
    $store=realpath($store); $public=realpath($_SERVER['DOCUMENT_ROOT']??'');
    if (!$store || !$public || $store===$public || str_starts_with($store,$public.DIRECTORY_SEPARATOR)) {
        $result['errors'][]='storage_must_be_outside_public_root'; return $result;
    }
    $lock=@fopen($store.'/.capture.lock','c');
    if (!$lock || !flock($lock,LOCK_EX)) {
        if ($lock) fclose($lock);
        $result['errors'][]='storage_lock_unavailable'; return $result;
    }
    try {
        $used=0; $count=0;
        foreach (new DirectoryIterator($store) as $file) {
            if ($file->isLink() || !$file->isFile() || $file->getExtension()!=='bin') continue;
            $used+=$file->getSize(); $count++;
        }
        foreach ($entries as $entry) {
            if ($entry['error']===UPLOAD_ERR_NO_FILE) continue;
            if ($entry['error']!==UPLOAD_ERR_OK || !is_string($entry['tmp']) || !is_uploaded_file($entry['tmp'])) {
                $result['errors'][]='php_upload_incomplete_or_invalid'; continue;
            }
            $size=@filesize($entry['tmp']);
            if ($size===false || $size>1048576) { $result['errors'][]='file_exceeds_1_MiB'; continue; }
            if ($count>=500 || $used+$size>52428800) { $result['errors'][]='storage_quota_reached'; continue; }
            $id=bin2hex(random_bytes(16)); $object=$store.'/'.$id.'.bin';
            $source=@fopen($entry['tmp'],'rb'); $dest=@fopen($object,'x+b');
            if (!$source || !$dest) {
                if ($source) fclose($source);
                if ($dest) { fclose($dest); @unlink($object); }
                $result['errors'][]='file_copy_failed'; continue;
            }
            @chmod($object,0600);
            $copied=stream_copy_to_stream($source,$dest,1048577); fclose($source);
            $flushed=fflush($dest); fclose($dest);
            if (!$flushed || $copied!==$size || $copied>1048576) {
                @unlink($object); $result['errors'][]='file_copy_failed'; continue;
            }
            // Hash the stored bytes, not the submitted filename or client metadata.
            $hash=hash_file('sha256',$object);
            if ($hash===false) { @unlink($object); $result['errors'][]='hash_failed'; continue; }
            $name=basename(str_replace('\\','/',is_string($entry['name'])?$entry['name']:'upload'));
            $name=substr(preg_replace('/[\x00-\x1f\x7f]/','_',$name),0,180);
            $record=['artifact_id'=>$id,'name'=>$name?:'upload','size_bytes'=>$size,
                'hash'=>$hash,'sha256'=>$hash,'hash_algorithm'=>'SHA-256',
                'storage_name'=>$id.'.bin','status'=>'CAPTURED_NOT_SCANNED',
                'capture_basis'=>'received_http_upload','captured_at'=>gmdate('c'),
                'event_id'=>$context['event_id'],'site_id'=>$context['site_id'],
                'field'=>substr($entry['field'],0,120)];
            $manifest=$object.'.json';
            $json=json_encode($record,JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES);
            if ($json===false || @file_put_contents($manifest,$json,LOCK_EX)!==strlen($json)) {
                @unlink($object); @unlink($manifest); $result['errors'][]='metadata_write_failed'; continue;
            }
            @chmod($manifest,0600); $used+=$size; $count++;
            $result['artifacts'][]=$record;
        }
    } catch (Throwable $error) {
        $result['errors'][]='capture_storage_error';
        error_log('DecoyGuard: artifact capture storage error');
    } finally { flock($lock,LOCK_UN); fclose($lock); }
    return $result;
}

// Run only inside the decoy application, never in the dashboard PHP service.
if (defined('DG_CAPTURED')) return;
$active = getenv('DECOYGUARD_ACTIVE', true);
if ($active === false) $active = getenv('DECOYGUARD_ACTIVE');
if ($active !== '1') { header('X-DecoyGuard-Capture: disabled'); return; }
define('DG_CAPTURED', true);
header('X-DecoyGuard-Capture: active');
$missingDocument = (string)($_SERVER['REDIRECT_STATUS'] ?? '') === '404';
if ($missingDocument) {
    http_response_code(404);
    if (!empty($_SERVER['REDIRECT_URL'])) $_SERVER['REQUEST_URI'] = $_SERVER['REDIRECT_URL']
        . (!empty($_SERVER['REDIRECT_QUERY_STRING']) ? '?'.$_SERVER['REDIRECT_QUERY_STRING'] : '');
}
$uri = $_SERVER['REQUEST_URI'] ?? '/';
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$body = file_get_contents('php://input', false, null, 0, 65536);
$fields = array_merge($_GET, $_POST);
if (stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    $json = json_decode($body, true);
    if (is_array($json)) $fields = array_merge($fields, $json);
}
function dg_redact($value) {
    if (!is_array($value)) return is_string($value) ? substr($value, 0, 4096) : $value;
    $out = [];
    foreach ($value as $key => $item) {
        $out[$key] = preg_match('/pass|secret|token|authorization|cookie|security.?answer|^answer$/i', (string)$key)
            ? '[REDACTED]' : dg_redact($item);
    }
    return $out;
}
// Detect before redaction: a probe in a password still generates evidence,
// without saving the password itself.
$inspection = urldecode($uri . ' ' . $body . ' ' . json_encode($fields) . ' ' . ($_SERVER['HTTP_USER_AGENT'] ?? ''));
$signatures = [
    'SQL Injection' => '/union\s+select|or\s+[\x27\x22]?1[\x27\x22]?\s*=\s*[\x27\x22]?1|[\x27\x22]\s*or\b|sleep\s*\(|information_schema/i',
    'Cross-Site Scripting' => '/<script|onerror\s*=|javascript:/i',
    'Directory Traversal' => '~\.\.[/\\\\]|/etc/passwd~i',
    'Command Injection' => '/shell_exec|system\s*\(|cmd=|\/bin\/sh/i',
    'Scanner Probe' => '/\b(?:nmap|sqlmap|nikto|masscan|gobuster|dirbuster|ffuf|metasploit)\b/i'
];
$matches = [];
foreach ($signatures as $name => $pattern) if (preg_match($pattern, $inspection)) $matches[] = $name;
if ($dgPresentation && preg_match('/\bnmap\b/i',$inspection)) $matches=array_values(array_diff($matches,['Scanner Probe']));
$canonical = ['SQL Injection'=>'or 1=1', 'Cross-Site Scripting'=>'<script', 'Directory Traversal'=>'../', 'Command Injection'=>'shell_exec', 'Scanner Probe'=>'nmap'];
$canaryHit = false;
$private = getenv('DECOY_PRIVATE_DIR') ?: '/var/www/decoyguard-private';
$canaries = is_file($private . '/canaries.json') ? json_decode(file_get_contents($private . '/canaries.json'), true) : [];
if (is_array($canaries)) {
    array_walk_recursive($fields, function ($value) use ($canaries, &$canaryHit) {
        foreach ($canaries as $canary) if (is_scalar($value) && is_scalar($canary) && (string)$value === (string)$canary) $canaryHit = true;
    });
}
$redacted = dg_redact($fields);
$evidence = json_encode($redacted);
foreach ($matches as $name) $evidence .= ' ' . $canonical[$name];
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
// The gateway overwrites X-Real-IP; trust it only when explicitly configured.
$isGateway = false;
if (getenv('DECOY_TRUST_PROXY', true) === '1') {
    foreach (['gateway','php'] as $proxyName) {
        $proxyIp = gethostbyname($proxyName);
        if ($proxyIp !== $proxyName && $ip === $proxyIp) { $isGateway = true; break; }
    }
}
if ($isGateway) {
    $candidate = $_SERVER['HTTP_X_REAL_IP'] ?? '';
    if (filter_var($candidate, FILTER_VALIDATE_IP)) $ip = $candidate;
}
$path = parse_url($uri, PHP_URL_PATH) ?: '/';
$event = [
    'event_id'=>'DG-WEB-' . ($isGateway && preg_match('/^[a-f0-9]{32}$/', $_SERVER['HTTP_X_DECOY_REQUEST_ID'] ?? '') ? $_SERVER['HTTP_X_DECOY_REQUEST_ID'] : bin2hex(random_bytes(16))), 'timestamp'=>date('c'),
    'source'=>'decoy-web', 'site_id'=>getenv('DECOY_SITE_ID', true) ?: 'juiceshop', 'source_ip'=>$ip, 'remote_addr'=>$ip,
    'target_type'=>'decoy', 'method'=>$method, 'uri'=>$path,
    'entry_point'=>($isGateway && ($_SERVER['HTTP_X_DECOY_ENTRY_POINT'] ?? '')==='protected-gateway') ? 'gateway-decoy-copy' : 'direct-decoy',
    'request'=>$method . ' ' . $path . ' HTTP/1.1',
    'user_agent'=>substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 2048),
    'fields'=>$redacted, 'detection_text'=>$evidence, 'canary_hit'=>$canaryHit,
    'attack_type'=>$matches ? implode(', ', $matches) : 'Decoy Interaction',
    'risk_score'=>$canaryHit ? 95 : ($matches ? 85 : 0), 'severity'=>($matches || $canaryHit) ? 'HIGH' : 'INFO',
    'decision'=>'CONTAINED', 'route'=>'HONEYPOT', 'subsystem'=>'DECOYGUARD_WEB'
];
$uploadCapture=dg_capture_uploads(['event_id'=>$event['event_id'],'site_id'=>$event['site_id']]);
$event['forensics']=['artifacts'=>$uploadCapture['artifacts']];
$event['artifact_capture_errors']=$uploadCapture['errors'];
if ($uploadCapture['artifacts']) {
    $compact=[];
    foreach ($uploadCapture['artifacts'] as $artifact) {
        $item=array_intersect_key($artifact,array_flip(['artifact_id','sha256','size_bytes','storage_name','status','site_id','event_id']));
        $item['name']=substr(preg_replace('/[^\x20-\x7e]/','_',$artifact['name']),0,80);
        $item['capture_basis']='received_http_upload'; $compact[]=$item;
    }
    $header=base64_encode(json_encode($compact,JSON_INVALID_UTF8_SUBSTITUTE|JSON_UNESCAPED_SLASHES));
    if (strlen($header)<=6000) header('X-DecoyGuard-Artifact-Evidence: '.$header);
}

register_shutdown_function(function () use ($event) {
    $finding=$GLOBALS['DG_APPLICATION_FINDING'] ?? null;
    if ((http_response_code() ?: 200)===403 && dg_valid_application_finding($finding)) {
        $event['security_finding']=$finding;
        $event['attack_type']='Account Parameter Tampering';
        $event['risk_score']=max(95,$event['risk_score']);
        $event['severity']='HIGH';
    }
    $dbPath = getenv('DECOY_DB_PATH') ?: '/var/www/decoy-database/decoy_website.db';
    // Preserve all raw JSONL telemetry, but store only actual detections in the incident DB.
    if (is_file($dbPath) && ($event['risk_score'] > 0 || $event['canary_hit'])) {
        try {
            $db = new PDO('sqlite:' . $dbPath, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
            $stmt = $db->prepare('INSERT INTO security_events (source_ip, event_type, severity, description) VALUES (?, ?, ?, ?)');
            $stmt->execute([$event['source_ip'], $event['attack_type'], $event['severity'], $event['request']]);
        } catch (Throwable $error) { /* JSONL remains the authoritative capture. */ }
    }
    $event['status'] = http_response_code() ?: 200;
    $event['peer_ip']=$_SERVER['REMOTE_ADDR'] ?? '';
    $event['client_ip_origin']=($event['source_ip'] ?? '') !== ($event['peer_ip'] ?? '') ? 'trusted-proxy' : 'transport-peer';
    $event['exploit_result'] = $GLOBALS['DG_EXPLOIT_RESULT'] ?? null;
    dg_emit_syslog($event);
    $file = getenv('TELEMETRY_LOG_PATH') ?: '/var/log/decoyguard/events.jsonl';
    if (@file_put_contents($file, json_encode($event, JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX) === false)
        error_log('DecoyGuard: telemetry write failed; check log volume permissions');
});

// An Apache error dispatch is telemetry, not a login or synthetic backend action.
if ($missingDocument) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Not Found\n";
    exit;
}
