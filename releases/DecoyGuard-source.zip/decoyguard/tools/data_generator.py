import os
import re
import json
import sqlite3
import random
from faker import Faker
if __package__ in (None, ""):
    from adaptive_analyzer import AdaptiveSemanticAnalyzer
else:
    from .adaptive_analyzer import AdaptiveSemanticAnalyzer

fake = Faker()

# Plausible domains for synthetic records. These addresses are for display only;
# they may coincide with real inboxes and must not be used to send messages.
SYNTHETIC_EMAIL_DOMAINS = ("gmail.com", "yahoo.com", "outlook.com", "hotmail.com")

# Central Honeytoken / Canary Definitions
# Single source of truth for all DecoyGuard canary values.
CANARY_DEFINITIONS = {
    "account_id": "999",
    "email": "admin.vault@decoy.test",
    "api_key": "CANARY_SEC_KEY_999_EXFIL",
    "username": "canary_user"
}


def export_canaries(output_path="decoy-website/private/canaries.json"):
    """
    Export the central canary definitions so other DecoyGuard
    components (such as guard_middleware.php) use the same values.
    """
    directory = os.path.dirname(output_path)

    if directory:
        os.makedirs(directory, exist_ok=True)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(CANARY_DEFINITIONS, f, indent=2)

    print(f"[✓] Canary definitions exported: {output_path}")

# Backwards-compatible aliases used by the existing generator logic
CANARY_ACCOUNT_ID = int(CANARY_DEFINITIONS["account_id"])
CANARY_EMAIL = CANARY_DEFINITIONS["email"]
CANARY_API_KEY = CANARY_DEFINITIONS["api_key"]
CANARY_USERNAME = CANARY_DEFINITIONS["username"]

FIELD_RULES = {
    # Identity / Authentication
    "email": "EMAIL", "e-mail": "EMAIL", "email_address": "EMAIL",
    "username": "USERNAME", "user": "USERNAME", "handle": "USERNAME",
    "name": "NAME", "full_name": "NAME", "firstname": "FIRST_NAME", "first_name": "FIRST_NAME",
    "lastname": "LAST_NAME", "last_name": "LAST_NAME", "password": "PASSWORD", "pass": "PASSWORD",

    # Financial & Numeric
    "price": "PRICE", "amount": "MONEY", "balance": "MONEY", "cost": "MONEY", "salary": "MONEY",
    "currency": "CURRENCY", "quantity": "INTEGER", "qty": "INTEGER", "count": "INTEGER",

    # IDs & Foreign Keys
    "id": "ID", "user_id": "USER_ID", "account_id": "ACCOUNT_ID", "account": "ACCOUNT_ID",
    "product_id": "PRODUCT_ID", "order_id": "ORDER_ID",

    # Contact & Location
    "phone": "PHONE", "mobile": "PHONE", "tel": "PHONE",
    "address": "ADDRESS", "street": "ADDRESS", "city": "CITY", "state": "STATE", "country": "COUNTRY",
    "zip": "ZIPCODE", "zipcode": "ZIPCODE", "postal_code": "ZIPCODE",

    # Content & Status
    "title": "TITLE", "subject": "TITLE", "comment": "TEXT", "description": "TEXT",
    "content": "TEXT", "message": "TEXT", "status": "STATUS", "date": "DATE",
    "created_at": "DATETIME", "updated_at": "DATETIME", "url": "URL", "rating": "RATING"
}

ENTITY_RULES = {
    "user": "users", "users": "users", "customer": "users", "customers": "users",
    "account": "accounts", "accounts": "accounts", "transaction": "transactions", "transactions": "transactions",
    "product": "products", "products": "products", "item": "products", "items": "products",
    "order": "orders", "orders": "orders", "cart": "carts", "carts": "carts",
    "profile": "profiles", "profiles": "profiles", "admin": "admins", "admins": "admins",
    "review": "reviews", "reviews": "reviews", "message": "messages", "messages": "messages"
}

ENTITY_DEFAULTS = {
    "users": {"password": "PASSWORD", "username": "USERNAME", "full_name": "NAME", "email": "EMAIL", "phone": "PHONE"},
    "accounts": {"account_id": "ACCOUNT_ID", "user_id": "USER_ID", "balance": "MONEY", "currency": "CURRENCY", "status": "STATUS"},
    "transactions": {"user_id": "USER_ID", "account_id": "ACCOUNT_ID", "amount": "MONEY", "status": "STATUS", "created_at": "DATETIME"},
    "products": {"title": "TITLE", "price": "PRICE", "quantity": "INTEGER"},
    "orders": {"user_id": "USER_ID", "amount": "MONEY", "status": "STATUS", "created_at": "DATETIME"},
    "carts": {"user_id": "USER_ID", "product_id": "PRODUCT_ID", "quantity": "INTEGER"},
    "profiles": {"user_id": "USER_ID", "username": "USERNAME", "full_name": "NAME", "email": "EMAIL"},
    "admins": {"username": "USERNAME", "email": "EMAIL", "password": "PASSWORD"},
    "reviews": {"user_id": "USER_ID", "product_id": "PRODUCT_ID", "rating": "RATING", "comment": "TEXT"},
    "messages": {"user_id": "USER_ID", "title": "TITLE", "message": "TEXT", "created_at": "DATETIME"}
}

class RuleBasedSchemaAnalyzer:
    @staticmethod
    def normalize_field_name(raw_name):
        cleaned = re.sub(r"^(txt|input|lbl|form|val|data|field)[_-]", "", str(raw_name).strip().lower())
        return re.sub(r"[^a-zA-Z0-9_]", "", cleaned)

    @classmethod
    def map_field(cls, raw_field_name):
        norm = cls.normalize_field_name(raw_field_name)
        if norm in FIELD_RULES:
            return FIELD_RULES[norm]
        for key in sorted(FIELD_RULES.keys(), key=len, reverse=True):
            if key in norm:
                return FIELD_RULES[key]
        return None

    @staticmethod
    def detect_entities(routes):
        entities = set()
        for route in routes:
            parts = [p.lower() for p in re.split(r"[/_.-]", route) if p]
            for part in parts:
                if part in ENTITY_RULES:
                    entities.add(ENTITY_RULES[part])
        if not entities:
            entities.add("users")
        return sorted(list(entities))

    @staticmethod
    def detect_entity_from_route(route):
        parts = [p.lower() for p in re.split(r"[/_.-]", route) if p]
        for part in parts:
            if part in ENTITY_RULES:
                return ENTITY_RULES[part]
        return None

class SyntheticDataGenerator:
    def __init__(self, db_path="decoy-website/decoy-database/decoy_website.db"):
        self.db_path = db_path
        db_directory = os.path.dirname(self.db_path)
        if db_directory:
            os.makedirs(db_directory, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA foreign_keys = ON")

        self.generated_user_ids = []
        self.generated_account_ids = []
        self.generated_product_ids = []
        self.generated_order_ids = []
        self._ensure_telemetry_table()

    def _ensure_telemetry_table(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS security_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_ip TEXT, event_type TEXT, severity TEXT, description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.conn.commit()

    def generate_value(self, field_type):
        if field_type == "EMAIL":
            return f"{fake.user_name()}@{random.choice(SYNTHETIC_EMAIL_DOMAINS)}"
        elif field_type == "USERNAME":
            return fake.user_name()
        elif field_type == "NAME":
            return fake.name()
        elif field_type == "FIRST_NAME":
            return fake.first_name()
        elif field_type == "LAST_NAME":
            return fake.last_name()
        elif field_type == "PASSWORD":
            return fake.sha256()[:16]
        elif field_type in ["PRICE", "MONEY"]:
            return round(random.uniform(10.0, 5000.0), 2)
        elif field_type == "CURRENCY":
            return random.choice(["USD", "MYR", "EUR", "GBP", "SGD"])
        elif field_type == "INTEGER":
            return random.randint(1, 100)
        elif field_type == "USER_ID":
            return random.choice(self.generated_user_ids) if self.generated_user_ids else random.randint(1, 999)
        elif field_type == "ACCOUNT_ID":
            return random.choice(self.generated_account_ids) if self.generated_account_ids else random.randint(1000, 9999)
        elif field_type == "PRODUCT_ID":
            return random.choice(self.generated_product_ids) if self.generated_product_ids else random.randint(100, 9999)
        elif field_type == "ORDER_ID":
            return random.choice(self.generated_order_ids) if self.generated_order_ids else random.randint(100, 9999)
        elif field_type == "ID":
            return random.randint(100, 9999)
        elif field_type == "PHONE":
            return fake.phone_number()
        elif field_type == "ADDRESS":
            return fake.street_address()
        elif field_type == "CITY":
            return fake.city()
        elif field_type == "STATE":
            return fake.state()
        elif field_type == "COUNTRY":
            return fake.country()
        elif field_type == "ZIPCODE":
            return fake.zipcode()
        elif field_type == "TITLE":
            return fake.sentence(nb_words=4).rstrip(".")
        elif field_type == "TEXT":
            return fake.sentence(nb_words=8)
        elif field_type == "STATUS":
            return random.choice(["ACTIVE", "PENDING", "COMPLETED", "SETTLED", "CANCELLED"])
        elif field_type == "DATE":
            return fake.date_this_year().isoformat()
        elif field_type == "DATETIME":
            return fake.date_time_this_year().isoformat()
        elif field_type == "URL":
            return fake.url()
        elif field_type == "RATING":
            return random.randint(1, 5)
        return fake.sentence(nb_words=5)
    def create_and_seed_entity(self, table_name, field_dict, row_count=20):
        if not field_dict:
            return

        cur = self.conn.cursor()

        safe_table_name = re.sub(
            r"[^a-zA-Z0-9_]",
            "",
            table_name
        )

        safe_fields = self._ensure_entity_schema(
            safe_table_name,
            field_dict
        )

        # Refresh application data only; never delete security_events.
        cur.execute(f"DELETE FROM {safe_table_name}")
        col_names = list(safe_fields.keys())

        placeholders = ", ".join(["?"] * len(col_names))

        insert_sql = (
            f"INSERT INTO {safe_table_name} "
            f"({', '.join('"' + col + '"' for col in col_names)}) "
            f"VALUES ({placeholders})"
        )

        for _ in range(row_count):
            row = [
                self.generate_value(safe_fields[col])
                for col in col_names
            ]

            cur.execute(insert_sql, row)

            self._store_generated_id(
                safe_table_name,
                cur.lastrowid
            )

        self._inject_canary(
            safe_table_name,
            safe_fields
        )

        self.conn.commit()

        print(
            f"[✓] Generated entity: "
            f"'{safe_table_name}' ({row_count} rows)"
        )

    def _ensure_entity_schema(self, table_name, field_dict):
        """
        Ensure an existing SQLite entity table contains every field
        discovered from the mirrored website.

        This allows the generator to adapt when a new website introduces
        fields that were not present in a previous generated database.
        """
        cur = self.conn.cursor()
        safe_table_name = re.sub(
            r"[^a-zA-Z0-9_]",
            "",
            table_name
        )
        safe_fields = {
            re.sub(r"[^a-zA-Z0-9_]", "", k): v
            for k, v in field_dict.items()
            if re.sub(r"[^a-zA-Z0-9_]", "", k) and re.sub(r"[^a-zA-Z0-9_]", "", k).lower() != "id"
        }
        # Create the table if it does not exist.
        columns = [
            "id INTEGER PRIMARY KEY AUTOINCREMENT"
        ]
        for field in safe_fields:
            columns.append(f'"{field}" TEXT')
        cur.execute(
            f"CREATE TABLE IF NOT EXISTS {safe_table_name} "
            f"({', '.join(columns)})"
        )
        # Inspect the existing schema.
        cur.execute(
            f"PRAGMA table_info({safe_table_name})"
        )
        existing_columns = {
            row[1]
            for row in cur.fetchall()
        }
        # Add newly discovered fields.
        for field in safe_fields:
            if field not in existing_columns:
                cur.execute(
                    f"ALTER TABLE {safe_table_name} "
                    f'ADD COLUMN "{field}" TEXT'
                )
                print(
                    f"[+] Added adaptive column: "
                    f"{safe_table_name}.{field}"
                )
        self.conn.commit()
        return safe_fields

    def _store_generated_id(self, table_name, inserted_id):
        if table_name == "users":
            self.generated_user_ids.append(inserted_id)
        elif table_name == "accounts":
            self.generated_account_ids.append(inserted_id)
        elif table_name == "products":
            self.generated_product_ids.append(inserted_id)
        elif table_name == "orders":
            self.generated_order_ids.append(inserted_id)

    def _inject_canary(self, table_name, field_dict):
        cur = self.conn.cursor()
        col_names = list(field_dict.keys())
        if not col_names:
            return

        canary_data = []
        for col in col_names:
            ftype = field_dict[col]
            if table_name == "accounts":
                canary_data.append(str(CANARY_ACCOUNT_ID) if ftype == "ACCOUNT_ID" else ("99999999.00" if ftype in ["MONEY", "PRICE"] else (CANARY_EMAIL if ftype == "EMAIL" else "CANARY_VAULT")))
            elif table_name == "admins":
                canary_data.append(
                    CANARY_USERNAME if ftype == "USERNAME"
                    else CANARY_EMAIL if ftype == "EMAIL"
                    else CANARY_API_KEY if ftype == "PASSWORD"
                    else "ADMIN_CANARY"
                )
            elif table_name == "users":
                if ftype in ["ACCOUNT_ID", "ID", "USER_ID"]:
                    canary_data.append(str(CANARY_ACCOUNT_ID))
                elif ftype == "EMAIL":
                    canary_data.append(CANARY_EMAIL)
                elif ftype == "PASSWORD":
                    canary_data.append(CANARY_API_KEY)
                elif ftype == "USERNAME":
                    canary_data.append(CANARY_USERNAME)
                elif ftype == "NAME":
                    canary_data.append("Canary User")
                else:
                    canary_data.append("CANARY_USER")
            else:
                if ftype == "EMAIL":
                    canary_data.append(CANARY_EMAIL)
                elif ftype in ["ACCOUNT_ID", "USER_ID"]:
                    canary_data.append(str(CANARY_ACCOUNT_ID))
                else:
                    canary_data.append("CANARY_VALUE")

        placeholders = ", ".join(["?"] * len(col_names))
        cur.execute(f"INSERT INTO {table_name} ({', '.join('"' + col + '"' for col in col_names)}) VALUES ({placeholders})", canary_data)
        print(f"[!] Canary planted in '{table_name}'")

    def close(self):
        self.conn.close()

def determine_form_entity(route, fields):
    analyzer = RuleBasedSchemaAnalyzer()
    entity = analyzer.detect_entity_from_route(route)
    if entity:
        return entity

    field_names = {str(f).lower() for f in fields}
    if any(k in field_names for k in ["product_id", "price", "sku"]):
        return "products"
    if any(k in field_names for k in ["order_id", "quantity"]):
        return "orders"
    if any(k in field_names for k in ["account_id", "balance"]):
        return "accounts"
    if any(k in field_names for k in ["username", "email", "password"]):
        return "users"
    return None

def build_ai_context(manifest):
    routes = manifest.get("routes", [])[:30]
    forms = manifest.get("forms", [])[:30]
    lines = ["Website routes:"] + [f"- {r}" for r in routes] + ["\nWebsite forms:"]
    for form in forms:
        lines.append(f"- {form.get('route', '/')}: {', '.join(form.get('fields', []))}")
    return "\n".join(lines)

def generate_decoy_database_from_manifest(
    manifest_path="decoy-website/public/site_manifest.json",
    db_path="decoy-website/decoy-database/decoy_website.db"
):
    if not os.path.exists(manifest_path):
        print(f"[!] Manifest not found: {manifest_path}")
        return False

    try:
        with open(manifest_path, "r", encoding="utf-8") as f:
            manifest = json.load(f)
    except Exception as e:
        print(f"[!] Failed to read manifest: {e}")
        return False

    routes = manifest.get("routes", [])
    forms = manifest.get("forms", [])
    api_routes = manifest.get("api_routes", [])


    analyzer = RuleBasedSchemaAnalyzer()
    entities = analyzer.detect_entities(routes + api_routes)
    print(f"[*] Detected entities: {', '.join(entities)}")

    semantic_analyzer = AdaptiveSemanticAnalyzer()
    ai_context = build_ai_context(manifest)
    entity_fields = {e: ENTITY_DEFAULTS.get(e, {}).copy() for e in entities}

    for form in forms:
        route = form.get("route", "/")
        fields = form.get("fields", [])
        if not fields:
            continue

        entity = determine_form_entity(route, fields)
        if not entity:
            continue

        if entity not in entity_fields:
            entity_fields[entity] = {}

        unknown_fields = []
        for raw_field in fields:
            field_name = analyzer.normalize_field_name(raw_field)
            if not field_name:
                continue
            field_type = analyzer.map_field(field_name)
            if field_type:
                entity_fields[entity][field_name] = field_type
            else:
                unknown_fields.append(field_name)

        if unknown_fields:
            context = f"{ai_context}\n\nCurrent route: {route}\nDetected entity: {entity}"
            ai_results = semantic_analyzer.classify_unknown_fields(unknown_fields, context=context)
            for field_name in unknown_fields:
                entity_fields[entity][field_name] = ai_results.get(field_name, "TEXT")

    generator = SyntheticDataGenerator(db_path)
    priority = {
        "users": 0, "accounts": 1, "products": 1, "admins": 1, "profiles": 2,
        "transactions": 3, "orders": 3, "carts": 4, "reviews": 4, "messages": 4
    }
    ordered_entities = sorted(entity_fields.keys(), key=lambda e: priority.get(e, 10))

    for entity in ordered_entities:
        fields = entity_fields[entity] or {"title": "TITLE", "status": "STATUS"}
        generator.create_and_seed_entity(entity, fields, row_count=20)

    # Export a bounded credential snapshot to the existing PRIVATE runtime catalog.
    # The runtime must not open the database containing security_events for demo SQL.
    private_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(manifest_path))), "private")
    os.makedirs(private_dir, exist_ok=True)
    catalog_path = os.path.join(private_dir, "backend_catalog.json")
    catalog = {}
    if os.path.exists(catalog_path):
        with open(catalog_path, "r", encoding="utf-8") as handle:
            catalog = json.load(handle)
    rows = []
    tables = {row[0] for row in generator.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "users" in tables:
        generator.conn.row_factory = sqlite3.Row
        for row in generator.conn.execute("SELECT * FROM users ORDER BY id LIMIT 1000"):
            record = dict(row)
            password = record.get("password") or record.get("pass")
            if not password:
                continue
            rows.append({"id": record["id"], "email": record.get("email", ""),
                         "username": record.get("username", ""), "password": password})
    catalog["generated_users"] = rows
    catalog["generated_data_source"] = "manifest-faker"
    temp_path = catalog_path + ".tmp"
    with open(temp_path, "w", encoding="utf-8") as handle:
        json.dump(catalog, handle, ensure_ascii=False)
    os.replace(temp_path, catalog_path)
    export_canaries(os.path.join(private_dir, "canaries.json"))
    generator.close()
    print("\n[✓] Decoy SQLite database initialized.")
    print(f"[✓] Entities generated: {len(ordered_entities)}")
    print(f"[✓] Database: {db_path}")
    print("[✓] Deterministic rules applied before AI fallback.")
    print("[✓] Synthetic data contains decoy canary values.")
    return True

init_decoy_database = generate_decoy_database_from_manifest

def refresh_saved_email_domains(project_root, *, apply=False):
    """Migrate only known generated accounts; run with DecoyGuard stopped.

    Manual local registrations and the deliberate canary remain unchanged.
    Evidence logs/captured source responses are never rewritten.
    """
    from pathlib import Path
    import hashlib
    import shutil
    import datetime
    import uuid

    root = Path(project_root).resolve()
    results = []
    old_domains = {'decoy.test', 'decoy-test.com', 'decoy-test.test'}
    def rewrite(value, mapping):
        if isinstance(value, str):
            return mapping.get(value, value)
        if isinstance(value, list):
            return [rewrite(item, mapping) for item in value]
        if isinstance(value, dict):
            return {key: item if re.search(r'pass|secret|token|authorization|cookie', str(key), re.I) else rewrite(item, mapping) for key, item in value.items()}
        return value
    def write_json(path, data):
        temp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
        try:
            with temp.open('x', encoding='utf-8') as handle:
                json.dump(data, handle, ensure_ascii=False, indent=2)
            os.replace(temp, path)
        finally:
            if temp.exists(): temp.unlink()

    for catalog_path in sorted(root.glob('decoy-website/**/private/backend_catalog.json')):
        if root not in catalog_path.resolve().parents:
            raise ValueError('Mirror catalog is outside the project')
        catalog = json.loads(catalog_path.read_text(encoding='utf-8'))
        if catalog.get('generated_data_source') != 'manifest-faker':
            continue
        state_path = catalog_path.parent / 'backend-state/state.json'
        state = json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else None
        if state is not None:
            if not isinstance(state, dict):
                raise ValueError('Local state must be an object: ' + str(state_path))
            # PHP json_encode([]) uses [] for empty associative maps.
            for field in ('sessions', 'resources', 'relations', 'auth_users'):
                value = state.get(field, {})
                if value == []:
                    state[field] = {}
                elif not isinstance(value, dict):
                    raise ValueError('Invalid nonempty local map: ' + field)

        manual_emails = set()
        if isinstance(state, dict):
            manual_emails.update(str(user.get('email', '')).lower() for user in state.get('auth_users', {}).values() if isinstance(user, dict))
            for path, bucket in state.get('resources', {}).items():
                if re.search(r'/(?:users?|register|signup|sign-up)$', path, re.I):
                    manual_emails.update(str(row.get('email', '')).lower() for row in bucket.get('records', []) if isinstance(row, dict))
        users = catalog.get('generated_users', [])
        reserved = {str(user.get('email', '')).lower() for user in users if isinstance(user, dict)} | manual_emails
        mapping = {}
        for user in users:
            if not isinstance(user, dict): continue
            email = user.get('email')
            if not isinstance(email, str) or '@' not in email or email.lower() == CANARY_EMAIL.lower() or email.lower() in manual_emails:
                continue
            local, domain = email.rsplit('@', 1)
            if domain.lower() not in old_domains or email in mapping:
                continue
            local = re.sub(r'[^a-zA-Z0-9._+-]', '', local) or 'member'
            digest = hashlib.sha256(email.encode()).digest()
            for attempt in range(10000):
                prefix = local if attempt == 0 else local + str(attempt)
                candidate = prefix + '@' + SYNTHETIC_EMAIL_DOMAINS[digest[0] % len(SYNTHETIC_EMAIL_DOMAINS)]
                if candidate.lower() not in reserved:
                    break
            else:
                raise ValueError('Could not allocate a unique synthetic email')
            mapping[email] = candidate
            reserved.add(candidate.lower())
        result = {'mirror': str(catalog_path.parent.parent.relative_to(root)), 'changed_accounts': len(mapping), 'applied': False}
        if not mapping or not apply:
            results.append(result)
            continue

        db_path = catalog_path.parent.parent / 'decoy-database/decoy_website.db'
        backup = catalog_path.parent / 'email-domain-backups' / (datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S') + '-' + uuid.uuid4().hex[:8])
        backup.mkdir(parents=True)
        try: backup.chmod(0o700)
        except OSError: pass
        shutil.copy2(catalog_path, backup / 'backend_catalog.json')
        if state_path.exists(): shutil.copy2(state_path, backup / 'state.json')
        connection = None
        try:
            if db_path.exists():
                if root not in db_path.resolve().parents: raise ValueError('Synthetic database is outside the project')
                connection = sqlite3.connect(str(db_path), timeout=5)
                with sqlite3.connect(str(backup / 'decoy_website.db')) as saved:
                    connection.backup(saved)
                connection.execute('BEGIN IMMEDIATE')
                tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")]
                for table in tables:
                    if table.lower() == 'security_events' or table.startswith('sqlite_'): continue
                    quoted = '"' + table.replace('"', '""') + '"'
                    for column in connection.execute('PRAGMA table_info(' + quoted + ')').fetchall():
                        if column[1].lower() not in ('email', 'email_address', 'e-mail'): continue
                        field = '"' + column[1].replace('"', '""') + '"'
                        for old, new in mapping.items():
                            connection.execute('UPDATE ' + quoted + ' SET ' + field + '=? WHERE ' + field + '=?', (new, old))
            # Never modify captured response bodies or manually registered accounts.
            updated = dict(catalog)
            updated['generated_users'] = [dict(user, email=mapping.get(user.get('email'), user.get('email'))) if isinstance(user, dict) else user for user in users]
            if state is not None:
                state['resources'] = rewrite(state.get('resources', {}), mapping)
                state['relations'] = rewrite(state.get('relations', {}), mapping)
                # Tokens may embed old email claims: invalidate affected generated sessions.
                state['sessions'] = {key: session for key, session in state.get('sessions', {}).items()
                                     if not isinstance(session, dict) or not isinstance(session.get('identity'), dict) or session['identity'].get('email') not in mapping}
                write_json(state_path, state)
            write_json(catalog_path, updated)
            if connection is not None: connection.commit()
        except Exception:
            if connection is not None: connection.rollback()
            shutil.copy2(backup / 'backend_catalog.json', catalog_path)
            if (backup / 'state.json').exists(): shutil.copy2(backup / 'state.json', state_path)
            raise
        finally:
            if connection is not None: connection.close()
        for file in backup.iterdir():
            try: file.chmod(0o600)
            except OSError: pass
        result.update(applied=True, backup=str(backup.relative_to(root)))
        results.append(result)
    return results


def data_generator_main():
    import argparse
    from pathlib import Path
    parser = argparse.ArgumentParser(description='DecoyGuard synthetic data tools')
    parser.add_argument('--refresh-email-domains', action='store_true', help='Preview legacy generated email changes')
    parser.add_argument('--apply', action='store_true', help='Apply changes with backups; stop DecoyGuard first')
    parser.add_argument('--root', default=str(Path(__file__).resolve().parent.parent), help='Project directory')
    args = parser.parse_args()
    if args.refresh_email_domains:
        for item in refresh_saved_email_domains(args.root, apply=args.apply):
            print(item['mirror'] + ': ' + str(item['changed_accounts']) + ' generated account(s)' + (' updated' if item['applied'] else ' (preview/no changes)'))
            if item.get('backup'): print('  Backup: ' + item['backup'])
        if not args.apply: print('Preview only. Stop DecoyGuard, then repeat with --apply.')
    elif args.apply:
        parser.error('--apply requires --refresh-email-domains')
    else:
        generate_decoy_database_from_manifest()

if __name__ == "__main__":
    data_generator_main()

