import subprocess
import json
import time
import sys
import os

# Since log_parser.py and honeypot_monitor.py are both in core/,
# ensure the current directory is in the path.
sys.path.append(os.path.dirname(__file__))

from log_parser import Parser


class HoneypotMonitor:

    # ============================================================
    # Beelzebub Honeypot Monitor
    # ============================================================
    #
    # Responsibilities:
    #   1. Stream Beelzebub events from Docker
    #   2. Parse them through the central Parser
    #   3. Save standardized events locally
    #   4. Send events to the DecoyGuard callback
    #
    # This avoids creating another Python file just for logging.
    # ============================================================

    def __init__(
        self,
        container_name="decoyguard_honeypot",
        log_file="./logs/beelzebub/beelzebub.jsonl"
    ):
        self.container_name = container_name
        self.running = False
        self.parser = Parser()

        # Existing DecoyGuard logs directory
        self.log_file = log_file

        # Make sure the directory exists
        log_dir = os.path.dirname(self.log_file)

        if log_dir:
            os.makedirs(log_dir, exist_ok=True)

    # ============================================================
    # SAVE HONEYPOT EVENT
    # ============================================================

    def save_event(self, event):
        """
        Append one standardized honeypot event to the local
        Beelzebub JSONL log file.

        JSONL means:
            one JSON object per line
        """

        try:
            with open(
                self.log_file,
                "a",
                encoding="utf-8"
            ) as file:

                file.write(
                    json.dumps(
                        event,
                        ensure_ascii=False
                    ) + "\n"
                )

        except Exception as e:
            print(f"[!] Failed to save honeypot event: {e}")

    # ============================================================
    # START MONITORING
    # ============================================================

    def start_monitoring(self, callback):

        """
        Start listening to Beelzebub events.

        callback:
            Function that receives each standardized
            honeypot event.
        """

        self.running = True

        print("[+] Starting Honeypot Monitor...")
        print(f"[+] Watching container: {self.container_name}")
        print(f"[+] Honeypot log: {self.log_file}")

        command = [
            "docker",
            "logs",
            "-f",
            self.container_name
        ]

        process = None

        try:

            process = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )

            # ====================================================
            # CONTINUOUS EVENT PROCESSING
            # ====================================================

            while self.running:

                line = process.stdout.readline()

                # Docker stream currently idle
                if not line:
                    time.sleep(0.05)
                    continue

                line = line.strip()

                # Ignore:
                #
                #   Beelzebub ASCII banner
                #   normal text messages
                #   startup messages
                #
                if not line:
                    continue

                if not line.startswith("{"):
                    continue

                # =================================================
                # PARSE EVENT
                # =================================================

                try:

                    processed_event = self.parser.parse_honeypot_log(
                        line
                    )

                    if not processed_event:
                        continue

                    # =================================================
                    # SAVE EVENT LOCALLY
                    # =================================================

                    self.save_event(processed_event)

                    # =================================================
                    # SEND TO DECoyGuard ENGINE
                    # =================================================

                    callback(processed_event)

                except Exception as parse_err:

                    print(
                        f"[!] Honeypot event processing error: "
                        f"{parse_err}"
                    )

        except Exception as e:

            print(
                f"[!] Honeypot monitor error: {e}"
            )

        finally:

            if process:

                try:
                    process.terminate()
                except Exception:
                    pass

    # ============================================================
    # STOP MONITORING
    # ============================================================

    def stop(self):

        """
        Signals the monitoring loop to terminate.
        """

        self.running = False

        print("[+] Honeypot Monitor stopped.")

# ============================================================
# STANDALONE EXECUTION ENTRY POINT
# ============================================================


if __name__ == "__main__":

    def log_callback(event):
        cmd = event.get("request") or event.get("Command") or "SSH Interaction"

        print(
            f"[HONEYPOT STREAM] "
            f"{event.get('remote_addr')} -> {cmd}"
        )

    monitor = HoneypotMonitor(
        container_name="decoyguard_honeypot"
    )

    try:
        monitor.start_monitoring(
            callback=log_callback
        )
    except KeyboardInterrupt:
        monitor.stop()