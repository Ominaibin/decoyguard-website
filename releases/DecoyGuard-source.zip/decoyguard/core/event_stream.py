"""Tail JSONL logs and prefer body-aware events over matching Nginx summaries."""
from collections import OrderedDict
import json
from pathlib import Path
import time


class EventStreams:
    def __init__(self, paths, raw_wait_seconds=2.0):
        self.states = {}
        # Nginx can finish/log a 401 before PHP's shutdown telemetry is visible.
        # Wait briefly for its richer counterpart; retain standalone edge errors.
        self.raw_wait_seconds = max(0.0, float(raw_wait_seconds))
        self.pending = OrderedDict()
        self.authoritative = OrderedDict()
        self._clock = time.monotonic
        for path in paths:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.touch(exist_ok=True)
            stream = p.open('rb')
            stream.seek(0, 2)
            self.states[p] = (stream, p.stat().st_ino)

    @staticmethod
    def _key(event):
        event_id, site_id = event.get('event_id'), event.get('site_id', '')
        if isinstance(event_id, str) and event_id and isinstance(site_id, str):
            return site_id, event_id
        return None

    def _read(self):
        for path, (stream, identity) in list(self.states.items()):
            try:
                stat = path.stat()
            except FileNotFoundError:
                continue
            if stat.st_ino != identity:
                stream.close()
                stream = path.open('rb')
                self.states[path] = (stream, stat.st_ino)
            elif stat.st_size < stream.tell():
                stream.seek(0)
            while True:
                pos = stream.tell()
                line = stream.readline()
                if not line or not line.endswith(b'\n'):
                    stream.seek(pos)
                    break
                try:
                    event = json.loads(line)
                    if isinstance(event, dict):
                        yield event
                except (ValueError, UnicodeDecodeError):
                    continue

    def poll(self):
        now = self._clock()
        while self.authoritative:
            _, recorded = next(iter(self.authoritative.items()))
            if now - recorded < 120 and len(self.authoritative) <= 4096:
                break
            self.authoritative.popitem(last=False)

        for event in self._read():
            key = self._key(event)
            source = event.get('source')
            if key is not None and source in ('decoy-web', 'gateway-decision'):
                # Consume the counterpart even when its body-aware record is INFO;
                # the core decides whether it is an actionable detection.
                self.pending.pop(key, None)
                if key in self.authoritative:
                    continue
                self.authoritative[key] = now
                if len(self.authoritative) > 4096:
                    self.authoritative.popitem(last=False)
                yield event
            elif (key is not None and event.get('target_type') in ('decoy', 'production')
                  and source in (None, '', 'web', 'nginx')):
                if key not in self.authoritative:
                    self.pending.setdefault(key, (now, event))
                    # Bound memory even under a large scan. No raw log is deleted.
                    if len(self.pending) > 4096:
                        _, (_, oldest) = self.pending.popitem(last=False)
                        yield oldest
            else:
                yield event

        # Raw Nginx-only failures still reach the existing core, after the grace
        # period. A PHP event arriving beyond it can still meet the core's legacy
        # incident-ID deduplication; the raw source logs remain intact either way.
        now = self._clock()
        while self.pending:
            key, (recorded, event) = next(iter(self.pending.items()))
            if now - recorded < self.raw_wait_seconds:
                break
            self.pending.popitem(last=False)
            yield event

    def close(self):
        for stream, _ in self.states.values():
            stream.close()
