"""
=================================================================================================
Decoyguard Universal Log Parser
-------------------------------------------------------------------------------------------------
Core Responsibilities:
- Parse website & honeypot log entries
- Standardize different server/container formats
- Produce a common event object for DecoyGuard
- Map security events to MITRE ATT&CK techniques
=================================================================================================
"""

import json
import re
import datetime

class Parser:

    def parse_web_log(self, line):
        """Parse & standardize Nginx/Web server JSON log entries with basic forensics."""
        if isinstance(line, str):
            line = line.strip()
            if not line:
                return None
            try:
                event = json.loads(line)
            except json.JSONDecodeError as e:
                print(f"[!] Web log parsing failed: {e}")
                return None
        else:
            event = line

        if not isinstance(event, dict):
            return None
        recorded = event.get("forensics") if isinstance(event.get("forensics"), dict) else {}
        recorded_bytes = event.get("body_bytes_sent", event.get("bytes_sent"))
        # Extract basic fields safely
        remote_addr = event.get("remote_addr", event.get("source_ip", "Unknown"))
        request = event.get("request", "")
        status = event.get("status", "200")
        bytes_sent = event.get("body_bytes_sent", event.get("bytes_sent", "0"))
        user_agent = event.get("http_user_agent", event.get("user_agent", "Unknown"))
        timestamp = event.get("time_local", event.get("timestamp", datetime.datetime.now().isoformat()))

        # Clean Time Formatting for Session Playback
        raw_time = str(timestamp)
        if "T" in raw_time:
            clean_time = raw_time.split("T")[1][:8]
        elif " " in raw_time:
            clean_time = raw_time.split(" ")[1][:8]
        else:
            clean_time = "00:00:00"

        # Dynamic MITRE mapping based on attack types and keywords in the request path
        request_path = (str(request) + ' ' + str(event.get("detection_text", ""))).lower()
        if event.get("attack_type") == "SQL Injection":
            request_path += " sql"
        mitre_tags = []
        
        if any(x in request_path for x in [".env", "config", "backup", "admin", "wp-admin"]):
            mitre_tags.append("T1083") # File and Directory Discovery
        if any(x in request_path for x in ["union", "select", "sql", "information_schema"]):
            mitre_tags.append("T1190") # Exploit Public-Facing Application / SQLi
        if any(x in request_path for x in ["../", "..\\", "/etc/passwd", "/etc/shadow"]):
            mitre_tags.append("T1083") # Directory Traversal / Discovery
        if any(x in request_path for x in ["cmd=", "exec", "system", "shell"]):
            mitre_tags.append("T1059") # Command and Scripting Interpreter
            
        mitre_tags = list(dict.fromkeys(mitre_tags))

        session_log = [
            {
                "time": clean_time,
                "text": request if request else "Malformed Request",
                "output": f"HTTP {status} - {bytes_sent} bytes",
                "delay": 800
            }
        ]

        return {
            "source": event.get("source", "web"),
            "site_id": event.get("site_id", ""),
            "target_type": event.get("target_type", "unknown"),
            "event_id": event.get("event_id"),
            "uri": event.get("uri", ""),
            "args": event.get("args", ""),
            "fields": event.get("fields", {}),
            "detection_text": event.get("detection_text", ""),
            "canary_hit": bool(event.get("canary_hit", False)),
            "attack_type": event.get("attack_type", ""),
            "risk_score": event.get("risk_score", 0),
            "severity": event.get("severity", "INFO"),
            "exploit_result": event.get("exploit_result"),
            "security_finding": event.get("security_finding"),
            "timestamp": timestamp,
            "remote_addr": remote_addr,
            "method": event.get("method", ""),
            "request": request,
            "status": status,
            "bytes_sent": bytes_sent,
            "referer": event.get("referer", ""),
            "user_agent": user_agent,
            
            "forensics": {
                "target_port": recorded.get("target_port", event.get("target_port", "Not recorded")),
                "client_tool": self.extract_client_tool(str(user_agent)),
                "duration": recorded.get("duration", event.get("duration", "Not recorded")),
                "transferred": recorded.get("transferred", f"{recorded_bytes} B" if recorded_bytes is not None else "Not recorded"),
                "mitre_tags": mitre_tags,
                "artifacts": self.recorded_artifacts(event),
                "session_log": session_log
            }
        }

    def parse_honeypot_log(self, raw_event):
        """Parse & standardize Beelzebub Docker honeypot logs with forensic extraction."""
        try:
            if isinstance(raw_event, str):
                raw_event = raw_event.strip()
                if not raw_event.startswith("{"):
                    return None
                raw_event = json.loads(raw_event)

            event = raw_event.get("event", raw_event)
            if not event:
                return None

            recorded = event.get("forensics") if isinstance(event.get("forensics"), dict) else {}
            command = event.get("Command") or event.get("request", "")
            
            mitre_tags = []
            artifacts = []
            
            if command:
                if re.search(r"whoami|id|groups", command): 
                    mitre_tags.append("T1033")
                if re.search(r"uname|cat /etc/os-release|hostname", command): 
                    mitre_tags.append("T1082")
                if re.search(r"wget|curl", command): 
                    mitre_tags.append("T1105")
                if re.search(r"chmod \+x", command): 
                    mitre_tags.append("T1222")
                if re.search(r"cat /etc/shadow|cat /etc/passwd", command):
                    mitre_tags.append("T1003")
                    
            raw_time = str(event.get("DateTime", "00:00:00"))
            if "T" in raw_time:
                clean_time = raw_time.split("T")[1][:8]
            elif " " in raw_time:
                clean_time = raw_time.split(" ")[1][:8]
            else:
                clean_time = "00:00:00"

            session_log = event.get("session_log", [
                {
                    "time": clean_time, 
                    "text": command if command else "connection established", 
                    "output": "Command logged by DecoyGuard proxy." if command else "",
                    "delay": 1200
                }
            ])

            return {
                "source": "honeypot",
                "remote_addr": event.get("SourceIp") or event.get("remote_addr", "unknown"),
                "username": event.get("User", ""),
                "password": event.get("Password", ""),
                "request": command,
                "protocol": event.get("Protocol", "SSH"),
                "status": event.get("Status") or event.get("status", ""),
                "user_agent": event.get("Client") or event.get("user_agent", ""),
                "timestamp": event.get("DateTime") or event.get("timestamp", ""),
                
                "forensics": {
                    "target_port": recorded.get("target_port", event.get("target_port", "Not recorded")),
                    "client_tool": event.get("Client") or event.get("user_agent", "Unknown Client"),
                    "duration": recorded.get("duration", event.get("Duration", "Not recorded")),
                    "transferred": recorded.get("transferred", event.get("Transferred", "Not recorded")),
                    "mitre_tags": mitre_tags,
                    "artifacts": self.recorded_artifacts(event),
                    "session_log": session_log
                }
            }
        except (json.JSONDecodeError, Exception) as e:
            print(f"[!] Honeypot event parsing failed: {e}")
            return None

    def extract_client_tool(self, user_agent):
        ua = user_agent.lower()
        if "wget" in ua:
            return "Wget"
        elif "curl" in ua:
            return "cURL"
        elif "sqlmap" in ua:
            return "SQLMap"
        elif "python" in ua:
            return "Python-Requests"
        elif "mozilla" in ua or "chrome" in ua or "safari" in ua:
            return "Browser"
        return "Unknown Tool"

    @staticmethod
    def recorded_artifacts(event):
        """Preserve supplied evidence; never infer captured files from a request."""
        forensic = event.get("forensics")
        raw = forensic.get("artifacts", []) if isinstance(forensic, dict) else event.get("artifacts", [])
        if not isinstance(raw, list):
            return []
        result = []
        for entry in raw[:8]:
            if not isinstance(entry, dict) or not isinstance(entry.get("name"), str):
                continue
            item = dict(entry)
            digest = item.get("sha256", item.get("hash"))
            if isinstance(digest, str) and re.fullmatch(r"[0-9a-fA-F]{64}", digest):
                item["sha256"] = item["hash"] = digest.lower()
            else:
                item.pop("sha256", None)
                item.pop("hash", None)
            result.append(item)
        return result

    def extract_artifacts(self, request_path):
        # Compatibility only: a URL does not prove that a file was captured.
        return []
