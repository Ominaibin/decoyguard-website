"""
DecoyGuard Router

Core Responsibilities:

- Decide where incoming traffic should be sent
- Use Analyzer results to determine routing
- Separate routing decisions from threat analysis
- Assign incident priority for security response
"""


class Router:

    def __init__(self):

        ####################################################
        # RISK THRESHOLDS
        ####################################################

        # Suspicious traffic.
        # Analyzer scores from 85 upward should no longer
        # automatically enter the normal web server.
        self.MONITOR_THRESHOLD = 85

        # High-risk traffic should be redirected to the
        # honeypot instead of being allowed to interact
        # with the real application.
        self.HONEYPOT_THRESHOLD = 150

        # Critical traffic should be isolated.
        self.ISOLATE_THRESHOLD = 300


    ####################################################
    # ROUTING DECISION
    ####################################################

    def decide(self, analysis):

        # Extract Analyzer information
        risk = analysis.get("risk_score", 0)
        immediate = analysis.get("immediate_threat", False)
        confidence = analysis.get("confidence", "LOW")
        severity = analysis.get("severity", "SAFE")
        stage = analysis.get("attack_stage", "NORMAL")

        ####################################################
        # EMERGENCY OVERRIDE
        ####################################################

        # Known aggressive tools such as:
        #
        # sqlmap
        # nikto
        # masscan
        # metasploit
        # dirbuster
        # gobuster
        # ffuf
        #
        # are already identified by Analyzer as immediate
        # threats.
        #
        # These should NEVER reach the real web server.

        if immediate:

            return {
                "decision": "ISOLATE",
                "route": "HONEYPOT",
                "severity": "CRITICAL",
                "priority": "P1 - Critical Incident",
                "reason": "Immediate Threat Tool Detected"
            }


        ####################################################
        # TIER 1 — CRITICAL
        # 300+
        ####################################################

        if risk >= self.ISOLATE_THRESHOLD:

            return {
                "decision": "ISOLATE",
                "route": "HONEYPOT",
                "severity": "CRITICAL",
                "priority": "P1 - Critical Incident",
                "reason": "Critical Risk Score"
            }


        ####################################################
        # TIER 2 — HIGH
        # 150–299
        ####################################################

        elif risk >= self.HONEYPOT_THRESHOLD:

            return {
                "decision": "REDIRECT",
                "route": "HONEYPOT",
                "severity": severity,
                "priority": "P2 - High Priority",
                "reason": "High Risk Score"
            }


        ####################################################
        # TIER 3 — SUSPICIOUS
        # 85–149
        ####################################################

        elif risk >= self.MONITOR_THRESHOLD:

            return {
                "decision": "MONITOR",
                "route": "REAL_SERVER",
                "severity": severity,
                "priority": "P3 - Medium Priority",
                "reason": "Suspicious Behaviour Under Monitoring"
            }


        ####################################################
        # TIER 4 — NORMAL
        # 0–84
        ####################################################

        else:

            return {
                "decision": "ALLOW",
                "route": "REAL_SERVER",
                "severity": severity,
                "priority": "P4 - Informational",
                "reason": "Low Risk / Normal Traffic"
            }


    ####################################################
    # ROUTING SUMMARY
    ####################################################

    def summarize(self, analysis, routing):

        return {
            "risk_score": analysis.get("risk_score", 0),
            "confidence": analysis.get("confidence", "LOW"),
            "severity": analysis.get("severity", "SAFE"),
            "attack_stage": analysis.get("attack_stage", "NORMAL"),
            "decision": routing.get("decision", "ALLOW"),
            "route": routing.get("route", "REAL_SERVER"),
            "priority": routing.get(
                "priority",
                "P4 - Informational"
            ),
            "reason": routing.get(
                "reason",
                "No specific reason provided"
            )
        }