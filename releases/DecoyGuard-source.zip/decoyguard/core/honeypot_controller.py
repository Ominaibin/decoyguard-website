"""
=================================================================================================
Decoyguard Honeypot Controller 
-------------------------------------------------------------------------------------------------
Core Resposibilities:
- Receive routing descicions from the Router
- Manage communication with the honeypot 
- Prepare attacker information
- Queue incidents for deceptions 
- Keep the integrating modular
=================================================================================================
"""

import json 
import os 
from datetime import datetime 

class HoneypotController:

    ####################################################
    # INITIALIZATION 
    ####################################################
    def __init__(self):
        # A simple queue where the attacker's file are saved
        # beelzebub honeypot container can constantly watch monitor this file and instantly trap the attacker, without slowing down the main website
        self.queue_file = "./logs/honeypot_queue.json"

        # Operational metrics tracking total structural mitigation per runtime execution
        self.total_redirected = 0
        self.total_isolated = 0

        # Run safe initialization to ensure environment runtime stability 
        self.initialize_queue()
    ####################################################
    # INITIALIZE QUEUE FILE
    ####################################################

    def initialize_queue(self):
        # Recursively verifies log directory presence to guarantee no I/O exceptions
        os.makedirs("./logs", exist_ok=True)

        # Idempotent lock file generation to guarantee standard empty serialization formatting
        if not os.path.exists(self.queue_file):
            with open(self.queue_file, "w") as f:
                json.dump([], f, indent=4)


    ####################################################
    # MAIN ENTRY POINT
    ####################################################

    def handle(self, request, analysis, routing):
        # Passive guard statement checking intercept validation parameters
        if routing["route"] != "HONEYPOT":
            return

        # Build out a thorough threat profile packet for forensic analytics
        incident = self.build_incident(
            request,
            analysis,
            routing
        )

        # Commits transaction to persistent disk array
        self.queue_incident(incident)

        # Increment specific metric tracking based on the mitigation classification
        if routing["decision"] == "REDIRECT":
            self.total_redirected += 1
        elif routing["decision"] == "ISOLATE":
            self.total_isolated += 1

        # Real-time console update demonstrating intercept execution success
        print(
            f"[HONEYPOT] {routing['decision']} -> "
            f"{request['ip']} queued for Beelzebub."
        )


    ####################################################
    # BUILD INCIDENT
    ####################################################

    def build_incident(self, request, analysis, routing):
        # Maps localized metrics into an enterprise schema object
        return {
            "incident_id": analysis["incident_id"],
            "timestamp": datetime.now().isoformat(),
            "source_ip": request["ip"],
            "request": request["request"],
            "risk_score": analysis["risk_score"],
            "severity": analysis["severity"],
            "attack_type": analysis["attack_type"],
            "attack_stage": analysis["attack_stage"],
            "decision": routing["decision"],
            "route": routing["route"],
            "priority": routing["priority"],
            "immediate_threat": analysis["immediate_threat"],
            
            # UPGRADE ADDITIONS: Maps the detailed engine calculations into the incident schema
            "risk_breakdown": analysis.get("risk_breakdown", {}),
            "risk_calculation": analysis.get("risk_calculation", []),
            "reasons": analysis.get("reasons", [])
        }


    ####################################################
    # APPEND INCIDENT TO QUEUE
    ####################################################

    def queue_incident(self, incident):
        # Open transaction log under read mode to load standard state array
        with open(self.queue_file, "r") as f:
            queue = json.load(f)

        # Enqueue new profile mutation record
        queue.append(incident)

        # Overwrite payload safely using deep indentation configuration
        with open(self.queue_file, "w") as f:
            json.dump(queue, f, indent=4)


    ####################################################
    # ENGINE STATISTICS
    ####################################################

    def statistics(self):
        # Output historical mitigation metrics for telemetry/dashboards
        return {
            "redirected": self.total_redirected,
            "isolated": self.total_isolated
        }

