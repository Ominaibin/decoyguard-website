"""
=================================================================================================
Decoyguard Exporter
-------------------------------------------------------------------------------------------------
Core Responsibilities:
- Prepare events for external system
- Standardize JSON output
- Integrate with behavioural engine
- Save exported alerts for Dashboard
=================================================================================================
"""

import json
import os


class Exporter:

    def __init__(self):

        # Dashboard log file
        self.output_file = "./logs/alerts.jsonl"

        os.makedirs("./logs", exist_ok=True)

    #######################################################################################
    # EXPORT EVENT
    # Takes heavy output object, translate it into a lean, optimized security packet
    #######################################################################################

    def send(self, output):

        # 1. Data Translation & Filtering (API Packet)
        packet = {

            "engine": "DecoyGuard",

            # Incident Information
            "incident_id": output["incident_id"],
            "source_ip": output["source_ip"],
            "timestamp": output["timestamp"],
            "analysis_time": output["analysis_time"],

            # Threat Assessment
            "risk_score": output["risk_score"],
            "severity": output["severity"],
            "confidence": output["confidence"],

            # Attack Classification
            "attack_type": output["attack_type"],
            "attack_stage": output["attack_stage"],

            # Routing Decision
            "decision": output["decision"],
            "route": output["route"],
            "priority": output["priority"],
            "recommended_action": output["recommended_action"],

            # Risk Analysis
            "risk_breakdown": output["risk_breakdown"],
            "risk_calculation": output["risk_calculation"],

            # Investigation Evidence
            "reasons": output["reasons"],

            # Forensic Evidence
            "forensics": output.get("forensics") or {},

            # Profile History
            "profile_history": output["profile_history"],

            "immediate_threat": output["immediate_threat"]
        }

        #########################################################
        # Visual Printing
        #########################################################

        print("\n==================== JSON EXPORT ====================\n")

        print(json.dumps(packet, indent=4))

        print("\n=====================================================\n")

        #########################################################
        # Save alert for Dashboard
        #########################################################

        try:
            with open(self.output_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(packet))
                f.write("\n")

        except Exception as e:
            print(f"[!] Failed writing dashboard log: {e}")

        #########################################################
        # Handoff
        #########################################################

        return packet