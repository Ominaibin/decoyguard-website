"""
=======================================================================
DecoyGuard Profiler
-----------------------------------------------------------------------
Maintains Behavioral profiles for every observed IP
=======================================================================
"""

from collections import deque

class Profiler:

    def __init__(self):
        # Stores every attacker profile in memory
        # Key = IP address, Value = The Profile Dictionary
        self.profiles = {}

######################################################
# PUBLIC METHOD (Called by the main controller)
######################################################

    def update(self, request):
        ip = request["ip"]

        # If this is the first time we see this IP, build a clean sheet for them
        if ip not in self.profiles:
            self.profiles[ip] = self.create_profile(request)

        # Extract the profile
        profile = self.profiles[ip]

        # Update their history metrics using the current web request data
        self.update_profile(profile, request)

        return profile

######################################################
# CREATE A NEW PROFILE
######################################################

    def create_profile(self, request):
        return {
            "ip": request["ip"],
            "first_seen": request["timestamp"],
            "last_seen": request["timestamp"],
            "total_requests": 0,
            "error_40x_count": 0,

            # Track login activity for brute-force detection
            "login_attempts": 0,
            "failed_logins": 0,

            # Keeps track of targeted paths
            # Clamp to 50 items max item so the script doesn't run out of system memory
            "visited_paths": [],
            "user_agents": [],

            # A double-ended queue
            # Stores the 100 timestamps of requests and adding a new one automatically kicks out the oldest request
            # This is for checking speed/burst frequency anomalies without filling the RAM
            "request_times": deque(maxlen=100),
            "current_risk": 0
        }

######################################################
# UPDATE EXISTING PROFILE
######################################################

    def update_profile(self, profile, request):

        # Update the time we last saw them active
        profile["last_seen"] = request["timestamp"]
        profile["total_requests"] += 1

        # Push the current timestamp into the moving history window
        # (deque converts to a standard JSON list cleanly when exported)
        profile["request_times"].append(request["timestamp"])

        # Record the requested path, clamping storage to the 50 paths
        profile["visited_paths"].append(request["request"])

        if len(profile["visited_paths"]) > 50:
            profile["visited_paths"].pop(0)

        if request["user_agent"] not in profile["user_agents"]:
            profile["user_agents"].append(request["user_agent"])

        # Check for discovery anomaly indicators
        if request["status"] in ["403", "404"]:
            profile["error_40x_count"] += 1

        # Track login attempts for brute-force detection
        request_text = request.get("request", "").lower()

        if "login" in request_text:
            profile["login_attempts"] += 1

            if request["status"] in ["401", "403"]:
                profile["failed_logins"] += 1

        return profile

######################################################
# UTILITIES
######################################################

    def get_profile(self, ip):
        return self.profiles.get(ip)

    def total_profiles(self):
        return len(self.profiles)