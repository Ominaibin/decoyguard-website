"""
=================================================================================================
DecoyGuard Logger
-------------------------------------------------------------------------------------------------
Core Responsibilities:
- Store structured security events
- Maintain audit trail
- Save routing decisions
- Write alerts in JSONL format
=================================================================================================
"""

import json
import os


class Logger:

    def __init__(self):
        # =====================================================================================
        # 1. DEFINE BASE LOG FOLDER
        # =====================================================================================

        # All DecoyGuard log files are stored inside ./logs
        self.LOG_FOLDER = "./logs"

        # Automatically create the logs folder if it does not already exist.
        # exist_ok=True prevents an error if the folder already exists.
        os.makedirs(self.LOG_FOLDER, exist_ok=True)

        # =====================================================================================
        # 2. DEFINE ALERT FILE
        # =====================================================================================

        # alerts.jsonl is the single source of truth for DecoyGuard alerts.
        #
        # JSONL = JSON Lines
        # Each detected event is stored as one complete JSON object per line.
        #
        # Example:
        # {"incident_id": "DG-12345678", "severity": "HIGH", ...}
        # {"incident_id": "DG-87654321", "severity": "MEDIUM", ...}
        #
        # This format allows the dashboard/API to read alerts individually
        # without having to load the entire file as one JSON object.

        self.ALERT_FILE = os.path.join(
            self.LOG_FOLDER,
            "alerts.jsonl"
        )

    # =========================================================================================
    # WRITE ALERT
    # =========================================================================================

    def write(self, data):
        """
        Write one structured DecoyGuard alert to alerts.jsonl.

        Each call creates exactly ONE new JSON line.
        Existing alerts are preserved because the file is opened in append mode.
        """

        with open(
            self.ALERT_FILE,
            "a",
            encoding="utf-8"
        ) as logfile:

            # Convert the Python dictionary into a JSON string
            # and write it as a single line.
            logfile.write(
                json.dumps(data, ensure_ascii=False) + "\n"
            )