"""
=================================================================
                    Behaviour & Web Exploit Engine
=================================================================

Responsibilities:
- Tails Nginx JSON log (access.json)
- Keeps production, decoy and dashboard findings in separate profiles
- Detects Web Exploits: SQL Injection, XSS, Directory Traversal,
  Shell Injection, Recon Scanners (Nmap, etc.)
- Detects Behavioural Anomalies: Bursts, Brute-force POSTs, 
  Enumeration (403/404), User-Agent hopping
- Outputs standardized alerts to ./logs/behaviour_events.jsonl
=================================================================
"""

import json
import os
import re
import time
import uuid
import socket
import ipaddress
from datetime import datetime, timezone
from collections import deque
from pathlib import Path
from urllib.parse import unquote_plus

# ================================================================
# CONFIGURATION
# ================================================================

BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = Path(os.environ.get("DECOYGUARD_LOG_DIR", str(BASE_DIR / "logs")))
NGINX_LOG = os.environ.get("DECOY_BE_ACCESS_LOG", str(LOG_DIR / "access.json"))
TELEMETRY_LOG = os.environ.get("TELEMETRY_LOG_PATH", str(LOG_DIR / "events.jsonl"))
BEHAVIOUR_LOG = os.environ.get("DECOY_BE_ALERT_LOG", str(LOG_DIR / "behaviour_events.jsonl"))
PRESENTATION_MODE = os.environ.get("DECOYGUARD_PRESENTATION") == "1"
BEHAVIOUR_WINDOW = 60
MAX_PROFILES = 4096
seen_events = set()
seen_order = deque()


POLL_INTERVAL = 0.1
BURST_WINDOW = 10
BURST_THRESHOLD = 6 if PRESENTATION_MODE else 10
POST_THRESHOLD = 3 if PRESENTATION_MODE else 5
ENUMERATION_THRESHOLD = 4 if PRESENTATION_MODE else 8
ERROR_THRESHOLD = 3 if PRESENTATION_MODE else 5
ENDPOINT_CHANGE_THRESHOLD = 6
USER_AGENT_CHANGE_THRESHOLD = 3
MAX_REQUEST_HISTORY = 100
PROFILE_TIMEOUT = 1800


# RFC 5424 UDP input. JSONL files remain the durable fallback if delivery fails.
SYSLOG_HOST = os.environ.get("DECOY_SYSLOG_BIND", "0.0.0.0")
SYSLOG_PORT = int(os.environ.get("DECOY_SYSLOG_PORT", "5514"))
SYSLOG_FILE = LOG_DIR / "syslog.jsonl"
SYSLOG_HEALTH = {"pid": os.getpid(), "started_at": datetime.now(timezone.utc).isoformat(),
                 "state": "starting", "received": 0, "accepted": 0, "rejected": 0, "last_received_at": None}

def write_syslog_health():
    SYSLOG_HEALTH["updated_at"] = datetime.now(timezone.utc).isoformat()
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        temporary = LOG_DIR / ("syslog-health." + str(os.getpid()) + ".tmp")
        temporary.write_text(json.dumps(SYSLOG_HEALTH), encoding="utf-8")
        os.replace(temporary, LOG_DIR / "syslog-health.json")
    except OSError as error:
        print(f"[BE] Cannot write collector health: {error}", flush=True)
SYSLOG_ALLOWED = [ipaddress.ip_network(v.strip()) for v in os.environ.get(
    "DECOY_SYSLOG_ALLOWED_CIDRS", "127.0.0.0/8,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,::1/128").split(",") if v.strip()]

def open_syslog_receiver():
    if os.environ.get("DECOY_SYSLOG_ENABLED", "1") != "1":
        SYSLOG_HEALTH["state"] = "disabled"; write_syslog_health(); return None
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.bind((SYSLOG_HOST, SYSLOG_PORT)); sock.setblocking(False)
    except OSError as error:
        sock.close()
        SYSLOG_HEALTH.update(state="bind-failed", error=str(error)); write_syslog_health()
        print(f"[BE] Syslog unavailable: {error}; file monitoring continues", flush=True)
        return None
    SYSLOG_HEALTH.update(state="listening", bind=SYSLOG_HOST, port=SYSLOG_PORT); write_syslog_health()
    print(f"[BE] RFC5424 UDP syslog listening on {SYSLOG_HOST}:{SYSLOG_PORT}; output={SYSLOG_FILE}", flush=True)
    return sock

def receive_syslog(sock):
    for _ in range(200):
        try: payload, peer = sock.recvfrom(65535)
        except BlockingIOError: break
        except OSError as error:
            print(f"[BE] Syslog receive error: {error}", flush=True); break
        SYSLOG_HEALTH["received"] += 1
        if not any(ipaddress.ip_address(peer[0]) in net for net in SYSLOG_ALLOWED):
            SYSLOG_HEALTH["rejected"] += 1; continue
        # Accept the explicit structured format used by our configured emitters.
        message = payload.decode("utf-8", errors="replace").strip()
        match = re.fullmatch(r"<(\d{1,3})>1 (\S+) (\S+) (\S+) (\S+) (\S+) - (\{.*\})", message)
        if not match or int(match[1]) > 191:
            SYSLOG_HEALTH["rejected"] += 1; continue
        try:
            event = json.loads(match[7])
            if not isinstance(event, dict) or not event.get("timestamp"): continue
            event["syslog_transport"] = "RFC5424/UDP"
            event["syslog_received_at"] = datetime.now(timezone.utc).isoformat()
            event["syslog_peer"] = peer[0]
            event["syslog_priority"] = int(match[1])
            event["syslog_app"] = match[4]
            # Payload is already redacted at the emitter. Never store credentials.
            event = redact_syslog(event)
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            with SYSLOG_FILE.open("a", encoding="utf-8") as out:
                out.write(json.dumps(event, ensure_ascii=True) + "\n")
            SYSLOG_HEALTH["accepted"] += 1
            SYSLOG_HEALTH["last_received_at"] = event["syslog_received_at"]
            # BE alerts are evidence, never fresh HTTP requests (prevents feedback).
            if event.get("source") != "behaviour-monitor": process_event(event)
        except (ValueError, TypeError):
            SYSLOG_HEALTH["rejected"] += 1; continue
        except OSError as error:
            print(f"[BE] Syslog persistence failed: {error}; JSONL monitoring continues", flush=True)

def redact_syslog(value):
    if isinstance(value, dict):
        return {k: "[REDACTED]" if re.search(r"pass|secret|token|authorization|cookie", str(k), re.I)
                else redact_syslog(v) for k, v in value.items()}
    if isinstance(value, list): return [redact_syslog(v) for v in value]
    return value

def emit_behaviour_syslog(event):
    # The local collector persists actual received datagrams, not a relabelled file.
    if os.environ.get("DECOY_SYSLOG_ENABLED", "1") != "1": return
    message = "<134>1 " + datetime.now(timezone.utc).isoformat() + " decoyguard behaviour - - - " + json.dumps(redact_syslog(event), ensure_ascii=True)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.sendto(message.encode("utf-8"), ("127.0.0.1", SYSLOG_PORT))
    except OSError: pass

# ================================================================
# ATTACK SIGNATURES (WEB LAYER)
# ================================================================

WEB_SIGNATURES = {
    "SQL_INJECTION": [r"' OR '1'='1", r"'\s*OR\s*'1'\s*=\s*'1", r"UNION\s+SELECT", r"DROP\s+TABLE", r"SLEEP\s*\("],
    "DIRECTORY_TRAVERSAL": [r"\.\./\.\./", r"/etc/passwd", r"/etc/shadow", r"boot\.ini"],
    "XSS_ATTACK": [r"<script>", r"alert\(", r"onerror=", r"prompt\("],
    "SHELL_INJECTION": [r"; ls", r"&& whoami", r"\| wget", r"curl "],
    "RECON_SCANNER": [r"nmap", r"sqlmap", r"nikto", r"gobuster", r"dirbuster", r"masscan"],
}

# ================================================================
# IN-MEMORY PROFILES
# ================================================================

profiles = {}

def generate_incident_id():
    return f"BE-{uuid.uuid4().hex[:8].upper()}"

def create_profile(ip, site_id=""):

    return {
        "ip": ip,
        "site_id": site_id,
        "target_type": "production",
        "history": deque(maxlen=MAX_REQUEST_HISTORY),
        "alert_times": {},
        "last_status": 0,
        "last_uri_original": "",
        "last_request": "",
        "auth_times": deque(maxlen=MAX_REQUEST_HISTORY),
        "scanner_times": deque(maxlen=MAX_REQUEST_HISTORY),
        "failed_paths": set(),
        "failed_posts": 0,
        "first_seen": None,
        "last_seen": None,
        "total_requests": 0,
        "request_times": deque(maxlen=MAX_REQUEST_HISTORY),
        "uris": deque(maxlen=MAX_REQUEST_HISTORY),
        "unique_uris": set(),
        "methods": set(),
        "user_agents": set(),
        "status_codes": deque(maxlen=MAX_REQUEST_HISTORY),
        "failed_requests": 0,
        "post_requests": 0,
        "post_targets": {},
        "endpoint_changes": 0,
        "last_uri": None,
        "alerts": set(),
        "risk_score": 0,
        "last_alert_time": 0
    }

def cleanup_old_profiles():
    now = time.time()
    expired = [ip for ip, p in profiles.items() if p.get("last_seen") and (now - p["last_seen"] > PROFILE_TIMEOUT)]
    for ip in expired:
        del profiles[ip]

def safe_int(value, default=0):
    try:
        return int(value)
    except (ValueError, TypeError):
        return default

def normalize_uri(uri):
    if not uri:
        return "/"
    uri = str(uri).strip().split("?", 1)[0]
    uri = re.sub(r"/+", "/", uri)
    if uri != "/":
        uri = uri.rstrip("/")
    return uri.lower()

def extract_event(raw_event):
    return {
        "ip": str(raw_event.get("remote_addr") or raw_event.get("source_ip") or "UNKNOWN"),
        "timestamp": str(raw_event.get("timestamp") or ""),
        "peer_ip": str(raw_event.get("peer_ip") or raw_event.get("remote_addr") or ""),
        "client_ip_origin": str(raw_event.get("client_ip_origin") or "transport-peer"),
        "method": str(raw_event.get("method") or "UNKNOWN").upper(),
        "uri": normalize_uri((str(raw_event.get("request") or "").split(" ")[1]
            if len(str(raw_event.get("request") or "").split(" ")) >= 2 else raw_event.get("uri")) or "/"),
        "args": str(raw_event.get("args") or ""),
        "request": str(raw_event.get("request") or ""),
        "status": safe_int(raw_event.get("status"), 0),
        "user_agent": str(raw_event.get("user_agent") or raw_event.get("http_user_agent") or "Unknown"),
        "auth_attempt": isinstance(raw_event.get("fields"), dict) and any(k in raw_event["fields"] for k in ("password", "pass", "passwd")),
        "referer": str(raw_event.get("referer") or ""),
        "target_type": str(raw_event.get("target_type") or "production"),
        "monitoring_layer": "gateway" if raw_event.get("source") == "gateway-decision" else str(raw_event.get("target_type") or "production"),
        "entry_point": str(raw_event.get("entry_point") or ""),
        "source": str(raw_event.get("source") or ""),
        "site_id": str(raw_event.get("site_id") or ""),
        "detection_text": str(raw_event.get("detection_text") or ""),
        "event_id": str(raw_event.get("event_id") or raw_event.get("incident_id") or "")
    }

def update_profile(profile, event):
    now = time.time()
    if profile["last_seen"] is not None and now-profile["last_seen"] > 120:
        profile["alert_times"].clear()
    profile["last_seen"] = now
    if profile["first_seen"] is None:
        profile["first_seen"] = now

    if event["method"] == "POST" and event.get("auth_attempt"):
        profile["auth_times"].append(now)
    if re.search(r"nmap|nikto|masscan", event["user_agent"], re.I):
        profile["scanner_times"].append(now)
    profile["total_requests"] += 1
    profile["last_request"] = event["request"]
    profile["last_event_id"] = event["event_id"]
    profile["peer_ip"] = event["peer_ip"]
    profile["client_ip_origin"] = event["client_ip_origin"]
    profile["target_type"] = event["target_type"]
    profile["monitoring_layer"] = event["monitoring_layer"]
    profile["last_status"] = event["status"]
    profile["last_uri_original"] = event["uri"]
    profile["history"].append((now, event["uri"], event["method"], event["status"], event["user_agent"]))
    while profile["history"] and now-profile["history"][0][0] > BEHAVIOUR_WINDOW:
        profile["history"].popleft()
    # All detection counters refer to the recent window, not lifetime browsing.
    history = list(profile["history"])
    profile["request_times"] = deque((r[0] for r in history), maxlen=MAX_REQUEST_HISTORY)
    profile["uris"] = deque((r[1] for r in history), maxlen=MAX_REQUEST_HISTORY)
    profile["unique_uris"] = {r[1] for r in history}
    profile["methods"] = {r[2] for r in history}
    profile["user_agents"] = {r[4] for r in history}
    profile["status_codes"] = deque((r[3] for r in history), maxlen=MAX_REQUEST_HISTORY)
    failed = [r for r in history if r[3] in (403, 404)]
    profile["failed_requests"] = len(failed)
    profile["failed_paths"] = {r[1] for r in failed}
    profile["post_requests"] = sum(r[2] == "POST" for r in history)
    failed_posts = [r for r in history if r[2] == "POST" and r[3] in (401, 403)]
    profile["failed_posts"] = len(failed_posts)
    profile["post_targets"] = {}
    for r in failed_posts:
        profile["post_targets"][r[1]] = profile["post_targets"].get(r[1], 0)+1
    profile["last_uri"] = event["uri"]

# ================================================================
# DETECTION ENGINES
# ================================================================

def detect_signatures(event):
    """Detect specific exploit attempts hitting production endpoints."""

    raw_target = f"{event['uri']} {event['args']} {event['request']} {event['user_agent']} {event['detection_text']}"
    target_string = unquote_plus(raw_target)

    findings = []

    for category, patterns in WEB_SIGNATURES.items():
        for pattern in patterns:
            if category == "RECON_SCANNER": continue  # A tool name alone is not a behavioural finding.
            if re.search(pattern, target_string, re.IGNORECASE):
                findings.append({
                    "event_type": category,
                    "severity": "CRITICAL" if category in ["SQL_INJECTION", "SHELL_INJECTION"] else "HIGH",
                    "confidence": "HIGH",
                    "score": 85,
                    "details": f"Exploit pattern matched '{pattern}' on request: {event['request']}"
                })
                break

    return findings

def detect_request_burst(profile):
    now = time.time()
    recent = [t for t in profile["request_times"] if now - t <= BURST_WINDOW]
    if len(recent) >= BURST_THRESHOLD and (profile["failed_requests"] >= 3 or len(recent) >= 40):
        return {
            "event_type": "REQUEST_BURST",
            "severity": "HIGH",
            "confidence": "HIGH",
            "score": 35,
            "details": f"{len(recent)} requests detected within {BURST_WINDOW}s."
        }
    return None

def detect_repeated_post(profile):
    for uri, count in profile["post_targets"].items():
        if count >= POST_THRESHOLD:
            return {
                "event_type": "REPEATED_POST_ACTIVITY",
                "severity": "MEDIUM",
                "confidence": "HIGH",
                "score": 30,
                "details": f"{count} POST requests observed against: {uri} (Potential Brute Force)"
            }
    attempts = sum(time.time()-t <= BEHAVIOUR_WINDOW for t in profile["auth_times"])
    if attempts >= POST_THRESHOLD:
        return {"event_type":"REPEATED_POST_ACTIVITY", "severity":"MEDIUM", "confidence":"MEDIUM",
                "score":30, "details":f"{attempts} authentication POST attempts within {BEHAVIOUR_WINDOW}s; HTTP success does not establish login success or failure."}
    return None

def detect_endpoint_enumeration(profile):
    unique_count = len(profile["failed_paths"])
    if unique_count >= ENUMERATION_THRESHOLD:
        return {
            "event_type": "ENDPOINT_ENUMERATION",
            "severity": "HIGH",
            "confidence": "HIGH",
            "score": 40,
            "details": f"{unique_count} distinct missing/restricted endpoints probed by same IP."
        }
    return None

def detect_error_pattern(profile):
    recent_errors = sum(1 for status in profile["status_codes"] if 400 <= status <= 599)
    if recent_errors >= ERROR_THRESHOLD:
        return {
            "event_type": "REPEATED_HTTP_ERRORS",
            "severity": "MEDIUM",
            "confidence": "HIGH",
            "score": 25,
            "details": f"{recent_errors} HTTP 4xx/5xx responses observed; 5xx may indicate an unavailable upstream."
        }
    return None

def detect_escalation(profile):
    indicators = 0
    if profile["failed_posts"] >= POST_THRESHOLD:
        indicators += 1
    if len(profile["failed_paths"]) >= ENUMERATION_THRESHOLD:
        indicators += 1
    elif profile["failed_requests"] >= ERROR_THRESHOLD:
        indicators += 1
    if len(profile["user_agents"]) >= USER_AGENT_CHANGE_THRESHOLD:
        indicators += 1
    if detect_request_burst(profile):
        indicators += 1

    if indicators >= 3:
        return {
            "event_type": "BEHAVIOURAL_ESCALATION",
            "severity": "CRITICAL",
            "confidence": "VERY HIGH",
            "score": 80,
            "details": f"{indicators} separate attack indicators active simultaneously."
        }
    return None

def analyze_behaviour(profile):
    findings = []
    scanners = sum(time.time()-t <= BEHAVIOUR_WINDOW for t in profile["scanner_times"])
    if scanners >= 3:
        findings.append({"event_type":"ENDPOINT_ENUMERATION", "severity":"HIGH", "confidence":"HIGH", "score":40,
                         "details":f"Scanner probing process: {scanners} scanner-identified HTTP requests within {BEHAVIOUR_WINDOW}s; tool identity plus repeated activity."})
    detectors = [
        detect_request_burst,
        detect_repeated_post,
        detect_endpoint_enumeration,
        detect_error_pattern,
        detect_escalation
    ]
    for detector in detectors:
        res = detector(profile)
        if res:
            findings.append(res)
    # One scan finding per episode, with its observed patterns retained as evidence.
    scan_types = {"REQUEST_BURST", "ENDPOINT_ENUMERATION", "REPEATED_HTTP_ERRORS"}
    scans = [f for f in findings if f["event_type"] in scan_types]
    if scans:
        primary = next((f for f in scans if f["event_type"] == "ENDPOINT_ENUMERATION"), scans[0]).copy()
        primary["details"] = " | ".join(dict.fromkeys(f["details"] for f in scans))
        primary["episode_family"] = "scanner-activity"
        findings = [f for f in findings if f["event_type"] not in scan_types] + [primary]
    return findings

# ================================================================
# ALERT EXPORT
# ================================================================

def write_behaviour_event(profile, finding):
    os.makedirs(os.path.dirname(os.path.abspath(BEHAVIOUR_LOG)), exist_ok=True)
    target = profile["target_type"]
    decoy = target == "decoy"
    # Keep the existing core's production routing feed separate from decoy observation.
    gateway = profile.get("monitoring_layer") == "gateway"
    engine = "Behaviour Engine" if gateway else ("Honeypot Behaviour Engine" if decoy else ("Dashboard Security Engine" if target == "dashboard" else "Behaviour Engine"))
    incident = generate_incident_id()
    basis = "signature" if finding["event_type"] in WEB_SIGNATURES else "behavioural-pattern"
    score_engine = "signature" if basis == "signature" else "behaviour"
    event = {
        "source_event_id": profile.get("last_event_id", ""),
        "detection_basis": basis, "peer_ip": profile.get("peer_ip", ""),
        "client_ip_origin": profile.get("client_ip_origin", "transport-peer"),
        "engine": engine, "source": "behaviour-monitor",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime()),
        "incident_id": incident, "source_ip": profile["ip"], "site_id": profile["site_id"],
        "target_type": target, "request": profile["last_request"],
        "monitoring_layer": profile.get("monitoring_layer",target),
        "entry_target_type": "production" if gateway else target,
        "upstream_target_type": target,
        "uri": profile["last_uri_original"], "status": profile["last_status"],
        "decision": "CONTAINED" if decoy else "MONITOR",
        "route": "HONEYPOT" if decoy else ("DASHBOARD" if target == "dashboard" else "REAL_SERVER"),
        "recommended_action": "MONITOR_DECOY" if decoy else ("MONITOR" if target == "dashboard" else ("REQUEST_DECOY" if finding["score"] >= 40 else "MONITOR")),
        "event_type": finding["event_type"], "attack_type": finding["event_type"].replace("_", " "),
        "severity": finding["severity"], "confidence": finding["confidence"],
        "risk_score": finding["score"], "details": finding["details"],
        "attack_stage": "RECONNAISSANCE" if finding["event_type"] in {"RECON_SCANNER", "ENDPOINT_ENUMERATION"} else "SUSPICIOUS_ACTIVITY",
        "risk_breakdown": {score_engine: {"score":finding["score"], "findings":1}},
        "risk_calculation": [{"engine":engine,"score":finding["score"],"details":[finding["details"]]}],
        "forensics": {"target_port":"HTTP / " + ("protected gateway → " + target if gateway else target), "session_log":[{
            "time":time.strftime("%H:%M:%S",time.gmtime()),"text":profile["last_request"],
            "output":"HTTP " + str(profile["last_status"]) + "; " + finding["details"]}],"artifacts":[]},
        "profile_summary": {"total_requests":profile["total_requests"],"window_seconds":BEHAVIOUR_WINDOW,
            "unique_endpoints":len(profile["unique_uris"]),"post_requests":profile["post_requests"],"failed_errors":profile["failed_requests"]}
    }
    # One small append per finding; retain plain JSONL compatibility with the dashboard.
    with open(BEHAVIOUR_LOG,"a",encoding="utf-8") as f:
        f.write(json.dumps(event,ensure_ascii=True)+"\n")
    emit_behaviour_syslog(event)
    location = "gateway→" + target if gateway else target
    print(f"[BE/{location}] {incident} | {profile['site_id']} | {profile['ip']} | {finding['event_type']} ({finding['severity']})",flush=True)
    print("    " + finding["details"],flush=True)


def should_alert(profile, finding):
    alert_type = finding.get("episode_family", finding["event_type"])
    now = time.time()
    last = profile["alert_times"].get(alert_type)
    # Sliding inactivity window: a continuous scan is one incident, even past 60s.
    if alert_type == "scanner-activity":
        profile["alert_times"][alert_type] = now
        return last is None or now-last > 120
    if last is None or now-last >= 60:
        profile["alert_times"][alert_type] = now
        return True
    return False

# ================================================================
# LOG PROCESSING PIPELINE
# ================================================================

def process_event(raw_event):
    if not isinstance(raw_event, dict): return
    # The gateway logs the completed request with body evidence and actual destination.
    # Its decoy-side copy remains in raw telemetry, but must not be counted twice here.
    if raw_event.get("source") == "decoy-web" and raw_event.get("entry_point") == "gateway-decoy-copy": return
    event = extract_event(raw_event)
    # Unknown/protocol-level records do not establish a website identity.
    if event["target_type"] not in {"production", "decoy", "dashboard"}: return
    if event["ip"] == "UNKNOWN" or event["status"] == 0: return
    # Gateway and decoy capture share a request ID. Count the request just once.
    event_id = event["event_id"]
    key_id = (event["site_id"], event["monitoring_layer"], event_id)
    if event_id:
        if key_id in seen_events: return
        seen_events.add(key_id); seen_order.append(key_id)
        if len(seen_order)>8192: seen_events.discard(seen_order.popleft())
    signatures = detect_signatures(event)
    # Dashboard polling and successful frontend asset loads are not suspicious bursts.
    routine = event["status"] < 400 and (re.search(r"\.(?:js|mjs|css|png|jpe?g|svg|ico|woff2?|map)$",event["uri"],re.I)
        or event["uri"].startswith("/socket.io"))
    if not signatures and (routine or event["target_type"] == "dashboard"): return
    key = (event["site_id"], event["monitoring_layer"], event["ip"])
    if key not in profiles:
        if len(profiles) >= MAX_PROFILES:
            oldest = min(profiles, key=lambda k: profiles[k]["last_seen"] or 0)
            del profiles[oldest]
        profiles[key] = create_profile(event["ip"],event["site_id"])

    profile = profiles[key]
    update_profile(profile, event)

    # 3. Check for Web Exploit Signatures (SQLi, XSS, Nmap, Shells)
    for finding in signatures:
        if should_alert(profile, finding):
            write_behaviour_event(profile, finding)

    # 4. Check for Behavioral Anomalies (Bursts, Enumeration, Brute Force)
    for finding in ([] if event["target_type"] == "dashboard" else analyze_behaviour(profile)):
        if should_alert(profile, finding):
            write_behaviour_event(profile, finding)

# ================================================================
# MAIN MONITOR LOOP
# ================================================================

def _tail_anchor(stream):
    position = stream.tell()
    start = max(0,position-64)
    stream.seek(start); anchor = stream.read(position-start); stream.seek(position)
    return start,anchor


def monitor():
    paths = list(dict.fromkeys([NGINX_LOG, TELEMETRY_LOG]))
    receiver = open_syslog_receiver()
    readers = {}
    existing_at_start = {path for path in paths if os.path.exists(path)}
    attached_once = set()
    print("DecoyGuard Behaviour Engine: production + decoy telemetry",flush=True)
    if PRESENTATION_MODE: print("[PRESENTATION] Enumeration=4 failures; errors=3; burst=6/10s with failures; failed POSTs=3; cooldown=15s. Nmap-name alerts reduced.",flush=True)
    print("Monitoring: " + ", ".join(paths),flush=True)
    print("Alerts: " + BEHAVIOUR_LOG,flush=True)
    last_cleanup = time.time()
    last_health = 0
    try:
        while True:
            if receiver is not None: receive_syslog(receiver)
            for path in paths:
                try:
                    stat = os.stat(path)
                except FileNotFoundError:
                    old = readers.pop(path,None)
                    if old: old[0].close()
                    continue
                identity = (stat.st_dev, stat.st_ino)
                reader = readers.get(path)
                if reader is None or reader[1] != identity:
                    if reader: reader[0].close()
                    stream = open(path,"rb")
                    # Existing history is not replayed as a new attack burst on restart.
                    if reader is None and path in existing_at_start and path not in attached_once: stream.seek(0,os.SEEK_END)
                    attached_once.add(path)
                    reader = (stream,identity,*_tail_anchor(stream)); readers[path] = reader
                    print("[BE] Attached: " + path,flush=True)
                stream = reader[0]
                if stat.st_size < stream.tell(): stream.seek(0)
                elif reader[3]:
                    position = stream.tell(); stream.seek(reader[2])
                    unchanged = stream.read(len(reader[3])) == reader[3]
                    stream.seek(position if unchanged else 0)
                for _ in range(1000):
                    position = stream.tell(); line = stream.readline()
                    if not line: break
                    if not line.endswith(b"\n"):
                        stream.seek(position); break
                    try:
                        process_event(json.loads(line.decode("utf-8",errors="replace")))
                    except (json.JSONDecodeError,UnicodeError): continue
                    except Exception as error: print("[BE] Processing error: " + str(error),flush=True)
                readers[path] = (stream,identity,*_tail_anchor(stream))
            if time.time()-last_health >= 5:
                write_syslog_health(); last_health = time.time()
            if time.time()-last_cleanup >= 60:
                cleanup_old_profiles(); last_cleanup = time.time()
            time.sleep(POLL_INTERVAL)
    finally:
        if receiver is not None: receiver.close()
        SYSLOG_HEALTH["state"] = "stopped"; write_syslog_health()
        for stream, *_ in readers.values(): stream.close()


if __name__ == "__main__":
    try:
        monitor()
    except KeyboardInterrupt:
        print("\n[!] Stopping Behaviour Engine...")